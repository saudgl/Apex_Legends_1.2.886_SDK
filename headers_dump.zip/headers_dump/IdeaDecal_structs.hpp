#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct IdeaDecal.DecalBlock
// Size: 0x10 // Inherited bytes: 0x00
struct FDecalBlock {
	// Fields
	struct UMaterialInterface* DecalMaterial; // Offset: 0x00 // Size: 0x08
	struct UTexture* DecalTexure; // Offset: 0x08 // Size: 0x08
};

