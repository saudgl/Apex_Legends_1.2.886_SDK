#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UIParticle.UIParticle
// Size: 0x140 // Inherited bytes: 0x110
struct UUIParticle : UWidget {
	// Fields
	struct UUIParticleAsset* Asset; // Offset: 0x110 // Size: 0x08
	struct FMulticastInlineDelegate EventOnEnd; // Offset: 0x118 // Size: 0x10
	char bPlayParticle : 1; // Offset: 0x128 // Size: 0x01
	char pad_0x128_1 : 7; // Offset: 0x128 // Size: 0x01
	bool IsPlaying; // Offset: 0x129 // Size: 0x01
	char pad_0x12A[0x16]; // Offset: 0x12a // Size: 0x16

	// Functions

	// Object Name: Function UIParticle.UIParticle.StopEmit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopEmit(); // Offset: 0x101cbd10c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UIParticle.UIParticle.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x101cbd120 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UIParticle.UIParticle.SetPlayParticle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlayParticle(bool InPlayParticle); // Offset: 0x101cbd088 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UIParticle.UIParticle.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(); // Offset: 0x101cbd134 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UIParticle.UIParticleAsset
// Size: 0x40 // Inherited bytes: 0x28
struct UUIParticleAsset : UObject {
	// Fields
	bool AutoPlay; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct TArray<struct FUIParticleEmitterInfo> Emitters; // Offset: 0x30 // Size: 0x10
};

// Object Name: Class UIParticle.UIParticleEmitter
// Size: 0x140 // Inherited bytes: 0x110
struct UUIParticleEmitter : UWidget {
	// Fields
	struct UUIParticleEmitterAsset* Asset; // Offset: 0x110 // Size: 0x08
	struct FMulticastInlineDelegate EventOnEnd; // Offset: 0x118 // Size: 0x10
	char bPlayParticle : 1; // Offset: 0x128 // Size: 0x01
	char pad_0x128_1 : 7; // Offset: 0x128 // Size: 0x01
	bool IsPlaying; // Offset: 0x129 // Size: 0x01
	char pad_0x12A[0x16]; // Offset: 0x12a // Size: 0x16

	// Functions

	// Object Name: Function UIParticle.UIParticleEmitter.StopEmit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopEmit(); // Offset: 0x101cbd8c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UIParticle.UIParticleEmitter.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x101cbd8d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UIParticle.UIParticleEmitter.SetPlayParticle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlayParticle(bool InPlayParticle); // Offset: 0x101cbd840 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UIParticle.UIParticleEmitter.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(); // Offset: 0x101cbd8ec // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UIParticle.UIParticleEmitterAsset
// Size: 0xd640 // Inherited bytes: 0x28
struct UUIParticleEmitterAsset : UObject {
	// Fields
	bool AutoPlay; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	float StartTimeOffset; // Offset: 0x2c // Size: 0x04
	int32_t SamplingTimes; // Offset: 0x30 // Size: 0x04
	enum class EEmitterType EmitterType; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	float EmitSeconds; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FUIParticleProperty MaxParticleCount; // Offset: 0x40 // Size: 0x7e8
	struct FUIParticleProperty SpawnParticlePerSecond; // Offset: 0x828 // Size: 0x7e8
	struct FUIParticleProperty ParticleEmitAngle; // Offset: 0x1010 // Size: 0x7e8
	struct FRange_Vector2D EmitPosRange; // Offset: 0x17f8 // Size: 0x14
	char pad_0x180C[0x4]; // Offset: 0x180c // Size: 0x04
	struct FPosotion_Vector2DCurve EmitPosition; // Offset: 0x1810 // Size: 0xfd0
	bool AutoEmitPosRange; // Offset: 0x27e0 // Size: 0x01
	bool AutoScale; // Offset: 0x27e1 // Size: 0x01
	bool ScaleByX; // Offset: 0x27e2 // Size: 0x01
	char pad_0x27E3[0x1]; // Offset: 0x27e3 // Size: 0x01
	struct FVector2D DesignSize; // Offset: 0x27e4 // Size: 0x08
	bool EmitAngleByWidgetAngle; // Offset: 0x27ec // Size: 0x01
	enum class EPositionType PositionType; // Offset: 0x27ed // Size: 0x01
	char pad_0x27EE[0x2]; // Offset: 0x27ee // Size: 0x02
	struct FUIParticleProperty LifeSpan; // Offset: 0x27f0 // Size: 0x7e8
	struct FUIParticleProperty Size; // Offset: 0x2fd8 // Size: 0x7e8
	struct FUIParticleProperty Pivot; // Offset: 0x37c0 // Size: 0x7e8
	struct FUIParticleProperty RotationStart; // Offset: 0x3fa8 // Size: 0x7e8
	struct FUIParticleProperty RotationSpeed; // Offset: 0x4790 // Size: 0x7e8
	struct FUIParticleProperty Color; // Offset: 0x4f78 // Size: 0x7e8
	struct UObject* ResourceObject; // Offset: 0x5760 // Size: 0x08
	bool RotationFollowSpeed; // Offset: 0x5768 // Size: 0x01
	bool UseSeparateSize; // Offset: 0x5769 // Size: 0x01
	char pad_0x576A[0x6]; // Offset: 0x576a // Size: 0x06
	struct FUIParticleProperty Gravity; // Offset: 0x5770 // Size: 0x7e8
	struct FUIParticleProperty StartSpeed; // Offset: 0x5f58 // Size: 0x7e8
	struct FUIParticleProperty AirResistance; // Offset: 0x6740 // Size: 0x7e8
	struct FUIParticleProperty RadialAcceleration; // Offset: 0x6f28 // Size: 0x7e8
	struct FUIParticleProperty TangentialAcceleration; // Offset: 0x7710 // Size: 0x7e8
	struct FUIParticleProperty Radius; // Offset: 0x7ef8 // Size: 0x7e8
	struct FUIParticleProperty DegreePerSecond; // Offset: 0x86e0 // Size: 0x7e8
	struct FUIParticleProperty PositionX; // Offset: 0x8ec8 // Size: 0x7e8
	struct FUIParticleProperty PositionY; // Offset: 0x96b0 // Size: 0x7e8
	struct TArray<struct FChildEmitter> ChildrenEmitters; // Offset: 0x9e98 // Size: 0x10
	struct TArray<struct FScalarParamCurve> ScalarParams; // Offset: 0x9ea8 // Size: 0x10
	struct TArray<struct FScalarParamCurve> ScalarParamsWhenStart; // Offset: 0x9eb8 // Size: 0x10
	enum class EParticleDrawEffect DrawEffect; // Offset: 0x9ec8 // Size: 0x01
	bool UseScaleFollowSpeedDirection; // Offset: 0x9ec9 // Size: 0x01
	char pad_0x9ECA[0x6]; // Offset: 0x9eca // Size: 0x06
	struct FUIParticleProperty ScaleFollowSpeedDirection; // Offset: 0x9ed0 // Size: 0x7e8
	bool UseScaleFollowSpeedVertical; // Offset: 0xa6b8 // Size: 0x01
	char pad_0xA6B9[0x7]; // Offset: 0xa6b9 // Size: 0x07
	struct FUIParticleProperty ScaleFollowSpeedVertical; // Offset: 0xa6c0 // Size: 0x7e8
	struct FUIParticleProperty DirectionScale; // Offset: 0xaea8 // Size: 0x7e8
	struct FUIParticleProperty VerticalDirectionScale; // Offset: 0xb690 // Size: 0x7e8
	struct FUIParticleProperty SineDirectionStart; // Offset: 0xbe78 // Size: 0x7e8
	struct FUIParticleProperty SineDirectionSpeed; // Offset: 0xc660 // Size: 0x7e8
	struct FUIParticleProperty SineDirectionRange; // Offset: 0xce48 // Size: 0x7e8
	struct TArray<struct UUIParticleEmitterAsset*> LevelOfDetail; // Offset: 0xd630 // Size: 0x10
};

// Object Name: Class UIParticle.UIParticleUtility
// Size: 0x28 // Inherited bytes: 0x28
struct UUIParticleUtility : UObject {
	// Functions

	// Object Name: Function UIParticle.UIParticleUtility.SetMultiThread
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMultiThread(bool Value); // Offset: 0x101cbf05c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UIParticle.UIParticleUtility.SetLOD
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetLOD(int32_t newlod); // Offset: 0x101cbf10c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UIParticle.UIParticleUtility.GetMultiThread
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetMultiThread(); // Offset: 0x101cbf028 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UIParticle.UIParticleUtility.GetLOD
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetLOD(); // Offset: 0x101cbf0d8 // Return & Params: Num(1) Size(0x4)
};

