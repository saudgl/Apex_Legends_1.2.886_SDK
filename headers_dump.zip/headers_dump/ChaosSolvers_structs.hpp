#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ChaosSolvers.SolverBreakingFilterSettings
// Size: 0x10 // Inherited bytes: 0x00
struct FSolverBreakingFilterSettings {
	// Fields
	bool FilterEnabled; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float MinMass; // Offset: 0x04 // Size: 0x04
	float MinSpeed; // Offset: 0x08 // Size: 0x04
	float MinVolume; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ChaosSolvers.SolverCollisionFilterSettings
// Size: 0x10 // Inherited bytes: 0x00
struct FSolverCollisionFilterSettings {
	// Fields
	bool FilterEnabled; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float MinMass; // Offset: 0x04 // Size: 0x04
	float MinSpeed; // Offset: 0x08 // Size: 0x04
	float MinImpulse; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ChaosSolvers.SolverTrailingFilterSettings
// Size: 0x10 // Inherited bytes: 0x00
struct FSolverTrailingFilterSettings {
	// Fields
	bool FilterEnabled; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float MinMass; // Offset: 0x04 // Size: 0x04
	float MinSpeed; // Offset: 0x08 // Size: 0x04
	float MinVolume; // Offset: 0x0c // Size: 0x04
};

