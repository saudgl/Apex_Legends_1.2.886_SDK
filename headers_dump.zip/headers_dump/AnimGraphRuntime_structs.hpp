#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_SkeletalControlBase
// Size: 0xf8 // Inherited bytes: 0x20
struct FAnimNode_SkeletalControlBase : FAnimNode_Base {
	// Fields
	struct FComponentSpacePoseLink ComponentPose; // Offset: 0x20 // Size: 0x10
	int32_t LODThreshold; // Offset: 0x30 // Size: 0x04
	float ActualAlpha; // Offset: 0x34 // Size: 0x04
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0x38 // Size: 0x01
	bool bAlphaBoolEnabled; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x2]; // Offset: 0x3a // Size: 0x02
	float Alpha; // Offset: 0x3c // Size: 0x04
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x40 // Size: 0x08
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x48 // Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x90 // Size: 0x08
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0x98 // Size: 0x30
	char pad_0xC8[0x30]; // Offset: 0xc8 // Size: 0x30
};

// Object Name: ScriptStruct AnimGraphRuntime.BoneSocketTarget
// Size: 0x60 // Inherited bytes: 0x00
struct FBoneSocketTarget {
	// Fields
	bool bUseSocket; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FBoneReference BoneReference; // Offset: 0x04 // Size: 0x10
	char pad_0x14[0xc]; // Offset: 0x14 // Size: 0x0c
	struct FSocketReference SocketReference; // Offset: 0x20 // Size: 0x40
};

// Object Name: ScriptStruct AnimGraphRuntime.SocketReference
// Size: 0x40 // Inherited bytes: 0x00
struct FSocketReference {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
	struct FName SocketName; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_LayeredBoneBlend
// Size: 0x1c0 // Inherited bytes: 0x20
struct FAnimNode_LayeredBoneBlend : FAnimNode_Base {
	// Fields
	struct FName NodeName; // Offset: 0x1c // Size: 0x08
	struct FPoseLink BasePose; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FPoseLink> BlendPoses; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FInputBlendPose> LayerSetup; // Offset: 0x48 // Size: 0x10
	bool bEnableDynamicLayerSetup; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	struct FName UsedLayerSetupName; // Offset: 0x5c // Size: 0x08
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TMap<struct FName, struct FInputLayerSetup> DynamicLayerSetupPreset; // Offset: 0x68 // Size: 0x50
	struct TArray<float> BlendWeights; // Offset: 0xb8 // Size: 0x10
	bool bMeshSpaceRotationBlend; // Offset: 0xc8 // Size: 0x01
	bool bMeshSpaceScaleBlend; // Offset: 0xc9 // Size: 0x01
	enum class ECurveBlendOption CurveBlendOption; // Offset: 0xca // Size: 0x01
	bool bBlendRootMotionBasedOnRootBone; // Offset: 0xcb // Size: 0x01
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
	int32_t LODThreshold; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct TArray<struct FPerBoneBlendWeight> PerBoneBlendWeights; // Offset: 0xd8 // Size: 0x10
	struct FGuid SkeletonGuid; // Offset: 0xe8 // Size: 0x10
	struct FGuid VirtualBoneGuid; // Offset: 0xf8 // Size: 0x10
	struct FName CurUsedLayerSetupName; // Offset: 0x108 // Size: 0x08
	struct TMap<struct FName, struct FName> LayerSetupPresetMapping; // Offset: 0x110 // Size: 0x50
	char pad_0x160[0x60]; // Offset: 0x160 // Size: 0x60
};

// Object Name: ScriptStruct AnimGraphRuntime.InputLayerSetup
// Size: 0x10 // Inherited bytes: 0x00
struct FInputLayerSetup {
	// Fields
	struct TArray<struct FInputBlendPose> LayerSetup; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayer
// Size: 0x3e8 // Inherited bytes: 0x40
struct FAnimNode_BlendSpacePlayer : FAnimNode_AssetPlayerBase {
	// Fields
	float X; // Offset: 0x3c // Size: 0x04
	float Y; // Offset: 0x40 // Size: 0x04
	float Z; // Offset: 0x44 // Size: 0x04
	float PlayRate; // Offset: 0x48 // Size: 0x04
	bool bLoop; // Offset: 0x4c // Size: 0x01
	bool bResetPlayTimeWhenBlendSpaceChanges; // Offset: 0x4d // Size: 0x01
	float StartPosition; // Offset: 0x50 // Size: 0x04
	char pad_0x56[0x2]; // Offset: 0x56 // Size: 0x02
	struct UBlendSpaceBase* BlendSpace; // Offset: 0x58 // Size: 0x08
	bool ApplyOrientationWarpingForEachSample; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x7]; // Offset: 0x61 // Size: 0x07
	struct FOrientationWarpingAngleConfig OrientationWarpingAngles; // Offset: 0x68 // Size: 0x10
	struct TArray<struct FOrientationWarpingSpineConfig> OrientationWarpingSpine; // Offset: 0x78 // Size: 0x10
	enum class EAxis RootYawRotationAxis; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x8f]; // Offset: 0x89 // Size: 0x8f
	struct UBlendSpaceBase* PreviousBlendSpace; // Offset: 0x118 // Size: 0x08
	enum class EBlendCrossFadeOption FadeStyle; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x3]; // Offset: 0x121 // Size: 0x03
	float BlendFadeTime; // Offset: 0x124 // Size: 0x04
	enum class EAlphaBlendOption BlendType; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x7]; // Offset: 0x129 // Size: 0x07
	struct UCurveFloat* CustomBlendCurve; // Offset: 0x130 // Size: 0x08
	char pad_0x138[0x8]; // Offset: 0x138 // Size: 0x08
	struct UBlendSpaceBase* FromBlendSpace; // Offset: 0x140 // Size: 0x08
	struct UBlendSpaceBase* ToBlendSpace; // Offset: 0x148 // Size: 0x08
	char pad_0x150[0x298]; // Offset: 0x150 // Size: 0x298
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_AimOffsetLookAt
// Size: 0x4c0 // Inherited bytes: 0x3e8
struct FAnimNode_AimOffsetLookAt : FAnimNode_BlendSpacePlayer {
	// Fields
	char pad_0x3E8[0x68]; // Offset: 0x3e8 // Size: 0x68
	struct FPoseLink BasePose; // Offset: 0x450 // Size: 0x10
	int32_t LODThreshold; // Offset: 0x460 // Size: 0x04
	struct FName SourceSocketName; // Offset: 0x464 // Size: 0x08
	struct FName PivotSocketName; // Offset: 0x46c // Size: 0x08
	struct FVector LookAtLocation; // Offset: 0x474 // Size: 0x0c
	struct FVector SocketAxis; // Offset: 0x480 // Size: 0x0c
	float Alpha; // Offset: 0x48c // Size: 0x04
	char pad_0x490[0x30]; // Offset: 0x490 // Size: 0x30
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_AnimDynamics
// Size: 0x470 // Inherited bytes: 0xf8
struct FAnimNode_AnimDynamics : FAnimNode_SkeletalControlBase {
	// Fields
	float LinearDampingOverride; // Offset: 0xf8 // Size: 0x04
	float AngularDampingOverride; // Offset: 0xfc // Size: 0x04
	char pad_0x100[0x60]; // Offset: 0x100 // Size: 0x60
	struct FBoneReference RelativeSpaceBone; // Offset: 0x160 // Size: 0x10
	struct FBoneReference BoundBone; // Offset: 0x170 // Size: 0x10
	struct FBoneReference ChainEnd; // Offset: 0x180 // Size: 0x10
	struct FVector BoxExtents; // Offset: 0x190 // Size: 0x0c
	struct FVector LocalJointOffset; // Offset: 0x19c // Size: 0x0c
	float GravityScale; // Offset: 0x1a8 // Size: 0x04
	struct FVector GravityOverride; // Offset: 0x1ac // Size: 0x0c
	float LinearSpringConstant; // Offset: 0x1b8 // Size: 0x04
	float AngularSpringConstant; // Offset: 0x1bc // Size: 0x04
	float WindScale; // Offset: 0x1c0 // Size: 0x04
	struct FVector ComponentLinearAccScale; // Offset: 0x1c4 // Size: 0x0c
	struct FVector ComponentLinearVelScale; // Offset: 0x1d0 // Size: 0x0c
	struct FVector ComponentAppliedLinearAccClamp; // Offset: 0x1dc // Size: 0x0c
	float AngularBiasOverride; // Offset: 0x1e8 // Size: 0x04
	int32_t NumSolverIterationsPreUpdate; // Offset: 0x1ec // Size: 0x04
	int32_t NumSolverIterationsPostUpdate; // Offset: 0x1f0 // Size: 0x04
	struct FAnimPhysConstraintSetup ConstraintSetup; // Offset: 0x1f4 // Size: 0x48
	char pad_0x23C[0x4]; // Offset: 0x23c // Size: 0x04
	struct TArray<struct FAnimPhysSphericalLimit> SphericalLimits; // Offset: 0x240 // Size: 0x10
	float SphereCollisionRadius; // Offset: 0x250 // Size: 0x04
	struct FVector ExternalForce; // Offset: 0x254 // Size: 0x0c
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits; // Offset: 0x260 // Size: 0x10
	enum class AnimPhysCollisionType CollisionType; // Offset: 0x270 // Size: 0x01
	enum class AnimPhysSimSpaceType SimulationSpace; // Offset: 0x271 // Size: 0x01
	char pad_0x272[0x2]; // Offset: 0x272 // Size: 0x02
	char bUseSphericalLimits : 1; // Offset: 0x274 // Size: 0x01
	char bUsePlanarLimit : 1; // Offset: 0x274 // Size: 0x01
	char bDoUpdate : 1; // Offset: 0x274 // Size: 0x01
	char bDoEval : 1; // Offset: 0x274 // Size: 0x01
	char bOverrideLinearDamping : 1; // Offset: 0x274 // Size: 0x01
	char bOverrideAngularBias : 1; // Offset: 0x274 // Size: 0x01
	char bOverrideAngularDamping : 1; // Offset: 0x274 // Size: 0x01
	char bEnableWind : 1; // Offset: 0x274 // Size: 0x01
	char pad_0x275_0 : 1; // Offset: 0x275 // Size: 0x01
	char bUseGravityOverride : 1; // Offset: 0x275 // Size: 0x01
	char bLinearSpring : 1; // Offset: 0x275 // Size: 0x01
	char bAngularSpring : 1; // Offset: 0x275 // Size: 0x01
	char bChain : 1; // Offset: 0x275 // Size: 0x01
	char pad_0x275_5 : 3; // Offset: 0x275 // Size: 0x01
	char pad_0x276[0xa]; // Offset: 0x276 // Size: 0x0a
	struct FRotationRetargetingInfo RetargetingSettings; // Offset: 0x280 // Size: 0x130
	char pad_0x3B0[0xc0]; // Offset: 0x3b0 // Size: 0xc0
};

// Object Name: ScriptStruct AnimGraphRuntime.RotationRetargetingInfo
// Size: 0x130 // Inherited bytes: 0x00
struct FRotationRetargetingInfo {
	// Fields
	bool bEnabled; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0xf]; // Offset: 0x01 // Size: 0x0f
	struct FTransform Source; // Offset: 0x10 // Size: 0x30
	struct FTransform Target; // Offset: 0x40 // Size: 0x30
	enum class ERotationComponent RotationComponent; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x3]; // Offset: 0x71 // Size: 0x03
	struct FVector TwistAxis; // Offset: 0x74 // Size: 0x0c
	bool bUseAbsoluteAngle; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x3]; // Offset: 0x81 // Size: 0x03
	float SourceMinimum; // Offset: 0x84 // Size: 0x04
	float SourceMaximum; // Offset: 0x88 // Size: 0x04
	float TargetMinimum; // Offset: 0x8c // Size: 0x04
	float TargetMaximum; // Offset: 0x90 // Size: 0x04
	enum class EEasingFuncType EasingType; // Offset: 0x94 // Size: 0x01
	char pad_0x95[0x3]; // Offset: 0x95 // Size: 0x03
	struct FRuntimeFloatCurve CustomCurve; // Offset: 0x98 // Size: 0x88
	bool bFlipEasing; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x3]; // Offset: 0x121 // Size: 0x03
	float EasingWeight; // Offset: 0x124 // Size: 0x04
	bool bClamp; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x7]; // Offset: 0x129 // Size: 0x07
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimPhysPlanarLimit
// Size: 0x40 // Inherited bytes: 0x00
struct FAnimPhysPlanarLimit {
	// Fields
	struct FBoneReference DrivingBone; // Offset: 0x00 // Size: 0x10
	struct FTransform PlaneTransform; // Offset: 0x10 // Size: 0x30
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimPhysSphericalLimit
// Size: 0x24 // Inherited bytes: 0x00
struct FAnimPhysSphericalLimit {
	// Fields
	struct FBoneReference DrivingBone; // Offset: 0x00 // Size: 0x10
	struct FVector SphereLocalOffset; // Offset: 0x10 // Size: 0x0c
	float LimitRadius; // Offset: 0x1c // Size: 0x04
	enum class ESphericalLimitType LimitType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimPhysConstraintSetup
// Size: 0x48 // Inherited bytes: 0x00
struct FAnimPhysConstraintSetup {
	// Fields
	enum class AnimPhysLinearConstraintType LinearXLimitType; // Offset: 0x00 // Size: 0x01
	enum class AnimPhysLinearConstraintType LinearYLimitType; // Offset: 0x01 // Size: 0x01
	enum class AnimPhysLinearConstraintType LinearZLimitType; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	struct FVector LinearAxesMin; // Offset: 0x04 // Size: 0x0c
	struct FVector LinearAxesMax; // Offset: 0x10 // Size: 0x0c
	enum class AnimPhysAngularConstraintType AngularConstraintType; // Offset: 0x1c // Size: 0x01
	enum class AnimPhysTwistAxis TwistAxis; // Offset: 0x1d // Size: 0x01
	enum class AnimPhysTwistAxis AngularTargetAxis; // Offset: 0x1e // Size: 0x01
	char pad_0x1F[0x1]; // Offset: 0x1f // Size: 0x01
	float ConeAngle; // Offset: 0x20 // Size: 0x04
	struct FVector AngularLimitsMin; // Offset: 0x24 // Size: 0x0c
	struct FVector AngularLimitsMax; // Offset: 0x30 // Size: 0x0c
	struct FVector AngularTarget; // Offset: 0x3c // Size: 0x0c
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_ApplyAdditive
// Size: 0xd8 // Inherited bytes: 0x20
struct FAnimNode_ApplyAdditive : FAnimNode_Base {
	// Fields
	struct FPoseLink Base; // Offset: 0x20 // Size: 0x10
	struct FPoseLink Additive; // Offset: 0x30 // Size: 0x10
	float Alpha; // Offset: 0x40 // Size: 0x04
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x44 // Size: 0x08
	int32_t LODThreshold; // Offset: 0x4c // Size: 0x04
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x50 // Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x98 // Size: 0x08
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0xa0 // Size: 0x30
	char pad_0xD0[0x4]; // Offset: 0xd0 // Size: 0x04
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0xd4 // Size: 0x01
	bool bAlphaBoolEnabled; // Offset: 0xd5 // Size: 0x01
	char pad_0xD6[0x2]; // Offset: 0xd6 // Size: 0x02
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_ApplyLimits
// Size: 0x118 // Inherited bytes: 0xf8
struct FAnimNode_ApplyLimits : FAnimNode_SkeletalControlBase {
	// Fields
	struct TArray<struct FAngularRangeLimit> AngularRangeLimits; // Offset: 0xf8 // Size: 0x10
	struct TArray<struct FVector> AngularOffsets; // Offset: 0x108 // Size: 0x10
};

// Object Name: ScriptStruct AnimGraphRuntime.AngularRangeLimit
// Size: 0x28 // Inherited bytes: 0x00
struct FAngularRangeLimit {
	// Fields
	struct FVector LimitMin; // Offset: 0x00 // Size: 0x0c
	struct FVector LimitMax; // Offset: 0x0c // Size: 0x0c
	struct FBoneReference Bone; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_BlendBoneByChannel
// Size: 0x78 // Inherited bytes: 0x20
struct FAnimNode_BlendBoneByChannel : FAnimNode_Base {
	// Fields
	struct FPoseLink A; // Offset: 0x20 // Size: 0x10
	struct FPoseLink B; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FBlendBoneByChannelEntry> BoneDefinitions; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10
	float Alpha; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x68 // Size: 0x08
	enum class EBoneControlSpace TransformsSpace; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x7]; // Offset: 0x71 // Size: 0x07
};

// Object Name: ScriptStruct AnimGraphRuntime.BlendBoneByChannelEntry
// Size: 0x24 // Inherited bytes: 0x00
struct FBlendBoneByChannelEntry {
	// Fields
	struct FBoneReference SourceBone; // Offset: 0x00 // Size: 0x10
	struct FBoneReference TargetBone; // Offset: 0x10 // Size: 0x10
	bool bBlendTranslation; // Offset: 0x20 // Size: 0x01
	bool bBlendRotation; // Offset: 0x21 // Size: 0x01
	bool bBlendScale; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x1]; // Offset: 0x23 // Size: 0x01
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_BlendListBase
// Size: 0xb8 // Inherited bytes: 0x20
struct FAnimNode_BlendListBase : FAnimNode_Base {
	// Fields
	struct TArray<struct FPoseLink> BlendPose; // Offset: 0x20 // Size: 0x10
	struct TArray<float> BlendTime; // Offset: 0x30 // Size: 0x10
	enum class EBlendListTransitionType TransitionType; // Offset: 0x40 // Size: 0x01
	enum class EAlphaBlendOption BlendType; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x2]; // Offset: 0x42 // Size: 0x02
	struct FName BlendProfileName; // Offset: 0x44 // Size: 0x08
	bool bResetChildOnActivation; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0xb]; // Offset: 0x4d // Size: 0x0b
	struct UCurveFloat* CustomBlendCurve; // Offset: 0x58 // Size: 0x08
	struct UBlendProfile* BlendProfile; // Offset: 0x60 // Size: 0x08
	char pad_0x68[0x50]; // Offset: 0x68 // Size: 0x50
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByBool
// Size: 0xc0 // Inherited bytes: 0xb8
struct FAnimNode_BlendListByBool : FAnimNode_BlendListBase {
	// Fields
	bool bActiveValue; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x7]; // Offset: 0xb9 // Size: 0x07
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByEnum
// Size: 0xd0 // Inherited bytes: 0xb8
struct FAnimNode_BlendListByEnum : FAnimNode_BlendListBase {
	// Fields
	struct TArray<int32_t> EnumToPoseIndex; // Offset: 0xb8 // Size: 0x10
	char ActiveEnumValue; // Offset: 0xc8 // Size: 0x01
	char pad_0xC9[0x7]; // Offset: 0xc9 // Size: 0x07
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByInt
// Size: 0xc0 // Inherited bytes: 0xb8
struct FAnimNode_BlendListByInt : FAnimNode_BlendListBase {
	// Fields
	int32_t ActiveChildIndex; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceEvaluator
// Size: 0x3f0 // Inherited bytes: 0x3e8
struct FAnimNode_BlendSpaceEvaluator : FAnimNode_BlendSpacePlayer {
	// Fields
	float NormalizedTime; // Offset: 0x3e8 // Size: 0x04
	char pad_0x3EC[0x4]; // Offset: 0x3ec // Size: 0x04
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_BoneDrivenController
// Size: 0x148 // Inherited bytes: 0xf8
struct FAnimNode_BoneDrivenController : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference SourceBone; // Offset: 0xf8 // Size: 0x10
	struct UCurveFloat* DrivingCurve; // Offset: 0x108 // Size: 0x08
	float Multiplier; // Offset: 0x110 // Size: 0x04
	float RangeMin; // Offset: 0x114 // Size: 0x04
	float RangeMax; // Offset: 0x118 // Size: 0x04
	float RemappedMin; // Offset: 0x11c // Size: 0x04
	float RemappedMax; // Offset: 0x120 // Size: 0x04
	struct FName ParameterName; // Offset: 0x124 // Size: 0x08
	struct FBoneReference TargetBone; // Offset: 0x12c // Size: 0x10
	enum class EDrivenDestinationMode DestinationMode; // Offset: 0x13c // Size: 0x01
	enum class EDrivenBoneModificationMode ModificationMode; // Offset: 0x13d // Size: 0x01
	enum class EComponentType SourceComponent; // Offset: 0x13e // Size: 0x01
	char bUseRange : 1; // Offset: 0x13f // Size: 0x01
	char bAffectTargetTranslationX : 1; // Offset: 0x13f // Size: 0x01
	char bAffectTargetTranslationY : 1; // Offset: 0x13f // Size: 0x01
	char bAffectTargetTranslationZ : 1; // Offset: 0x13f // Size: 0x01
	char bAffectTargetRotationX : 1; // Offset: 0x13f // Size: 0x01
	char bAffectTargetRotationY : 1; // Offset: 0x13f // Size: 0x01
	char bAffectTargetRotationZ : 1; // Offset: 0x13f // Size: 0x01
	char bAffectTargetScaleX : 1; // Offset: 0x13f // Size: 0x01
	char bAffectTargetScaleY : 1; // Offset: 0x140 // Size: 0x01
	char bAffectTargetScaleZ : 1; // Offset: 0x140 // Size: 0x01
	char pad_0x140_2 : 6; // Offset: 0x140 // Size: 0x01
	char pad_0x141[0x7]; // Offset: 0x141 // Size: 0x07
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_CCDIK
// Size: 0x1b0 // Inherited bytes: 0xf8
struct FAnimNode_CCDIK : FAnimNode_SkeletalControlBase {
	// Fields
	struct FVector EffectorLocation; // Offset: 0xf8 // Size: 0x0c
	enum class EBoneControlSpace EffectorLocationSpace; // Offset: 0x104 // Size: 0x01
	char pad_0x105[0xb]; // Offset: 0x105 // Size: 0x0b
	struct FBoneSocketTarget EffectorTarget; // Offset: 0x110 // Size: 0x60
	struct FBoneReference TipBone; // Offset: 0x170 // Size: 0x10
	struct FBoneReference RootBone; // Offset: 0x180 // Size: 0x10
	float Precision; // Offset: 0x190 // Size: 0x04
	int32_t MaxIterations; // Offset: 0x194 // Size: 0x04
	bool bStartFromTail; // Offset: 0x198 // Size: 0x01
	bool bEnableRotationLimit; // Offset: 0x199 // Size: 0x01
	char pad_0x19A[0x6]; // Offset: 0x19a // Size: 0x06
	struct TArray<float> RotationLimitPerJoints; // Offset: 0x1a0 // Size: 0x10
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_Constraint
// Size: 0x138 // Inherited bytes: 0xf8
struct FAnimNode_Constraint : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference BoneToModify; // Offset: 0xf8 // Size: 0x10
	struct TArray<struct FConstraint> ConstraintSetup; // Offset: 0x108 // Size: 0x10
	struct TArray<float> ConstraintWeights; // Offset: 0x118 // Size: 0x10
	char pad_0x128[0x10]; // Offset: 0x128 // Size: 0x10
};

// Object Name: ScriptStruct AnimGraphRuntime.Constraint
// Size: 0x1c // Inherited bytes: 0x00
struct FConstraint {
	// Fields
	struct FBoneReference TargetBone; // Offset: 0x00 // Size: 0x10
	enum class EConstraintOffsetOption OffsetOption; // Offset: 0x10 // Size: 0x01
	enum class ETransformConstraintType TransformType; // Offset: 0x11 // Size: 0x01
	struct FFilterOptionPerAxis PerAxis; // Offset: 0x12 // Size: 0x03
	char pad_0x15[0x7]; // Offset: 0x15 // Size: 0x07
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_CopyBone
// Size: 0x120 // Inherited bytes: 0xf8
struct FAnimNode_CopyBone : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference SourceBone; // Offset: 0xf8 // Size: 0x10
	struct FBoneReference TargetBone; // Offset: 0x108 // Size: 0x10
	bool bCopyTranslation; // Offset: 0x118 // Size: 0x01
	bool bCopyRotation; // Offset: 0x119 // Size: 0x01
	bool bCopyScale; // Offset: 0x11a // Size: 0x01
	enum class EBoneControlSpace ControlSpace; // Offset: 0x11b // Size: 0x01
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_CopyBoneDelta
// Size: 0x128 // Inherited bytes: 0xf8
struct FAnimNode_CopyBoneDelta : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference SourceBone; // Offset: 0xf8 // Size: 0x10
	struct FBoneReference TargetBone; // Offset: 0x108 // Size: 0x10
	bool bCopyTranslation; // Offset: 0x118 // Size: 0x01
	bool bCopyRotation; // Offset: 0x119 // Size: 0x01
	bool bCopyScale; // Offset: 0x11a // Size: 0x01
	enum class CopyBoneDeltaMode CopyMode; // Offset: 0x11b // Size: 0x01
	float TranslationMultiplier; // Offset: 0x11c // Size: 0x04
	float RotationMultiplier; // Offset: 0x120 // Size: 0x04
	float ScaleMultiplier; // Offset: 0x124 // Size: 0x04
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_CopyPoseFromMesh
// Size: 0x148 // Inherited bytes: 0x20
struct FAnimNode_CopyPoseFromMesh : FAnimNode_Base {
	// Fields
	struct TWeakObjectPtr<struct USkeletalMeshComponent> SourceMeshComponent; // Offset: 0x1c // Size: 0x08
	bool bUseAttachedParent; // Offset: 0x24 // Size: 0x01
	bool bCopyCurves; // Offset: 0x25 // Size: 0x01
	char pad_0x2A[0x11e]; // Offset: 0x2a // Size: 0x11e
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_CurveSource
// Size: 0x50 // Inherited bytes: 0x20
struct FAnimNode_CurveSource : FAnimNode_Base {
	// Fields
	struct FPoseLink SourcePose; // Offset: 0x20 // Size: 0x10
	struct FName SourceBinding; // Offset: 0x30 // Size: 0x08
	float Alpha; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct TScriptInterface<ICurveSourceInterface> CurveSource; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_Fabrik
// Size: 0x1c0 // Inherited bytes: 0xf8
struct FAnimNode_Fabrik : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xF8[0x8]; // Offset: 0xf8 // Size: 0x08
	struct FTransform EffectorTransform; // Offset: 0x100 // Size: 0x30
	struct FBoneSocketTarget EffectorTarget; // Offset: 0x130 // Size: 0x60
	struct FBoneReference TipBone; // Offset: 0x190 // Size: 0x10
	struct FBoneReference RootBone; // Offset: 0x1a0 // Size: 0x10
	float Precision; // Offset: 0x1b0 // Size: 0x04
	int32_t MaxIterations; // Offset: 0x1b4 // Size: 0x04
	enum class EBoneControlSpace EffectorTransformSpace; // Offset: 0x1b8 // Size: 0x01
	enum class EBoneRotationSource EffectorRotationSource; // Offset: 0x1b9 // Size: 0x01
	char pad_0x1BA[0x6]; // Offset: 0x1ba // Size: 0x06
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_HandIKRetargeting
// Size: 0x150 // Inherited bytes: 0xf8
struct FAnimNode_HandIKRetargeting : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference RightHandFK; // Offset: 0xf8 // Size: 0x10
	struct FBoneReference LeftHandFK; // Offset: 0x108 // Size: 0x10
	struct FBoneReference RightHandIK; // Offset: 0x118 // Size: 0x10
	struct FBoneReference LeftHandIK; // Offset: 0x128 // Size: 0x10
	struct TArray<struct FBoneReference> IKBonesToMove; // Offset: 0x138 // Size: 0x10
	float HandFKWeight; // Offset: 0x148 // Size: 0x04
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_LegIK
// Size: 0x128 // Inherited bytes: 0xf8
struct FAnimNode_LegIK : FAnimNode_SkeletalControlBase {
	// Fields
	float ReachPrecision; // Offset: 0xf8 // Size: 0x04
	int32_t MaxIterations; // Offset: 0xfc // Size: 0x04
	struct TArray<struct FAnimLegIKDefinition> LegsDefinition; // Offset: 0x100 // Size: 0x10
	char pad_0x110[0x18]; // Offset: 0x110 // Size: 0x18
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimLegIKDefinition
// Size: 0x2c // Inherited bytes: 0x00
struct FAnimLegIKDefinition {
	// Fields
	struct FBoneReference IKFootBone; // Offset: 0x00 // Size: 0x10
	struct FBoneReference FKFootBone; // Offset: 0x10 // Size: 0x10
	int32_t NumBonesInLimb; // Offset: 0x20 // Size: 0x04
	float MinRotationAngle; // Offset: 0x24 // Size: 0x04
	enum class EAxis FootBoneForwardAxis; // Offset: 0x28 // Size: 0x01
	enum class EAxis HingeRotationAxis; // Offset: 0x29 // Size: 0x01
	bool bEnableRotationLimit; // Offset: 0x2a // Size: 0x01
	bool bEnableKneeTwistCorrection; // Offset: 0x2b // Size: 0x01
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimLegIKData
// Size: 0xa0 // Inherited bytes: 0x00
struct FAnimLegIKData {
	// Fields
	char pad_0x0[0xa0]; // Offset: 0x00 // Size: 0xa0
};

// Object Name: ScriptStruct AnimGraphRuntime.IKChain
// Size: 0x38 // Inherited bytes: 0x00
struct FIKChain {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
};

// Object Name: ScriptStruct AnimGraphRuntime.IKChainLink
// Size: 0x3c // Inherited bytes: 0x00
struct FIKChainLink {
	// Fields
	char pad_0x0[0x3c]; // Offset: 0x00 // Size: 0x3c
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_LookAt
// Size: 0x1e0 // Inherited bytes: 0xf8
struct FAnimNode_LookAt : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference BoneToModify; // Offset: 0xf8 // Size: 0x10
	char pad_0x108[0x8]; // Offset: 0x108 // Size: 0x08
	struct FBoneSocketTarget LookAtTarget; // Offset: 0x110 // Size: 0x60
	struct FVector LookAtLocation; // Offset: 0x170 // Size: 0x0c
	struct FAxis LookAt_Axis; // Offset: 0x17c // Size: 0x10
	bool bUseLookUpAxis; // Offset: 0x18c // Size: 0x01
	enum class EInterpolationBlend InterpolationType; // Offset: 0x18d // Size: 0x01
	char pad_0x18E[0x2]; // Offset: 0x18e // Size: 0x02
	struct FAxis LookUp_Axis; // Offset: 0x190 // Size: 0x10
	float LookAtClamp; // Offset: 0x1a0 // Size: 0x04
	float InterpolationTime; // Offset: 0x1a4 // Size: 0x04
	float InterpolationTriggerThreashold; // Offset: 0x1a8 // Size: 0x04
	char pad_0x1AC[0x34]; // Offset: 0x1ac // Size: 0x34
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_MakeDynamicAdditive
// Size: 0x48 // Inherited bytes: 0x20
struct FAnimNode_MakeDynamicAdditive : FAnimNode_Base {
	// Fields
	struct FPoseLink Base; // Offset: 0x20 // Size: 0x10
	struct FPoseLink Additive; // Offset: 0x30 // Size: 0x10
	bool bMeshSpaceAdditive; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_ModifyBone
// Size: 0x138 // Inherited bytes: 0xf8
struct FAnimNode_ModifyBone : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference BoneToModify; // Offset: 0xf8 // Size: 0x10
	struct FVector Translation; // Offset: 0x108 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x114 // Size: 0x0c
	struct FVector Scale; // Offset: 0x120 // Size: 0x0c
	enum class EBoneModificationMode TranslationMode; // Offset: 0x12c // Size: 0x01
	enum class EBoneModificationMode RotationMode; // Offset: 0x12d // Size: 0x01
	enum class EBoneModificationMode ScaleMode; // Offset: 0x12e // Size: 0x01
	enum class EBoneControlSpace TranslationSpace; // Offset: 0x12f // Size: 0x01
	enum class EBoneControlSpace RotationSpace; // Offset: 0x130 // Size: 0x01
	enum class EBoneControlSpace ScaleSpace; // Offset: 0x131 // Size: 0x01
	char pad_0x132[0x6]; // Offset: 0x132 // Size: 0x06
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_ModifyCurve
// Size: 0x68 // Inherited bytes: 0x20
struct FAnimNode_ModifyCurve : FAnimNode_Base {
	// Fields
	struct FPoseLink SourcePose; // Offset: 0x20 // Size: 0x10
	struct TArray<float> CurveValues; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FName> CurveNames; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10
	float Alpha; // Offset: 0x60 // Size: 0x04
	enum class EModifyCurveApplyMode ApplyMode; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_MultiWayBlend
// Size: 0x60 // Inherited bytes: 0x20
struct FAnimNode_MultiWayBlend : FAnimNode_Base {
	// Fields
	struct TArray<struct FPoseLink> Poses; // Offset: 0x20 // Size: 0x10
	struct TArray<float> DesiredAlphas; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x10]; // Offset: 0x40 // Size: 0x10
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x50 // Size: 0x08
	bool bAdditiveNode; // Offset: 0x58 // Size: 0x01
	bool bNormalizeAlpha; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_ObserveBone
// Size: 0x130 // Inherited bytes: 0xf8
struct FAnimNode_ObserveBone : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference BoneToObserve; // Offset: 0xf8 // Size: 0x10
	enum class EBoneControlSpace DisplaySpace; // Offset: 0x108 // Size: 0x01
	bool bRelativeToRefPose; // Offset: 0x109 // Size: 0x01
	char pad_0x10A[0x2]; // Offset: 0x10a // Size: 0x02
	struct FVector Translation; // Offset: 0x10c // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x118 // Size: 0x0c
	struct FVector Scale; // Offset: 0x124 // Size: 0x0c
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_PoseHandler
// Size: 0x90 // Inherited bytes: 0x40
struct FAnimNode_PoseHandler : FAnimNode_AssetPlayerBase {
	// Fields
	struct UPoseAsset* PoseAsset; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x48]; // Offset: 0x48 // Size: 0x48
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_PoseBlendNode
// Size: 0xb0 // Inherited bytes: 0x90
struct FAnimNode_PoseBlendNode : FAnimNode_PoseHandler {
	// Fields
	struct FPoseLink SourcePose; // Offset: 0x90 // Size: 0x10
	enum class EAlphaBlendOption BlendOption; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
	struct UCurveFloat* CustomCurve; // Offset: 0xa8 // Size: 0x08
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_PoseByName
// Size: 0xa8 // Inherited bytes: 0x90
struct FAnimNode_PoseByName : FAnimNode_PoseHandler {
	// Fields
	struct FName PoseName; // Offset: 0x90 // Size: 0x08
	float PoseWeight; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0xc]; // Offset: 0x9c // Size: 0x0c
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_PoseDriver
// Size: 0x140 // Inherited bytes: 0x90
struct FAnimNode_PoseDriver : FAnimNode_PoseHandler {
	// Fields
	struct FPoseLink SourcePose; // Offset: 0x90 // Size: 0x10
	struct TArray<struct FBoneReference> SourceBones; // Offset: 0xa0 // Size: 0x10
	struct TArray<struct FBoneReference> OnlyDriveBones; // Offset: 0xb0 // Size: 0x10
	struct TArray<struct FPoseDriverTarget> PoseTargets; // Offset: 0xc0 // Size: 0x10
	char pad_0xD0[0x30]; // Offset: 0xd0 // Size: 0x30
	struct FBoneReference EvalSpaceBone; // Offset: 0x100 // Size: 0x10
	struct FRBFParams RBFParams; // Offset: 0x110 // Size: 0x28
	enum class EPoseDriverSource DriveSource; // Offset: 0x138 // Size: 0x01
	enum class EPoseDriverOutput DriveOutput; // Offset: 0x139 // Size: 0x01
	char bOnlyDriveSelectedBones : 1; // Offset: 0x13a // Size: 0x01
	char pad_0x13A_1 : 7; // Offset: 0x13a // Size: 0x01
	char pad_0x13B[0x5]; // Offset: 0x13b // Size: 0x05
};

// Object Name: ScriptStruct AnimGraphRuntime.RBFParams
// Size: 0x28 // Inherited bytes: 0x00
struct FRBFParams {
	// Fields
	int32_t TargetDimensions; // Offset: 0x00 // Size: 0x04
	float Radius; // Offset: 0x04 // Size: 0x04
	enum class ERBFFunctionType Function; // Offset: 0x08 // Size: 0x01
	enum class ERBFDistanceMethod DistanceMethod; // Offset: 0x09 // Size: 0x01
	enum class EBoneAxis TwistAxis; // Offset: 0x0a // Size: 0x01
	char pad_0xB[0x1]; // Offset: 0x0b // Size: 0x01
	float WeightThreshold; // Offset: 0x0c // Size: 0x04
	enum class ERBFNormalizeMethod NormalizeMethod; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FVector MedianReference; // Offset: 0x14 // Size: 0x0c
	float MedianMin; // Offset: 0x20 // Size: 0x04
	float MedianMax; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AnimGraphRuntime.PoseDriverTarget
// Size: 0xc0 // Inherited bytes: 0x00
struct FPoseDriverTarget {
	// Fields
	struct TArray<struct FPoseDriverTransform> BoneTransforms; // Offset: 0x00 // Size: 0x10
	struct FRotator TargetRotation; // Offset: 0x10 // Size: 0x0c
	float TargetScale; // Offset: 0x1c // Size: 0x04
	enum class ERBFDistanceMethod DistanceMethod; // Offset: 0x20 // Size: 0x01
	enum class ERBFFunctionType FunctionType; // Offset: 0x21 // Size: 0x01
	bool bApplyCustomCurve; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x5]; // Offset: 0x23 // Size: 0x05
	struct FRichCurve CustomCurve; // Offset: 0x28 // Size: 0x80
	struct FName DrivenName; // Offset: 0xa8 // Size: 0x08
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	bool bIsHidden; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x7]; // Offset: 0xb9 // Size: 0x07
};

// Object Name: ScriptStruct AnimGraphRuntime.PoseDriverTransform
// Size: 0x18 // Inherited bytes: 0x00
struct FPoseDriverTransform {
	// Fields
	struct FVector TargetTranslation; // Offset: 0x00 // Size: 0x0c
	struct FRotator TargetRotation; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_PoseSnapshot
// Size: 0xa0 // Inherited bytes: 0x20
struct FAnimNode_PoseSnapshot : FAnimNode_Base {
	// Fields
	struct FName SnapshotName; // Offset: 0x1c // Size: 0x08
	struct FPoseSnapshot Snapshot; // Offset: 0x28 // Size: 0x38
	enum class ESnapshotSourceMode mode; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x3f]; // Offset: 0x61 // Size: 0x3f
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_RandomPlayer
// Size: 0x78 // Inherited bytes: 0x20
struct FAnimNode_RandomPlayer : FAnimNode_Base {
	// Fields
	struct TArray<struct FRandomPlayerSequenceEntry> Entries; // Offset: 0x20 // Size: 0x10
	char pad_0x30[0x44]; // Offset: 0x30 // Size: 0x44
	bool bShuffleMode; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03
};

// Object Name: ScriptStruct AnimGraphRuntime.RandomPlayerSequenceEntry
// Size: 0x50 // Inherited bytes: 0x00
struct FRandomPlayerSequenceEntry {
	// Fields
	struct UAnimSequence* Sequence; // Offset: 0x00 // Size: 0x08
	float ChanceToPlay; // Offset: 0x08 // Size: 0x04
	int32_t MinLoopCount; // Offset: 0x0c // Size: 0x04
	int32_t MaxLoopCount; // Offset: 0x10 // Size: 0x04
	float MinPlayRate; // Offset: 0x14 // Size: 0x04
	float MaxPlayRate; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FAlphaBlend BlendIn; // Offset: 0x20 // Size: 0x30
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_MeshSpaceRefPose
// Size: 0x20 // Inherited bytes: 0x20
struct FAnimNode_MeshSpaceRefPose : FAnimNode_Base {
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_RefPose
// Size: 0x20 // Inherited bytes: 0x20
struct FAnimNode_RefPose : FAnimNode_Base {
	// Fields
	enum class ERefPoseType RefPoseType; // Offset: 0x1c // Size: 0x01
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_ResetRoot
// Size: 0x108 // Inherited bytes: 0xf8
struct FAnimNode_ResetRoot : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xF8[0x10]; // Offset: 0xf8 // Size: 0x10
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_RigidBody
// Size: 0x580 // Inherited bytes: 0xf8
struct FAnimNode_RigidBody : FAnimNode_SkeletalControlBase {
	// Fields
	struct UPhysicsAsset* OverridePhysicsAsset; // Offset: 0xf8 // Size: 0x08
	char pad_0x100[0x90]; // Offset: 0x100 // Size: 0x90
	struct FVector OverrideWorldGravity; // Offset: 0x190 // Size: 0x0c
	struct FVector ExternalForce; // Offset: 0x19c // Size: 0x0c
	struct FVector ComponentLinearAccScale; // Offset: 0x1a8 // Size: 0x0c
	struct FVector ComponentLinearVelScale; // Offset: 0x1b4 // Size: 0x0c
	struct FVector ComponentAppliedLinearAccClamp; // Offset: 0x1c0 // Size: 0x0c
	float CachedBoundsScale; // Offset: 0x1cc // Size: 0x04
	struct FBoneReference BaseBoneRef; // Offset: 0x1d0 // Size: 0x10
	enum class ECollisionChannel OverlapChannel; // Offset: 0x1e0 // Size: 0x01
	enum class ESimulationSpace SimulationSpace; // Offset: 0x1e1 // Size: 0x01
	bool bForceDisableCollisionBetweenConstraintBodies; // Offset: 0x1e2 // Size: 0x01
	char pad_0x1E3[0x1]; // Offset: 0x1e3 // Size: 0x01
	char bEnableWorldGeometry : 1; // Offset: 0x1e4 // Size: 0x01
	char bOverrideWorldGravity : 1; // Offset: 0x1e4 // Size: 0x01
	char bTransferBoneVelocities : 1; // Offset: 0x1e4 // Size: 0x01
	char bFreezeIncomingPoseOnStart : 1; // Offset: 0x1e4 // Size: 0x01
	char bClampLinearTranslationLimitToRefPose : 1; // Offset: 0x1e4 // Size: 0x01
	char pad_0x1E4_5 : 3; // Offset: 0x1e4 // Size: 0x01
	char pad_0x1E5[0x39b]; // Offset: 0x1e5 // Size: 0x39b
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_RigidBody_Chaos
// Size: 0x520 // Inherited bytes: 0xf8
struct FAnimNode_RigidBody_Chaos : FAnimNode_SkeletalControlBase {
	// Fields
	struct UPhysicsAsset* OverridePhysicsAsset; // Offset: 0xf8 // Size: 0x08
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0x100 // Size: 0x08
	bool bSimulating; // Offset: 0x108 // Size: 0x01
	char pad_0x109[0x3]; // Offset: 0x109 // Size: 0x03
	int32_t NumIterations; // Offset: 0x10c // Size: 0x04
	bool bNotifyCollisions; // Offset: 0x110 // Size: 0x01
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0x111 // Size: 0x01
	char pad_0x112[0x2]; // Offset: 0x112 // Size: 0x02
	float Density; // Offset: 0x114 // Size: 0x04
	float MinMass; // Offset: 0x118 // Size: 0x04
	float MaxMass; // Offset: 0x11c // Size: 0x04
	enum class ECollisionTypeEnum CollisionType; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x3]; // Offset: 0x121 // Size: 0x03
	float ImplicitShapeParticlesPerUnitArea; // Offset: 0x124 // Size: 0x04
	int32_t ImplicitShapeMinNumParticles; // Offset: 0x128 // Size: 0x04
	int32_t ImplicitShapeMaxNumParticles; // Offset: 0x12c // Size: 0x04
	int32_t MinLevelSetResolution; // Offset: 0x130 // Size: 0x04
	int32_t MaxLevelSetResolution; // Offset: 0x134 // Size: 0x04
	int32_t CollisionGroup; // Offset: 0x138 // Size: 0x04
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0x13c // Size: 0x01
	char pad_0x13D[0x3]; // Offset: 0x13d // Size: 0x03
	struct FVector InitialLinearVelocity; // Offset: 0x140 // Size: 0x0c
	struct FVector InitialAngularVelocity; // Offset: 0x14c // Size: 0x0c
	char pad_0x158[0x98]; // Offset: 0x158 // Size: 0x98
	struct FVector OverrideWorldGravity; // Offset: 0x1f0 // Size: 0x0c
	struct FVector ExternalForce; // Offset: 0x1fc // Size: 0x0c
	struct FVector ComponentLinearAccScale; // Offset: 0x208 // Size: 0x0c
	struct FVector ComponentLinearVelScale; // Offset: 0x214 // Size: 0x0c
	struct FVector ComponentAppliedLinearAccClamp; // Offset: 0x220 // Size: 0x0c
	float CachedBoundsScale; // Offset: 0x22c // Size: 0x04
	struct FBoneReference BaseBoneRef; // Offset: 0x230 // Size: 0x10
	enum class ECollisionChannel OverlapChannel; // Offset: 0x240 // Size: 0x01
	enum class ESimulationSpace SimulationSpace; // Offset: 0x241 // Size: 0x01
	bool bForceDisableCollisionBetweenConstraintBodies; // Offset: 0x242 // Size: 0x01
	char pad_0x243[0x1]; // Offset: 0x243 // Size: 0x01
	char bEnableWorldGeometry : 1; // Offset: 0x244 // Size: 0x01
	char bOverrideWorldGravity : 1; // Offset: 0x244 // Size: 0x01
	char bTransferBoneVelocities : 1; // Offset: 0x244 // Size: 0x01
	char bFreezeIncomingPoseOnStart : 1; // Offset: 0x244 // Size: 0x01
	char bClampLinearTranslationLimitToRefPose : 1; // Offset: 0x244 // Size: 0x01
	char pad_0x244_5 : 3; // Offset: 0x244 // Size: 0x01
	char pad_0x245[0x2db]; // Offset: 0x245 // Size: 0x2db
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_RotateRootBone
// Size: 0xb0 // Inherited bytes: 0x20
struct FAnimNode_RotateRootBone : FAnimNode_Base {
	// Fields
	struct FPoseLink BasePose; // Offset: 0x20 // Size: 0x10
	float Pitch; // Offset: 0x30 // Size: 0x04
	float Yaw; // Offset: 0x34 // Size: 0x04
	struct FInputScaleBiasClamp PitchScaleBiasClamp; // Offset: 0x38 // Size: 0x30
	struct FInputScaleBiasClamp YawScaleBiasClamp; // Offset: 0x68 // Size: 0x30
	struct FRotator MeshToComponent; // Offset: 0x98 // Size: 0x0c
	char pad_0xA4[0xc]; // Offset: 0xa4 // Size: 0x0c
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_RotationMultiplier
// Size: 0x120 // Inherited bytes: 0xf8
struct FAnimNode_RotationMultiplier : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference TargetBone; // Offset: 0xf8 // Size: 0x10
	struct FBoneReference SourceBone; // Offset: 0x108 // Size: 0x10
	float Multiplier; // Offset: 0x118 // Size: 0x04
	enum class EBoneAxis RotationAxisToRefer; // Offset: 0x11c // Size: 0x01
	bool bIsAdditive; // Offset: 0x11d // Size: 0x01
	char pad_0x11E[0x2]; // Offset: 0x11e // Size: 0x02
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpace
// Size: 0x490 // Inherited bytes: 0x3e8
struct FAnimNode_RotationOffsetBlendSpace : FAnimNode_BlendSpacePlayer {
	// Fields
	struct FPoseLink BasePose; // Offset: 0x3e8 // Size: 0x10
	int32_t LODThreshold; // Offset: 0x3f8 // Size: 0x04
	float Alpha; // Offset: 0x3fc // Size: 0x04
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x400 // Size: 0x08
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x408 // Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x450 // Size: 0x08
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0x458 // Size: 0x30
	char pad_0x488[0x4]; // Offset: 0x488 // Size: 0x04
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0x48c // Size: 0x01
	bool bAlphaBoolEnabled; // Offset: 0x48d // Size: 0x01
	char pad_0x48E[0x2]; // Offset: 0x48e // Size: 0x02
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_ScaleChainLength
// Size: 0x88 // Inherited bytes: 0x20
struct FAnimNode_ScaleChainLength : FAnimNode_Base {
	// Fields
	struct FPoseLink InputPose; // Offset: 0x20 // Size: 0x10
	float DefaultChainLength; // Offset: 0x30 // Size: 0x04
	struct FBoneReference ChainStartBone; // Offset: 0x34 // Size: 0x10
	struct FBoneReference ChainEndBone; // Offset: 0x44 // Size: 0x10
	struct FVector TargetLocation; // Offset: 0x54 // Size: 0x0c
	float Alpha; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x68 // Size: 0x08
	enum class EScaleChainInitialLength ChainInitialLength; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x17]; // Offset: 0x71 // Size: 0x17
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator
// Size: 0x58 // Inherited bytes: 0x40
struct FAnimNode_SequenceEvaluator : FAnimNode_AssetPlayerBase {
	// Fields
	struct UAnimSequenceBase* Sequence; // Offset: 0x40 // Size: 0x08
	float ExplicitTime; // Offset: 0x48 // Size: 0x04
	bool bShouldLoop; // Offset: 0x4c // Size: 0x01
	bool bTeleportToExplicitTime; // Offset: 0x4d // Size: 0x01
	enum class ESequenceEvalReinit ReinitializationBehavior; // Offset: 0x4e // Size: 0x01
	char pad_0x4F[0x1]; // Offset: 0x4f // Size: 0x01
	float StartPosition; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_Slot
// Size: 0x58 // Inherited bytes: 0x20
struct FAnimNode_Slot : FAnimNode_Base {
	// Fields
	struct FPoseLink Source; // Offset: 0x20 // Size: 0x10
	struct FName SlotName; // Offset: 0x30 // Size: 0x08
	bool bAlwaysUpdateSourcePose; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x1f]; // Offset: 0x39 // Size: 0x1f
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_SplineIK
// Size: 0x290 // Inherited bytes: 0xf8
struct FAnimNode_SplineIK : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference StartBone; // Offset: 0xf8 // Size: 0x10
	struct FBoneReference EndBone; // Offset: 0x108 // Size: 0x10
	enum class ESplineBoneAxis BoneAxis; // Offset: 0x118 // Size: 0x01
	bool bAutoCalculateSpline; // Offset: 0x119 // Size: 0x01
	char pad_0x11A[0x2]; // Offset: 0x11a // Size: 0x02
	int32_t PointCount; // Offset: 0x11c // Size: 0x04
	struct TArray<struct FTransform> ControlPoints; // Offset: 0x120 // Size: 0x10
	float Roll; // Offset: 0x130 // Size: 0x04
	float TwistStart; // Offset: 0x134 // Size: 0x04
	float TwistEnd; // Offset: 0x138 // Size: 0x04
	char pad_0x13C[0x4]; // Offset: 0x13c // Size: 0x04
	struct FAlphaBlend TwistBlend; // Offset: 0x140 // Size: 0x30
	float Stretch; // Offset: 0x170 // Size: 0x04
	float Offset; // Offset: 0x174 // Size: 0x04
	char pad_0x178[0x118]; // Offset: 0x178 // Size: 0x118
};

// Object Name: ScriptStruct AnimGraphRuntime.SplineIKCachedBoneData
// Size: 0x14 // Inherited bytes: 0x00
struct FSplineIKCachedBoneData {
	// Fields
	struct FBoneReference Bone; // Offset: 0x00 // Size: 0x10
	int32_t RefSkeletonIndex; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_SpringBone
// Size: 0x158 // Inherited bytes: 0xf8
struct FAnimNode_SpringBone : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference SpringBone; // Offset: 0xf8 // Size: 0x10
	float MaxDisplacement; // Offset: 0x108 // Size: 0x04
	float SpringStiffness; // Offset: 0x10c // Size: 0x04
	float SpringDamping; // Offset: 0x110 // Size: 0x04
	float ErrorResetThresh; // Offset: 0x114 // Size: 0x04
	char pad_0x118[0x3c]; // Offset: 0x118 // Size: 0x3c
	char bLimitDisplacement : 1; // Offset: 0x154 // Size: 0x01
	char bTranslateX : 1; // Offset: 0x154 // Size: 0x01
	char bTranslateY : 1; // Offset: 0x154 // Size: 0x01
	char bTranslateZ : 1; // Offset: 0x154 // Size: 0x01
	char bRotateX : 1; // Offset: 0x154 // Size: 0x01
	char bRotateY : 1; // Offset: 0x154 // Size: 0x01
	char bRotateZ : 1; // Offset: 0x154 // Size: 0x01
	char pad_0x154_7 : 1; // Offset: 0x154 // Size: 0x01
	char pad_0x155[0x3]; // Offset: 0x155 // Size: 0x03
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_StateResult
// Size: 0x40 // Inherited bytes: 0x40
struct FAnimNode_StateResult : FAnimNode_Root {
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_Trail
// Size: 0x290 // Inherited bytes: 0xf8
struct FAnimNode_Trail : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xF8[0x38]; // Offset: 0xf8 // Size: 0x38
	struct FBoneReference TrailBone; // Offset: 0x130 // Size: 0x10
	int32_t ChainLength; // Offset: 0x140 // Size: 0x04
	enum class EAxis ChainBoneAxis; // Offset: 0x144 // Size: 0x01
	char bInvertChainBoneAxis : 1; // Offset: 0x145 // Size: 0x01
	char bLimitStretch : 1; // Offset: 0x145 // Size: 0x01
	char bLimitRotation : 1; // Offset: 0x145 // Size: 0x01
	char bUsePlanarLimit : 1; // Offset: 0x145 // Size: 0x01
	char bActorSpaceFakeVel : 1; // Offset: 0x145 // Size: 0x01
	char bReorientParentToChild : 1; // Offset: 0x145 // Size: 0x01
	char pad_0x145_6 : 2; // Offset: 0x145 // Size: 0x01
	char pad_0x146[0x2]; // Offset: 0x146 // Size: 0x02
	float MaxDeltaTime; // Offset: 0x148 // Size: 0x04
	float RelaxationSpeedScale; // Offset: 0x14c // Size: 0x04
	struct FRuntimeFloatCurve TrailRelaxationSpeed; // Offset: 0x150 // Size: 0x88
	struct FInputScaleBiasClamp RelaxationSpeedScaleInputProcessor; // Offset: 0x1d8 // Size: 0x30
	struct TArray<struct FRotationLimit> RotationLimits; // Offset: 0x208 // Size: 0x10
	struct TArray<struct FVector> RotationOffsets; // Offset: 0x218 // Size: 0x10
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits; // Offset: 0x228 // Size: 0x10
	float StretchLimit; // Offset: 0x238 // Size: 0x04
	struct FVector FakeVelocity; // Offset: 0x23c // Size: 0x0c
	struct FBoneReference BaseJoint; // Offset: 0x248 // Size: 0x10
	float LastBoneRotationAnimAlphaBlend; // Offset: 0x258 // Size: 0x04
	char pad_0x25C[0x34]; // Offset: 0x25c // Size: 0x34
};

// Object Name: ScriptStruct AnimGraphRuntime.RotationLimit
// Size: 0x18 // Inherited bytes: 0x00
struct FRotationLimit {
	// Fields
	struct FVector LimitMin; // Offset: 0x00 // Size: 0x0c
	struct FVector LimitMax; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_TwistCorrectiveNode
// Size: 0x168 // Inherited bytes: 0xf8
struct FAnimNode_TwistCorrectiveNode : FAnimNode_SkeletalControlBase {
	// Fields
	struct FReferenceBoneFrame BaseFrame; // Offset: 0xf8 // Size: 0x20
	struct FReferenceBoneFrame TwistFrame; // Offset: 0x118 // Size: 0x20
	struct FAxis TwistPlaneNormalAxis; // Offset: 0x138 // Size: 0x10
	float RangeMax; // Offset: 0x148 // Size: 0x04
	float RemappedMin; // Offset: 0x14c // Size: 0x04
	float RemappedMax; // Offset: 0x150 // Size: 0x04
	struct FAnimCurveParam Curve; // Offset: 0x154 // Size: 0x0c
	char pad_0x160[0x8]; // Offset: 0x160 // Size: 0x08
};

// Object Name: ScriptStruct AnimGraphRuntime.ReferenceBoneFrame
// Size: 0x20 // Inherited bytes: 0x00
struct FReferenceBoneFrame {
	// Fields
	struct FBoneReference Bone; // Offset: 0x00 // Size: 0x10
	struct FAxis Axis; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_TwoBoneIK
// Size: 0x210 // Inherited bytes: 0xf8
struct FAnimNode_TwoBoneIK : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference IKBone; // Offset: 0xf8 // Size: 0x10
	float StartStretchRatio; // Offset: 0x108 // Size: 0x04
	float MaxStretchScale; // Offset: 0x10c // Size: 0x04
	struct FVector EffectorLocation; // Offset: 0x110 // Size: 0x0c
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
	struct FBoneSocketTarget EffectorTarget; // Offset: 0x120 // Size: 0x60
	struct FVector JointTargetLocation; // Offset: 0x180 // Size: 0x0c
	char pad_0x18C[0x4]; // Offset: 0x18c // Size: 0x04
	struct FBoneSocketTarget JointTarget; // Offset: 0x190 // Size: 0x60
	struct FAxis TwistAxis; // Offset: 0x1f0 // Size: 0x10
	enum class EBoneControlSpace EffectorLocationSpace; // Offset: 0x200 // Size: 0x01
	enum class EBoneControlSpace JointTargetLocationSpace; // Offset: 0x201 // Size: 0x01
	char bAllowStretching : 1; // Offset: 0x202 // Size: 0x01
	char bTakeRotationFromEffectorSpace : 1; // Offset: 0x202 // Size: 0x01
	char bMaintainEffectorRelRot : 1; // Offset: 0x202 // Size: 0x01
	char bAllowTwist : 1; // Offset: 0x202 // Size: 0x01
	char pad_0x202_4 : 4; // Offset: 0x202 // Size: 0x01
	char pad_0x203[0xd]; // Offset: 0x203 // Size: 0x0d
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimNode_TwoWayBlend
// Size: 0xd8 // Inherited bytes: 0x20
struct FAnimNode_TwoWayBlend : FAnimNode_Base {
	// Fields
	struct FPoseLink A; // Offset: 0x20 // Size: 0x10
	struct FPoseLink B; // Offset: 0x30 // Size: 0x10
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0x40 // Size: 0x01
	char bAlphaBoolEnabled : 1; // Offset: 0x41 // Size: 0x01
	char pad_0x41_1 : 2; // Offset: 0x41 // Size: 0x01
	char bResetChildOnActivation : 1; // Offset: 0x41 // Size: 0x01
	char pad_0x41_4 : 4; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x2]; // Offset: 0x42 // Size: 0x02
	float Alpha; // Offset: 0x44 // Size: 0x04
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x48 // Size: 0x08
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x50 // Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x98 // Size: 0x08
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0xa0 // Size: 0x30
	char pad_0xD0[0x8]; // Offset: 0xd0 // Size: 0x08
};

// Object Name: ScriptStruct AnimGraphRuntime.AnimSequencerInstanceProxy
// Size: 0xa30 // Inherited bytes: 0x7b0
struct FAnimSequencerInstanceProxy : FAnimInstanceProxy {
	// Fields
	char pad_0x7B0[0x280]; // Offset: 0x7b0 // Size: 0x280
};

// Object Name: ScriptStruct AnimGraphRuntime.PositionHistory
// Size: 0x30 // Inherited bytes: 0x00
struct FPositionHistory {
	// Fields
	struct TArray<struct FVector> Positions; // Offset: 0x00 // Size: 0x10
	float Range; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x1c]; // Offset: 0x14 // Size: 0x1c
};

// Object Name: ScriptStruct AnimGraphRuntime.RBFEntry
// Size: 0x10 // Inherited bytes: 0x00
struct FRBFEntry {
	// Fields
	struct TArray<float> Values; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AnimGraphRuntime.RBFTarget
// Size: 0xa0 // Inherited bytes: 0x10
struct FRBFTarget : FRBFEntry {
	// Fields
	float ScaleFactor; // Offset: 0x10 // Size: 0x04
	bool bApplyCustomCurve; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	struct FRichCurve CustomCurve; // Offset: 0x18 // Size: 0x80
	enum class ERBFDistanceMethod DistanceMethod; // Offset: 0x98 // Size: 0x01
	enum class ERBFFunctionType FunctionType; // Offset: 0x99 // Size: 0x01
	char pad_0x9A[0x6]; // Offset: 0x9a // Size: 0x06
};

