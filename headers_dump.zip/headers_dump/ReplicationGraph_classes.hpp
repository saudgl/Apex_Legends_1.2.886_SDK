#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ReplicationGraph.ReplicationGraph
// Size: 0x780 // Inherited bytes: 0x78
struct UReplicationGraph : UReplicationDriver {
	// Fields
	struct UNetReplicationGraphConnection* ReplicationConnectionManagerClass; // Offset: 0x78 // Size: 0x08
	struct UNetDriver* NetDriver; // Offset: 0x80 // Size: 0x08
	struct TArray<struct UNetReplicationGraphConnection*> Connections; // Offset: 0x88 // Size: 0x10
	struct TArray<struct UNetReplicationGraphConnection*> PendingConnections; // Offset: 0x98 // Size: 0x10
	char pad_0xA8[0x50]; // Offset: 0xa8 // Size: 0x50
	struct TArray<struct UReplicationGraphNode*> GlobalGraphNodes; // Offset: 0xf8 // Size: 0x10
	struct TArray<struct UReplicationGraphNode*> PrepareForReplicationNodes; // Offset: 0x108 // Size: 0x10
	char pad_0x118[0x138]; // Offset: 0x118 // Size: 0x138
	struct TArray<struct FClassCountCheckerConfig> CountCheckerConfigs; // Offset: 0x250 // Size: 0x10
	struct TArray<struct FClassCountCheckerConfig> CloseCountCheckerConfigs; // Offset: 0x260 // Size: 0x10
	char pad_0x270[0x510]; // Offset: 0x270 // Size: 0x510
};

// Object Name: Class ReplicationGraph.BasicReplicationGraph
// Size: 0x7b0 // Inherited bytes: 0x780
struct UBasicReplicationGraph : UReplicationGraph {
	// Fields
	struct UReplicationGraphNode_GridSpatialization2D* GridNode; // Offset: 0x780 // Size: 0x08
	struct UReplicationGraphNode_ActorList* AlwaysRelevantNode; // Offset: 0x788 // Size: 0x08
	struct TArray<struct FConnectionAlwaysRelevantNodePair> AlwaysRelevantForConnectionList; // Offset: 0x790 // Size: 0x10
	struct TArray<struct AActor*> ActorsWithoutNetConnection; // Offset: 0x7a0 // Size: 0x10
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode
// Size: 0x50 // Inherited bytes: 0x28
struct UReplicationGraphNode : UObject {
	// Fields
	struct TArray<struct UReplicationGraphNode*> AllChildNodes; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x18]; // Offset: 0x38 // Size: 0x18
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_ActorList
// Size: 0xf8 // Inherited bytes: 0x50
struct UReplicationGraphNode_ActorList : UReplicationGraphNode {
	// Fields
	char pad_0x50[0xa8]; // Offset: 0x50 // Size: 0xa8
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_ActorListFrequencyBuckets
// Size: 0x138 // Inherited bytes: 0x50
struct UReplicationGraphNode_ActorListFrequencyBuckets : UReplicationGraphNode {
	// Fields
	char pad_0x50[0xe8]; // Offset: 0x50 // Size: 0xe8
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_DynamicSpatialFrequency
// Size: 0x128 // Inherited bytes: 0xf8
struct UReplicationGraphNode_DynamicSpatialFrequency : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xF8[0x30]; // Offset: 0xf8 // Size: 0x30
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_ConnectionDormancyNode
// Size: 0x190 // Inherited bytes: 0xf8
struct UReplicationGraphNode_ConnectionDormancyNode : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xF8[0x98]; // Offset: 0xf8 // Size: 0x98
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_DormancyNode
// Size: 0x148 // Inherited bytes: 0xf8
struct UReplicationGraphNode_DormancyNode : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xF8[0x50]; // Offset: 0xf8 // Size: 0x50
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_GridCell
// Size: 0x150 // Inherited bytes: 0xf8
struct UReplicationGraphNode_GridCell : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xF8[0x48]; // Offset: 0xf8 // Size: 0x48
	struct UReplicationGraphNode* DynamicNode; // Offset: 0x140 // Size: 0x08
	struct UReplicationGraphNode_DormancyNode* DormancyNode; // Offset: 0x148 // Size: 0x08
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_GridSpatialization2D
// Size: 0x230 // Inherited bytes: 0x50
struct UReplicationGraphNode_GridSpatialization2D : UReplicationGraphNode {
	// Fields
	char pad_0x50[0x1e0]; // Offset: 0x50 // Size: 0x1e0
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_AlwaysRelevant
// Size: 0x68 // Inherited bytes: 0x50
struct UReplicationGraphNode_AlwaysRelevant : UReplicationGraphNode {
	// Fields
	struct UReplicationGraphNode* ChildNode; // Offset: 0x50 // Size: 0x08
	char pad_0x58[0x10]; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_AlwaysRelevant_ForConnection
// Size: 0x130 // Inherited bytes: 0xf8
struct UReplicationGraphNode_AlwaysRelevant_ForConnection : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xF8[0x18]; // Offset: 0xf8 // Size: 0x18
	struct TArray<struct FAlwaysRelevantActorInfo> PastRelevantActors; // Offset: 0x110 // Size: 0x10
	struct AActor* LastViewer; // Offset: 0x120 // Size: 0x08
	struct AActor* LastViewTarget; // Offset: 0x128 // Size: 0x08
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_TearOff_ForConnection
// Size: 0x78 // Inherited bytes: 0x50
struct UReplicationGraphNode_TearOff_ForConnection : UReplicationGraphNode {
	// Fields
	struct TArray<struct FTearOffActorInfo> TearOffActors; // Offset: 0x50 // Size: 0x10
	char pad_0x60[0x18]; // Offset: 0x60 // Size: 0x18
};

// Object Name: Class ReplicationGraph.NetReplicationGraphConnection
// Size: 0x238 // Inherited bytes: 0x28
struct UNetReplicationGraphConnection : UReplicationConnectionDriver {
	// Fields
	struct UNetConnection* NetConnection; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x148]; // Offset: 0x30 // Size: 0x148
	struct AReplicationGraphDebugActor* DebugActor; // Offset: 0x178 // Size: 0x08
	char pad_0x180[0x18]; // Offset: 0x180 // Size: 0x18
	struct TArray<struct FLastLocationGatherInfo> LastGatherLocations; // Offset: 0x198 // Size: 0x10
	char pad_0x1A8[0x8]; // Offset: 0x1a8 // Size: 0x08
	struct TArray<struct UReplicationGraphNode*> ConnectionGraphNodes; // Offset: 0x1b0 // Size: 0x10
	struct UReplicationGraphNode_TearOff_ForConnection* TearOffNode; // Offset: 0x1c0 // Size: 0x08
	char pad_0x1C8[0x70]; // Offset: 0x1c8 // Size: 0x70
};

// Object Name: Class ReplicationGraph.ReplicationGraphDebugActor
// Size: 0x278 // Inherited bytes: 0x268
struct AReplicationGraphDebugActor : AActor {
	// Fields
	struct UReplicationGraph* ReplicationGraph; // Offset: 0x268 // Size: 0x08
	struct UNetReplicationGraphConnection* ConnectionManager; // Offset: 0x270 // Size: 0x08

	// Functions

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerStopDebugging
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerStopDebugging(); // Offset: 0x101d0cddc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerStartDebugging
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerStartDebugging(); // Offset: 0x101d0ce38 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetPeriodFrameForClass
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetPeriodFrameForClass(struct UObject* Class, int32_t PeriodFrame); // Offset: 0x101d0cac0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetCullDistanceForClass
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetCullDistanceForClass(struct UObject* Class, float CullDistance); // Offset: 0x101d0cbc0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetConditionalActorBreakpoint
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetConditionalActorBreakpoint(struct AActor* Actor); // Offset: 0x101d0ca08 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerPrintAllActorInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerPrintAllActorInfo(struct FString Str); // Offset: 0x101d0ccc0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerCellInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerCellInfo(); // Offset: 0x101d0cd80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ClientCellInfo
	// Flags: [Net|NetReliableNative|Event|Public|HasDefaults|NetClient]
	void ClientCellInfo(struct FVector CellLocation, struct FVector CellExtent, struct TArray<struct AActor*> Actors); // Offset: 0x101d0c8f4 // Return & Params: Num(3) Size(0x28)
};

