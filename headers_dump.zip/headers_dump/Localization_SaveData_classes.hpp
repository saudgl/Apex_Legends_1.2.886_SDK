#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Localization_SaveData.Localization_SaveData_C
// Size: 0x4c // Inherited bytes: 0x28
struct ULocalization_SaveData_C : USaveGame {
	// Fields
	struct FString LastSelectLanguage; // Offset: 0x28 // Size: 0x10
	struct FString LastSelectAKLanguage; // Offset: 0x38 // Size: 0x10
	int32_t LastSelectAKPakID; // Offset: 0x48 // Size: 0x04
};

