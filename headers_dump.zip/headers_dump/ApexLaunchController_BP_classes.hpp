#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ApexLaunchController_BP.ApexLaunchController_BP_C
// Size: 0x668 // Inherited bytes: 0x668
struct AApexLaunchController_BP_C : AApexLaunchPlayerController {
};

