#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_QualityPhoneWhiteList_Type.BP_STRUCT_QualityPhoneWhiteList_Type
// Size: 0x50 // Inherited bytes: 0x00
struct FBP_STRUCT_QualityPhoneWhiteList_Type {
	// Fields
	int32_t ID_13_727014802F99356C2D798800027EB204; // Offset: 0x00 // Size: 0x04
	struct FName GroupName_14_081CE1004DAF271469EADA7E0687DFB5; // Offset: 0x04 // Size: 0x08
	struct FName CPU_15_3326378063AC680049F0F5BF00429FA5; // Offset: 0x0c // Size: 0x08
	struct FName GPU_16_1B8938802401A61C49F0063100429BA5; // Offset: 0x14 // Size: 0x08
	struct FName RAM_17_394855800D18933049F32390004281AD; // Offset: 0x1c // Size: 0x08
	struct FName PhoneModel_18_27F2F84079EB22551548EFFC00CC48DC; // Offset: 0x24 // Size: 0x08
	struct FName PhoneName_19_15FF7C402D9A984F1F14E9B3060CC715; // Offset: 0x2c // Size: 0x08
	struct FName Resolution_20_4833CA8061C67AC8478201F802145DFE; // Offset: 0x34 // Size: 0x08
	struct FName WidthHeightRatio_21_5F1F738050436EDE22548773017E959F; // Offset: 0x3c // Size: 0x08
	int32_t GroupID_22_058B64006E435E5C28EDC80209868644; // Offset: 0x44 // Size: 0x04
	int32_t SpecialScreenAdaptiveID_23_727014802F99356C2D798800027EB204; // Offset: 0x48 // Size: 0x04
	int32_t GroupGradeID_24_15653CC065618EE1192D48B1071FC1B4; // Offset: 0x4c // Size: 0x04
};

