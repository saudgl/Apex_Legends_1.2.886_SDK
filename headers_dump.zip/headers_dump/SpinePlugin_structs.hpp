#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct SpinePlugin.SpineEvent
// Size: 0x30 // Inherited bytes: 0x00
struct FSpineEvent {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct FString StringValue; // Offset: 0x10 // Size: 0x10
	int32_t IntValue; // Offset: 0x20 // Size: 0x04
	float FloatValue; // Offset: 0x24 // Size: 0x04
	float Time; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct SpinePlugin.SpineAnimationStateMixData
// Size: 0x28 // Inherited bytes: 0x00
struct FSpineAnimationStateMixData {
	// Fields
	struct FString From; // Offset: 0x00 // Size: 0x10
	struct FString To; // Offset: 0x10 // Size: 0x10
	float Mix; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

