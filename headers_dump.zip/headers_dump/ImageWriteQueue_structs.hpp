#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ImageWriteQueue.ImageWriteOptions
// Size: 0x60 // Inherited bytes: 0x00
struct FImageWriteOptions {
	// Fields
	enum class EDesiredImageFormat Format; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FDelegate OnComplete; // Offset: 0x04 // Size: 0x10
	int32_t CompressionQuality; // Offset: 0x14 // Size: 0x04
	bool bOverwriteFile; // Offset: 0x18 // Size: 0x01
	bool bAsync; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x46]; // Offset: 0x1a // Size: 0x46
};

