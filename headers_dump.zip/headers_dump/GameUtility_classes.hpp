#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GameUtility.UtilityActionScriptableBase
// Size: 0x30 // Inherited bytes: 0x28
struct UUtilityActionScriptableBase : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function GameUtility.UtilityActionScriptableBase.WhenActionTick
	// Flags: [Event|Public|BlueprintEvent]
	void WhenActionTick(float DeltaSeconds); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.WhenActionDeactivated
	// Flags: [Event|Public|BlueprintEvent]
	void WhenActionDeactivated(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.WhenActionActivated
	// Flags: [Event|Public|BlueprintEvent]
	void WhenActionActivated(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.WhenActionAborted
	// Flags: [Native|Event|Public|BlueprintEvent]
	void WhenActionAborted(); // Offset: 0x101f34150 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.ToCompareActionState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ToCompareActionState(struct FGameUtilityCompareExpandActionContext& Context); // Offset: 0x101f33ff0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.RestoreActionState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RestoreActionState(struct FGameUtilityCompareExpandActionContext& Context); // Offset: 0x101f33f5c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.IsSameExpandAction
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	bool IsSameExpandAction(struct FGameUtilityCompareExpandActionContext& Context); // Offset: 0x1043c773c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.IsActionExecutable
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool IsActionExecutable(); // Offset: 0x101f3416c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.GetOwner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUtilityInstanceBase* GetOwner(); // Offset: 0x101f34084 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.GetEvaluateGraphExposedInputs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetEvaluateGraphExposedInputs(); // Offset: 0x101f340a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.FinishAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishAction(bool Succeeded); // Offset: 0x101f340cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.FinishAbort
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishAbort(); // Offset: 0x101f340b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameUtility.UtilityActionScriptableBase.CalSunkCostWeight
	// Flags: [Event|Public|BlueprintEvent|Const]
	float CalSunkCostWeight(); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class GameUtility.UtilityInstanceBase
// Size: 0x68 // Inherited bytes: 0x28
struct UUtilityInstanceBase : UObject {
	// Fields
	char pad_0x28[0x38]; // Offset: 0x28 // Size: 0x38
	int32_t EvaluatedExpandActionCount; // Offset: 0x60 // Size: 0x04
	int32_t EvaluateExpandActionIndex; // Offset: 0x64 // Size: 0x04

	// Functions

	// Object Name: Function GameUtility.UtilityInstanceBase.Tick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Tick(float DeltaSeconds); // Offset: 0x101f34978 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameUtility.UtilityInstanceBase.ReceiveWhenPreEvalUtility
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenPreEvalUtility(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameUtility.UtilityInstanceBase.GenerateStateTableInstances
	// Flags: [Event|Protected|BlueprintEvent|Const]
	struct TArray<struct UUtilityInstanceBase*> GenerateStateTableInstances(); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class GameUtility.UtilityInstanceBlueprint
// Size: 0xd0 // Inherited bytes: 0xd0
struct UUtilityInstanceBlueprint : UBlueprint {
};

// Object Name: Class GameUtility.UtilityInstanceGeneratedClass
// Size: 0x410 // Inherited bytes: 0x400
struct UUtilityInstanceGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	struct TArray<struct FName> AllActionNames; // Offset: 0x400 // Size: 0x10
};

// Object Name: Class GameUtility.UtilityFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UUtilityFunctionLibrary : UBlueprintFunctionLibrary {
};

