#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct GameUtility.UtilityActionBase
// Size: 0xc8 // Inherited bytes: 0x00
struct FUtilityActionBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FName ActionName; // Offset: 0x08 // Size: 0x08
	char bEnableWeightUtilityCurve : 1; // Offset: 0x10 // Size: 0x01
	char pad_0x10_1 : 7; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FRuntimeFloatCurve WeightUtilityCurve; // Offset: 0x18 // Size: 0x88
	struct UFunction* CalRawWeightFunction; // Offset: 0xa0 // Size: 0x08
	struct UFunction* EvaluateActionCountFunction; // Offset: 0xa8 // Size: 0x08
	struct UFunction* EvaluateParamsFunction; // Offset: 0xb0 // Size: 0x08
	char pad_0xB8[0x8]; // Offset: 0xb8 // Size: 0x08
	struct UUtilityInstanceBase* OwnerProtected; // Offset: 0xc0 // Size: 0x08
};

// Object Name: ScriptStruct GameUtility.UtilityActionSubInstance
// Size: 0xd0 // Inherited bytes: 0xc8
struct FUtilityActionSubInstance : FUtilityActionBase {
	// Fields
	struct UUtilityInstanceBase* SubInstance; // Offset: 0xc8 // Size: 0x08
};

// Object Name: ScriptStruct GameUtility.UtilityActionScriptBase
// Size: 0xd0 // Inherited bytes: 0xc8
struct FUtilityActionScriptBase : FUtilityActionBase {
	// Fields
	struct UUtilityActionScriptableBase* ScriptInstance; // Offset: 0xc8 // Size: 0x08
};

// Object Name: ScriptStruct GameUtility.GameUtilityCompareExpandActionContext
// Size: 0x10 // Inherited bytes: 0x00
struct FGameUtilityCompareExpandActionContext {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

