#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct MaterialShaderQualitySettings.MaterialQualityOverrides
// Size: 0x14 // Inherited bytes: 0x00
struct FMaterialQualityOverrides {
	// Fields
	bool bDiscardQualityDuringCook; // Offset: 0x00 // Size: 0x01
	bool bEnableOverride; // Offset: 0x01 // Size: 0x01
	bool bForceFullyRough; // Offset: 0x02 // Size: 0x01
	bool bForceIBLDisable; // Offset: 0x03 // Size: 0x01
	bool bEnableSpotLightShadow; // Offset: 0x04 // Size: 0x01
	bool bForceNonMetal; // Offset: 0x05 // Size: 0x01
	bool bForceDisableLMDirectionality; // Offset: 0x06 // Size: 0x01
	bool bForceLQReflections; // Offset: 0x07 // Size: 0x01
	bool bDisableMaterialNormalCalculation; // Offset: 0x08 // Size: 0x01
	bool bForceNoMicroShadow; // Offset: 0x09 // Size: 0x01
	bool bForceHalfPrecisionSpecular; // Offset: 0x0a // Size: 0x01
	bool bForceVertexLighting; // Offset: 0x0b // Size: 0x01
	enum class EMobileFogQuality MobileFogQuality; // Offset: 0x0c // Size: 0x01
	bool bUseCSMLayerFade; // Offset: 0x0d // Size: 0x01
	enum class EMobileCSMQuality MobileCSMQuality; // Offset: 0x0e // Size: 0x01
	bool bEnableAdditiveFade; // Offset: 0x0f // Size: 0x01
	bool bMixableAdditiveFade; // Offset: 0x10 // Size: 0x01
	bool bUnlimitedPCF; // Offset: 0x11 // Size: 0x01
	bool bEnableLDRColorGradingFit; // Offset: 0x12 // Size: 0x01
	bool bForceLightMapSHdisable; // Offset: 0x13 // Size: 0x01
};

