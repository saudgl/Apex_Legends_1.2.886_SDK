#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Basic.ApexGameInstanceSubsystem
// Size: 0x38 // Inherited bytes: 0x30
struct UApexGameInstanceSubsystem : UGameInstanceSubsystem {
	// Fields
	bool bCreateInDedicatedServer; // Offset: 0x30 // Size: 0x01
	bool bCreateInClient; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
};

// Object Name: Class Basic.ApexWorldSubsystem
// Size: 0x88 // Inherited bytes: 0x30
struct UApexWorldSubsystem : UWorldSubsystem {
	// Fields
	bool bCreateInDedicatedServer; // Offset: 0x30 // Size: 0x01
	bool bCreateInClient; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
	struct TSet<struct FName> CreateFrontendStates; // Offset: 0x38 // Size: 0x50
};

// Object Name: Class Basic.ApexTickableWorldSubsystem
// Size: 0x90 // Inherited bytes: 0x40
struct UApexTickableWorldSubsystem : UTickableWorldSubsystem {
	// Fields
	bool bCreateInDedicatedServer; // Offset: 0x39 // Size: 0x01
	bool bCreateInClient; // Offset: 0x3a // Size: 0x01
	struct TSet<struct FName> CreateFrontendStates; // Offset: 0x40 // Size: 0x50
};

// Object Name: Class Basic.ApexGameModeSubsystem
// Size: 0x30 // Inherited bytes: 0x30
struct UApexGameModeSubsystem : UGameModeSubsystem {
};

// Object Name: Class Basic.ApexSubsystemDataAsset
// Size: 0x50 // Inherited bytes: 0x30
struct UApexSubsystemDataAsset : UDataAsset {
	// Fields
	struct TArray<struct UApexWorldSubsystem*> WorldSubsystems; // Offset: 0x30 // Size: 0x10
	struct TArray<struct UApexGameModeSubsystem*> GameModeSubsystems; // Offset: 0x40 // Size: 0x10
};

