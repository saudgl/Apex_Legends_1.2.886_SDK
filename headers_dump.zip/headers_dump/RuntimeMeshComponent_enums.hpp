#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum RuntimeMeshComponent.ERuntimeMeshThreadingPriority
enum class ERuntimeMeshThreadingPriority : uint8 {
	Normal = 0,
	AboveNormal = 1,
	BelowNormal = 2,
	Highest = 3,
	Lowest = 4,
	SlightlyBelowNormal = 5,
	TimeCritical = 6,
	ERuntimeMeshThreadingPriority_MAX = 7
};

// Object Name: Enum RuntimeMeshComponent.ERuntimeMeshCollisionFaceSourceType
enum class ERuntimeMeshCollisionFaceSourceType : uint8 {
	Collision = 0,
	Renderable = 1,
	ERuntimeMeshCollisionFaceSourceType_MAX = 2
};

// Object Name: Enum RuntimeMeshComponent.ERuntimeMeshCollisionCookingMode
enum class ERuntimeMeshCollisionCookingMode : uint8 {
	CollisionPerformance = 0,
	CookingPerformance = 1,
	ERuntimeMeshCollisionCookingMode_MAX = 2
};

// Object Name: Enum RuntimeMeshComponent.ERuntimeMeshUpdateFrequency
enum class ERuntimeMeshUpdateFrequency : uint8 {
	Average = 0,
	Frequent = 1,
	Infrequent = 2,
	ERuntimeMeshUpdateFrequency_MAX = 3
};

// Object Name: Enum RuntimeMeshComponent.ERuntimeMeshMobility
enum class ERuntimeMeshMobility : uint8 {
	Movable = 0,
	Stationary = 1,
	Static = 2,
	ERuntimeMeshMobility_MAX = 3
};

