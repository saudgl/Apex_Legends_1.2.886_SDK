#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Skill.SkillCreatorSystem
// Size: 0x58 // Inherited bytes: 0x40
struct USkillCreatorSystem : UTickableWorldSubsystem {
	// Fields
	char pad_0x40[0x18]; // Offset: 0x40 // Size: 0x18
};

// Object Name: Class Skill.SkillReaderSystem
// Size: 0xb8 // Inherited bytes: 0x40
struct USkillReaderSystem : UTickableWorldSubsystem {
	// Fields
	char pad_0x40[0x78]; // Offset: 0x40 // Size: 0x78
};

// Object Name: Class Skill.SkillWriterSystem
// Size: 0x30 // Inherited bytes: 0x30
struct USkillWriterSystem : UEngineSubsystem {
};

// Object Name: Class Skill.SkillTriggerBase
// Size: 0x38 // Inherited bytes: 0x28
struct USkillTriggerBase : UObject {
	// Fields
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> SkillManagerComponent; // Offset: 0x28 // Size: 0x08
	int32_t SkillID; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04

	// Functions

	// Object Name: Function Skill.SkillTriggerBase.OnUnInitSkill
	// Flags: [Event|Public|BlueprintEvent]
	void OnUnInitSkill(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.SkillTriggerBase.OnInitSkill
	// Flags: [Event|Public|BlueprintEvent]
	void OnInitSkill(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.SkillTriggerBase.GetSkillManagerComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUTSkillManagerComponent* GetSkillManagerComponent(); // Offset: 0x101d5273c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Skill.UTSkill
// Size: 0x410 // Inherited bytes: 0x268
struct AUTSkill : AActor {
	// Fields
	char pad_0x268[0x8]; // Offset: 0x268 // Size: 0x08
	struct FString SkillName; // Offset: 0x270 // Size: 0x10
	struct FString SkillDescription; // Offset: 0x280 // Size: 0x10
	enum class ESkillCastType SkillCastType; // Offset: 0x290 // Size: 0x01
	char pad_0x291[0x7]; // Offset: 0x291 // Size: 0x07
	struct FString TriggerEventParam; // Offset: 0x298 // Size: 0x10
	int32_t TriggerCondition; // Offset: 0x2a8 // Size: 0x04
	bool bIgnoreDisableTrigger; // Offset: 0x2ac // Size: 0x01
	enum class ESkillType SkillType; // Offset: 0x2ad // Size: 0x01
	bool bOnlyTriggerInAuthority; // Offset: 0x2ae // Size: 0x01
	bool bOnlyRunInAuthority; // Offset: 0x2af // Size: 0x01
	bool bMeleeSkill; // Offset: 0x2b0 // Size: 0x01
	bool bNoEnergyStart; // Offset: 0x2b1 // Size: 0x01
	bool bNeedAutonomousClientSimulate; // Offset: 0x2b2 // Size: 0x01
	bool bClearInputCache; // Offset: 0x2b3 // Size: 0x01
	bool NotInterruptOtherTriggerSkill; // Offset: 0x2b4 // Size: 0x01
	bool EnableFPPTPPSwitch; // Offset: 0x2b5 // Size: 0x01
	bool EnableBackSwingAfterInterrupt; // Offset: 0x2b6 // Size: 0x01
	char pad_0x2B7[0x1]; // Offset: 0x2b7 // Size: 0x01
	struct FUTSkillCreateData BaseData; // Offset: 0x2b8 // Size: 0xd0
	struct USkillTriggerBase* SkillTriggerClass; // Offset: 0x388 // Size: 0x08
	bool NegativeSkill; // Offset: 0x390 // Size: 0x01
	char pad_0x391[0x3]; // Offset: 0x391 // Size: 0x03
	int32_t SkillCategory; // Offset: 0x394 // Size: 0x04
	bool ShouldShowTargetPrompt; // Offset: 0x398 // Size: 0x01
	bool ChangePawnStatus; // Offset: 0x399 // Size: 0x01
	bool SilencedByRevenant; // Offset: 0x39a // Size: 0x01
	bool bDeserializeComplete; // Offset: 0x39b // Size: 0x01
	char pad_0x39C[0x1c]; // Offset: 0x39c // Size: 0x1c
	struct TMap<struct UObject*, int32_t> InstancedNodeNameToMemoryMap; // Offset: 0x3b8 // Size: 0x50
	int32_t InstancedNodesTotalSize; // Offset: 0x408 // Size: 0x04
	char pad_0x40C[0x4]; // Offset: 0x40c // Size: 0x04

	// Functions

	// Object Name: Function Skill.UTSkill.SetAvailableTimes
	// Flags: [Native|Public|BlueprintCallable]
	void SetAvailableTimes(struct UUTSkillManagerComponent* SkillManagerComponent, int32_t Times); // Offset: 0x101d53600 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.PlusRemainTimes
	// Flags: [Native|Public|BlueprintCallable]
	bool PlusRemainTimes(struct UUTSkillManagerComponent* SkillManagerComponent, bool bTimesForRound, int32_t Times); // Offset: 0x101d53400 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function Skill.UTSkill.OnPhaseFinished
	// Flags: [Native|Public]
	void OnPhaseFinished(struct UUTSkillManagerComponent* SkillManagerComponent, float RemainDeltaSeconds); // Offset: 0x101d532a4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.OnEvent
	// Flags: [Native|Public|BlueprintCallable]
	bool OnEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class EUTSkillEventType TheEventType, struct UUTSkillManagerComponent* EventOrigin); // Offset: 0x101d539ec // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Skill.UTSkill.GetSkillPhase
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillPhase* GetSkillPhase(int32_t PhaseIndex); // Offset: 0x101d530f0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkill.GetRemainTimes
	// Flags: [Native|Public|BlueprintCallable]
	int32_t GetRemainTimes(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d5336c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.GetFromActorStorage
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AActor* GetFromActorStorage(struct UUTSkillManagerComponent* SkillManagerComponent, int32_t Index); // Offset: 0x101d53020 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkill.GetComponentByTag
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UActorComponent* GetComponentByTag(struct UActorComponent* ComponentClass, struct FName Tag); // Offset: 0x101d53b08 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkill.DoSkillReleased
	// Flags: [Native|Public|BlueprintCallable]
	void DoSkillReleased(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d5374c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkill.DoSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	void DoSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d53854 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkill.DoResetReleased
	// Flags: [Native|Public|BlueprintCallable]
	void DoResetReleased(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d536c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkill.DoResetCD
	// Flags: [Native|Public|BlueprintCallable]
	void DoResetCD(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d537d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkill.DeductRemainTimes
	// Flags: [Native|Public|BlueprintCallable]
	bool DeductRemainTimes(struct UUTSkillManagerComponent* SkillManagerComponent, int32_t Times); // Offset: 0x101d53528 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Skill.UTSkill.CheckPhaseCondition
	// Flags: [Native|Public|BlueprintCallable]
	bool CheckPhaseCondition(struct UUTSkillManagerComponent* SkillManagerComponent, int32_t PhaseID, bool ResetConditions); // Offset: 0x101d53184 // Return & Params: Num(4) Size(0xe)

	// Object Name: Function Skill.UTSkill.CanDisableTrigger
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CanDisableTrigger(); // Offset: 0x101d538d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkill.CanBePlayed
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	bool CanBePlayed(struct UUTSkillManagerComponent* SkillManagerComponent, bool bShowFailureMsg); // Offset: 0x101d5390c // Return & Params: Num(3) Size(0xa)
};

// Object Name: Class Skill.UTSkillBaseWidget
// Size: 0x48 // Inherited bytes: 0x28
struct UUTSkillBaseWidget : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	bool bWidgetEnabled; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // Offset: 0x34 // Size: 0x08
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct UActorComponent* CurOwnerActorComponent; // Offset: 0x40 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillBaseWidget.GetTargetActor
	// Flags: [Native|Public|HasOutParms]
	bool GetTargetActor(struct UUTSkillManagerComponent* SkillManagerComponent, struct TArray<struct TWeakObjectPtr<struct AActor>>& OutTargets); // Offset: 0x101d5a278 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Skill.UTSkillBaseWidget.GetOwnerPawn
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetOwnerPawn(); // Offset: 0x101d5a3ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillBaseWidget.GetOwnerCharacter
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetOwnerCharacter(); // Offset: 0x101d5a370 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Skill.UTSkillEffect
// Size: 0x50 // Inherited bytes: 0x48
struct UUTSkillEffect : UUTSkillBaseWidget {
	// Fields
	float fADScale; // Offset: 0x48 // Size: 0x04
	float fAPScale; // Offset: 0x4c // Size: 0x04

	// Functions

	// Object Name: Function Skill.UTSkillEffect.UpdateAction
	// Flags: [Native|Public]
	void UpdateAction(struct UUTSkillManagerComponent* SkillManagerComponent, float DeltaSeconds); // Offset: 0x101d5a97c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillEffect.UndoAction
	// Flags: [Native|Public]
	void UndoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d5aac8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillEffect.SetActionStart
	// Flags: [Native|Public]
	void SetActionStart(struct UUTSkillManagerComponent* SkillManagerComponent, bool bStart); // Offset: 0x101d5a7a4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillEffect.RecoverAction
	// Flags: [Native|Public]
	void RecoverAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d5a720 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillEffect.PhaseExit
	// Flags: [Native|Public]
	void PhaseExit(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d5a874 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillEffect.MainHandInterruptSkill
	// Flags: [Native|Public]
	void MainHandInterruptSkill(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d5aa44 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillEffect.DoHurtAppearance
	// Flags: [Native|Public]
	void DoHurtAppearance(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim); // Offset: 0x101d5abe0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillEffect.DoAction
	// Flags: [Native|Public]
	bool DoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d5ab4c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillEffect.CameraModeChangedEvent
	// Flags: [Native|Public]
	void CameraModeChangedEvent(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d5a8f8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Skill.UTSkillAction
// Size: 0x78 // Inherited bytes: 0x50
struct UUTSkillAction : UUTSkillEffect {
	// Fields
	struct FUTSkillActionCreateData BaseData; // Offset: 0x50 // Size: 0x0c
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	bool m_Inheritable; // Offset: 0x60 // Size: 0x01
	bool m_OverrideActionColor; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x2]; // Offset: 0x62 // Size: 0x02
	struct FLinearColor m_ActionColor; // Offset: 0x64 // Size: 0x10
	bool m_Disabled; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03

	// Functions

	// Object Name: Function Skill.UTSkillAction.UpdateActionBP
	// Flags: [Native|Event|Public|BlueprintEvent]
	void UpdateActionBP(struct UUTSkillManagerComponent* SkillManagerComponent, float DeltaSeconds); // Offset: 0x101d5487c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillAction.UpdateAction_Internal
	// Flags: [Native|Public]
	void UpdateAction_Internal(float DeltaSeconds); // Offset: 0x101d5465c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillAction.UndoActionBP
	// Flags: [Native|Event|Public|BlueprintEvent]
	void UndoActionBP(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d54944 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.UndoAction_Internal
	// Flags: [Native|Public]
	void UndoAction_Internal(); // Offset: 0x101d546e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillAction.ResetBP
	// Flags: [Native|Event|Public|BlueprintEvent]
	void ResetBP(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d547f8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.Reset_Internal
	// Flags: [Native|Public]
	void Reset_Internal(); // Offset: 0x101d54640 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillAction.Reset
	// Flags: [Final|Native|Public]
	void Reset(struct UActorComponent* SkillManagerComponent); // Offset: 0x101d54a5c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.RealDoActionBP
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool RealDoActionBP(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d549c8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillAction.RealDoAction_Internal
	// Flags: [Native|Public]
	bool RealDoAction_Internal(); // Offset: 0x101d546fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillAction.RealDoAction
	// Flags: [Native|Public]
	bool RealDoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d54ad8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillAction.PhaseExit_Internal
	// Flags: [Native|Public]
	void PhaseExit_Internal(); // Offset: 0x101d54624 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillAction.JudgeNeedPhaseWait
	// Flags: [Native|Public]
	bool JudgeNeedPhaseWait(); // Offset: 0x101d54738 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillAction.CameraModeChangedEventBP
	// Flags: [Native|Event|Public|BlueprintEvent]
	void CameraModeChangedEventBP(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d54774 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.CameraModeChangedEvent_Internal
	// Flags: [Native|Public]
	void CameraModeChangedEvent_Internal(); // Offset: 0x101d54608 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Skill.UTSkillCDBase
// Size: 0x58 // Inherited bytes: 0x28
struct UUTSkillCDBase : UObject {
	// Fields
	float FinishCountdown; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct UUTSkillManagerComponent* CurOwnerManager; // Offset: 0x30 // Size: 0x08
	struct AGameStateBase* CurGameState; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x18]; // Offset: 0x40 // Size: 0x18

	// Functions

	// Object Name: Function Skill.UTSkillCDBase.SetAvailableTimesRound
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAvailableTimesRound(int32_t Value); // Offset: 0x101d55820 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.SetAvailableTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAvailableTimes(int32_t Value); // Offset: 0x101d558b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.PlusRemainTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool PlusRemainTimes(bool bTimesForRound, int32_t Times); // Offset: 0x101d5569c // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Skill.UTSkillCDBase.HasRemainTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasRemainTimes(); // Offset: 0x101d55634 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillCDBase.GetThreshold
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetThreshold(); // Offset: 0x101d55970 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.GetRemainTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetRemainTimes(); // Offset: 0x101d55668 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.GetMaxEnergy
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxEnergy(); // Offset: 0x101d559e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.GetMaxAccumulateCount
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMaxAccumulateCount(); // Offset: 0x101d55934 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.GetCurrentPercent
	// Flags: [Native|Public|BlueprintCallable]
	float GetCurrentPercent(); // Offset: 0x101d55a24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.GetCurrentEnergy
	// Flags: [Native|Public|BlueprintCallable]
	float GetCurrentEnergy(); // Offset: 0x101d55a60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.GetCDDuration
	// Flags: [Native|Public|BlueprintCallable]
	float GetCDDuration(); // Offset: 0x101d559ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.GetAvailableTimesRound
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetAvailableTimesRound(); // Offset: 0x101d55804 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.GetAvailableTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetAvailableTimes(); // Offset: 0x101d5589c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillCDBase.DeductRemainTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DeductRemainTimes(int32_t Times); // Offset: 0x101d55778 // Return & Params: Num(2) Size(0x5)
};

// Object Name: Class Skill.UTSkillCD_EnergyOfSkill
// Size: 0x98 // Inherited bytes: 0x58
struct UUTSkillCD_EnergyOfSkill : UUTSkillCDBase {
	// Fields
	enum class ECDSpeedUpType CDSpeedUpType; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	float InitEnergy; // Offset: 0x5c // Size: 0x04
	float MaxEnergy; // Offset: 0x60 // Size: 0x04
	float CurEnergy; // Offset: 0x64 // Size: 0x04
	float DeltaEnergy; // Offset: 0x68 // Size: 0x04
	float InitEnergyFactor; // Offset: 0x6c // Size: 0x04
	float InitEnergyRespawnFactor; // Offset: 0x70 // Size: 0x04
	float InitEnergyRoundRestartFactor; // Offset: 0x74 // Size: 0x04
	float InitEnergyChangeLegendFactor; // Offset: 0x78 // Size: 0x04
	float InitEnergyColddownFactor; // Offset: 0x7c // Size: 0x04
	int32_t InitEnergyRespawnPolicy; // Offset: 0x80 // Size: 0x04
	int32_t InitEnergyRoundRestartPolicy; // Offset: 0x84 // Size: 0x04
	int32_t InitEnergyChangeLegendPolicy; // Offset: 0x88 // Size: 0x04
	int32_t InitEnergyColddownPolicy; // Offset: 0x8c // Size: 0x04
	char pad_0x90[0x8]; // Offset: 0x90 // Size: 0x08
};

// Object Name: Class Skill.UTSkillCD_CastEnergyBySkill
// Size: 0xa8 // Inherited bytes: 0x98
struct UUTSkillCD_CastEnergyBySkill : UUTSkillCD_EnergyOfSkill {
	// Fields
	enum class ECDCompare thresCompare; // Offset: 0x94 // Size: 0x01
	float Threshold; // Offset: 0x98 // Size: 0x04
	float castEnergy; // Offset: 0x9c // Size: 0x04
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
};

// Object Name: Class Skill.UTSkillCondition
// Size: 0x58 // Inherited bytes: 0x48
struct UUTSkillCondition : UUTSkillBaseWidget {
	// Fields
	struct TArray<enum class EUTSkillPhaseJumpResult> ErrorCode; // Offset: 0x48 // Size: 0x10

	// Functions

	// Object Name: Function Skill.UTSkillCondition.IsTargetOK
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool IsTargetOK(struct UActorComponent* SkillManagerComponent, struct AActor* Target); // Offset: 0x101d5995c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillCondition.IsOK_Internal
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent]
	bool IsOK_Internal(int32_t& SearchDepth); // Offset: 0x101d598b8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillCondition.IsOK
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	bool IsOK(struct UActorComponent* SkillManagerComponent, int32_t& SearchDepth); // Offset: 0x101d59a30 // Return & Params: Num(3) Size(0xd)
};

// Object Name: Class Skill.UTSkillEventEffectMapForEditor
// Size: 0x98 // Inherited bytes: 0x48
struct UUTSkillEventEffectMapForEditor : UUTSkillBaseWidget {
	// Fields
	enum class EUTSkillEventType SkillEventType; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
	struct TArray<struct FName> InterestedOwnerTags; // Offset: 0x50 // Size: 0x10
	struct UUTSkillEffect* SkillEffect; // Offset: 0x60 // Size: 0x08
	bool bSkipFollowingActions; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
	struct TArray<struct FSkillConditionWarpper> Conditions; // Offset: 0x70 // Size: 0x10
	struct TArray<struct FSkillConditionWarpper> TargetConditions; // Offset: 0x80 // Size: 0x10
	char pad_0x90[0x8]; // Offset: 0x90 // Size: 0x08
};

// Object Name: Class Skill.UTSkillInstancedNodeContainerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillInstancedNodeContainerInterface : UInterface {
};

// Object Name: Class Skill.UTSkillInstancedNodeInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillInstancedNodeInterface : UInterface {
};

// Object Name: Class Skill.UTSkillInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillInterface : UInterface {
	// Functions

	// Object Name: Function Skill.UTSkillInterface.TriggerEvent
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void TriggerEvent(int32_t SkillHandle, enum class EUTSkillEventType EventType); // Offset: 0x101d5c340 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillInterface.HandleSkillStart
	// Flags: [Native|Event|Public|BlueprintEvent]
	void HandleSkillStart(int32_t SkillID); // Offset: 0x101d5c2bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillInterface.HandleSkillEnd
	// Flags: [Native|Event|Public|BlueprintEvent]
	void HandleSkillEnd(int32_t SkillID, enum class EUTSkillStopReason Reason); // Offset: 0x101d5c1f4 // Return & Params: Num(2) Size(0x5)
};

// Object Name: Class Skill.UTSkillLocationPicker
// Size: 0x48 // Inherited bytes: 0x48
struct UUTSkillLocationPicker : UUTSkillBaseWidget {
	// Functions

	// Object Name: Function Skill.UTSkillLocationPicker.PickLocation
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	bool PickLocation(struct AActor* OwnerPawn, struct FVector& OutLocation, struct FRotator& OutRotation); // Offset: 0x101d5c9b0 // Return & Params: Num(4) Size(0x21)
};

// Object Name: Class Skill.UTSkillManagerComponent
// Size: 0xa10 // Inherited bytes: 0xf0
struct UUTSkillManagerComponent : UActorComponent {
	// Fields
	char pad_0xF0[0x8]; // Offset: 0xf0 // Size: 0x08
	struct UDataTable* SkillsTable; // Offset: 0xf8 // Size: 0x08
	struct UDataTable* CommonSkillsTable; // Offset: 0x100 // Size: 0x08
	bool bHasInitSkillArchetypes; // Offset: 0x108 // Size: 0x01
	char pad_0x109[0x7]; // Offset: 0x109 // Size: 0x07
	struct TArray<struct TSoftClassPtr<UObject>> SkillArchetypesFromSkillsTable; // Offset: 0x110 // Size: 0x10
	bool isNeedCheckValidation; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x7]; // Offset: 0x121 // Size: 0x07
	struct TArray<struct AUTSkill*> Skills; // Offset: 0x128 // Size: 0x10
	struct TArray<struct UUAEUserWidget*> SkillAsyncLoaded; // Offset: 0x138 // Size: 0x10
	struct UUAEUserWidget* SkillUIRoot; // Offset: 0x148 // Size: 0x08
	struct TMap<struct AUTSkill*, int32_t> SkillToIndexMap; // Offset: 0x150 // Size: 0x50
	struct TMap<enum class ESkillType, int32_t> SkillTypeToIndexMap; // Offset: 0x1a0 // Size: 0x50
	struct TMap<struct AUTSkill*, int32_t> SkillCurPhaseIndexes; // Offset: 0x1f0 // Size: 0x50
	char pad_0x240[0x8]; // Offset: 0x240 // Size: 0x08
	struct TMap<int32_t, int32_t> SkillHandleToIndexMap; // Offset: 0x248 // Size: 0x50
	struct TMap<int32_t, int32_t> SkillIndexToHandleMap; // Offset: 0x298 // Size: 0x50
	struct TMap<int32_t, struct FUTSkillCreateData> SkillHandleToBaseData; // Offset: 0x2e8 // Size: 0x50
	struct TSet<int32_t> CastingSkillIndexes; // Offset: 0x338 // Size: 0x50
	struct AActor* Target; // Offset: 0x388 // Size: 0x08
	struct TArray<struct AActor*> SkillActorList; // Offset: 0x390 // Size: 0x10
	struct TArray<struct AActor*> PausedSkillActorList; // Offset: 0x3a0 // Size: 0x10
	struct TArray<struct FUTSkillSynData> SkillSynData; // Offset: 0x3b0 // Size: 0x10
	struct FUTSkillPhaseJumpResult SkillPhaseJumpResult; // Offset: 0x3c0 // Size: 0x08
	float PredictSkillDiscordCorrectionTime; // Offset: 0x3c8 // Size: 0x04
	char pad_0x3CC[0x54]; // Offset: 0x3cc // Size: 0x54
	struct FMulticastInlineDelegate OnSkillHit; // Offset: 0x420 // Size: 0x10
	char pad_0x430[0x1]; // Offset: 0x430 // Size: 0x01
	bool bDisableTriggerSkill; // Offset: 0x431 // Size: 0x01
	char pad_0x432[0x26]; // Offset: 0x432 // Size: 0x26
	struct FUTSkillHitEnvInfo SkillHitEnvInfo; // Offset: 0x458 // Size: 0x30
	struct TArray<struct FString> MutexMontageGroupBeenPlayed; // Offset: 0x488 // Size: 0x10
	struct FUTSkillHitInfo SkillHitInfo; // Offset: 0x498 // Size: 0x30
	char pad_0x4C8[0x8]; // Offset: 0x4c8 // Size: 0x08
	struct FString LastESkillTargetDesc; // Offset: 0x4d0 // Size: 0x10
	struct TMap<struct FString, struct FTimerHandle> SkillTimerMap; // Offset: 0x4e0 // Size: 0x50
	bool bDebugSkillInfo; // Offset: 0x530 // Size: 0x01
	char pad_0x531[0x17]; // Offset: 0x531 // Size: 0x17
	struct TMap<int32_t, struct USkillTriggerBase*> SkillTriggerMap; // Offset: 0x548 // Size: 0x50
	struct TArray<struct FUTAddedSkillSturct> LoadingSkillStructList; // Offset: 0x598 // Size: 0x10
	struct TArray<int32_t> PendingRemoveSkillHandles; // Offset: 0x5a8 // Size: 0x10
	struct TArray<struct FUTAddedSkillSturct> RepAddedSkillStructList; // Offset: 0x5b8 // Size: 0x10
	struct FString RepSkillDebugInfo; // Offset: 0x5c8 // Size: 0x10
	struct FString RepSkillSynInfo; // Offset: 0x5d8 // Size: 0x10
	struct FMulticastInlineDelegate OnSkillCast; // Offset: 0x5e8 // Size: 0x10
	struct FMulticastInlineDelegate OnKeyDownDelegate; // Offset: 0x5f8 // Size: 0x10
	struct FMulticastInlineDelegate SkillStopEvent; // Offset: 0x608 // Size: 0x10
	struct FMulticastInlineDelegate StartSkillFailedEvent; // Offset: 0x618 // Size: 0x10
	struct FMulticastInlineDelegate SkillStartEvent; // Offset: 0x628 // Size: 0x10
	struct FMulticastInlineDelegate SkillReleasedEvent; // Offset: 0x638 // Size: 0x10
	char pad_0x648[0x30]; // Offset: 0x648 // Size: 0x30
	struct FMulticastInlineDelegate SkillInitEvent; // Offset: 0x678 // Size: 0x10
	struct FMulticastInlineDelegate SkillUnInitEvent; // Offset: 0x688 // Size: 0x10
	struct FMulticastInlineDelegate DisableTriggerSkillEvent; // Offset: 0x698 // Size: 0x10
	struct FMulticastInlineDelegate EnableTriggerSkillEvent; // Offset: 0x6a8 // Size: 0x10
	char pad_0x6B8[0x8]; // Offset: 0x6b8 // Size: 0x08
	struct TMap<struct FName, int32_t> TriggerConditionMap; // Offset: 0x6c0 // Size: 0x50
	struct TMap<struct FName, struct AUTSkill*> TriggerSkillMap; // Offset: 0x710 // Size: 0x50
	struct TMap<struct FName, struct AUTSkill*> TriggerCancelSkillMap; // Offset: 0x760 // Size: 0x50
	struct TArray<struct AUTSkill*> PendingPassiveSkills; // Offset: 0x7b0 // Size: 0x10
	struct TMap<struct TWeakObjectPtr<struct UObject>, struct FSkillModifierList> SkillModifierLookupTable; // Offset: 0x7c0 // Size: 0x50
	struct TMap<struct FSkillModifierDesc, struct FSkillModifierCalculator> SkillAttributeModifiers; // Offset: 0x810 // Size: 0x50
	char pad_0x860[0x68]; // Offset: 0x860 // Size: 0x68
	bool bHasInitInFightStage; // Offset: 0x8c8 // Size: 0x01
	char pad_0x8C9[0x7]; // Offset: 0x8c9 // Size: 0x07
	struct FMulticastInlineDelegate SkillCDInitFinishedEvent; // Offset: 0x8d0 // Size: 0x10
	struct FMulticastInlineDelegate SkillStartCDEvent; // Offset: 0x8e0 // Size: 0x10
	struct FMulticastInlineDelegate SkillModifyCDEvent; // Offset: 0x8f0 // Size: 0x10
	struct TArray<struct FSkillCDSyncData> SkillsCDSyncData; // Offset: 0x900 // Size: 0x10
	char pad_0x910[0x8]; // Offset: 0x910 // Size: 0x08
	struct TMap<int32_t, struct FPredcitionData> SkillsPredictionData; // Offset: 0x918 // Size: 0x50
	char pad_0x968[0xa8]; // Offset: 0x968 // Size: 0xa8

	// Functions

	// Object Name: Function Skill.UTSkillManagerComponent.UpdateSkillCDState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateSkillCDState(bool bCanUpdate); // Offset: 0x101d5dd78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.TriggerEventByType
	// Flags: [Native|Public|BlueprintCallable]
	bool TriggerEventByType(enum class ESkillType SkillType, enum class EUTSkillEventType EventType, int32_t TriggerIndex); // Offset: 0x101d60414 // Return & Params: Num(4) Size(0x9)

	// Object Name: Function Skill.UTSkillManagerComponent.TriggerEvent
	// Flags: [Native|Public|BlueprintCallable]
	bool TriggerEvent(int32_t SkillID, enum class EUTSkillEventType EventType, int32_t TriggerIndex); // Offset: 0x101d6063c // Return & Params: Num(4) Size(0xd)

	// Object Name: Function Skill.UTSkillManagerComponent.TraceTarget
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	bool TraceTarget(struct FVector StartTrace, struct FVector EndTrace, enum class UTPickerTargetType TargetType, float Radius, struct AActor*& TargetActor); // Offset: 0x101d5edd0 // Return & Params: Num(6) Size(0x29)

	// Object Name: Function Skill.UTSkillManagerComponent.SwitchSkill
	// Flags: [Native|Public]
	void SwitchSkill(int32_t SkillID, enum class EUTSkillEventType EventType); // Offset: 0x101d60150 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillWithID
	// Flags: [Native|Public|BlueprintCallable]
	bool StopSkillWithID(int32_t SkillID, enum class EUTSkillStopReason StopReason, bool bCheckEnableBackSwing); // Offset: 0x101d6002c // Return & Params: Num(4) Size(0x7)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillSpecific
	// Flags: [Final|Native|Public]
	void StopSkillSpecific(struct AUTSkill* Skill, enum class EUTSkillStopReason Reason, bool bCheckEnableBackSwing); // Offset: 0x101d5fcfc // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillOnDisconnected
	// Flags: [Native|Public]
	void StopSkillOnDisconnected(); // Offset: 0x101d5fe54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillAll
	// Flags: [Native|Public]
	void StopSkillAll(enum class EUTSkillStopReason StopReason, bool bCheckEnableBackSwing); // Offset: 0x101d5ff5c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Skill.UTSkillManagerComponent.ShouldTriggerEvent
	// Flags: [Native|Public|BlueprintCallable]
	bool ShouldTriggerEvent(int32_t SkillID, enum class EUTSkillEventType EventType); // Offset: 0x101d5e768 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Skill.UTSkillManagerComponent.SetTarget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTarget(struct AActor* InTarget); // Offset: 0x101d60d38 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillCurPhase
	// Flags: [Native|Public]
	void SetSkillCurPhase(struct AUTSkill* Skill, int32_t PhaseIndex); // Offset: 0x101d60774 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillCastingState
	// Flags: [Native|Public|BlueprintCallable]
	void SetSkillCastingState(int32_t SkillIndex, bool bCasting); // Offset: 0x101d5e8fc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.SetPredictionDataBaseKey
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetPredictionDataBaseKey(int32_t SkillID); // Offset: 0x101d5d8d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.SetHasInitSkillSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHasInitSkillSystem(bool hasInit); // Offset: 0x101d5e85c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerOnWillEnterBackground
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerOnWillEnterBackground(); // Offset: 0x101d5fe24 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerMarkCDSyncStateDirty
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerMarkCDSyncStateDirty(); // Offset: 0x101d5dd5c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerInitOneSkill
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerInitOneSkill(struct TSoftClassPtr<UObject> SkillClass, int32_t SkillIndex, int32_t SkillHandle); // Offset: 0x101d5f5d8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerDeleteSkill
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerDeleteSkill(int32_t SkillID); // Offset: 0x101d5faac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.RepSkillSynData
	// Flags: [Native|Public|BlueprintCallable]
	void RepSkillSynData(struct TArray<struct FUTSkillSynData> originList); // Offset: 0x101d5ecf0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.RepSkillPhaseJumpResult
	// Flags: [Native|Public]
	void RepSkillPhaseJumpResult(); // Offset: 0x101d5e9dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.RepSkillHitInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RepSkillHitInfo(); // Offset: 0x101d5e9c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.RefreshSkillCDSyncData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshSkillCDSyncData(); // Offset: 0x101d5db8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.PlayHurtSkillEffect
	// Flags: [Native|Public]
	void PlayHurtSkillEffect(struct FUTSkillHitInfo TheSkillHitInfo); // Offset: 0x101d5f3ac // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Skill.UTSkillManagerComponent.OnWillEnterBackground
	// Flags: [Final|Native|Public]
	void OnWillEnterBackground(); // Offset: 0x101d5fe40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnSameTeam
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool OnSameTeam(struct AActor* A, struct AActor* B); // Offset: 0x101d5f2f0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillHitInfo
	// Flags: [Native|Public]
	void OnRep_SkillHitInfo(); // Offset: 0x101d5e840 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_HasInitInFightStage
	// Flags: [Native|Protected]
	void OnRep_HasInitInFightStage(); // Offset: 0x101d5e1c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_CDSyncData
	// Flags: [Final|Native|Protected]
	void OnRep_CDSyncData(); // Offset: 0x101d5da40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_AddedSkillList
	// Flags: [Final|Native|Public]
	void OnRep_AddedSkillList(struct TArray<struct FUTAddedSkillSturct> originList); // Offset: 0x101d5e26c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.OnAsyncLoadFinishedByItem
	// Flags: [Final|Native|Public]
	void OnAsyncLoadFinishedByItem(int32_t SkillHandle); // Offset: 0x101d5e5c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.OnAsyncLoadFinishByOnRepSkill
	// Flags: [Final|Native|Public]
	void OnAsyncLoadFinishByOnRepSkill(struct FUTSkillSynData CurSynData, struct FUTSkillSynData LastSynData, bool bFirstRep); // Offset: 0x101d5e3fc // Return & Params: Num(3) Size(0x41)

	// Object Name: Function Skill.UTSkillManagerComponent.OnAsyncLoadFinishByInitSkill
	// Flags: [Native|Public]
	void OnAsyncLoadFinishByInitSkill(int32_t SkillIndex); // Offset: 0x101d5e540 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.K2_AddNewPhasePredictionKey
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void K2_AddNewPhasePredictionKey(int32_t SkillID, int32_t RepPhaseID); // Offset: 0x101d5d984 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.IsReadyToCastSkill
	// Flags: [Native|Public|BlueprintCallable]
	bool IsReadyToCastSkill(int32_t SkillID); // Offset: 0x101d5fa18 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsHasInitSkillSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsHasInitSkillSystem(); // Offset: 0x101d5e8e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.IsDisableTriggerSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDisableTriggerSkill(); // Offset: 0x101d602e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCastingSkillOfSkillType
	// Flags: [Native|Public]
	bool IsCastingSkillOfSkillType(enum class ESkillType SkillType); // Offset: 0x101d5f948 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCastingSkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsCastingSkillID(int32_t SkillID); // Offset: 0x101d5f8bc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCastingSkillHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsCastingSkillHandle(int32_t SkillHandle); // Offset: 0x101d5f830 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCastingSkill
	// Flags: [Native|Public]
	bool IsCastingSkill(); // Offset: 0x101d5f9dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.InternalCallClientPredictFailed
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void InternalCallClientPredictFailed(int32_t SkillID); // Offset: 0x101d5d854 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.InitSkillUIs
	// Flags: [Native|Public]
	void InitSkillUIs(); // Offset: 0x101d60c04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.InitSkillUI
	// Flags: [Native|Public|BlueprintCallable]
	void InitSkillUI(int32_t SkillIndex); // Offset: 0x101d60c20 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.InitSkillSystem
	// Flags: [Native|Public|BlueprintCallable]
	void InitSkillSystem(bool isDedicateServer, bool IsBroadcastFromParent, bool IsBroadcastToParent); // Offset: 0x101d5f6fc // Return & Params: Num(3) Size(0x3)

	// Object Name: Function Skill.UTSkillManagerComponent.InitSkillComponent
	// Flags: [Native|Public|BlueprintCallable]
	void InitSkillComponent(); // Offset: 0x101d60758 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.GetTarget
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AActor* GetTarget(); // Offset: 0x101d60db0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillTypeBySkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ESkillType GetSkillTypeBySkillID(int32_t SkillID); // Offset: 0x101d60388 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillPhaseDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetSkillPhaseDuration(int32_t SkillIndex, int32_t PhaseIndex); // Offset: 0x101d60dcc // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillPhase
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetSkillPhase(int32_t SkillIndex); // Offset: 0x101d5f054 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillNextPhase
	// Flags: [Final|Native|Public]
	int32_t GetSkillNextPhase(struct AUTSkill* Skill); // Offset: 0x101d6083c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSkillName(int32_t SkillIndex); // Offset: 0x101d60e98 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillIDByHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetSkillIDByHandle(int32_t SkillHandle); // Offset: 0x101d5e6dc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillHandleBySkillIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetSkillHandleBySkillIndex(int32_t SkillIndex); // Offset: 0x101d60f6c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillCurPhase
	// Flags: [Final|Native|Public]
	int32_t GetSkillCurPhase(struct AUTSkill* Skill); // Offset: 0x101d608c8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillByName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkillByName(struct FString SkillName); // Offset: 0x101d5f0e0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillByHandle
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkillByHandle(int32_t SkillHandle); // Offset: 0x101d5f1c8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillBaseDataBySkillIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FUTSkillCreateData GetSkillBaseDataBySkillIndex(int32_t SkillIndex); // Offset: 0x101d60ff8 // Return & Params: Num(2) Size(0xd8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillBaseDataByHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FUTSkillCreateData GetSkillBaseDataByHandle(int32_t SkillHandle); // Offset: 0x101d61200 // Return & Params: Num(2) Size(0xd8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetSkillActors(struct AActor* MatchClass, struct TArray<struct AActor*>& OutActors); // Offset: 0x101d5ddfc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillActorList_Mutable
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct AActor*> GetSkillActorList_Mutable(); // Offset: 0x101d60a5c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillActorList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct AActor*> GetSkillActorList(); // Offset: 0x101d60ae0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillActorByTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AActor* GetSkillActorByTag(struct FName TagName); // Offset: 0x101d602fc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetSkillActor(struct AActor* MatchClass); // Offset: 0x101d5e038 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkill(int32_t SkillID); // Offset: 0x101d5f25c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetPausedSkillActorList_Mutable
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct AActor*> GetPausedSkillActorList_Mutable(); // Offset: 0x101d60954 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetPausedSkillActorList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct AActor*> GetPausedSkillActorList(); // Offset: 0x101d609d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetCurSkillIndex(struct AUTSkill* Skill); // Offset: 0x101d61320 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillHandle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetCurSkillHandle(struct AUTSkill* Skill); // Offset: 0x101d61294 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCharacterAbilityCDThresholdScale
	// Flags: [Native|Public]
	float GetCharacterAbilityCDThresholdScale(enum class ECDSpeedUpType SpeedUpType); // Offset: 0x101d5dc34 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCharacterAbilityCDSpeedScale
	// Flags: [Native|Public]
	float GetCharacterAbilityCDSpeedScale(enum class ECDSpeedUpType SpeedUpType); // Offset: 0x101d5dcc8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCharacterAbilityCDCastScale
	// Flags: [Native|Public]
	float GetCharacterAbilityCDCastScale(enum class ECDSpeedUpType SpeedUpType); // Offset: 0x101d5dba0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCastingSkillAndSkillIndex
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct AUTSkill* GetCastingSkillAndSkillIndex(int32_t& SkillIndex); // Offset: 0x101d5ef84 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCastingSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AUTSkill* GetCastingSkill(); // Offset: 0x101d5f020 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.ForceSyncCDState
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ForceSyncCDState(struct TArray<struct FSkillCDSyncData> CDSyncData); // Offset: 0x101d5da54 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.EnableTriggerSkillAll
	// Flags: [Native|Public|BlueprintCallable]
	void EnableTriggerSkillAll(); // Offset: 0x101d5fe70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.DisableTriggerSkillAll
	// Flags: [Native|Public|BlueprintCallable]
	void DisableTriggerSkillAll(enum class EUTSkillStopReason StopReason, bool bCheckEnableBackSwing); // Offset: 0x101d5fe8c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Skill.UTSkillManagerComponent.DeleteSkillUIs
	// Flags: [Native|Public]
	void DeleteSkillUIs(); // Offset: 0x101d60b64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.DeleteSkillUI
	// Flags: [Native|Public]
	void DeleteSkillUI(int32_t SkillIndex); // Offset: 0x101d60b80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.DeleteSkill
	// Flags: [Native|Public]
	void DeleteSkill(int32_t SkillID); // Offset: 0x101d5fbb4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ClientPlayHurtMontage
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults]
	void ClientPlayHurtMontage(struct FSoftObjectPath MontagePath); // Offset: 0x101d60ca4 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.ClientMulticastDeleteSkill
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void ClientMulticastDeleteSkill(int32_t SkillID); // Offset: 0x101d5fb30 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ClientInitOneSkill
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void ClientInitOneSkill(struct TSoftClassPtr<UObject> SkillClass, int32_t SkillIndex, int32_t SkillHandle); // Offset: 0x101d5f4b4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Skill.UTSkillManagerComponent.ClientCallTriggerEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientCallTriggerEvent(int32_t SkillID, enum class EUTSkillEventType EventType, int32_t TriggerIndex); // Offset: 0x101d60530 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.ClearSkillActor
	// Flags: [Native|Public]
	void ClearSkillActor(); // Offset: 0x101d5fc38 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ClearSkill
	// Flags: [Native|Public]
	void ClearSkill(); // Offset: 0x101d5fc54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.Clear
	// Flags: [Native|Public]
	void Clear(bool bClearSkillActor); // Offset: 0x101d5fc70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.CheckSkillCDFinish
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CheckSkillCDFinish(int32_t SkillCD); // Offset: 0x101d5db00 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.CheckServerCDState
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void CheckServerCDState(); // Offset: 0x101d5dae4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.CameraModeChangedEvent
	// Flags: [Native|Public]
	void CameraModeChangedEvent(); // Offset: 0x101d5fe08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.CalculateRepUndoPhaseIdx
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CalculateRepUndoPhaseIdx(struct TArray<int32_t>& LastDonePhaseIds, struct TArray<int32_t>& CurDonePhaseIds, struct TArray<int32_t>& UndoPhaseIds); // Offset: 0x101d5e9f8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Skill.UTSkillManagerComponent.CalculateLocallyControlledUndoPhaseIdx
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CalculateLocallyControlledUndoPhaseIdx(struct TArray<int32_t>& LastDonePhaseIds, struct TArray<int32_t>& CurDonePhaseIds, struct TArray<int32_t>& UndoPhaseIds, int32_t SkillIndex); // Offset: 0x101d5eb50 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Skill.UTSkillManagerComponent.BeginAddSkillByItemAsync
	// Flags: [Final|Native|Public|HasOutParms]
	void BeginAddSkillByItemAsync(struct FUTAddedSkillSturct& temp); // Offset: 0x101d5e640 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.BackpackLoadSkillItemForAutoUse
	// Flags: [Final|Native|Public]
	bool BackpackLoadSkillItemForAutoUse(int32_t SkillIndex); // Offset: 0x101d5e1e0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.AddSkillEventCache
	// Flags: [Native|Public]
	void AddSkillEventCache(enum class EUTSkillEventType InSkillEventType, struct UUTSkillManagerComponent* EventOrigin); // Offset: 0x101d60218 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Skill.UTSkillPhase
// Size: 0x208 // Inherited bytes: 0xf0
struct UUTSkillPhase : UActorComponent {
	// Fields
	char pad_0xF0[0x8]; // Offset: 0xf0 // Size: 0x08
	int32_t PhaseIndex; // Offset: 0xf8 // Size: 0x04
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
	struct FString PhaseName; // Offset: 0x100 // Size: 0x10
	struct FString PhaseDescription; // Offset: 0x110 // Size: 0x10
	struct FName PhaseTag; // Offset: 0x120 // Size: 0x08
	bool bDeserializeComplete; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x3]; // Offset: 0x129 // Size: 0x03
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // Offset: 0x12c // Size: 0x08
	char pad_0x134[0x4]; // Offset: 0x134 // Size: 0x04
	struct FUTSkillPhaseCreateData BaseData; // Offset: 0x138 // Size: 0xc8
	struct UUTSkillPicker* InEffectPickerOnAction; // Offset: 0x200 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillPhase.StopPhase
	// Flags: [Native|Public]
	bool StopPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d67b4c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillPhase.StartPhase
	// Flags: [Native|Public]
	void StartPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d67c64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.RecoverPhase
	// Flags: [Native|Public]
	void RecoverPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d67ac8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.PlaySkillHurtEffect
	// Flags: [Native|Public]
	bool PlaySkillHurtEffect(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim); // Offset: 0x101d67970 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillPhase.PlaySkillHurtAppearances
	// Flags: [Native|Public]
	bool PlaySkillHurtAppearances(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim); // Offset: 0x101d6789c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillPhase.PickTargets
	// Flags: [Native|Public]
	void PickTargets(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d67be0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.OnEvent
	// Flags: [Native|Public]
	bool OnEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class EUTSkillEventType TheEventType, struct UUTSkillManagerComponent* EventOrigin); // Offset: 0x101d67e04 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Skill.UTSkillPhase.OnCustomEvent
	// Flags: [Native|Public]
	bool OnCustomEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class EUTSkillEventType TheEventType, struct UUTSkillManagerComponent* EventOrigin); // Offset: 0x101d67ce8 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Skill.UTSkillPhase.GetPhaseSpeed
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetPhaseSpeed(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d67750 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillPhase.GetPhaseDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetPhaseDuration(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d677dc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillPhase.ForceExecutePhase
	// Flags: [Native|Public]
	void ForceExecutePhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x101d67a44 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.ClearAttachments
	// Flags: [Final|Native|Public]
	bool ClearAttachments(); // Offset: 0x101d67868 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Skill.UTSkillPicker
// Size: 0x88 // Inherited bytes: 0x48
struct UUTSkillPicker : UUTSkillBaseWidget {
	// Fields
	struct FUTSkillPickerCreateData BaseData; // Offset: 0x48 // Size: 0x0c
	char pad_0x54[0xc]; // Offset: 0x54 // Size: 0x0c
	struct TArray<struct FUTSkillPickedTarget> PickedResultTargets; // Offset: 0x60 // Size: 0x10
	struct TArray<struct TWeakObjectPtr<struct AActor>> IgnoreTargets; // Offset: 0x70 // Size: 0x10
	char pad_0x80[0x8]; // Offset: 0x80 // Size: 0x08
};

// Object Name: Class Skill.UTSkillWidget
// Size: 0x398 // Inherited bytes: 0x388
struct UUTSkillWidget : UUAEUserWidget {
	// Fields
	struct UUTSkillManagerComponent* skillManager; // Offset: 0x388 // Size: 0x08
	int32_t SkillHandle; // Offset: 0x390 // Size: 0x04
	int32_t SkillUIID; // Offset: 0x394 // Size: 0x04

	// Functions

	// Object Name: Function Skill.UTSkillWidget.TriggerEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TriggerEvent(enum class EUTSkillEventType SkillEvent); // Offset: 0x101d69508 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillWidget.SetSkillUIID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillUIID(int32_t ID); // Offset: 0x101d69680 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillWidget.SetSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillManager(struct UUTSkillManagerComponent* manager); // Offset: 0x101d69490 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.SetSkillHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillHandle(int32_t Handle); // Offset: 0x101d69818 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillWidget.RemoveFromUIManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveFromUIManager(); // Offset: 0x101d689fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillWidget.GetSkillUIID
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetSkillUIID(); // Offset: 0x101d6964c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillWidget.GetSkillName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetSkillName(); // Offset: 0x101d68ed0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillWidget.GetSkillManger
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUTSkillManagerComponent* GetSkillManger(); // Offset: 0x101d69474 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.GetSkillIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetSkillIndex(); // Offset: 0x101d696fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillWidget.GetSkillHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetSkillHandle(); // Offset: 0x101d697fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillWidget.GetSkillCDProgess
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<float> GetSkillCDProgess(); // Offset: 0x101d69014 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillWidget.GetSkillCDByType
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<float> GetSkillCDByType(int32_t Type); // Offset: 0x101d691a8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillWidget.GetSkillCDBases
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct UUTSkillCDBase*> GetSkillCDBases(); // Offset: 0x101d69398 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillWidget.GetSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkill(); // Offset: 0x101d697b4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.GetMaxEnergy
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetMaxEnergy(int32_t Index); // Offset: 0x101d68a4c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.GetEnergyValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetEnergyValue(int32_t Index); // Offset: 0x101d68e0c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.GetEnergyThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetEnergyThreshold(int32_t Index); // Offset: 0x101d68c2c // Return & Params: Num(2) Size(0x8)
};

