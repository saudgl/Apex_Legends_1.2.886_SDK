#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Bp_CommonMediaWithSubtitle.Bp_CommonMediaWithSubtitle_C
// Size: 0x3ec // Inherited bytes: 0x240
struct UBp_CommonMediaWithSubtitle_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x240 // Size: 0x08
	struct UImage* MovieBg; // Offset: 0x248 // Size: 0x08
	struct UImage* MovieCover; // Offset: 0x250 // Size: 0x08
	struct UImage* MovieImage; // Offset: 0x258 // Size: 0x08
	struct UTextBlock* SubtitleText; // Offset: 0x260 // Size: 0x08
	struct UAkComponent* AkComponent; // Offset: 0x268 // Size: 0x08
	struct UMediaPlayer* MediaPlayer; // Offset: 0x270 // Size: 0x08
	int32_t VideoId; // Offset: 0x278 // Size: 0x04
	bool Looping; // Offset: 0x27c // Size: 0x01
	char pad_0x27D[0x3]; // Offset: 0x27d // Size: 0x03
	struct FVector2D MovieImageAlignment; // Offset: 0x280 // Size: 0x08
	struct FAnchors MovieImageAnchors; // Offset: 0x288 // Size: 0x10
	struct FVector2D MovieImageSize; // Offset: 0x298 // Size: 0x08
	struct FVector2D MovieImagePosition; // Offset: 0x2a0 // Size: 0x08
	struct FVector2D SubtitleTextAlignment; // Offset: 0x2a8 // Size: 0x08
	struct FAnchors SubtitleTextAnchors; // Offset: 0x2b0 // Size: 0x10
	struct FVector2D SubtitleTextSize; // Offset: 0x2c0 // Size: 0x08
	struct FVector2D SubtitleTextPosition; // Offset: 0x2c8 // Size: 0x08
	struct FSlateColor SubtitleTextColorAndOpacity; // Offset: 0x2d0 // Size: 0x28
	struct FSlateFontInfo SubtitleTextFont; // Offset: 0x2f8 // Size: 0x50
	struct FSlateBrush SubtitleTextStrikeBrush; // Offset: 0x348 // Size: 0x88
	struct FLinearColor SubtitleTextShadowColorAndOpacity; // Offset: 0x3d0 // Size: 0x10
	struct FVector2D SubtitleTextShadowOffset; // Offset: 0x3e0 // Size: 0x08
	enum class ETextJustify SubtitleTextJustification; // Offset: 0x3e8 // Size: 0x01
	enum class ESlateVisibility SubtitleTextVisible; // Offset: 0x3e9 // Size: 0x01
	enum class ESlateVisibility MovieImageVisible; // Offset: 0x3ea // Size: 0x01
	enum class ESlateVisibility MovieBgVisible; // Offset: 0x3eb // Size: 0x01

	// Functions

	// Object Name: Function Bp_CommonMediaWithSubtitle.Bp_CommonMediaWithSubtitle_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Bp_CommonMediaWithSubtitle.Bp_CommonMediaWithSubtitle_C.GetTotalMilliseconds
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetTotalMilliseconds(float& TotalMilliseconds); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Bp_CommonMediaWithSubtitle.Bp_CommonMediaWithSubtitle_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnInitialized(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Bp_CommonMediaWithSubtitle.Bp_CommonMediaWithSubtitle_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Bp_CommonMediaWithSubtitle.Bp_CommonMediaWithSubtitle_C.ExecuteUbergraph_Bp_CommonMediaWithSubtitle
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Bp_CommonMediaWithSubtitle(int32_t EntryPoint); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)
};

