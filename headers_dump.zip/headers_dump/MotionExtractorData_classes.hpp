#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MotionExtractorData.MotionExtractorDataAsset
// Size: 0x40 // Inherited bytes: 0x30
struct UMotionExtractorDataAsset : UDataAsset {
	// Fields
	struct UCurveVector* MotionMovementCurve; // Offset: 0x30 // Size: 0x08
	float EndRotationYaw; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04

	// Functions

	// Object Name: Function MotionExtractorData.MotionExtractorDataAsset.ImportCurve
	// Flags: [Final|Native|Public]
	void ImportCurve(); // Offset: 0x101dfbea4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MotionExtractorData.MotionExtractorDataAsset.ExportCurve
	// Flags: [Final|Native|Public]
	void ExportCurve(); // Offset: 0x101dfbeb8 // Return & Params: Num(0) Size(0x0)
};

