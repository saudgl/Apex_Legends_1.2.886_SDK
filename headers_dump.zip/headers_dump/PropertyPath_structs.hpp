#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct PropertyPath.CachedPropertyPath
// Size: 0x28 // Inherited bytes: 0x00
struct FCachedPropertyPath {
	// Fields
	struct TArray<struct FPropertyPathSegment> Segments; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
	struct UFunction* CachedFunction; // Offset: 0x18 // Size: 0x08
	char pad_0x20[0x8]; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct PropertyPath.PropertyPathSegment
// Size: 0x28 // Inherited bytes: 0x00
struct FPropertyPathSegment {
	// Fields
	struct FName Name; // Offset: 0x00 // Size: 0x08
	int32_t ArrayIndex; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct UStruct* Struct; // Offset: 0x10 // Size: 0x08
	char pad_0x18[0x10]; // Offset: 0x18 // Size: 0x10
};

