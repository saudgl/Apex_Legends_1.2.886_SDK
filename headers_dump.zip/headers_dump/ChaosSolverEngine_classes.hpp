#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ChaosSolverEngine.ChaosEventListenerComponent
// Size: 0xf8 // Inherited bytes: 0xf0
struct UChaosEventListenerComponent : UActorComponent {
	// Fields
	char pad_0xF0[0x8]; // Offset: 0xf0 // Size: 0x08
};

// Object Name: Class ChaosSolverEngine.ChaosGameplayEventDispatcher
// Size: 0x260 // Inherited bytes: 0xf8
struct UChaosGameplayEventDispatcher : UChaosEventListenerComponent {
	// Fields
	char pad_0xF8[0xc0]; // Offset: 0xf8 // Size: 0xc0
	struct TMap<struct UPrimitiveComponent*, struct FChaosHandlerSet> CollisionEventRegistrations; // Offset: 0x1b8 // Size: 0x50
	struct TMap<struct UPrimitiveComponent*, struct FBreakEventCallbackWrapper> BreakEventRegistrations; // Offset: 0x208 // Size: 0x50
	char pad_0x258[0x8]; // Offset: 0x258 // Size: 0x08
};

// Object Name: Class ChaosSolverEngine.ChaosNotifyHandlerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UChaosNotifyHandlerInterface : UInterface {
};

// Object Name: Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UChaosSolverEngineBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FHitResult ConvertPhysicsCollisionToHitResult(struct FChaosPhysicsCollisionInfo& PhysicsCollision); // Offset: 0x104fe7858 // Return & Params: Num(2) Size(0xf8)
};

// Object Name: Class ChaosSolverEngine.ChaosSolver
// Size: 0x28 // Inherited bytes: 0x28
struct UChaosSolver : UObject {
};

// Object Name: Class ChaosSolverEngine.ChaosSolverActor
// Size: 0x2d8 // Inherited bytes: 0x268
struct AChaosSolverActor : AActor {
	// Fields
	float TimeStepMultiplier; // Offset: 0x268 // Size: 0x04
	int32_t CollisionIterations; // Offset: 0x26c // Size: 0x04
	int32_t PushOutIterations; // Offset: 0x270 // Size: 0x04
	int32_t PushOutPairIterations; // Offset: 0x274 // Size: 0x04
	float ClusterConnectionFactor; // Offset: 0x278 // Size: 0x04
	enum class EClusterConnectionTypeEnum ClusterUnionConnectionType; // Offset: 0x27c // Size: 0x01
	bool DoGenerateCollisionData; // Offset: 0x27d // Size: 0x01
	char pad_0x27E[0x2]; // Offset: 0x27e // Size: 0x02
	struct FSolverCollisionFilterSettings CollisionFilterSettings; // Offset: 0x280 // Size: 0x10
	bool DoGenerateBreakingData; // Offset: 0x290 // Size: 0x01
	char pad_0x291[0x3]; // Offset: 0x291 // Size: 0x03
	struct FSolverBreakingFilterSettings BreakingFilterSettings; // Offset: 0x294 // Size: 0x10
	bool DoGenerateTrailingData; // Offset: 0x2a4 // Size: 0x01
	char pad_0x2A5[0x3]; // Offset: 0x2a5 // Size: 0x03
	struct FSolverTrailingFilterSettings TrailingFilterSettings; // Offset: 0x2a8 // Size: 0x10
	bool bHasFloor; // Offset: 0x2b8 // Size: 0x01
	char pad_0x2B9[0x3]; // Offset: 0x2b9 // Size: 0x03
	float FloorHeight; // Offset: 0x2bc // Size: 0x04
	float MassScale; // Offset: 0x2c0 // Size: 0x04
	struct FChaosDebugSubstepControl ChaosDebugSubstepControl; // Offset: 0x2c4 // Size: 0x03
	char pad_0x2C7[0x1]; // Offset: 0x2c7 // Size: 0x01
	struct UBillboardComponent* SpriteComponent; // Offset: 0x2c8 // Size: 0x08
	struct UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent; // Offset: 0x2d0 // Size: 0x08

	// Functions

	// Object Name: Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive
	// Flags: [Native|Public|BlueprintCallable]
	void SetSolverActive(bool bActive); // Offset: 0x104fe7e64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAsCurrentWorldSolver(); // Offset: 0x104fe7ef0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class ChaosSolverEngine.ChaosSolverSettings
// Size: 0x58 // Inherited bytes: 0x38
struct UChaosSolverSettings : UDeveloperSettings {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FSoftClassPath DefaultChaosSolverActorClass; // Offset: 0x40 // Size: 0x18
};

