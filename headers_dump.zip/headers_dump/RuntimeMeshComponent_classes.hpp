#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class RuntimeMeshComponent.RuntimeMeshComponent
// Size: 0x5c0 // Inherited bytes: 0x5a0
struct URuntimeMeshComponent : UMeshComponent {
	// Fields
	char pad_0x5A0[0x8]; // Offset: 0x5a0 // Size: 0x08
	struct URuntimeMesh* RuntimeMeshReference; // Offset: 0x5a8 // Size: 0x08
	char pad_0x5B0[0x10]; // Offset: 0x5b0 // Size: 0x10

	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetupMaterialSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetupMaterialSlot(int32_t MaterialSlot, struct FName SlotName, struct UMaterialInterface* InMaterial); // Offset: 0x101dd8ae8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetRuntimeMeshMobility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRuntimeMeshMobility(enum class ERuntimeMeshMobility NewMobility); // Offset: 0x101dd8cc0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetRuntimeMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRuntimeMesh(struct URuntimeMesh* NewMesh); // Offset: 0x101dd8dd8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.InitializeStaticProvider
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct URuntimeMeshProviderStatic* InitializeStaticProvider(); // Offset: 0x101dd8e54 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.Initialize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Initialize(struct URuntimeMeshProvider* Provider); // Offset: 0x101dd8e94 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetRuntimeMeshMobility
	// Flags: [Final|Native|Public|BlueprintCallable]
	enum class ERuntimeMeshMobility GetRuntimeMeshMobility(); // Offset: 0x101dd8d50 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetRuntimeMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct URuntimeMesh* GetRuntimeMesh(); // Offset: 0x101dd8dbc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetProvider
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct URuntimeMeshProvider* GetProvider(); // Offset: 0x101dd8c9c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetOrCreateRuntimeMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct URuntimeMesh* GetOrCreateRuntimeMesh(); // Offset: 0x101dd8d80 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetMaterialSlots
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FRuntimeMeshMaterialSlot> GetMaterialSlots(); // Offset: 0x101dd8c04 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetHitSource
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FRuntimeMeshCollisionHitInfo GetHitSource(int32_t FaceIndex); // Offset: 0x101dd8a44 // Return & Params: Num(2) Size(0x28)
};

// Object Name: Class RuntimeMeshComponent.RuntimeMesh
// Size: 0xa8 // Inherited bytes: 0x28
struct URuntimeMesh : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct URuntimeMeshProvider* MeshProvider; // Offset: 0x58 // Size: 0x08
	char pad_0x60[0x8]; // Offset: 0x60 // Size: 0x08
	struct UBodySetup* BodySetup; // Offset: 0x68 // Size: 0x08
	char pad_0x70[0x10]; // Offset: 0x70 // Size: 0x10
	struct TArray<struct FRuntimeMeshAsyncBodySetupData> AsyncBodySetupQueue; // Offset: 0x80 // Size: 0x10
	char pad_0x90[0x8]; // Offset: 0x90 // Size: 0x08
	struct FMulticastInlineDelegate CollisionUpdated; // Offset: 0x98 // Size: 0x10

	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.SetupMaterialSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetupMaterialSlot(int32_t MaterialSlot, struct FName SlotName, struct UMaterialInterface* InMaterial); // Offset: 0x101dcc15c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reset(); // Offset: 0x101dcc3ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.IsMaterialSlotNameValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsMaterialSlotNameValid(struct FName MaterialSlotName); // Offset: 0x101dcbfc4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.InitializeStaticProvider
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct URuntimeMeshProviderStatic* InitializeStaticProvider(); // Offset: 0x101dcc3b8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.Initialize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Initialize(struct URuntimeMeshProvider* Provider); // Offset: 0x101dcc400 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.GetProvider
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct URuntimeMeshProvider* GetProvider(); // Offset: 0x101dcc39c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.GetNumMaterials
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetNumMaterials(); // Offset: 0x101dcc2e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.GetMaterialSlots
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FRuntimeMeshMaterialSlot> GetMaterialSlots(); // Offset: 0x101dcc31c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.GetMaterialSlotNames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FName> GetMaterialSlotNames(); // Offset: 0x101dcc050 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.GetMaterialIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMaterialIndex(struct FName MaterialSlotName); // Offset: 0x101dcc0d0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.GetMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMaterialInterface* GetMaterial(int32_t SlotIndex); // Offset: 0x101dcc25c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function RuntimeMeshComponent.RuntimeMesh.GetLocalBounds
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FBoxSphereBounds GetLocalBounds(); // Offset: 0x101dcbf78 // Return & Params: Num(1) Size(0x1c)
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshActor
// Size: 0x270 // Inherited bytes: 0x268
struct ARuntimeMeshActor : AActor {
	// Fields
	struct URuntimeMeshComponent* RuntimeMeshComponent; // Offset: 0x268 // Size: 0x08

	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshActor.SetRuntimeMeshMobility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRuntimeMeshMobility(enum class ERuntimeMeshMobility NewMobility); // Offset: 0x101dccb50 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshActor.GetRuntimeMeshMobility
	// Flags: [Final|Native|Public|BlueprintCallable]
	enum class ERuntimeMeshMobility GetRuntimeMeshMobility(); // Offset: 0x101dccbcc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshActor.GetRuntimeMeshComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct URuntimeMeshComponent* GetRuntimeMeshComponent(); // Offset: 0x101dccb34 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshBlueprintFunctions
// Size: 0x28 // Inherited bytes: 0x28
struct URuntimeMeshBlueprintFunctions : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetVertexIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetVertexIndex(struct FRuntimeMeshTriangleStream& Stream, struct FRuntimeMeshTriangleStream& OutStream, int32_t Index, int32_t NewIndex); // Offset: 0x101dd06cc // Return & Params: Num(4) Size(0x38)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetTexCoord
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetTexCoord(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t Index, struct FVector2D NewTexCoord, int32_t ChannelId); // Offset: 0x101dd1e0c // Return & Params: Num(5) Size(0x40)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetTangents
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetTangents(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, int32_t Index, struct FVector InTangentX, struct FVector InTangentY, struct FVector InTangentZ); // Offset: 0x101dd2a70 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetTangent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetTangent(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, int32_t Index, struct FVector NewTangent); // Offset: 0x101dd2ea0 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetPosition(struct FRuntimeMeshVertexPositionStream& Stream, struct FRuntimeMeshVertexPositionStream& OutStream, int32_t Index, struct FVector NewPosition); // Offset: 0x101dd3f9c // Return & Params: Num(4) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNumTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetNumTriangles(struct FRuntimeMeshTriangleStream& Stream, struct FRuntimeMeshTriangleStream& OutStream, int32_t NewNum, bool bAllowShrinking); // Offset: 0x101dd12a4 // Return & Params: Num(4) Size(0x35)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNumTexCoords
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetNumTexCoords(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t NewNum, bool bAllowShrinking); // Offset: 0x101dd28dc // Return & Params: Num(4) Size(0x35)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNumTangents
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetNumTangents(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, int32_t NewNum, bool bAllowShrinking); // Offset: 0x101dd3cac // Return & Params: Num(4) Size(0x35)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNumPositions
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetNumPositions(struct FRuntimeMeshVertexPositionStream& Stream, struct FRuntimeMeshVertexPositionStream& OutStream, int32_t NewNum, bool bAllowShrinking); // Offset: 0x101dd47fc // Return & Params: Num(4) Size(0x25)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNumColors
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetNumColors(struct FRuntimeMeshVertexColorStream& Stream, struct FRuntimeMeshVertexColorStream& OutStream, int32_t NewNum, bool bAllowShrinking); // Offset: 0x101dd1c90 // Return & Params: Num(4) Size(0x25)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNumCollisionVertices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetNumCollisionVertices(struct FRuntimeMeshCollisionVertexStream& Stream, struct FRuntimeMeshCollisionVertexStream& OutStream, int32_t NewNum, bool bAllowShrinking); // Offset: 0x101dcfcb8 // Return & Params: Num(4) Size(0x25)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNumCollisionTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetNumCollisionTriangles(struct FRuntimeMeshCollisionTriangleStream& Stream, struct FRuntimeMeshCollisionTriangleStream& OutStream, int32_t NewNum, bool bAllowShrinking); // Offset: 0x101dcf42c // Return & Params: Num(4) Size(0x25)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNumCollisionTexCoords
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetNumCollisionTexCoords(struct FRuntimeMeshCollisionTexCoordStream& Stream, struct FRuntimeMeshCollisionTexCoordStream& OutStream, int32_t NewNumChannels, int32_t NewNumTexCoords, bool bAllowShrinking); // Offset: 0x101dceb48 // Return & Params: Num(5) Size(0x29)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNumCollisionMaterialIndices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetNumCollisionMaterialIndices(struct FRuntimeMeshCollisionMaterialIndexStream& Stream, struct FRuntimeMeshCollisionMaterialIndexStream& OutStream, int32_t NewNum, bool bAllowShrinking); // Offset: 0x101dcdfd4 // Return & Params: Num(4) Size(0x25)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetNormal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetNormal(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, int32_t Index, struct FVector NewNormal); // Offset: 0x101dd31a8 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetColor
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetColor(struct FRuntimeMeshVertexColorStream& Stream, struct FRuntimeMeshVertexColorStream& OutStream, int32_t Index, struct FLinearColor NewColor); // Offset: 0x101dd1430 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetCollisionVertex
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetCollisionVertex(struct FRuntimeMeshCollisionVertexStream& Stream, struct FRuntimeMeshCollisionVertexStream& OutStream, int32_t Index, struct FVector NewVertex); // Offset: 0x101dcf5a8 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SetCollisionTexCoord
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetCollisionTexCoord(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t Index, struct FVector2D NewTexCoord, int32_t ChannelId); // Offset: 0x101dce150 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.SeCollisionMaterialIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SeCollisionMaterialIndex(struct FRuntimeMeshCollisionMaterialIndexStream& Stream, struct FRuntimeMeshCollisionMaterialIndexStream& OutStream, int32_t Index, int32_t NewIndex); // Offset: 0x101dcd8d0 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.RuntimeMeshInitializeMultiThreading
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RuntimeMeshInitializeMultiThreading(int32_t NumThreads, int32_t StackSize, enum class ERuntimeMeshThreadingPriority ThreadPriority); // Offset: 0x101dd5868 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumTriangles(struct FRuntimeMeshTriangleStream& Stream, struct FRuntimeMeshTriangleStream& OutStream, int32_t& OutNumTriangles); // Offset: 0x101dd0ffc // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumTexCoords
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumTexCoords(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t& OutNumTexCoords); // Offset: 0x101dd2780 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumTexCoordChannels
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumTexCoordChannels(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t& OutNumTexCoordChannels); // Offset: 0x101dd2624 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumTangents
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumTangents(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, int32_t& OutNumTangents); // Offset: 0x101dd3b60 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumPositions
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumPositions(struct FRuntimeMeshVertexPositionStream& Stream, struct FRuntimeMeshVertexPositionStream& OutStream, int32_t& OutNumPositions); // Offset: 0x101dd46b8 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumIndices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumIndices(struct FRuntimeMeshTriangleStream& Stream, struct FRuntimeMeshTriangleStream& OutStream, int32_t& OutNumIndices); // Offset: 0x101dd1150 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumColors
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumColors(struct FRuntimeMeshVertexColorStream& Stream, struct FRuntimeMeshVertexColorStream& OutStream, int32_t& OutNumColors); // Offset: 0x101dd1b4c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumCollisionVertices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumCollisionVertices(struct FRuntimeMeshCollisionVertexStream& Stream, struct FRuntimeMeshCollisionVertexStream& OutStream, int32_t& OutNumVertices); // Offset: 0x101dcfb74 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumCollisionTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumCollisionTriangles(struct FRuntimeMeshCollisionTriangleStream& Stream, struct FRuntimeMeshCollisionTriangleStream& OutStream, int32_t& OutNumTriangles); // Offset: 0x101dcf2e8 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumCollisionTexCoords
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumCollisionTexCoords(struct FRuntimeMeshCollisionTexCoordStream& Stream, struct FRuntimeMeshCollisionTexCoordStream& OutStream, int32_t ChannelId, int32_t& OutNumTexCoords); // Offset: 0x101dce954 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumCollisionTexCoordChannels
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumCollisionTexCoordChannels(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t& OutNumTexCoordChannels); // Offset: 0x101dce7f8 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.NumCollisionMaterialIndices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void NumCollisionMaterialIndices(struct FRuntimeMeshCollisionMaterialIndexStream& Stream, struct FRuntimeMeshCollisionMaterialIndexStream& OutStream, int32_t& OutNumIndices); // Offset: 0x101dcde90 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetVertexIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetVertexIndex(struct FRuntimeMeshTriangleStream& Stream, struct FRuntimeMeshTriangleStream& OutStream, int32_t Index, int32_t& OutIndex); // Offset: 0x101dd0850 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetTriangleStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshTriangleStream GetTriangleStream(struct FRuntimeMeshRenderableMeshData& MeshData, struct FRuntimeMeshRenderableMeshData& OutMeshData); // Offset: 0x101dd4ba8 // Return & Params: Num(3) Size(0x118)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetTexCoordStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshVertexTexCoordStream GetTexCoordStream(struct FRuntimeMeshRenderableMeshData& MeshData, struct FRuntimeMeshRenderableMeshData& OutMeshData); // Offset: 0x101dd4fec // Return & Params: Num(3) Size(0x118)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetTexCoord
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetTexCoord(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t Index, struct FVector2D& OutTexCoord); // Offset: 0x101dd1fd8 // Return & Params: Num(4) Size(0x3c)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetTangentStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshVertexTangentStream GetTangentStream(struct FRuntimeMeshRenderableMeshData& MeshData, struct FRuntimeMeshRenderableMeshData& OutMeshData); // Offset: 0x101dd522c // Return & Params: Num(3) Size(0x118)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetTangents
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetTangents(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, int32_t Index, struct FVector& OutTangentX, struct FVector& OutTangentY, struct FVector& OutTangentZ); // Offset: 0x101dd2c74 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetTangent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetTangent(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, int32_t Index, struct FVector& OutTangent); // Offset: 0x101dd301c // Return & Params: Num(4) Size(0x40)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetPositionStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshVertexPositionStream GetPositionStream(struct FRuntimeMeshRenderableMeshData& MeshData, struct FRuntimeMeshRenderableMeshData& OutMeshData); // Offset: 0x101dd545c // Return & Params: Num(3) Size(0x110)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetPosition(struct FRuntimeMeshVertexPositionStream& Stream, struct FRuntimeMeshVertexPositionStream& OutStream, int32_t Index, struct FVector& OutPosition); // Offset: 0x101dd4110 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetNormal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetNormal(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, int32_t Index, struct FVector& OutNormal); // Offset: 0x101dd3324 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetColorStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshVertexColorStream GetColorStream(struct FRuntimeMeshRenderableMeshData& MeshData, struct FRuntimeMeshRenderableMeshData& OutMeshData); // Offset: 0x101dd4dd8 // Return & Params: Num(3) Size(0x110)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetColor
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetColor(struct FRuntimeMeshVertexColorStream& Stream, struct FRuntimeMeshVertexColorStream& OutStream, int32_t Index, struct FLinearColor& OutColor); // Offset: 0x101dd15a4 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetCollisionVertexStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshCollisionVertexStream GetCollisionVertexStream(struct FRuntimeMeshCollisionData& CollisionData, struct FRuntimeMeshCollisionData& OutCollisionData); // Offset: 0x101dd0494 // Return & Params: Num(3) Size(0xc0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetCollisionVertex
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetCollisionVertex(struct FRuntimeMeshCollisionVertexStream& Stream, struct FRuntimeMeshCollisionVertexStream& OutStream, int32_t Index, struct FVector& OutVertex); // Offset: 0x101dcf71c // Return & Params: Num(4) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetCollisionTriangleStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshCollisionTriangleStream GetCollisionTriangleStream(struct FRuntimeMeshCollisionData& CollisionData, struct FRuntimeMeshCollisionData& OutCollisionData); // Offset: 0x101dd025c // Return & Params: Num(3) Size(0xc0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetCollisionTriangle
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetCollisionTriangle(struct FRuntimeMeshCollisionTriangleStream& Stream, struct FRuntimeMeshCollisionTriangleStream& OutStream, int32_t Index, int32_t& OutIndexA, int32_t& OutIndexB, int32_t& OutIndexC); // Offset: 0x101dced70 // Return & Params: Num(6) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetCollisionTexCoordStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshCollisionTexCoordStream GetCollisionTexCoordStream(struct FRuntimeMeshCollisionData& CollisionData, struct FRuntimeMeshCollisionData& OutCollisionData); // Offset: 0x101dd0068 // Return & Params: Num(3) Size(0xc0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetCollisionTexCoord
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetCollisionTexCoord(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t Index, struct FVector2D& OutTexCoord, int32_t ChannelId); // Offset: 0x101dce31c // Return & Params: Num(5) Size(0x40)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetCollisionMaterialIndexStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshCollisionMaterialIndexStream GetCollisionMaterialIndexStream(struct FRuntimeMeshCollisionData& CollisionData, struct FRuntimeMeshCollisionData& OutCollisionData); // Offset: 0x101dcfe34 // Return & Params: Num(3) Size(0xc0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetCollisionMaterialIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetCollisionMaterialIndex(struct FRuntimeMeshCollisionMaterialIndexStream& Stream, struct FRuntimeMeshCollisionMaterialIndexStream& OutStream, int32_t Index, int32_t& OutIndex); // Offset: 0x101dcda44 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetBounds
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetBounds(struct FRuntimeMeshVertexPositionStream& Stream, struct FRuntimeMeshVertexPositionStream& OutStream, struct FBox& OutBounds); // Offset: 0x101dd3e30 // Return & Params: Num(3) Size(0x3c)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.GetAdjacencyTriangleStream
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FRuntimeMeshTriangleStream GetAdjacencyTriangleStream(struct FRuntimeMeshRenderableMeshData& MeshData, struct FRuntimeMeshRenderableMeshData& OutMeshData); // Offset: 0x101dd4978 // Return & Params: Num(3) Size(0x118)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.EmptyTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EmptyTriangles(struct FRuntimeMeshTriangleStream& Stream, struct FRuntimeMeshTriangleStream& OutStream, int32_t Slack); // Offset: 0x101dd0eb8 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.EmptyTexCoords
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EmptyTexCoords(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t Slack); // Offset: 0x101dd24d8 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.EmptyTangents
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EmptyTangents(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, int32_t Slack); // Offset: 0x101dd3a24 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.EmptyPositions
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EmptyPositions(struct FRuntimeMeshVertexPositionStream& Stream, struct FRuntimeMeshVertexPositionStream& OutStream, int32_t Slack); // Offset: 0x101dd4584 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.EmptyColors
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EmptyColors(struct FRuntimeMeshVertexColorStream& Stream, struct FRuntimeMeshVertexColorStream& OutStream, int32_t Slack); // Offset: 0x101dd1a18 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.EmptyCollisionVertices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EmptyCollisionVertices(struct FRuntimeMeshCollisionVertexStream& Stream, struct FRuntimeMeshCollisionVertexStream& OutStream, int32_t Slack); // Offset: 0x101dcfa40 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.EmptyCollisionTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EmptyCollisionTriangles(struct FRuntimeMeshCollisionTriangleStream& Stream, struct FRuntimeMeshCollisionTriangleStream& OutStream, int32_t Slack); // Offset: 0x101dcf1b4 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.EmptyCollisionTexCoords
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EmptyCollisionTexCoords(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t Slack); // Offset: 0x101dce6ac // Return & Params: Num(3) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.EmptyCollisionMaterialIndices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EmptyCollisionMaterialIndices(struct FRuntimeMeshCollisionMaterialIndexStream& Stream, struct FRuntimeMeshCollisionMaterialIndexStream& OutStream, int32_t Slack); // Offset: 0x101dcdd5c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.CreateRenderableMeshData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FRuntimeMeshRenderableMeshData CreateRenderableMeshData(bool bWantsHighPrecisionTangents, bool bWantsHighPrecisionTexCoords, char NumTexCoords, bool bWants32BitIndices); // Offset: 0x101dd5670 // Return & Params: Num(5) Size(0x88)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AppendTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AppendTriangles(struct FRuntimeMeshTriangleStream& Stream, struct FRuntimeMeshTriangleStream& OutStream, struct FRuntimeMeshTriangleStream& InOther); // Offset: 0x101dd09ec // Return & Params: Num(3) Size(0x48)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AppendTexCoords
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AppendTexCoords(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, struct FRuntimeMeshVertexTexCoordStream& InOther); // Offset: 0x101dd2174 // Return & Params: Num(3) Size(0x48)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AppendTangents
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AppendTangents(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, struct FRuntimeMeshVertexTangentStream& InOther); // Offset: 0x101dd34b0 // Return & Params: Num(3) Size(0x48)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AppendPositions
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AppendPositions(struct FRuntimeMeshVertexPositionStream& Stream, struct FRuntimeMeshVertexPositionStream& OutStream, struct FRuntimeMeshVertexPositionStream& InOther); // Offset: 0x101dd4294 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AppendColors
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AppendColors(struct FRuntimeMeshVertexColorStream& Stream, struct FRuntimeMeshVertexColorStream& OutStream, struct FRuntimeMeshVertexColorStream& InOther); // Offset: 0x101dd1728 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddTriangle
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddTriangle(struct FRuntimeMeshTriangleStream& Stream, struct FRuntimeMeshTriangleStream& OutStream, int32_t NewIndexA, int32_t NewIndexB, int32_t NewIndexC); // Offset: 0x101dd0b54 // Return & Params: Num(5) Size(0x3c)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddTexCoord
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void AddTexCoord(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, int32_t& OutIndex, struct FVector2D InTexCoord, int32_t ChannelId); // Offset: 0x101dd22e8 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddTangents
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void AddTangents(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, struct FVector InTangentX, struct FVector InTangentY, struct FVector InTangentZ, int32_t& OutIndex); // Offset: 0x101dd360c // Return & Params: Num(6) Size(0x58)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void AddPosition(struct FRuntimeMeshVertexPositionStream& Stream, struct FRuntimeMeshVertexPositionStream& OutStream, struct FVector InPosition, int32_t& OutIndex); // Offset: 0x101dd43e4 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddNormalAndTangent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void AddNormalAndTangent(struct FRuntimeMeshVertexTangentStream& Stream, struct FRuntimeMeshVertexTangentStream& OutStream, struct FVector InNormal, struct FVector InTangent, int32_t& OutIndex); // Offset: 0x101dd383c // Return & Params: Num(5) Size(0x4c)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddIndex(struct FRuntimeMeshTriangleStream& Stream, struct FRuntimeMeshTriangleStream& OutStream, int32_t NewIndex, int32_t& OutIndex); // Offset: 0x101dd0d1c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddColor
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void AddColor(struct FRuntimeMeshVertexColorStream& Stream, struct FRuntimeMeshVertexColorStream& OutStream, struct FLinearColor InColor, int32_t& OutIndex); // Offset: 0x101dd1878 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddCollisionVertex
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void AddCollisionVertex(struct FRuntimeMeshCollisionVertexStream& Stream, struct FRuntimeMeshCollisionVertexStream& OutStream, struct FVector InVertex, int32_t& OutIndex); // Offset: 0x101dcf8a0 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddCollisionTriangle
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddCollisionTriangle(struct FRuntimeMeshCollisionTriangleStream& Stream, struct FRuntimeMeshCollisionTriangleStream& OutStream, int32_t NewIndexA, int32_t NewIndexB, int32_t NewIndexC, int32_t& OutTriangleIndex); // Offset: 0x101dcefa4 // Return & Params: Num(6) Size(0x30)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddCollisionTexCoord
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void AddCollisionTexCoord(struct FRuntimeMeshVertexTexCoordStream& Stream, struct FRuntimeMeshVertexTexCoordStream& OutStream, struct FVector2D InTexCoord, int32_t& OutIndex); // Offset: 0x101dce4f8 // Return & Params: Num(4) Size(0x3c)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddCollisionSphere
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddCollisionSphere(struct FRuntimeMeshCollisionSettings& Settings, struct FRuntimeMeshCollisionSettings& OutSettings, struct FRuntimeMeshCollisionSphere NewSphere); // Offset: 0x101dcd430 // Return & Params: Num(3) Size(0xa0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddCollisionMaterialIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddCollisionMaterialIndex(struct FRuntimeMeshCollisionMaterialIndexStream& Stream, struct FRuntimeMeshCollisionMaterialIndexStream& OutStream, int32_t NewIndex, int32_t& OutIndex); // Offset: 0x101dcdbd0 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddCollisionConvex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddCollisionConvex(struct FRuntimeMeshCollisionSettings& Settings, struct FRuntimeMeshCollisionSettings& OutSettings, struct FRuntimeMeshCollisionConvexMesh NewConvex); // Offset: 0x101dccf4c // Return & Params: Num(3) Size(0xc0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddCollisionCapsule
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddCollisionCapsule(struct FRuntimeMeshCollisionSettings& Settings, struct FRuntimeMeshCollisionSettings& OutSettings, struct FRuntimeMeshCollisionCapsule NewCapsule); // Offset: 0x101dcd1d4 // Return & Params: Num(3) Size(0xb0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshBlueprintFunctions.AddCollisionBox
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddCollisionBox(struct FRuntimeMeshCollisionSettings& Settings, struct FRuntimeMeshCollisionSettings& OutSettings, struct FRuntimeMeshCollisionBox NewBox); // Offset: 0x101dcd668 // Return & Params: Num(3) Size(0xb4)
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshComponentStatic
// Size: 0x6d0 // Inherited bytes: 0x5c0
struct URuntimeMeshComponentStatic : URuntimeMeshComponent {
	// Fields
	struct URuntimeMesh* RuntimeMesh; // Offset: 0x5b8 // Size: 0x08
	bool bWantsNormals; // Offset: 0x5c0 // Size: 0x01
	bool bWantsTangents; // Offset: 0x5c1 // Size: 0x01
	int32_t LODForMeshCollision; // Offset: 0x5c4 // Size: 0x04
	struct TSet<int32_t> SectionsForMeshCollision; // Offset: 0x5c8 // Size: 0x50
	struct FRuntimeMeshCollisionSettings CollisionSettings; // Offset: 0x618 // Size: 0x48
	struct FRuntimeMeshCollisionData CollisionMesh; // Offset: 0x660 // Size: 0x58
	char pad_0x6BE[0x12]; // Offset: 0x6be // Size: 0x12

	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.UpdateSectionFromComponents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateSectionFromComponents(int32_t LODIndex, int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FVector2D>& UV2, struct TArray<struct FVector2D>& UV3, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FRuntimeMeshTangent>& Tangents); // Offset: 0x101dda090 // Return & Params: Num(11) Size(0x98)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.UpdateSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateSection_Blueprint(int32_t LODIndex, int32_t SectionId, struct FRuntimeMeshRenderableMeshData& SectionData); // Offset: 0x101dda4ac // Return & Params: Num(3) Size(0x88)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.SetRenderableSectionAffectsCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderableSectionAffectsCollision(int32_t SectionId, bool bCollisionEnabled); // Offset: 0x101dd9c80 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.SetRenderableLODForCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderableLODForCollision(int32_t LODIndex); // Offset: 0x101dd9d44 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.SetCollisionSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetCollisionSettings(struct FRuntimeMeshCollisionSettings& NewCollisionSettings); // Offset: 0x101dd9ed0 // Return & Params: Num(1) Size(0x48)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.SetCollisionMesh
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetCollisionMesh(struct FRuntimeMeshCollisionData& NewCollisionMesh); // Offset: 0x101dd9dc0 // Return & Params: Num(1) Size(0x58)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.SetbWantsTangents
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetbWantsTangents(bool InbWantsTangents, bool bDeleteNormalsProviderIfUseless); // Offset: 0x101dd9ac8 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.SetbWantsNormals
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetbWantsNormals(bool InbWantsNormals, bool bDeleteNormalsProviderIfUseless); // Offset: 0x101dd9ba4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.GetSectionsForMeshCollision
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct TSet<int32_t> GetSectionsForMeshCollision(); // Offset: 0x101dd98d0 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.GetLODForMeshCollision
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	int32_t GetLODForMeshCollision(); // Offset: 0x101dd9a2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.GetCollisionSettings
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct FRuntimeMeshCollisionSettings GetCollisionSettings(); // Offset: 0x101dd971c // Return & Params: Num(1) Size(0x48)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.GetCollisionMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct FRuntimeMeshCollisionData GetCollisionMesh(); // Offset: 0x101dd9540 // Return & Params: Num(1) Size(0x58)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.GetbWantsTangents
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool GetbWantsTangents(); // Offset: 0x101dd9a60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.GetbWantsNormals
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool GetbWantsNormals(); // Offset: 0x101dd9a94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.CreateSectionFromComponents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateSectionFromComponents(int32_t LODIndex, int32_t SectionIndex, int32_t MaterialSlot, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FVector2D>& UV2, struct TArray<struct FVector2D>& UV3, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FRuntimeMeshTangent>& Tangents, enum class ERuntimeMeshUpdateFrequency UpdateFrequency, bool bCreateCollision); // Offset: 0x101dda628 // Return & Params: Num(14) Size(0xa2)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.CreateSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateSection_Blueprint(int32_t LODIndex, int32_t SectionId, struct FRuntimeMeshSectionProperties& SectionProperties, struct FRuntimeMeshRenderableMeshData& SectionData); // Offset: 0x101ddab18 // Return & Params: Num(4) Size(0x98)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponentStatic.ClearSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearSection(int32_t LODIndex, int32_t SectionId); // Offset: 0x101dd9fd4 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshProvider
// Size: 0x38 // Inherited bytes: 0x28
struct URuntimeMeshProvider : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.SetupMaterialSlot
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void SetupMaterialSlot(int32_t MaterialSlot, struct FName SlotName, struct UMaterialInterface* InMaterial); // Offset: 0x101ddc0b4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.SetSectionVisibility
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void SetSectionVisibility(int32_t LODIndex, int32_t SectionId, bool bIsVisible); // Offset: 0x101ddbce8 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.SetSectionCastsShadow
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void SetSectionCastsShadow(int32_t LODIndex, int32_t SectionId, bool bCastsShadow); // Offset: 0x101ddbbd8 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.RemoveSection
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void RemoveSection(int32_t LODIndex, int32_t SectionId); // Offset: 0x101ddbb14 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.MarkSectionDirty
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void MarkSectionDirty(int32_t LODIndex, int32_t SectionId); // Offset: 0x101ddbe98 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.MarkProxyParametersDirty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MarkProxyParametersDirty(); // Offset: 0x101ddc3a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.MarkLODDirty
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void MarkLODDirty(int32_t LODIndex); // Offset: 0x101ddbe14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.MarkCollisionDirty
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void MarkCollisionDirty(); // Offset: 0x101ddbaf8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.MarkAllLODsDirty
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void MarkAllLODsDirty(); // Offset: 0x101ddbdf8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.Initialize
	// Flags: [Native|Event|Public|BlueprintEvent]
	void Initialize(); // Offset: 0x101ddc384 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.HasCollisionMesh
	// Flags: [Native|Event|Protected|BlueprintCallable|BlueprintEvent]
	bool HasCollisionMesh(); // Offset: 0x101ddb820 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.GetSectionMeshForLOD
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent]
	bool GetSectionMeshForLOD(int32_t LODIndex, int32_t SectionId, struct FRuntimeMeshRenderableMeshData& MeshData); // Offset: 0x101ddb910 // Return & Params: Num(4) Size(0x89)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.GetNumMaterialSlots
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	int32_t GetNumMaterialSlots(); // Offset: 0x101ddbfe4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.GetMaterialSlots
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	struct TArray<struct FRuntimeMeshMaterialSlot> GetMaterialSlots(); // Offset: 0x101ddbf5c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.GetMaterialIndex
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	int32_t GetMaterialIndex(struct FName MaterialSlotName); // Offset: 0x101ddc020 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.GetCollisionSettings
	// Flags: [Native|Event|Protected|BlueprintCallable|BlueprintEvent]
	struct FRuntimeMeshCollisionSettings GetCollisionSettings(); // Offset: 0x101ddb85c // Return & Params: Num(1) Size(0x48)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.GetCollisionMesh
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent]
	bool GetCollisionMesh(struct FRuntimeMeshCollisionData& CollisionData); // Offset: 0x101ddb6f8 // Return & Params: Num(2) Size(0x59)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.GetBounds
	// Flags: [Native|Event|Protected|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FBoxSphereBounds GetBounds(); // Offset: 0x101ddbaa4 // Return & Params: Num(1) Size(0x1c)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.CreateSection
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CreateSection(int32_t LODIndex, int32_t SectionId, struct FRuntimeMeshSectionProperties& SectionProperties); // Offset: 0x101ddc1bc // Return & Params: Num(3) Size(0x18)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProvider.ConfigureLODs
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void ConfigureLODs(struct TArray<struct FRuntimeMeshLODProperties>& LODs); // Offset: 0x101ddc2e4 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshProviderBox
// Size: 0x50 // Inherited bytes: 0x38
struct URuntimeMeshProviderBox : URuntimeMeshProvider {
	// Fields
	struct FVector BoxRadius; // Offset: 0x38 // Size: 0x0c
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct UMaterialInterface* Material; // Offset: 0x48 // Size: 0x08
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshProviderCollisionFromRenderable
// Size: 0x138 // Inherited bytes: 0x38
struct URuntimeMeshProviderCollisionFromRenderable : URuntimeMeshProvider {
	// Fields
	char pad_0x38[0xf8]; // Offset: 0x38 // Size: 0xf8
	struct URuntimeMeshProvider* SourceProvider; // Offset: 0x130 // Size: 0x08
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshProviderMemoryCache
// Size: 0x40 // Inherited bytes: 0x38
struct URuntimeMeshProviderMemoryCache : URuntimeMeshProvider {
	// Fields
	struct URuntimeMeshProvider* SourceProvider; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshProviderNormals
// Size: 0x48 // Inherited bytes: 0x38
struct URuntimeMeshProviderNormals : URuntimeMeshProvider {
	// Fields
	struct URuntimeMeshProvider* SourceProvider; // Offset: 0x38 // Size: 0x08
	bool ComputeNormals; // Offset: 0x40 // Size: 0x01
	bool ComputeTangents; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x6]; // Offset: 0x42 // Size: 0x06
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshProviderPlane
// Size: 0x98 // Inherited bytes: 0x38
struct URuntimeMeshProviderPlane : URuntimeMeshProvider {
	// Fields
	struct FVector LocationA; // Offset: 0x38 // Size: 0x0c
	struct FVector LocationB; // Offset: 0x44 // Size: 0x0c
	struct FVector LocationC; // Offset: 0x50 // Size: 0x0c
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct TArray<int32_t> VertsAB; // Offset: 0x60 // Size: 0x10
	struct TArray<int32_t> VertsAC; // Offset: 0x70 // Size: 0x10
	struct TArray<float> ScreenSize; // Offset: 0x80 // Size: 0x10
	struct UMaterialInterface* Material; // Offset: 0x90 // Size: 0x08
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshProviderSphere
// Size: 0x58 // Inherited bytes: 0x38
struct URuntimeMeshProviderSphere : URuntimeMeshProvider {
	// Fields
	float SphereRadius; // Offset: 0x38 // Size: 0x04
	int32_t MaxLatitudeSegments; // Offset: 0x3c // Size: 0x04
	int32_t MinLatitudeSegments; // Offset: 0x40 // Size: 0x04
	int32_t MaxLongitudeSegments; // Offset: 0x44 // Size: 0x04
	int32_t MinLongitudeSegments; // Offset: 0x48 // Size: 0x04
	float LODMultiplier; // Offset: 0x4c // Size: 0x04
	struct UMaterialInterface* Material; // Offset: 0x50 // Size: 0x08
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshProviderStatic
// Size: 0x1d0 // Inherited bytes: 0x38
struct URuntimeMeshProviderStatic : URuntimeMeshProvider {
	// Fields
	bool StoreEditorGeneratedDataForGame; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x197]; // Offset: 0x39 // Size: 0x197

	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.UpdateSectionFromComponents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateSectionFromComponents(int32_t LODIndex, int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FVector2D>& UV2, struct TArray<struct FVector2D>& UV3, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FRuntimeMeshTangent>& Tangents); // Offset: 0x101de0ad0 // Return & Params: Num(11) Size(0x98)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.UpdateSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateSection_Blueprint(int32_t LODIndex, int32_t SectionId, struct FRuntimeMeshRenderableMeshData& SectionData); // Offset: 0x101de13dc // Return & Params: Num(3) Size(0x88)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.SetRenderableSectionAffectsCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderableSectionAffectsCollision(int32_t SectionId, bool bCollisionEnabled); // Offset: 0x101de04fc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.SetRenderableLODForCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderableLODForCollision(int32_t LODIndex); // Offset: 0x101de07c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.SetCollisionSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetCollisionSettings(struct FRuntimeMeshCollisionSettings& NewCollisionSettings); // Offset: 0x101de0860 // Return & Params: Num(1) Size(0x48)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.GetRenderableSectionAffectingCollision
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct TSet<int32_t> GetRenderableSectionAffectingCollision(); // Offset: 0x101de05c0 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.GetRenderableLODForCollision
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	int32_t GetRenderableLODForCollision(); // Offset: 0x101de0844 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.GetCollisionSettingsStored
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct FRuntimeMeshCollisionSettings GetCollisionSettingsStored(); // Offset: 0x101de0964 // Return & Params: Num(1) Size(0x48)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.CreateSectionFromComponents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateSectionFromComponents(int32_t LODIndex, int32_t SectionIndex, int32_t MaterialSlot, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FVector2D>& UV2, struct TArray<struct FVector2D>& UV3, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FRuntimeMeshTangent>& Tangents, enum class ERuntimeMeshUpdateFrequency UpdateFrequency, bool bCreateCollision); // Offset: 0x101de0eec // Return & Params: Num(14) Size(0xa2)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.CreateSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateSection_Blueprint(int32_t LODIndex, int32_t SectionId, struct FRuntimeMeshSectionProperties& SectionProperties, struct FRuntimeMeshRenderableMeshData& SectionData); // Offset: 0x101de1580 // Return & Params: Num(4) Size(0x98)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshProviderStatic.ClearSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearSection(int32_t LODIndex, int32_t SectionId); // Offset: 0x101de0a14 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshProviderStaticMesh
// Size: 0x48 // Inherited bytes: 0x38
struct URuntimeMeshProviderStaticMesh : URuntimeMeshProvider {
	// Fields
	struct UStaticMesh* StaticMesh; // Offset: 0x38 // Size: 0x08
	int32_t MaxLOD; // Offset: 0x40 // Size: 0x04
	int32_t ComplexCollisionLOD; // Offset: 0x44 // Size: 0x04
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshStaticMeshConverter
// Size: 0x28 // Inherited bytes: 0x28
struct URuntimeMeshStaticMeshConverter : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshStaticMeshConverter.CopyStaticMeshSectionToRenderableMeshData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool CopyStaticMeshSectionToRenderableMeshData(struct UStaticMesh* StaticMesh, int32_t LODIndex, int32_t SectionId, struct FRuntimeMeshRenderableMeshData& OutMeshData); // Offset: 0x101de2a28 // Return & Params: Num(5) Size(0x91)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshStaticMeshConverter.CopyStaticMeshLODToCollisionData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool CopyStaticMeshLODToCollisionData(struct UStaticMesh* StaticMesh, int32_t LODIndex, struct FRuntimeMeshCollisionData& OutCollisionData); // Offset: 0x101de2750 // Return & Params: Num(4) Size(0x69)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshStaticMeshConverter.CopyStaticMeshCollisionToCollisionSettings
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool CopyStaticMeshCollisionToCollisionSettings(struct UStaticMesh* StaticMesh, struct FRuntimeMeshCollisionSettings& OutCollisionSettings); // Offset: 0x101de28e0 // Return & Params: Num(3) Size(0x51)
};

