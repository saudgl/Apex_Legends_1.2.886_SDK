#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class EventFlowSystem.EventFlowBase
// Size: 0xf8 // Inherited bytes: 0x28
struct UEventFlowBase : UObject {
	// Fields
	struct UEventFlowManager* Owner; // Offset: 0x28 // Size: 0x08
	enum class EEventFlowState EventFlowState; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct TArray<struct UEventFlowSequenceBase*> StartSequences; // Offset: 0x38 // Size: 0x10
	struct TSet<struct UEventFlowSequenceBase*> PreActivedSequences; // Offset: 0x48 // Size: 0x50
	struct TArray<struct UEventFlowSequenceBase*> ActivedSequences; // Offset: 0x98 // Size: 0x10
	struct FMulticastInlineDelegate OnSequenceActived; // Offset: 0xa8 // Size: 0x10
	char pad_0xB8[0x18]; // Offset: 0xb8 // Size: 0x18
	struct FMulticastInlineDelegate OnSequenceDeactived; // Offset: 0xd0 // Size: 0x10
	char pad_0xE0[0x18]; // Offset: 0xe0 // Size: 0x18

	// Functions

	// Object Name: DelegateFunction EventFlowSystem.EventFlowBase.OnSequenceDeactived__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSequenceDeactived__DelegateSignature(struct UEventFlowSequenceBase* DeactivedSequence); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction EventFlowSystem.EventFlowBase.OnSequenceActived__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSequenceActived__DelegateSignature(struct UEventFlowSequenceBase* ActivedSequence); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowBase.OnRep_StartSequences
	// Flags: [Final|Native|Public]
	void OnRep_StartSequences(); // Offset: 0x101eb5598 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowBase.OnRep_Owner
	// Flags: [Final|Native|Public]
	void OnRep_Owner(); // Offset: 0x101eb55ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowBase.OnRep_ActivedSequences
	// Flags: [Final|Native|Public]
	void OnRep_ActivedSequences(); // Offset: 0x101eb5584 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowBase.IsLocalController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLocalController(); // Offset: 0x101eb5444 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EventFlowSystem.EventFlowBase.InvokeInterruptFlowByNodeName
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool InvokeInterruptFlowByNodeName(struct FName StopNodeName, bool MarkInterruptAlways); // Offset: 0x101eb54ac // Return & Params: Num(3) Size(0xa)

	// Object Name: Function EventFlowSystem.EventFlowBase.HasAuthority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAuthority(); // Offset: 0x101eb5478 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EventFlowSystem.EventFlowBase.EventFlowStart
	// Flags: [Event|Public|BlueprintEvent]
	void EventFlowStart(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class EventFlowSystem.EventFlowBlueprint
// Size: 0xd0 // Inherited bytes: 0xd0
struct UEventFlowBlueprint : UBlueprint {
};

// Object Name: Class EventFlowSystem.EventFlowBlueprintGeneratedClass
// Size: 0x400 // Inherited bytes: 0x400
struct UEventFlowBlueprintGeneratedClass : UBlueprintGeneratedClass {
};

// Object Name: Class EventFlowSystem.EventFlowDetails
// Size: 0x278 // Inherited bytes: 0x110
struct UEventFlowDetails : UWidget {
	// Fields
	struct UEventFlowBase* EventFlow; // Offset: 0x110 // Size: 0x08
	char pad_0x118[0x10]; // Offset: 0x118 // Size: 0x10
	struct FSlateBrush ContainerBackgroundImage; // Offset: 0x128 // Size: 0x88
	struct FSlateBrush OrLogicSeparatorImage; // Offset: 0x1b0 // Size: 0x88
	struct FLinearColor ActivedColor; // Offset: 0x238 // Size: 0x10
	struct FLinearColor BranchActivedColor; // Offset: 0x248 // Size: 0x10
	struct FLinearColor FinishedColor; // Offset: 0x258 // Size: 0x10
	struct FLinearColor InterruptedColor; // Offset: 0x268 // Size: 0x10

	// Functions

	// Object Name: Function EventFlowSystem.EventFlowDetails.SetEventFlow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEventFlow(struct UEventFlowBase* InEventFlow); // Offset: 0x101eb5fdc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class EventFlowSystem.EventFlowNode
// Size: 0x50 // Inherited bytes: 0x28
struct UEventFlowNode : UObject {
	// Fields
	struct TArray<struct UEventFlowNode*> PrevNodes; // Offset: 0x28 // Size: 0x10
	struct TArray<struct UEventFlowNode*> NextNodes; // Offset: 0x38 // Size: 0x10
	struct UEventFlowNode* GeneratedByTemplate; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function EventFlowSystem.EventFlowNode.IsEvaluateBound
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsEvaluateBound(struct FEvaluateEventFlowParameter& Evaluator); // Offset: 0x101eb9228 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function EventFlowSystem.EventFlowNode.ExecuteEvaluate
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable|Const]
	bool ExecuteEvaluate(struct FEvaluateEventFlowParameter& Evaluator); // Offset: 0x101eb90fc // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class EventFlowSystem.EventFlowElementBase
// Size: 0x90 // Inherited bytes: 0x50
struct UEventFlowElementBase : UEventFlowNode {
	// Fields
	struct UEventFlowSequenceBase* OwningSequence; // Offset: 0x50 // Size: 0x08
	char bIsFinished : 1; // Offset: 0x58 // Size: 0x01
	char bIsOptional : 1; // Offset: 0x58 // Size: 0x01
	char bTickable : 1; // Offset: 0x58 // Size: 0x01
	char bLocalJudgment : 1; // Offset: 0x58 // Size: 0x01
	char bIsShow : 1; // Offset: 0x58 // Size: 0x01
	char pad_0x58_5 : 3; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
	struct FText Describe; // Offset: 0x60 // Size: 0x18
	struct FEvaluateEventFlowParameter EvaluateDescribe; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function EventFlowSystem.EventFlowElementBase.SetElementUnfinishedToServer
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetServer]
	void SetElementUnfinishedToServer(); // Offset: 0x101eb68a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.SetElementUnfinish
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetElementUnfinish(); // Offset: 0x101eb6948 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.SetElementFinishedToServer
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetServer]
	void SetElementFinishedToServer(struct FName EventName); // Offset: 0x101eb68c4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.SetElementFinished
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void SetElementFinished(struct FEventFlowFinishEvent& OnElementFinishedEvent, struct FName EventName); // Offset: 0x101eb695c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.ReceiveWhenTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenTick(float DeltaSeconds); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.ReceiveWhenDeactive
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenDeactive(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.ReceiveWhenConstruct
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenConstruct(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.ReceiveWhenActive
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenActive(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.ReceiveGetDescribe
	// Flags: [Event|Protected|BlueprintEvent|Const]
	struct FText ReceiveGetDescribe(); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.OnRep_IsFinished
	// Flags: [Final|Native|Public]
	void OnRep_IsFinished(); // Offset: 0x101eb6e44 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.GetManagerOwner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetManagerOwner(); // Offset: 0x101eb6da8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.GetManager
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UEventFlowManager* GetManager(); // Offset: 0x101eb6ddc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.GetIsShow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsShow(); // Offset: 0x101eb6c28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.GetIsOptional
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsOptional(); // Offset: 0x101eb6c4c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.GetEventFlow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UEventFlowBase* GetEventFlow(); // Offset: 0x101eb6e10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.GetElementTemplate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UEventFlowElementBase* GetElementTemplate(); // Offset: 0x101eb6c70 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.GetDescribeEx
	// Flags: [Final|Native|Public|Const]
	struct FText GetDescribeEx(); // Offset: 0x101eb6b80 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.GetDescribe
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetDescribe(); // Offset: 0x101eb6a50 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function EventFlowSystem.EventFlowElementBase.ForceFinishElementToServer
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ForceFinishElementToServer(struct FName EventName); // Offset: 0x101eb6824 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class EventFlowSystem.EFE_DelayFinish
// Size: 0xb0 // Inherited bytes: 0x90
struct UEFE_DelayFinish : UEventFlowElementBase {
	// Fields
	float DelayTime; // Offset: 0x8c // Size: 0x04
	char bUseDelayRandomTime : 1; // Offset: 0x90 // Size: 0x01
	float DelayRandomTime; // Offset: 0x94 // Size: 0x04
	float UsedDelayTime; // Offset: 0x98 // Size: 0x04
	float RemainTime; // Offset: 0x9c // Size: 0x04
	struct FEventFlowFinishEvent OnElementFinished; // Offset: 0xa0 // Size: 0x10
};

// Object Name: Class EventFlowSystem.EventFlowElement_BranchContainer
// Size: 0xc0 // Inherited bytes: 0x90
struct UEventFlowElement_BranchContainer : UEventFlowElementBase {
	// Fields
	struct TArray<struct UEventFlowElementBase*> Elements; // Offset: 0x90 // Size: 0x10
	struct TArray<enum class EEventFlowElementLogic> ElementLogics; // Offset: 0xa0 // Size: 0x10
	struct FEventFlowFinishEvent OnContainerFinished; // Offset: 0xb0 // Size: 0x10

	// Functions

	// Object Name: Function EventFlowSystem.EventFlowElement_BranchContainer.GetElementLogics
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<enum class EEventFlowElementLogic> GetElementLogics(); // Offset: 0x101eb7b84 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EventFlowSystem.EventFlowElement_BranchContainer.AddElementTemplateBranchContainer
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEventFlowElementBase* AddElementTemplateBranchContainer(struct UEventFlowElementBase* Template); // Offset: 0x101eb7af8 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class EventFlowSystem.EventFlowElementSubInstanceBase
// Size: 0x98 // Inherited bytes: 0x90
struct UEventFlowElementSubInstanceBase : UEventFlowElementBase {
	// Fields
	struct UObject* SubInstance; // Offset: 0x90 // Size: 0x08
};

// Object Name: Class EventFlowSystem.EventFlowElementBlueprint
// Size: 0xd0 // Inherited bytes: 0xd0
struct UEventFlowElementBlueprint : UBlueprint {
};

// Object Name: Class EventFlowSystem.EventFlowElementGeneratedClass
// Size: 0x400 // Inherited bytes: 0x400
struct UEventFlowElementGeneratedClass : UBlueprintGeneratedClass {
};

// Object Name: Class EventFlowSystem.EventFlowManager
// Size: 0x1d8 // Inherited bytes: 0xf0
struct UEventFlowManager : UActorComponent {
	// Fields
	struct TSet<struct UEventFlowBase*> PreUnderwayEventFlowList; // Offset: 0xf0 // Size: 0x50
	struct TArray<struct UEventFlowBase*> UnderwayEventFlowList; // Offset: 0x140 // Size: 0x10
	struct TArray<struct UEventFlowBase*> PreFinishedEventFlowList; // Offset: 0x150 // Size: 0x10
	struct TArray<struct UEventFlowBase*> FinishedEventFlowList; // Offset: 0x160 // Size: 0x10
	struct FMulticastInlineDelegate OnEventFlowActived; // Offset: 0x170 // Size: 0x10
	struct FMulticastInlineDelegate OnEventFlowFinished; // Offset: 0x180 // Size: 0x10
	struct FMulticastInlineDelegate OnUnderwayEventFlowRemoved; // Offset: 0x190 // Size: 0x10
	struct FMulticastInlineDelegate OnFinishedEventFlowRemoved; // Offset: 0x1a0 // Size: 0x10
	struct TArray<struct UEventFlowElementBase*> TickableElements; // Offset: 0x1b0 // Size: 0x10
	struct UEventFlowBase* SupportEventFlowType; // Offset: 0x1c0 // Size: 0x08
	char pad_0x1C8[0x10]; // Offset: 0x1c8 // Size: 0x10

	// Functions

	// Object Name: Function EventFlowSystem.EventFlowManager.RemoveEventFlowInstance
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void RemoveEventFlowInstance(struct UEventFlowBase* EventFlowInstance); // Offset: 0x101eb878c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowManager.RemoveEventFlow
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void RemoveEventFlow(struct UEventFlowBase* EventFlow); // Offset: 0x101eb8710 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction EventFlowSystem.EventFlowManager.OnUnderwayEventFlowRemoved__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUnderwayEventFlowRemoved__DelegateSignature(struct UEventFlowBase* EventFlow); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowManager.OnRep_UnderwayEventFlowList
	// Flags: [Final|Native|Public]
	void OnRep_UnderwayEventFlowList(); // Offset: 0x101eb8898 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowManager.OnRep_FinishedEventFlowList
	// Flags: [Final|Native|Public]
	void OnRep_FinishedEventFlowList(); // Offset: 0x101eb8884 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction EventFlowSystem.EventFlowManager.OnFinishedEventFlowRemoved__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnFinishedEventFlowRemoved__DelegateSignature(struct UEventFlowBase* EventFlow); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction EventFlowSystem.EventFlowManager.OnEventFlowFinished__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEventFlowFinished__DelegateSignature(struct UEventFlowBase* EventFlow); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction EventFlowSystem.EventFlowManager.OnEventFlowActived__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEventFlowActived__DelegateSignature(struct UEventFlowBase* EventFlow); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowManager.IsEventFlowExistInUnderwayList
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsEventFlowExistInUnderwayList(struct UEventFlowBase* EventFlow); // Offset: 0x101eb8684 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function EventFlowSystem.EventFlowManager.IsEventFlowExistInFinishList
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsEventFlowExistInFinishList(struct UEventFlowBase* EventFlow); // Offset: 0x101eb85f8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function EventFlowSystem.EventFlowManager.IsEventFlowExist
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsEventFlowExist(struct UEventFlowBase* EventFlow); // Offset: 0x101eb856c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function EventFlowSystem.EventFlowManager.ActiveEventFlowInstance
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void ActiveEventFlowInstance(struct UEventFlowBase* EventFlowInstance); // Offset: 0x101eb8808 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class EventFlowSystem.EventFlowFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UEventFlowFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function EventFlowSystem.EventFlowFunctionLibrary.MakeEventFlowFinishEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventFlowFinishEvent MakeEventFlowFinishEvent(struct FDelegate& Delegate); // Offset: 0x101eb96b8 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class EventFlowSystem.EventFlowSequenceBase
// Size: 0xa8 // Inherited bytes: 0x50
struct UEventFlowSequenceBase : UEventFlowNode {
	// Fields
	struct UEventFlowSequenceBase* PrevSequence; // Offset: 0x50 // Size: 0x08
	struct UEventFlowBase* OwningEventFlow; // Offset: 0x58 // Size: 0x08
	struct FText Describe; // Offset: 0x60 // Size: 0x18
	struct FEvaluateEventFlowParameter EvaluateDescribe; // Offset: 0x78 // Size: 0x10
	int32_t NodeID; // Offset: 0x88 // Size: 0x04
	char bReportTLog : 1; // Offset: 0x8c // Size: 0x01
	char pad_0x8C_1 : 7; // Offset: 0x8c // Size: 0x01
	char pad_0x8D[0x3]; // Offset: 0x8d // Size: 0x03
	struct TArray<enum class EEventFlowElementLogic> ElementLogics; // Offset: 0x90 // Size: 0x10
	char InstancedCount; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1_0 : 1; // Offset: 0xa1 // Size: 0x01
	char bIsInterruptAlways : 1; // Offset: 0xa1 // Size: 0x01
	char pad_0xA1_2 : 6; // Offset: 0xa1 // Size: 0x01
	char pad_0xA2[0x6]; // Offset: 0xa2 // Size: 0x06

	// Functions

	// Object Name: Function EventFlowSystem.EventFlowSequenceBase.IsSequenceFinished
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSequenceFinished(); // Offset: 0x101eb9c7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EventFlowSystem.EventFlowSequenceBase.HasShownElement
	// Flags: [Final|Native|Public|Const]
	bool HasShownElement(); // Offset: 0x101eb9cb8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EventFlowSystem.EventFlowSequenceBase.GetElementLogics
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<enum class EEventFlowElementLogic> GetElementLogics(); // Offset: 0x101eb9bf4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EventFlowSystem.EventFlowSequenceBase.GetDescribe
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetDescribe(); // Offset: 0x101eb9cec // Return & Params: Num(1) Size(0x18)

	// Object Name: Function EventFlowSystem.EventFlowSequenceBase.ConstructAndActiveSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ConstructAndActiveSequence(struct UEventFlowBase* InOwner); // Offset: 0x101eb9ab8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EventFlowSystem.EventFlowSequenceBase.CanReinstanceSequence
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool CanReinstanceSequence(struct UEventFlowSequenceBase* Sequence, char MaxInstanceCount); // Offset: 0x101eb9b34 // Return & Params: Num(3) Size(0xa)
};

// Object Name: Class EventFlowSystem.EventFlowSequence_List
// Size: 0xd8 // Inherited bytes: 0xa8
struct UEventFlowSequence_List : UEventFlowSequenceBase {
	// Fields
	struct TArray<struct UEventFlowElementBase*> Elements; // Offset: 0xa8 // Size: 0x10
	struct TArray<struct UEventFlowSequenceBase*> NextSequences; // Offset: 0xb8 // Size: 0x10
	struct FEventFlowFinishEvent OnSequenceFinished; // Offset: 0xc8 // Size: 0x10

	// Functions

	// Object Name: Function EventFlowSystem.EventFlowSequence_List.CreateInstanceFromTemplate
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	struct UEventFlowSequence_List* CreateInstanceFromTemplate(struct UObject* Outer, struct UEventFlowSequence_List* RefValue, struct FEventFlowFinishEvent InOnSequenceFinished); // Offset: 0x101eba2b8 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function EventFlowSystem.EventFlowSequence_List.AddElementTemplateToSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEventFlowElementBase* AddElementTemplateToSequence(struct UEventFlowElementBase* Template); // Offset: 0x101eba22c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class EventFlowSystem.EventFlowSequence_Branch
// Size: 0xd0 // Inherited bytes: 0xa8
struct UEventFlowSequence_Branch : UEventFlowSequenceBase {
	// Fields
	struct TArray<struct UEventFlowElementBase*> Elements; // Offset: 0xa8 // Size: 0x10
	char bIsBranchesActived : 1; // Offset: 0xb8 // Size: 0x01
	char pad_0xB8_1 : 7; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x7]; // Offset: 0xb9 // Size: 0x07
	struct TArray<struct FEventFlowSequenceBranchData> Branches; // Offset: 0xc0 // Size: 0x10

	// Functions

	// Object Name: Function EventFlowSystem.EventFlowSequence_Branch.OnRep_IsBranchesActived
	// Flags: [Final|Native|Public]
	void OnRep_IsBranchesActived(); // Offset: 0x101ebaa04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EventFlowSystem.EventFlowSequence_Branch.CreateInstanceFromTemplate
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	struct UEventFlowSequence_Branch* CreateInstanceFromTemplate(struct UObject* Outer, struct UEventFlowSequence_Branch* RefValue); // Offset: 0x101ebaaa4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function EventFlowSystem.EventFlowSequence_Branch.AddElementTemplateToSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEventFlowElementBase* AddElementTemplateToSequence(struct UEventFlowElementBase* Template); // Offset: 0x101ebaa18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function EventFlowSystem.EventFlowSequence_Branch.AddBranchTemplateFromTemplate
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEventFlowElementBase* AddBranchTemplateFromTemplate(struct UEventFlowElementBase* Template, bool AutoFinishOtherBranch); // Offset: 0x101eba92c // Return & Params: Num(3) Size(0x18)
};

