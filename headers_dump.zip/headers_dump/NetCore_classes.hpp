#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class NetCore.NetAnalyticsAggregatorConfig
// Size: 0x38 // Inherited bytes: 0x28
struct UNetAnalyticsAggregatorConfig : UObject {
	// Fields
	struct TArray<struct FNetAnalyticsDataConfig> NetAnalyticsData; // Offset: 0x28 // Size: 0x10
};

