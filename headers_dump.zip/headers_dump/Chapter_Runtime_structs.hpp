#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Chapter_Runtime.ChapterParams
// Size: 0x10 // Inherited bytes: 0x00
struct FChapterParams {
	// Fields
	struct TArray<struct FChapterParam> Params; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Chapter_Runtime.ChapterParam
// Size: 0x30 // Inherited bytes: 0x00
struct FChapterParam {
	// Fields
	struct FString VariableName; // Offset: 0x00 // Size: 0x10
	float FloatValue; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString StringValue; // Offset: 0x18 // Size: 0x10
	int32_t NumberValue; // Offset: 0x28 // Size: 0x04
	enum class EChapterParamType Type; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: ScriptStruct Chapter_Runtime.ChapterType_TrackLink
// Size: 0x28 // Inherited bytes: 0x00
struct FChapterType_TrackLink {
	// Fields
	struct FString TrackName; // Offset: 0x00 // Size: 0x10
	struct FChapterParams Params; // Offset: 0x10 // Size: 0x10
	bool bOnServer; // Offset: 0x20 // Size: 0x01
	bool bLuaTrack; // Offset: 0x21 // Size: 0x01
	char pad_0x22[0x6]; // Offset: 0x22 // Size: 0x06
};

// Object Name: ScriptStruct Chapter_Runtime.ChapterType_Tracks
// Size: 0x10 // Inherited bytes: 0x00
struct FChapterType_Tracks {
	// Fields
	struct TArray<struct FChapterType_TrackLink> TrackLinks; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Chapter_Runtime.ChapterProfileTemplate
// Size: 0x48 // Inherited bytes: 0x00
struct FChapterProfileTemplate {
	// Fields
	struct FString ModuleName; // Offset: 0x00 // Size: 0x10
	struct FString TrackName; // Offset: 0x10 // Size: 0x10
	struct FString TrackDescribe; // Offset: 0x20 // Size: 0x10
	bool bOnServer; // Offset: 0x30 // Size: 0x01
	bool bLuaTrack; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
	struct FString ArgsList; // Offset: 0x38 // Size: 0x10
};

