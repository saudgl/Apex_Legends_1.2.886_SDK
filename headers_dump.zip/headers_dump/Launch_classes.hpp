#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Launch.Launch_C
// Size: 0x279 // Inherited bytes: 0x270
struct ALaunch_C : ALevelScriptActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x270 // Size: 0x08
	bool UpdateVersion; // Offset: 0x278 // Size: 0x01

	// Functions

	// Object Name: Function Launch.Launch_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Launch.Launch_C.ExecuteUbergraph_Launch
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Launch(int32_t EntryPoint); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)
};

