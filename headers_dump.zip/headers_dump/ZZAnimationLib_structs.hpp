#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_BlendListBase_Component
// Size: 0xe0 // Inherited bytes: 0x20
struct FAnimNode_BlendListBase_Component : FAnimNode_Base {
	// Fields
	struct TArray<struct FPoseLink> BlendLocalPose; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FComponentSpacePoseLink> BlendComponentPose; // Offset: 0x30 // Size: 0x10
	struct TArray<bool> PosesUseByLocalSpace; // Offset: 0x40 // Size: 0x10
	struct TArray<float> BlendTime; // Offset: 0x50 // Size: 0x10
	enum class EBlendListTransitionType_Component TransitionType; // Offset: 0x60 // Size: 0x01
	enum class EAlphaBlendOption BlendType; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x2]; // Offset: 0x62 // Size: 0x02
	struct FName BlendProfileName; // Offset: 0x64 // Size: 0x08
	bool bResetChildOnActivation; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0xb]; // Offset: 0x6d // Size: 0x0b
	struct UCurveFloat* CustomBlendCurve; // Offset: 0x78 // Size: 0x08
	struct UBlendProfile* BlendProfile; // Offset: 0x80 // Size: 0x08
	bool CalcInLocalSpacePose; // Offset: 0x88 // Size: 0x01
	bool IsOutputLocalSpacePose; // Offset: 0x89 // Size: 0x01
	char pad_0x8A[0x56]; // Offset: 0x8a // Size: 0x56
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_BlendListByBool_Component
// Size: 0xe8 // Inherited bytes: 0xe0
struct FAnimNode_BlendListByBool_Component : FAnimNode_BlendListBase_Component {
	// Fields
	bool bActiveValue; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x7]; // Offset: 0xe1 // Size: 0x07
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_BlendListByEnum_Component
// Size: 0xf8 // Inherited bytes: 0xe0
struct FAnimNode_BlendListByEnum_Component : FAnimNode_BlendListBase_Component {
	// Fields
	struct TArray<int32_t> EnumToPoseIndex; // Offset: 0xe0 // Size: 0x10
	char ActiveEnumValue; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x7]; // Offset: 0xf1 // Size: 0x07
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_BlendListByInt_Component
// Size: 0xe8 // Inherited bytes: 0xe0
struct FAnimNode_BlendListByInt_Component : FAnimNode_BlendListBase_Component {
	// Fields
	int32_t ActiveChildIndex; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_CacheBlend
// Size: 0x2b0 // Inherited bytes: 0x20
struct FAnimNode_CacheBlend : FAnimNode_Base {
	// Fields
	struct FPoseLink Source; // Offset: 0x20 // Size: 0x10
	float BlendTime; // Offset: 0x30 // Size: 0x04
	bool ToggleFlag; // Offset: 0x34 // Size: 0x01
	enum class EAlphaBlendOption BlendType; // Offset: 0x35 // Size: 0x01
	char pad_0x36[0x2]; // Offset: 0x36 // Size: 0x02
	struct UCurveFloat* CustomBlendCurve; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x270]; // Offset: 0x40 // Size: 0x270
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_Chain
// Size: 0x2f8 // Inherited bytes: 0xf8
struct FAnimNode_Chain : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference ChainHeadBone; // Offset: 0xf8 // Size: 0x10
	struct TArray<struct FBoneReference> ChainEndBones; // Offset: 0x108 // Size: 0x10
	struct FVector GravityAcce; // Offset: 0x118 // Size: 0x0c
	struct FAxis BoneTwistAxis; // Offset: 0x124 // Size: 0x10
	float ParticleRadiusSize; // Offset: 0x134 // Size: 0x04
	float Damp; // Offset: 0x138 // Size: 0x04
	float LengthStiffness; // Offset: 0x13c // Size: 0x04
	float GlobalConstraintStiffness; // Offset: 0x140 // Size: 0x04
	float LocalConstraintStiffness; // Offset: 0x144 // Size: 0x04
	float SubStepTime; // Offset: 0x148 // Size: 0x04
	int32_t MaxStepCountPerFrame; // Offset: 0x14c // Size: 0x04
	int32_t IterationPerSubStep; // Offset: 0x150 // Size: 0x04
	float DebugConstraintDrawSize; // Offset: 0x154 // Size: 0x04
	float DebugPlaneConstraintArrowSize; // Offset: 0x158 // Size: 0x04
	float DebugPlaneConstraintArrowLength; // Offset: 0x15c // Size: 0x04
	bool ChainLengthNeverChange; // Offset: 0x160 // Size: 0x01
	bool NeedShapeConstraint; // Offset: 0x161 // Size: 0x01
	bool EnableGlobalConstraint; // Offset: 0x162 // Size: 0x01
	bool LockEndBone; // Offset: 0x163 // Size: 0x01
	bool RemoveTwist; // Offset: 0x164 // Size: 0x01
	bool AutoTwistAxisSetup; // Offset: 0x165 // Size: 0x01
	bool EnableSecondaryAxis; // Offset: 0x166 // Size: 0x01
	char pad_0x167[0x1]; // Offset: 0x167 // Size: 0x01
	struct TArray<struct FColliderBodySetupInfo> Colliders; // Offset: 0x168 // Size: 0x10
	struct TArray<struct FPlanarConstraintInfo> CollisionPlanes; // Offset: 0x178 // Size: 0x10
	struct TArray<struct FIgnoreCollisionInfo> IgnoreCollisions; // Offset: 0x188 // Size: 0x10
	bool bEnableDebugDraw; // Offset: 0x198 // Size: 0x01
	bool bEnableDebugDrawInAnimGraph; // Offset: 0x199 // Size: 0x01
	char pad_0x19A[0x6]; // Offset: 0x19a // Size: 0x06
	struct UCurveFloat* ParticleDampingCoefficientCurve; // Offset: 0x1a0 // Size: 0x08
	struct UCurveFloat* ParticleGlobalConstraintStiffnessCoefficientCurve; // Offset: 0x1a8 // Size: 0x08
	struct UCurveFloat* ParticleLocalConstraintStiffnessCoefficientCurve; // Offset: 0x1b0 // Size: 0x08
	struct UCurveFloat* ParticleRadiusCurve; // Offset: 0x1b8 // Size: 0x08
	struct TArray<struct FParticlePhyAttrOverride> OverrideParticlePhysInfo; // Offset: 0x1c0 // Size: 0x10
	struct TArray<struct FLengthConstraintPhyAttrOverride> OverrideLengthConstraintPhysInfo; // Offset: 0x1d0 // Size: 0x10
	struct TArray<struct FLocalConstraintPhyAttrOverride> OverrideLocalConstraintPhysInfo; // Offset: 0x1e0 // Size: 0x10
	struct TArray<struct FGlobalConstraintPhyAttrOverride> OverrideGlobalConstraintPhysInfo; // Offset: 0x1f0 // Size: 0x10
	char pad_0x200[0xf8]; // Offset: 0x200 // Size: 0xf8
};

// Object Name: ScriptStruct ZZAnimationLib.GlobalConstraintPhyAttrOverride
// Size: 0x10 // Inherited bytes: 0x00
struct FGlobalConstraintPhyAttrOverride {
	// Fields
	struct FName ChildParticleRelatedBoneName; // Offset: 0x00 // Size: 0x08
	float Stiffness; // Offset: 0x08 // Size: 0x04
	bool OverrideStiffnessValue; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ZZAnimationLib.LocalConstraintPhyAttrOverride
// Size: 0x18 // Inherited bytes: 0x00
struct FLocalConstraintPhyAttrOverride {
	// Fields
	struct FName ParentParticleRelatedBoneName; // Offset: 0x00 // Size: 0x08
	struct FName ChildParticleRelatedBoneName; // Offset: 0x08 // Size: 0x08
	float Stiffness; // Offset: 0x10 // Size: 0x04
	bool ParentDominate; // Offset: 0x14 // Size: 0x01
	bool OverrideStiffnessValue; // Offset: 0x15 // Size: 0x01
	bool OverrideParentDominate; // Offset: 0x16 // Size: 0x01
	char pad_0x17[0x1]; // Offset: 0x17 // Size: 0x01
};

// Object Name: ScriptStruct ZZAnimationLib.LengthConstraintPhyAttrOverride
// Size: 0x18 // Inherited bytes: 0x00
struct FLengthConstraintPhyAttrOverride {
	// Fields
	struct FName ParentParticleRelatedBoneName; // Offset: 0x00 // Size: 0x08
	struct FName ChildParticleRelatedBoneName; // Offset: 0x08 // Size: 0x08
	float Stiffness; // Offset: 0x10 // Size: 0x04
	bool ParentDominate; // Offset: 0x14 // Size: 0x01
	bool OverrideStiffnessValue; // Offset: 0x15 // Size: 0x01
	bool OverrideParentDominate; // Offset: 0x16 // Size: 0x01
	char pad_0x17[0x1]; // Offset: 0x17 // Size: 0x01
};

// Object Name: ScriptStruct ZZAnimationLib.ParticlePhyAttrOverride
// Size: 0x24 // Inherited bytes: 0x00
struct FParticlePhyAttrOverride {
	// Fields
	struct FName ParticleRelatedBoneName; // Offset: 0x00 // Size: 0x08
	struct FAxis TwistLocalAxis; // Offset: 0x08 // Size: 0x10
	float DampingValue; // Offset: 0x18 // Size: 0x04
	float ParticleRadiusValue; // Offset: 0x1c // Size: 0x04
	bool OverrideTwistLocalAxis; // Offset: 0x20 // Size: 0x01
	bool OverrideDampingValue; // Offset: 0x21 // Size: 0x01
	bool OverrideParticleRadiusValue; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x1]; // Offset: 0x23 // Size: 0x01
};

// Object Name: ScriptStruct ZZAnimationLib.IgnoreCollisionInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FIgnoreCollisionInfo {
	// Fields
	struct FName BoneName; // Offset: 0x00 // Size: 0x08
	struct FName IgnoreColliderName; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ZZAnimationLib.PlanarConstraintInfo
// Size: 0x3c // Inherited bytes: 0x00
struct FPlanarConstraintInfo {
	// Fields
	struct FBoneReference PlaneBone1; // Offset: 0x00 // Size: 0x10
	struct FBoneReference PlaneBone2; // Offset: 0x10 // Size: 0x10
	struct FBoneReference PlaneBone3; // Offset: 0x20 // Size: 0x10
	struct FName ColliderName; // Offset: 0x30 // Size: 0x08
	bool ConstraintInPositivePosition; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
};

// Object Name: ScriptStruct ZZAnimationLib.ColliderBodySetupInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FColliderBodySetupInfo {
	// Fields
	enum class EColliderType ColliderType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FName AttachBoneName; // Offset: 0x04 // Size: 0x08
	struct FName ColliderName; // Offset: 0x0c // Size: 0x08
	struct FVector ColliderOffset; // Offset: 0x14 // Size: 0x0c
	enum class EBoneControlSpace OffsetSpace; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	float SphereRadius; // Offset: 0x24 // Size: 0x04
	float CapsuleHalfLength; // Offset: 0x28 // Size: 0x04
	struct FAxis CapsuleAxis; // Offset: 0x2c // Size: 0x10
	bool ConstraintParticleOutsideSphere; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_ConstraintedLegIK
// Size: 0x128 // Inherited bytes: 0xf8
struct FAnimNode_ConstraintedLegIK : FAnimNode_SkeletalControlBase {
	// Fields
	float ReachPrecision; // Offset: 0xf8 // Size: 0x04
	int32_t MaxIterations; // Offset: 0xfc // Size: 0x04
	struct FZZBlueprintableLegDefinition LegsDefinition; // Offset: 0x100 // Size: 0x10
	char pad_0x110[0x18]; // Offset: 0x110 // Size: 0x18
};

// Object Name: ScriptStruct ZZAnimationLib.ZZBlueprintableLegDefinition
// Size: 0x10 // Inherited bytes: 0x00
struct FZZBlueprintableLegDefinition {
	// Fields
	struct TArray<struct FZZAnimConstraintedLegIKDefinition> Legs; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ZZAnimationLib.ZZAnimConstraintedLegIKDefinition
// Size: 0x40 // Inherited bytes: 0x00
struct FZZAnimConstraintedLegIKDefinition {
	// Fields
	struct FBoneReference IKFootBone; // Offset: 0x00 // Size: 0x10
	struct FBoneReference FKFootBone; // Offset: 0x10 // Size: 0x10
	int32_t NumBonesInLimb; // Offset: 0x20 // Size: 0x04
	float MinRotationAngle; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FZZBoneAngleConstraints> BoneConstraints; // Offset: 0x28 // Size: 0x10
	enum class EAxis FootBoneForwardAxis; // Offset: 0x38 // Size: 0x01
	enum class EAxis HingeRotationAxis; // Offset: 0x39 // Size: 0x01
	bool bEnableRotationLimit; // Offset: 0x3a // Size: 0x01
	bool bEnableKneeTwistCorrection; // Offset: 0x3b // Size: 0x01
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ZZAnimationLib.ZZBoneAngleConstraints
// Size: 0x1c // Inherited bytes: 0x00
struct FZZBoneAngleConstraints {
	// Fields
	struct FBoneReference BoneName; // Offset: 0x00 // Size: 0x10
	float MinRotationAngleRadians; // Offset: 0x10 // Size: 0x04
	float AngleRange; // Offset: 0x14 // Size: 0x04
	enum class EAxis ConstraintPlaneNormalAxis; // Offset: 0x18 // Size: 0x01
	bool FlipAxis; // Offset: 0x19 // Size: 0x01
	bool EnableLimit; // Offset: 0x1a // Size: 0x01
	char pad_0x1B[0x1]; // Offset: 0x1b // Size: 0x01
};

// Object Name: ScriptStruct ZZAnimationLib.ZZAnimConstraintedLegIKData
// Size: 0xa0 // Inherited bytes: 0x00
struct FZZAnimConstraintedLegIKData {
	// Fields
	char pad_0x0[0xa0]; // Offset: 0x00 // Size: 0xa0
};

// Object Name: ScriptStruct ZZAnimationLib.ZZConstraintedIKChain
// Size: 0x40 // Inherited bytes: 0x00
struct FZZConstraintedIKChain {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x00 // Size: 0x40
};

// Object Name: ScriptStruct ZZAnimationLib.ZZConstraintedIKChainLink
// Size: 0x3c // Inherited bytes: 0x00
struct FZZConstraintedIKChainLink {
	// Fields
	char pad_0x0[0x3c]; // Offset: 0x00 // Size: 0x3c
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_LayeredBoneBlendEx
// Size: 0xd0 // Inherited bytes: 0x20
struct FAnimNode_LayeredBoneBlendEx : FAnimNode_Base {
	// Fields
	struct FPoseLink BasePose; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FPoseLink> BlendPoses; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FInputBlendPose> LayerSetup; // Offset: 0x40 // Size: 0x10
	struct TArray<float> BlendWeights; // Offset: 0x50 // Size: 0x10
	bool bMeshSpaceRotationBlend; // Offset: 0x60 // Size: 0x01
	bool bMeshSpaceScaleBlend; // Offset: 0x61 // Size: 0x01
	enum class ECurveBlendOption CurveBlendOption; // Offset: 0x62 // Size: 0x01
	bool bBlendRootMotionBasedOnRootBone; // Offset: 0x63 // Size: 0x01
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	int32_t LODThreshold; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct TArray<struct FPerBoneBlendWeight> PerBoneBlendWeights; // Offset: 0x70 // Size: 0x10
	struct FGuid SkeletonGuid; // Offset: 0x80 // Size: 0x10
	struct FGuid VirtualBondGuid; // Offset: 0x90 // Size: 0x10
	char pad_0xA0[0x30]; // Offset: 0xa0 // Size: 0x30
};

// Object Name: ScriptStruct ZZAnimationLib.AnimMode_OrientationWarping
// Size: 0x60 // Inherited bytes: 0x20
struct FAnimMode_OrientationWarping : FAnimNode_Base {
	// Fields
	struct FPoseLink BasePose; // Offset: 0x20 // Size: 0x10
	float LocomotionAngle; // Offset: 0x30 // Size: 0x04
	struct FAxisSettings Settings; // Offset: 0x34 // Size: 0x08
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct TArray<struct FBoneRef> SpineBones; // Offset: 0x40 // Size: 0x10
	struct FBoneReference IKFootRootBone; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct ZZAnimationLib.BoneRef
// Size: 0x10 // Inherited bytes: 0x00
struct FBoneRef {
	// Fields
	struct FBoneReference Bone; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ZZAnimationLib.AxisSettings
// Size: 0x08 // Inherited bytes: 0x00
struct FAxisSettings {
	// Fields
	enum class EAxis YawRotationAxis; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float BodyOrientationAlpha; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_PartAnimPlayer
// Size: 0xc0 // Inherited bytes: 0x88
struct FAnimNode_PartAnimPlayer : FAnimNode_SequencePlayer {
	// Fields
	struct FPartAnimStructForPin PartAnimStruct; // Offset: 0x88 // Size: 0x10
	bool ResetAccumulatedTimeToggle; // Offset: 0x98 // Size: 0x01
	bool EvaluatePartAnimByName; // Offset: 0x99 // Size: 0x01
	char pad_0x9A[0x26]; // Offset: 0x9a // Size: 0x26
};

// Object Name: ScriptStruct ZZAnimationLib.PartAnimStructForPin
// Size: 0x10 // Inherited bytes: 0x00
struct FPartAnimStructForPin {
	// Fields
	struct TArray<struct UAnimSequenceBase*> PartAnims; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_RandomPlayerX
// Size: 0x78 // Inherited bytes: 0x20
struct FAnimNode_RandomPlayerX : FAnimNode_Base {
	// Fields
	struct FRandomPlayerSequenceEntryContainer EntryContainer; // Offset: 0x20 // Size: 0x10
	char pad_0x30[0x44]; // Offset: 0x30 // Size: 0x44
	bool bShuffleMode; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03
};

// Object Name: ScriptStruct ZZAnimationLib.RandomPlayerSequenceEntryContainer
// Size: 0x10 // Inherited bytes: 0x00
struct FRandomPlayerSequenceEntryContainer {
	// Fields
	struct TArray<struct FRandomPlayerSequenceEntryX> Entries; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ZZAnimationLib.RandomPlayerSequenceEntryX
// Size: 0x50 // Inherited bytes: 0x00
struct FRandomPlayerSequenceEntryX {
	// Fields
	struct UAnimSequence* Sequence; // Offset: 0x00 // Size: 0x08
	float ChanceToPlay; // Offset: 0x08 // Size: 0x04
	int32_t MinLoopCount; // Offset: 0x0c // Size: 0x04
	int32_t MaxLoopCount; // Offset: 0x10 // Size: 0x04
	float MinPlayRate; // Offset: 0x14 // Size: 0x04
	float MaxPlayRate; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FAlphaBlend BlendIn; // Offset: 0x20 // Size: 0x30
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_SpeedWarping
// Size: 0x190 // Inherited bytes: 0xf8
struct FAnimNode_SpeedWarping : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference IKFootRootBone; // Offset: 0xf8 // Size: 0x10
	struct TArray<struct FIKBones> FeetDefinitions; // Offset: 0x108 // Size: 0x10
	struct FBoneReference PelvisBone; // Offset: 0x118 // Size: 0x10
	enum class EIKFootRootLocalAxis SpeedWarpingAxisMode; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x3]; // Offset: 0x129 // Size: 0x03
	float SpeedScaling; // Offset: 0x12c // Size: 0x04
	float PelvisAdjustmentAlpha; // Offset: 0x130 // Size: 0x04
	float MaxIter; // Offset: 0x134 // Size: 0x04
	struct FPelvisAdjustmentInterp PelvisAdjustmentInterp; // Offset: 0x138 // Size: 0x08
	bool ClampIKUsingFKLeg; // Offset: 0x140 // Size: 0x01
	char pad_0x141[0x4f]; // Offset: 0x141 // Size: 0x4f
};

// Object Name: ScriptStruct ZZAnimationLib.PelvisAdjustmentInterp
// Size: 0x08 // Inherited bytes: 0x00
struct FPelvisAdjustmentInterp {
	// Fields
	float Stiffness; // Offset: 0x00 // Size: 0x04
	float Dampen; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ZZAnimationLib.IKBones
// Size: 0x20 // Inherited bytes: 0x00
struct FIKBones {
	// Fields
	struct FBoneReference IKFootBone; // Offset: 0x00 // Size: 0x10
	struct FBoneReference FKFootBone; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ZZAnimationLib.IKFootLocation
// Size: 0x30 // Inherited bytes: 0x00
struct FIKFootLocation {
	// Fields
	struct FVector LimbRootLocation; // Offset: 0x00 // Size: 0x0c
	struct FVector OriginLocation; // Offset: 0x0c // Size: 0x0c
	struct FVector ActualLocation; // Offset: 0x18 // Size: 0x0c
	struct FVector NewLocation; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct ZZAnimationLib.SingleCharacterSpeedLayer
// Size: 0x10 // Inherited bytes: 0x00
struct FSingleCharacterSpeedLayer {
	// Fields
	float AnimationStandardVelocity; // Offset: 0x00 // Size: 0x04
	float AnimationLayerSpeed; // Offset: 0x04 // Size: 0x04
	struct FVector2D LayerRange; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ZZAnimationLib.DynamicAttrAnimInstanceProxy
// Size: 0x990 // Inherited bytes: 0x7b0
struct FDynamicAttrAnimInstanceProxy : FAnimInstanceProxy {
	// Fields
	struct AActor* OwningActor; // Offset: 0x7a8 // Size: 0x08
	struct FAnimInstanceAttributeDict AttrDicts; // Offset: 0x7b0 // Size: 0x1e0
};

// Object Name: ScriptStruct ZZAnimationLib.AnimInstanceAttributeDict
// Size: 0x1e0 // Inherited bytes: 0x00
struct FAnimInstanceAttributeDict {
	// Fields
	struct TMap<struct FName, bool> BoolAttrs; // Offset: 0x00 // Size: 0x50
	struct TMap<struct FName, float> FloatAttrs; // Offset: 0x50 // Size: 0x50
	struct TMap<struct FName, struct FVector> VectorAttrs; // Offset: 0xa0 // Size: 0x50
	struct TMap<struct FName, struct FRotator> RotatorAttrs; // Offset: 0xf0 // Size: 0x50
	struct TMap<struct FName, int32_t> IntegerAttrs; // Offset: 0x140 // Size: 0x50
	struct TMap<struct FName, struct UAnimSequence*> SequenceAttrs; // Offset: 0x190 // Size: 0x50
};

// Object Name: ScriptStruct ZZAnimationLib.CustomizedOrientationWarpingAngleSetting
// Size: 0x30 // Inherited bytes: 0x00
struct FCustomizedOrientationWarpingAngleSetting {
	// Fields
	struct TArray<struct FCustomizedOrientationWarpingAngleRange> RangeSetting; // Offset: 0x00 // Size: 0x10
	struct TArray<float> DirectionAngleSetting; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FCustomizedOrientationWarpingIndexGroup> DirectionGroups; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ZZAnimationLib.CustomizedOrientationWarpingIndexGroup
// Size: 0x50 // Inherited bytes: 0x00
struct FCustomizedOrientationWarpingIndexGroup {
	// Fields
	struct TSet<int32_t> DirectionGroup; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ZZAnimationLib.CustomizedOrientationWarpingAngleRange
// Size: 0x0c // Inherited bytes: 0x00
struct FCustomizedOrientationWarpingAngleRange {
	// Fields
	struct FVector2D AngleRange; // Offset: 0x00 // Size: 0x08
	int32_t DirectionIndex; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ZZAnimationLib.JogStartAnimBPValues
// Size: 0x38 // Inherited bytes: 0x00
struct FJogStartAnimBPValues {
	// Fields
	struct UAnimSequence* JogStartFirstStepAnimation1; // Offset: 0x00 // Size: 0x08
	struct UAnimSequence* JogStartFirstStepAnimation2; // Offset: 0x08 // Size: 0x08
	struct UAnimSequence* JogStartAnimation; // Offset: 0x10 // Size: 0x08
	float JogStartFirstStepAnimation1CurrentTime; // Offset: 0x18 // Size: 0x04
	float JogStartFirstStepAnimation2CurrentTime; // Offset: 0x1c // Size: 0x04
	float JogStartAnimationCurrentTime; // Offset: 0x20 // Size: 0x04
	float JogStartFirstStepAlpha; // Offset: 0x24 // Size: 0x04
	float JogStartFirstStepAngleAlpha; // Offset: 0x28 // Size: 0x04
	float JogStartOrientationWarpingAngleAlpha; // Offset: 0x2c // Size: 0x04
	bool JogStartNormalToJogging; // Offset: 0x30 // Size: 0x01
	bool JogStartEarlyOutToJogging; // Offset: 0x31 // Size: 0x01
	bool IdleNormalToJogStarting; // Offset: 0x32 // Size: 0x01
	char pad_0x33[0x5]; // Offset: 0x33 // Size: 0x05
};

// Object Name: ScriptStruct ZZAnimationLib.AnimMovementData
// Size: 0x60 // Inherited bytes: 0x00
struct FAnimMovementData {
	// Fields
	struct FVector MovementInputVector; // Offset: 0x00 // Size: 0x0c
	struct FVector MovementLastInputVector; // Offset: 0x0c // Size: 0x0c
	struct FVector Velocity; // Offset: 0x18 // Size: 0x0c
	struct FVector HorizontalVelocity; // Offset: 0x24 // Size: 0x0c
	struct FVector Acceleration; // Offset: 0x30 // Size: 0x0c
	struct FRotator VelocityRotation; // Offset: 0x3c // Size: 0x0c
	struct FRotator AccelerationRotation; // Offset: 0x48 // Size: 0x0c
	float VelocitySize; // Offset: 0x54 // Size: 0x04
	float VelocityHorizontalSize; // Offset: 0x58 // Size: 0x04
	bool HasMovementInput; // Offset: 0x5c // Size: 0x01
	bool HasAcceleration; // Offset: 0x5d // Size: 0x01
	char pad_0x5E[0x2]; // Offset: 0x5e // Size: 0x02
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_CSCopySingleBone
// Size: 0x118 // Inherited bytes: 0xf8
struct FAnimNode_CSCopySingleBone : FAnimNode_SkeletalControlBase {
	// Fields
	struct FComponentSpacePoseLink SourcePose; // Offset: 0xf8 // Size: 0x10
	struct FBoneReference CopyBone; // Offset: 0x108 // Size: 0x10
};

// Object Name: ScriptStruct ZZAnimationLib.ZZAnimNode_HoldGunIK
// Size: 0x280 // Inherited bytes: 0xf8
struct FZZAnimNode_HoldGunIK : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xF8[0x8]; // Offset: 0xf8 // Size: 0x08
	struct FBoneSocketTarget HoldingPoint; // Offset: 0x100 // Size: 0x60
	struct FBoneReference IKBone; // Offset: 0x160 // Size: 0x10
	float StartStretchRatio; // Offset: 0x170 // Size: 0x04
	float MaxStretchScale; // Offset: 0x174 // Size: 0x04
	struct FVector EffectorLocation; // Offset: 0x178 // Size: 0x0c
	char pad_0x184[0xc]; // Offset: 0x184 // Size: 0x0c
	struct FBoneSocketTarget EffectorTarget; // Offset: 0x190 // Size: 0x60
	struct FVector JointTargetLocation; // Offset: 0x1f0 // Size: 0x0c
	char pad_0x1FC[0x4]; // Offset: 0x1fc // Size: 0x04
	struct FBoneSocketTarget JointTarget; // Offset: 0x200 // Size: 0x60
	struct FAxis TwistAxis; // Offset: 0x260 // Size: 0x10
	enum class EBoneControlSpace EffectorLocationSpace; // Offset: 0x270 // Size: 0x01
	enum class EBoneControlSpace JointTargetLocationSpace; // Offset: 0x271 // Size: 0x01
	char bAllowStretching : 1; // Offset: 0x272 // Size: 0x01
	char bTakeRotationFromEffectorSpace : 1; // Offset: 0x272 // Size: 0x01
	char bMaintainEffectorRelRot : 1; // Offset: 0x272 // Size: 0x01
	char bAllowTwist : 1; // Offset: 0x272 // Size: 0x01
	char pad_0x272_4 : 4; // Offset: 0x272 // Size: 0x01
	char pad_0x273[0xd]; // Offset: 0x273 // Size: 0x0d
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_LayerBlend2
// Size: 0x1c8 // Inherited bytes: 0x1c0
struct FAnimNode_LayerBlend2 : FAnimNode_LayeredBoneBlend {
	// Fields
	float MeshSpaceRotBlendWeight; // Offset: 0x1c0 // Size: 0x04
	char pad_0x1C4[0x4]; // Offset: 0x1c4 // Size: 0x04
};

// Object Name: ScriptStruct ZZAnimationLib.SingleBoneLayeredConfig
// Size: 0x14 // Inherited bytes: 0x00
struct FSingleBoneLayeredConfig {
	// Fields
	struct FBoneReference Bone; // Offset: 0x00 // Size: 0x10
	float BoneBlendWeight; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_SpringArmSocket
// Size: 0x1d0 // Inherited bytes: 0xf8
struct FAnimNode_SpringArmSocket : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xF8[0x8]; // Offset: 0xf8 // Size: 0x08
	struct FBoneSocketTarget SpringArmEndSocket; // Offset: 0x100 // Size: 0x60
	struct FBoneReference SpringArmRootBone; // Offset: 0x160 // Size: 0x10
	float SpringStiffness; // Offset: 0x170 // Size: 0x04
	float Damp; // Offset: 0x174 // Size: 0x04
	float SubStepTime; // Offset: 0x178 // Size: 0x04
	float springArmOffsetThreshold; // Offset: 0x17c // Size: 0x04
	bool flipSpringArm; // Offset: 0x180 // Size: 0x01
	bool simpleLagSpringArm; // Offset: 0x181 // Size: 0x01
	char pad_0x182[0x2]; // Offset: 0x182 // Size: 0x02
	float LagSpeed; // Offset: 0x184 // Size: 0x04
	float angleConstraint; // Offset: 0x188 // Size: 0x04
	int32_t MaxIterationCount; // Offset: 0x18c // Size: 0x04
	char pad_0x190[0x40]; // Offset: 0x190 // Size: 0x40
};

// Object Name: ScriptStruct ZZAnimationLib.AnimNode_VirtualParent
// Size: 0x1a0 // Inherited bytes: 0xf8
struct FAnimNode_VirtualParent : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xF8[0x8]; // Offset: 0xf8 // Size: 0x08
	struct FBoneSocketTarget VirtualParentSocket; // Offset: 0x100 // Size: 0x60
	struct TArray<struct FBoneReference> VirtualChildren; // Offset: 0x160 // Size: 0x10
	struct FVector AdditiveParentLocationOffset; // Offset: 0x170 // Size: 0x0c
	struct FRotator AddRotationInBoneSpace; // Offset: 0x17c // Size: 0x0c
	bool NeedToApplyRotationToParentAsWell; // Offset: 0x188 // Size: 0x01
	char pad_0x189[0x17]; // Offset: 0x189 // Size: 0x17
};

