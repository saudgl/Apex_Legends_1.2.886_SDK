#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct NetCore.NetAnalyticsDataConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FNetAnalyticsDataConfig {
	// Fields
	struct FName DataName; // Offset: 0x00 // Size: 0x08
	bool bEnabled; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

