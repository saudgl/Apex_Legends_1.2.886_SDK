#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct EntityDispatcher_Runtime.DA_NavPathPoint
// Size: 0x20 // Inherited bytes: 0x00
struct FDA_NavPathPoint {
	// Fields
	struct FVector RelativeLocation; // Offset: 0x00 // Size: 0x0c
	struct FRotator RelativeRotation; // Offset: 0x0c // Size: 0x0c
	struct FName SlotName; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.PlaySequenceMoveToData
// Size: 0x60 // Inherited bytes: 0x00
struct FPlaySequenceMoveToData {
	// Fields
	struct TSoftObjectPtr<APawn> PawnRef; // Offset: 0x00 // Size: 0x28
	struct FMovieSceneObjectBindingID BindingID; // Offset: 0x28 // Size: 0x18
	struct FVector Location; // Offset: 0x40 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x4c // Size: 0x0c
	char bIsArrived : 1; // Offset: 0x58 // Size: 0x01
	char pad_0x58_1 : 7; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.PlaySequenceActorData
// Size: 0x40 // Inherited bytes: 0x00
struct FPlaySequenceActorData {
	// Fields
	struct TSoftObjectPtr<AActor> ActorRef; // Offset: 0x00 // Size: 0x28
	struct FMovieSceneObjectBindingID BindingID; // Offset: 0x28 // Size: 0x18
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.DispatchableAction_SelectionEntryAbstract
// Size: 0x28 // Inherited bytes: 0x00
struct FDispatchableAction_SelectionEntryAbstract {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	int32_t SelectionIndex; // Offset: 0x08 // Size: 0x04
	struct FDispatchableActionFinishEvent OnSelected; // Offset: 0x0c // Size: 0x10
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct UFunction* EvaluateFunction; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.DispatchableActionFinishEvent
// Size: 0x10 // Inherited bytes: 0x00
struct FDispatchableActionFinishEvent {
	// Fields
	struct FDelegate OnDispatchableActionFinished; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.DispatchableAction_SelectionEntryBase
// Size: 0x40 // Inherited bytes: 0x28
struct FDispatchableAction_SelectionEntryBase : FDispatchableAction_SelectionEntryAbstract {
	// Fields
	struct FText SelectionText; // Offset: 0x28 // Size: 0x18
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.DispatchableAction_SelectionEntryExample_3
// Size: 0x48 // Inherited bytes: 0x40
struct FDispatchableAction_SelectionEntryExample_3 : FDispatchableAction_SelectionEntryBase {
	// Fields
	float LockTime; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.DispatchableAction_SelectionEntryExample_2
// Size: 0x48 // Inherited bytes: 0x40
struct FDispatchableAction_SelectionEntryExample_2 : FDispatchableAction_SelectionEntryBase {
	// Fields
	char Type; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.TogetherData
// Size: 0x28 // Inherited bytes: 0x00
struct FTogetherData {
	// Fields
	char bReady : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_1 : 7; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FTogetherEntityData> TogetherEntityDatas; // Offset: 0x08 // Size: 0x10
	struct FDelegate OnStartWaitAction; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.TogetherEntityData
// Size: 0x40 // Inherited bytes: 0x00
struct FTogetherEntityData {
	// Fields
	struct TSoftObjectPtr<AActor> Entity; // Offset: 0x00 // Size: 0x28
	struct FVector TogetherLocation; // Offset: 0x28 // Size: 0x0c
	struct FRotator TogetherRotation; // Offset: 0x34 // Size: 0x0c
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.EvaluateDispatchableActionParameter
// Size: 0x10 // Inherited bytes: 0x00
struct FEvaluateDispatchableActionParameter {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.DispatchableActionCompatibleMatrix
// Size: 0x20 // Inherited bytes: 0x00
struct FDispatchableActionCompatibleMatrix {
	// Fields
	struct TArray<struct UDispatchableActionBase*> CompatibleActions; // Offset: 0x00 // Size: 0x10
	struct TArray<enum class EDispatchableActionCompatibleType> CompatibleMatrix; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.DispatchingActionCollectionRef
// Size: 0x08 // Inherited bytes: 0x00
struct FDispatchingActionCollectionRef {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.DispatchingActionCollection
// Size: 0x10 // Inherited bytes: 0x00
struct FDispatchingActionCollection {
	// Fields
	struct TArray<struct UDispatchableActionBase*> Actions; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EntityDispatcher_Runtime.ReplicableSequenceBinding
// Size: 0x20 // Inherited bytes: 0x00
struct FReplicableSequenceBinding {
	// Fields
	struct FMovieSceneObjectBindingID BindingID; // Offset: 0x00 // Size: 0x18
	struct AActor* BindingActor; // Offset: 0x18 // Size: 0x08
};

