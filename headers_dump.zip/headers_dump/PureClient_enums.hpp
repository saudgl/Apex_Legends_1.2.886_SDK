#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum PureClient.EGameRepairMode
enum class EGameRepairMode : uint8 {
	NonRepair = 0,
	AllRepair = 1,
	ResRepair = 2,
	DlcRepair = 3,
	EGameRepairMode_MAX = 4
};

// Object Name: Enum PureClient.ETaskState
enum class ETaskState : uint8 {
	eReady = 0,
	eDownloading = 1,
	eSuccees = 2,
	eRetry = 3,
	eFailed = 4,
	ETaskState_MAX = 5
};

