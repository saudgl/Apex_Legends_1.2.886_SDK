#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ReplicationGraph.LastLocationGatherInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FLastLocationGatherInfo {
	// Fields
	struct UNetConnection* Connection; // Offset: 0x00 // Size: 0x08
	struct FVector LastLocation; // Offset: 0x08 // Size: 0x0c
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ReplicationGraph.ClassCountCheckerConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FClassCountCheckerConfig {
	// Fields
	struct FSoftClassPath CheckClass; // Offset: 0x00 // Size: 0x18
	int32_t MaxCount; // Offset: 0x18 // Size: 0x04
	int32_t MaxInitialCount; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ReplicationGraph.TearOffActorInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FTearOffActorInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct AActor* Actor; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ReplicationGraph.ConnectionAlwaysRelevantNodePair
// Size: 0x10 // Inherited bytes: 0x00
struct FConnectionAlwaysRelevantNodePair {
	// Fields
	struct UNetConnection* NetConnection; // Offset: 0x00 // Size: 0x08
	struct UReplicationGraphNode_AlwaysRelevant_ForConnection* Node; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ReplicationGraph.AlwaysRelevantActorInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FAlwaysRelevantActorInfo {
	// Fields
	struct UNetConnection* Connection; // Offset: 0x00 // Size: 0x08
	struct AActor* LastViewer; // Offset: 0x08 // Size: 0x08
	struct AActor* LastViewTarget; // Offset: 0x10 // Size: 0x08
};

