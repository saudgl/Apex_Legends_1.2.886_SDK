#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ApasCore.ApasBlueprint
// Size: 0xd0 // Inherited bytes: 0xd0
struct UApasBlueprint : UBlueprint {
};

// Object Name: Class ApasCore.ApasBlueprintGeneratedClass
// Size: 0x400 // Inherited bytes: 0x400
struct UApasBlueprintGeneratedClass : UBlueprintGeneratedClass {
};

// Object Name: Class ApasCore.ApasSettings
// Size: 0x40 // Inherited bytes: 0x28
struct UApasSettings : UObject {
	// Fields
	bool m_EnableAsync; // Offset: 0x28 // Size: 0x01
	bool m_AllowAsyncAbilityUpdate; // Offset: 0x29 // Size: 0x01
	bool m_AllowAsyncCooldownUpdate; // Offset: 0x2a // Size: 0x01
	bool m_LogAbilityFailues; // Offset: 0x2b // Size: 0x01
	bool m_LogVerbose; // Offset: 0x2c // Size: 0x01
	bool m_EchoVerboseToScreen; // Offset: 0x2d // Size: 0x01
	char pad_0x2E[0x2]; // Offset: 0x2e // Size: 0x02
	float m_VerboseScreenOutputLifetime; // Offset: 0x30 // Size: 0x04
	bool m_ForceServerAbilityActivation; // Offset: 0x34 // Size: 0x01
	bool m_CopyInheritedTasks; // Offset: 0x35 // Size: 0x01
	bool m_AlwaysForwardToServer; // Offset: 0x36 // Size: 0x01
	char pad_0x37[0x1]; // Offset: 0x37 // Size: 0x01
	uint32_t m_PredictionTolerance; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

