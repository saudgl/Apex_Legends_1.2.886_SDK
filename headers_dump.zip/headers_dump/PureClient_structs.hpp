#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct PureClient.UpdateVersionInfo
// Size: 0x100 // Inherited bytes: 0x00
struct FUpdateVersionInfo {
	// Fields
	struct FString NewVersion; // Offset: 0x00 // Size: 0x10
	struct FString CurrentVersion; // Offset: 0x10 // Size: 0x10
	struct FString CurrentSrcVersion; // Offset: 0x20 // Size: 0x10
	bool IsAppUpdating; // Offset: 0x30 // Size: 0x01
	bool IsNeedUpdating; // Offset: 0x31 // Size: 0x01
	bool IsResRepairing; // Offset: 0x32 // Size: 0x01
	bool IsForcedUpdating; // Offset: 0x33 // Size: 0x01
	bool IsGrayVersion; // Offset: 0x34 // Size: 0x01
	bool IsAuditVersion; // Offset: 0x35 // Size: 0x01
	bool IsNormalVersion; // Offset: 0x36 // Size: 0x01
	char pad_0x37[0x1]; // Offset: 0x37 // Size: 0x01
	uint64_t NeedDownloadSize; // Offset: 0x38 // Size: 0x08
	struct FString VersionDesc; // Offset: 0x40 // Size: 0x10
	struct FString AppStoreUrl; // Offset: 0x50 // Size: 0x10
	struct FString GoogleStoreUrl; // Offset: 0x60 // Size: 0x10
	uint64_t SkipDownloadSize; // Offset: 0x70 // Size: 0x08
	bool IsForceUpdate; // Offset: 0x78 // Size: 0x01
	bool IsAutoSkipAppUpdate; // Offset: 0x79 // Size: 0x01
	char pad_0x7A[0x6]; // Offset: 0x7a // Size: 0x06
	struct FString ForceVersionListStr; // Offset: 0x80 // Size: 0x10
	struct FString ForceVersionLimit; // Offset: 0x90 // Size: 0x10
	struct FString RestartVersionListStr; // Offset: 0xa0 // Size: 0x10
	struct FString RestartVersionLimit; // Offset: 0xb0 // Size: 0x10
	bool IsNeedResatrt; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x7]; // Offset: 0xc1 // Size: 0x07
	struct FString LobbyServerInfo; // Offset: 0xc8 // Size: 0x10
	struct FString ExtraInfo; // Offset: 0xd8 // Size: 0x10
	bool IsAppDiffUpdate; // Offset: 0xe8 // Size: 0x01
	char pad_0xE9[0x3]; // Offset: 0xe9 // Size: 0x03
	int32_t CusGrayNum; // Offset: 0xec // Size: 0x04
	struct TArray<struct FString> CusGrayArray; // Offset: 0xf0 // Size: 0x10
};

// Object Name: ScriptStruct PureClient.LoginResultData
// Size: 0xa8 // Inherited bytes: 0x00
struct FLoginResultData {
	// Fields
	int32_t ChannelId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString OpenId; // Offset: 0x08 // Size: 0x10
	struct FString Token; // Offset: 0x18 // Size: 0x10
	struct FString Pf; // Offset: 0x28 // Size: 0x10
	struct FString PfKey; // Offset: 0x38 // Size: 0x10
	struct FString UserName; // Offset: 0x48 // Size: 0x10
	struct FString PictureUrl; // Offset: 0x58 // Size: 0x10
	int32_t gender; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString Birthdate; // Offset: 0x70 // Size: 0x10
	struct FString Channel; // Offset: 0x80 // Size: 0x10
	struct FString ChannelInfo; // Offset: 0x90 // Size: 0x10
	int32_t FirstLoginTag; // Offset: 0xa0 // Size: 0x04
	bool IsNeedRealNameAuth; // Offset: 0xa4 // Size: 0x01
	char pad_0xA5[0x3]; // Offset: 0xa5 // Size: 0x03
};

