#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PureClient.AClientGCloudConnector
// Size: 0x78 // Inherited bytes: 0x28
struct UAClientGCloudConnector : UObject {
	// Fields
	char pad_0x28[0x48]; // Offset: 0x28 // Size: 0x48
	bool bIsManualUpdate; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x7]; // Offset: 0x71 // Size: 0x07
};

// Object Name: Class PureClient.AClientGCloudConnectorMgr
// Size: 0x170 // Inherited bytes: 0x38
struct UAClientGCloudConnectorMgr : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0x108]; // Offset: 0x38 // Size: 0x108
	struct UAClientGCloudConnector* Connector; // Offset: 0x140 // Size: 0x08
	struct UHttpDNS* HttpDNS; // Offset: 0x148 // Size: 0x08
	char pad_0x150[0x18]; // Offset: 0x150 // Size: 0x18
	struct UReportManager* ReportManager; // Offset: 0x168 // Size: 0x08
};

// Object Name: Class PureClient.AClientPayMgr
// Size: 0xa0 // Inherited bytes: 0x38
struct UAClientPayMgr : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0x68]; // Offset: 0x38 // Size: 0x68
};

// Object Name: Class PureClient.AClientWebView
// Size: 0x40 // Inherited bytes: 0x38
struct UAClientWebView : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class PureClient.ApexAudioModule
// Size: 0x88 // Inherited bytes: 0x38
struct UApexAudioModule : UApexGameInstanceSubsystem {
	// Fields
	int32_t LerpTimeInMs; // Offset: 0x34 // Size: 0x04
	char pad_0x3C[0x4c]; // Offset: 0x3c // Size: 0x4c

	// Functions

	// Object Name: Function PureClient.ApexAudioModule.SetVolumeWithSettingData
	// Flags: [Final|Native|Public]
	void SetVolumeWithSettingData(); // Offset: 0x103fa7128 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PureClient.ApexAudioModule.ReloadApexAudioConfig
	// Flags: [Final|Native|Protected]
	void ReloadApexAudioConfig(); // Offset: 0x103fa6f68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PureClient.ApexAudioModule.OnSettingChanged
	// Flags: [Final|Native|Protected]
	void OnSettingChanged(struct TArray<struct FString> ChangedPropertyNames); // Offset: 0x103fa6f7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PureClient.ApexAudioModule.OnGameInstanceInit
	// Flags: [Final|Native|Public]
	void OnGameInstanceInit(struct UGameInstance* GameInstance); // Offset: 0x103fa713c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PureClient.ApexAudioModule.GetVOAudioEffectValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetVOAudioEffectValue(); // Offset: 0x103fa6edc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PureClient.ApexAudioModule.GetUIAudioEffectValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetUIAudioEffectValue(); // Offset: 0x103fa6f14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PureClient.ApexAudioModule.GetTeamVoiceValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetTeamVoiceValue(); // Offset: 0x103fa6e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PureClient.ApexAudioModule.GetSpeakerValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetSpeakerValue(); // Offset: 0x103fa6ea4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PureClient.ApexAudioModule.GetMyVoiceValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMyVoiceValue(); // Offset: 0x103fa6e88 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PureClient.ApexAudioModule.GetMicValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMicValue(); // Offset: 0x103fa6ec0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PureClient.ApexAudioModule.GetMainVolumeValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMainVolumeValue(); // Offset: 0x103fa6f30 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PureClient.ApexAudioModule.GetBGMValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetBGMValue(); // Offset: 0x103fa6ef8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PureClient.ApexAudioModule.GetAudioQualityLevel
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetAudioQualityLevel(); // Offset: 0x103fa6f4c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class PureClient.BackgroundDownloadService
// Size: 0x40 // Inherited bytes: 0x28
struct UBackgroundDownloadService : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	bool EnableBackgroundDownloadAndroid; // Offset: 0x38 // Size: 0x01
	bool EnableBackgroundDownloadIOS; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x6]; // Offset: 0x3a // Size: 0x06
};

// Object Name: Class PureClient.CrashSaveGame
// Size: 0x30 // Inherited bytes: 0x28
struct UCrashSaveGame : USaveGame {
	// Fields
	int32_t lastSaveTime; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class PureClient.CustomConfigResMgr
// Size: 0x40 // Inherited bytes: 0x38
struct UCustomConfigResMgr : UApexGameInstanceSubsystem {
	// Fields
	struct UCustomConfigResUpdater* ConfigUpdater; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class PureClient.CustomConfigResUpdater
// Size: 0x38 // Inherited bytes: 0x28
struct UCustomConfigResUpdater : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class PureClient.CustomResUpdater
// Size: 0x178 // Inherited bytes: 0x28
struct UCustomResUpdater : UObject {
	// Fields
	char pad_0x28[0xb8]; // Offset: 0x28 // Size: 0xb8
	struct FString TestUpdateUrl; // Offset: 0xe0 // Size: 0x10
	struct FString ReleaseUpdateUrl; // Offset: 0xf0 // Size: 0x10
	struct FString TestROWUpdateUrl; // Offset: 0x100 // Size: 0x10
	struct FString ReleaseROWUpdateUrl; // Offset: 0x110 // Size: 0x10
	struct FString UpdateChannelIOS; // Offset: 0x120 // Size: 0x10
	struct FString UpdateChannelAndroid; // Offset: 0x130 // Size: 0x10
	struct FString UpdateChannelWin; // Offset: 0x140 // Size: 0x10
	struct FString VersionFile; // Offset: 0x150 // Size: 0x10
	struct FString HotFixFile; // Offset: 0x160 // Size: 0x10
	uint64_t SkipDownloadSize; // Offset: 0x170 // Size: 0x08

	// Functions

	// Object Name: Function PureClient.CustomResUpdater.OnDownloadSuccess
	// Flags: [Final|Native|Public]
	void OnDownloadSuccess(struct FString Filename, float Progress, struct FString CustomDefine, struct FString ResultMsg); // Offset: 0x103fa82d8 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function PureClient.CustomResUpdater.OnDownloadFailed
	// Flags: [Final|Native|Public]
	void OnDownloadFailed(struct FString Filename, float Progress, struct FString CustomDefine, struct FString ResultMsg); // Offset: 0x103fa816c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function PureClient.CustomResUpdater.OnDownloadCancel
	// Flags: [Final|Native|Public]
	void OnDownloadCancel(struct FString Filename, float Progress, struct FString CustomDefine, struct FString ResultMsg); // Offset: 0x103fa8000 // Return & Params: Num(4) Size(0x38)
};

// Object Name: Class PureClient.DolphinUpdater
// Size: 0x458 // Inherited bytes: 0x28
struct UDolphinUpdater : UObject {
	// Fields
	char pad_0x28[0x328]; // Offset: 0x28 // Size: 0x328
	bool OpenDebugLog; // Offset: 0x350 // Size: 0x01
	bool OpenErrorLog; // Offset: 0x351 // Size: 0x01
	char pad_0x352[0x6]; // Offset: 0x352 // Size: 0x06
	struct FString AppStoreUrl; // Offset: 0x358 // Size: 0x10
	struct FString GoogleStoreUrl; // Offset: 0x368 // Size: 0x10
	struct FString ExtraInfo; // Offset: 0x378 // Size: 0x10
	bool DisableUpdate; // Offset: 0x388 // Size: 0x01
	char pad_0x389[0x7]; // Offset: 0x389 // Size: 0x07
	struct FString CustomApkPath; // Offset: 0x390 // Size: 0x10
	bool ForceUpdate; // Offset: 0x3a0 // Size: 0x01
	bool AutoSkipAppUpdate; // Offset: 0x3a1 // Size: 0x01
	bool IgnoreResUpdateError; // Offset: 0x3a2 // Size: 0x01
	char pad_0x3A3[0x5]; // Offset: 0x3a3 // Size: 0x05
	struct FString TestUpdateUrl; // Offset: 0x3a8 // Size: 0x10
	struct FString ReleaseUpdateUrl; // Offset: 0x3b8 // Size: 0x10
	uint32_t UpdateChannel; // Offset: 0x3c8 // Size: 0x04
	uint32_t UpdateChannelIOS; // Offset: 0x3cc // Size: 0x04
	uint32_t UpdateChannelAndroid; // Offset: 0x3d0 // Size: 0x04
	uint32_t UpdateChannelWin; // Offset: 0x3d4 // Size: 0x04
	uint64_t SkipDownloadSize; // Offset: 0x3d8 // Size: 0x08
	bool bIsGrayUpdate; // Offset: 0x3e0 // Size: 0x01
	bool IsAppDiffUpdate; // Offset: 0x3e1 // Size: 0x01
	char pad_0x3E2[0x6]; // Offset: 0x3e2 // Size: 0x06
	int64_t CusGrayNum; // Offset: 0x3e8 // Size: 0x08
	struct TArray<struct FString> CusGrayArray; // Offset: 0x3f0 // Size: 0x10
	struct FString ForceVersionListStr; // Offset: 0x400 // Size: 0x10
	struct FString ForceVersionLimit; // Offset: 0x410 // Size: 0x10
	struct FString RestartVersionListStr; // Offset: 0x420 // Size: 0x10
	struct FString RestartVersionLimit; // Offset: 0x430 // Size: 0x10
	struct FString LobbyServerInfo; // Offset: 0x440 // Size: 0x10
	bool EnableRollback; // Offset: 0x450 // Size: 0x01
	bool EnableDolphinBgDownload; // Offset: 0x451 // Size: 0x01
	char pad_0x452[0x6]; // Offset: 0x452 // Size: 0x06
};

// Object Name: Class PureClient.GameUpdateMgr
// Size: 0x60 // Inherited bytes: 0x38
struct UGameUpdateMgr : UApexGameInstanceSubsystem {
	// Fields
	struct UDolphinUpdater* DolphinUpdater; // Offset: 0x38 // Size: 0x08
	struct UCustomResUpdater* CustomResUpdater; // Offset: 0x40 // Size: 0x08
	struct UTranslateResUpdate* TranslateResUpdate; // Offset: 0x48 // Size: 0x08
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
	struct UMergePakUpdater* MergePakUpdater; // Offset: 0x58 // Size: 0x08
};

// Object Name: Class PureClient.GCloudFriendMgr
// Size: 0x50 // Inherited bytes: 0x38
struct UGCloudFriendMgr : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 // Size: 0x18
};

// Object Name: Class PureClient.GCloudPufferMgr
// Size: 0x168 // Inherited bytes: 0x38
struct UGCloudPufferMgr : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0x28]; // Offset: 0x38 // Size: 0x28
	struct FString TestPufferServerUrl; // Offset: 0x60 // Size: 0x10
	struct FString ReleasePufferServerUrl; // Offset: 0x70 // Size: 0x10
	uint32_t PufferProductId; // Offset: 0x80 // Size: 0x04
	uint32_t PufferAndroidProductId; // Offset: 0x84 // Size: 0x04
	uint32_t PufferIOSProductId; // Offset: 0x88 // Size: 0x04
	uint32_t PufferHightProductId; // Offset: 0x8c // Size: 0x04
	bool NeedCheck; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
	int64_t PufferGameId; // Offset: 0x98 // Size: 0x08
	uint32_t MaxDownloadSpeed; // Offset: 0xa0 // Size: 0x04
	uint32_t MaxDownTask; // Offset: 0xa4 // Size: 0x04
	uint32_t MaxDownloadsPerTask; // Offset: 0xa8 // Size: 0x04
	bool FileRestore; // Offset: 0xac // Size: 0x01
	char pad_0xAD[0x3]; // Offset: 0xad // Size: 0x03
	struct FString DefaultFileName; // Offset: 0xb0 // Size: 0x10
	bool RemoveOldWhenUpdate; // Offset: 0xc0 // Size: 0x01
	bool PufferMulVersion; // Offset: 0xc1 // Size: 0x01
	char pad_0xC2[0x2]; // Offset: 0xc2 // Size: 0x02
	int32_t PufferMulType; // Offset: 0xc4 // Size: 0x04
	struct FString PufferVersionName; // Offset: 0xc8 // Size: 0x10
	struct FString CurPufferVersionName; // Offset: 0xd8 // Size: 0x10
	struct FString TempDirName; // Offset: 0xe8 // Size: 0x10
	struct FString DefaultPufferVersion; // Offset: 0xf8 // Size: 0x10
	bool IsBanPufferDiff; // Offset: 0x108 // Size: 0x01
	char pad_0x109[0x7]; // Offset: 0x109 // Size: 0x07
	struct FString ChunkInfoName; // Offset: 0x110 // Size: 0x10
	bool IsBanPufferInit; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x47]; // Offset: 0x121 // Size: 0x47
};

// Object Name: Class PureClient.MyGoogleLVLObserver
// Size: 0x40 // Inherited bytes: 0x28
struct UMyGoogleLVLObserver : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 // Size: 0x18
};

// Object Name: Class PureClient.GoogleLVLModule
// Size: 0x50 // Inherited bytes: 0x38
struct UGoogleLVLModule : UApexGameInstanceSubsystem {
	// Fields
	bool OpenGoogleLVL; // Offset: 0x32 // Size: 0x01
	char pad_0x39[0x17]; // Offset: 0x39 // Size: 0x17
};

// Object Name: Class PureClient.GPMReport
// Size: 0x48 // Inherited bytes: 0x28
struct UGPMReport : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
};

// Object Name: Class PureClient.HttpDNS
// Size: 0x28 // Inherited bytes: 0x28
struct UHttpDNS : UObject {
};

// Object Name: Class PureClient.HttpDownloadFile
// Size: 0x140 // Inherited bytes: 0x30
struct UHttpDownloadFile : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnWait; // Offset: 0x40 // Size: 0x10
	struct FMulticastInlineDelegate OnFail; // Offset: 0x50 // Size: 0x10
	struct FMulticastInlineDelegate OnProgress; // Offset: 0x60 // Size: 0x10
	struct FMulticastInlineDelegate OnCancel; // Offset: 0x70 // Size: 0x10
	enum class ETaskState State; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x3]; // Offset: 0x81 // Size: 0x03
	int32_t TryCount; // Offset: 0x84 // Size: 0x04
	struct FString URL; // Offset: 0x88 // Size: 0x10
	struct FString Filename; // Offset: 0x98 // Size: 0x10
	struct FString Directory; // Offset: 0xa8 // Size: 0x10
	float Progress; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	int64_t CurFileSize; // Offset: 0xc0 // Size: 0x08
	int64_t TotalFileSize; // Offset: 0xc8 // Size: 0x08
	int32_t MaxTask; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct FString MD5Str; // Offset: 0xd8 // Size: 0x10
	bool bClearCache; // Offset: 0xe8 // Size: 0x01
	char pad_0xE9[0x7]; // Offset: 0xe9 // Size: 0x07
	struct FString CustomDefineStr; // Offset: 0xf0 // Size: 0x10
	struct FString ResultMsg; // Offset: 0x100 // Size: 0x10
	int32_t WaitResponse; // Offset: 0x110 // Size: 0x04
	char pad_0x114[0x4]; // Offset: 0x114 // Size: 0x04
	struct UHttpSubsystemMgr* Mgr; // Offset: 0x118 // Size: 0x08
	char pad_0x120[0x20]; // Offset: 0x120 // Size: 0x20

	// Functions

	// Object Name: Function PureClient.HttpDownloadFile.DownLoadHttpFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UHttpDownloadFile* DownLoadHttpFile(struct UObject* WorldContextObject, struct FString InUrl, struct FString InFilename, struct FString InDirectory, struct FString CusStr, bool bClearCache); // Offset: 0x103fa9f50 // Return & Params: Num(7) Size(0x58)
};

// Object Name: Class PureClient.HttpSubsystemMgr
// Size: 0x70 // Inherited bytes: 0x30
struct UHttpSubsystemMgr : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
	int32_t MaxParallel; // Offset: 0x38 // Size: 0x04
	int32_t MaxTryCount; // Offset: 0x3c // Size: 0x04
	int64_t RequestKBSize; // Offset: 0x40 // Size: 0x08
	float ResponseTimeout; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x14]; // Offset: 0x4c // Size: 0x14
	struct TArray<struct UHttpDownloadFile*> DownloadHttpFiles; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class PureClient.LoginMgrWrapper
// Size: 0x240 // Inherited bytes: 0x38
struct ULoginMgrWrapper : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0xc0]; // Offset: 0x38 // Size: 0xc0
	bool OpenServerList; // Offset: 0xf8 // Size: 0x01
	bool OpenPasscode; // Offset: 0xf9 // Size: 0x01
	bool HideLegal; // Offset: 0xfa // Size: 0x01
	char pad_0xFB[0x5]; // Offset: 0xfb // Size: 0x05
	struct TMap<struct FString, struct FString> ChannelList; // Offset: 0x100 // Size: 0x50
	struct TMap<struct FString, struct FString> GameServerBackupIpList; // Offset: 0x150 // Size: 0x50
	int32_t AuthFailedTimeInterval; // Offset: 0x1a0 // Size: 0x04
	int32_t AuthFailedLimitMinCount; // Offset: 0x1a4 // Size: 0x04
	int32_t AuthFailedLimitMaxCount; // Offset: 0x1a8 // Size: 0x04
	char pad_0x1AC[0x4]; // Offset: 0x1ac // Size: 0x04
	int64_t AuthFailedLimitShortCD; // Offset: 0x1b0 // Size: 0x08
	int64_t AuthFailedLimitLongCD; // Offset: 0x1b8 // Size: 0x08
	struct TArray<int64_t> AuthFailedRecordList; // Offset: 0x1c0 // Size: 0x10
	struct FString MSDKTestUrl; // Offset: 0x1d0 // Size: 0x10
	struct FString MSDKReleaseUrl; // Offset: 0x1e0 // Size: 0x10
	bool EnableLaunchMode; // Offset: 0x1f0 // Size: 0x01
	bool IsThirdPay; // Offset: 0x1f1 // Size: 0x01
	char pad_0x1F2[0x6]; // Offset: 0x1f2 // Size: 0x06
	struct FString H5ServerURL; // Offset: 0x1f8 // Size: 0x10
	struct FString NotifySmallIcon; // Offset: 0x208 // Size: 0x10
	struct FString TestLobbyServerUrl; // Offset: 0x218 // Size: 0x10
	bool OpenGMPanel; // Offset: 0x228 // Size: 0x01
	char pad_0x229[0x17]; // Offset: 0x229 // Size: 0x17
};

// Object Name: Class PureClient.LogReport
// Size: 0x50 // Inherited bytes: 0x28
struct ULogReport : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 // Size: 0x28
};

// Object Name: Class PureClient.MergePakUpdater
// Size: 0x60 // Inherited bytes: 0x28
struct UMergePakUpdater : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
	int32_t MaxThread; // Offset: 0x48 // Size: 0x04
	bool BChangeToPakName; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
	float ThreadWaitTime; // Offset: 0x50 // Size: 0x04
	int32_t MainThreadWaitFrame; // Offset: 0x54 // Size: 0x04
	bool BAutoClearFinish; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07

	// Functions

	// Object Name: Function PureClient.MergePakUpdater.StartMergeDiffPak
	// Flags: [Final|Native|Public]
	void StartMergeDiffPak(struct FString oldPakName, struct FString diffPakName, struct FString newPakName, struct FString MD5Str, struct FString oldMD5Str); // Offset: 0x103fab200 // Return & Params: Num(5) Size(0x50)

	// Object Name: Function PureClient.MergePakUpdater.SetThreadNum
	// Flags: [Final|Native|Public]
	void SetThreadNum(int32_t threadNum); // Offset: 0x103faad7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PureClient.MergePakUpdater.OnNotifyFinish
	// Flags: [Final|Native|Public]
	void OnNotifyFinish(struct FString oldPakName, struct FString diffPakName, struct FString newPakName, int32_t RetCode, int64_t Duration); // Offset: 0x103faaf14 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function PureClient.MergePakUpdater.Init
	// Flags: [Final|Native|Public]
	void Init(); // Offset: 0x103fab578 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PureClient.MergePakUpdater.GetPakName
	// Flags: [Final|Native|Public]
	struct FString GetPakName(struct FString pakPath); // Offset: 0x103faadf8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function PureClient.MergePakUpdater.ClearMergeDiffTask
	// Flags: [Final|Native|Public]
	void ClearMergeDiffTask(); // Offset: 0x103fab1ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PureClient.MergePakUpdater.ClearFinishMergeDiffTask
	// Flags: [Final|Native|Public]
	void ClearFinishMergeDiffTask(); // Offset: 0x103fab1c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PureClient.MergePakUpdater.ClearCurMergeDiffTask
	// Flags: [Final|Native|Public]
	void ClearCurMergeDiffTask(); // Offset: 0x103fab1d8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class PureClient.MSDKDeepLinkModule
// Size: 0x40 // Inherited bytes: 0x38
struct UMSDKDeepLinkModule : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class PureClient.MSDKLBSModule
// Size: 0x40 // Inherited bytes: 0x38
struct UMSDKLBSModule : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class PureClient.NetInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UNetInterface : UInterface {
};

// Object Name: Class PureClient.PandoraModule
// Size: 0xa8 // Inherited bytes: 0x38
struct UPandoraModule : UApexGameInstanceSubsystem {
	// Fields
	bool bInitSDK; // Offset: 0x32 // Size: 0x01
	bool bFormal; // Offset: 0x33 // Size: 0x01
	struct FString AppID_qq; // Offset: 0x38 // Size: 0x10
	struct FString AppID_wx; // Offset: 0x48 // Size: 0x10
	struct FString AppID_qq_row; // Offset: 0x58 // Size: 0x10
	struct FString AppID_wx_row; // Offset: 0x68 // Size: 0x10
	struct FString ChanelID; // Offset: 0x78 // Size: 0x10
	struct FString EditorPlatform; // Offset: 0x88 // Size: 0x10
	int32_t SDKVersion; // Offset: 0x98 // Size: 0x04
	char pad_0x9E[0xa]; // Offset: 0x9e // Size: 0x0a
};

// Object Name: Class PureClient.PufferDiffMgr
// Size: 0x2a0 // Inherited bytes: 0x38
struct UPufferDiffMgr : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0x1b8]; // Offset: 0x38 // Size: 0x1b8
	struct ULuaStateWrapper* LuaStateWrapper; // Offset: 0x1f0 // Size: 0x08
	char pad_0x1F8[0xa8]; // Offset: 0x1f8 // Size: 0xa8
};

// Object Name: Class PureClient.ReportManager
// Size: 0xc0 // Inherited bytes: 0x38
struct UReportManager : UApexGameInstanceSubsystem {
	// Fields
	char pad_0x38[0x28]; // Offset: 0x38 // Size: 0x28
	struct ULogReport* LogReport; // Offset: 0x60 // Size: 0x08
	struct UGPMReport* GPMReport; // Offset: 0x68 // Size: 0x08
	struct UTGPAReport* TGPARportInstance; // Offset: 0x70 // Size: 0x08
	struct FString CDNBaseUrl; // Offset: 0x78 // Size: 0x10
	struct FString ReportChannel; // Offset: 0x88 // Size: 0x10
	bool EnableUploadCrashLog; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x1f]; // Offset: 0x99 // Size: 0x1f
	bool EnableLuaReport; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x1]; // Offset: 0xb9 // Size: 0x01
	bool EnableUpload; // Offset: 0xba // Size: 0x01
	bool EnableCPPReport; // Offset: 0xbb // Size: 0x01
	bool EnableEngineReport; // Offset: 0xbc // Size: 0x01
	char pad_0xBD[0x3]; // Offset: 0xbd // Size: 0x03
};

// Object Name: Class PureClient.TGPAReport
// Size: 0x60 // Inherited bytes: 0x28
struct UTGPAReport : UObject {
	// Fields
	struct UOverheadReportConfig* OverheadReportConfig; // Offset: 0x28 // Size: 0x08
	struct FString OverheadReportConfigPath; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x8]; // Offset: 0x40 // Size: 0x08
	bool isUpdateEnableLog; // Offset: 0x48 // Size: 0x01
	bool bEnableLog; // Offset: 0x49 // Size: 0x01
	bool isUpdateGameInfo1; // Offset: 0x4a // Size: 0x01
	bool isUpdateGameInfo2; // Offset: 0x4b // Size: 0x01
	bool isUpdateGameInfo3; // Offset: 0x4c // Size: 0x01
	bool isUpdateGameInfo4; // Offset: 0x4d // Size: 0x01
	bool isUpdateGameFps; // Offset: 0x4e // Size: 0x01
	bool isLoginSendInfo; // Offset: 0x4f // Size: 0x01
	bool isUpdateTargetFrame; // Offset: 0x50 // Size: 0x01
	char UpdateTargetFrame; // Offset: 0x51 // Size: 0x01
	bool isUpdateOverheadInfo; // Offset: 0x52 // Size: 0x01
	char pad_0x53[0xd]; // Offset: 0x53 // Size: 0x0d
};

// Object Name: Class PureClient.TranslateResUpdate
// Size: 0xf0 // Inherited bytes: 0x28
struct UTranslateResUpdate : UObject {
	// Fields
	struct FString TestUpdateUrl; // Offset: 0x28 // Size: 0x10
	struct FString ReleaseUpdateUrl; // Offset: 0x38 // Size: 0x10
	struct FString TestROWUpdateUrl; // Offset: 0x48 // Size: 0x10
	struct FString ReleaseROWUpdateUrl; // Offset: 0x58 // Size: 0x10
	struct FString UpdateChannelIOS; // Offset: 0x68 // Size: 0x10
	struct FString UpdateChannelAndroid; // Offset: 0x78 // Size: 0x10
	struct FString UpdateChannelWin; // Offset: 0x88 // Size: 0x10
	struct FString SaveFileName; // Offset: 0x98 // Size: 0x10
	struct FString CurrentPakName; // Offset: 0xa8 // Size: 0x10
	int32_t CurrentVersion; // Offset: 0xb8 // Size: 0x04
	bool IsUpdating; // Offset: 0xbc // Size: 0x01
	char pad_0xBD[0x3]; // Offset: 0xbd // Size: 0x03
	struct FString BaseServerUrl; // Offset: 0xc0 // Size: 0x10
	struct FString PakFolderName; // Offset: 0xd0 // Size: 0x10
	struct FString FileListTag; // Offset: 0xe0 // Size: 0x10

	// Functions

	// Object Name: Function PureClient.TranslateResUpdate.OnDownloadSuccess
	// Flags: [Final|Native|Public]
	void OnDownloadSuccess(struct FString Filename, float Progress, struct FString CustomDefine, struct FString ResultMsg); // Offset: 0x103facc1c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function PureClient.TranslateResUpdate.OnDownloadFailed
	// Flags: [Final|Native|Public]
	void OnDownloadFailed(struct FString Filename, float Progress, struct FString CustomDefine, struct FString ResultMsg); // Offset: 0x103facab0 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function PureClient.TranslateResUpdate.OnDownloadCancel
	// Flags: [Final|Native|Public]
	void OnDownloadCancel(struct FString Filename, float Progress, struct FString CustomDefine, struct FString ResultMsg); // Offset: 0x103fac944 // Return & Params: Num(4) Size(0x38)
};

