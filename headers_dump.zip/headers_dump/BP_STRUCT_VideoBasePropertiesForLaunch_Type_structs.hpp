#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VideoBasePropertiesForLaunch_Type.BP_STRUCT_VideoBasePropertiesForLaunch_Type
// Size: 0xa4 // Inherited bytes: 0x00
struct FBP_STRUCT_VideoBasePropertiesForLaunch_Type {
	// Fields
	int32_t Id_2_9FEF3EAF4C14F892F196AC8E92143981; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int32_t> SubtitleStartAndEndIds_3_510BCEC06352BF616F7829540D317643; // Offset: 0x08 // Size: 0x10
	struct FString VideoSourcePath_4_721683001A8B01EE72AB098C0B9FFD78; // Offset: 0x18 // Size: 0x10
	struct FString MediaPlayerPath_5_03A49C405A4A98AB7CF1AC770D70E678; // Offset: 0x28 // Size: 0x10
	struct FString MediaTexturePath_6_3545FD40738BE4455DCFDCCE07F16238; // Offset: 0x38 // Size: 0x10
	struct FString BgTexturePath_7_4BDD2F807D3267784F1C21040BA8E618; // Offset: 0x48 // Size: 0x10
	struct FString SoundBankArrStr_8_575DDE80068DFFEA3B7E72F60B80EB72; // Offset: 0x58 // Size: 0x10
	struct FString SoundEventArrStr_9_08948000163FF5CE3515DA810814CEA2; // Offset: 0x68 // Size: 0x10
	bool IsShowFirstBg_10_68F4294060DF166D160B685E04681F27; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x7]; // Offset: 0x79 // Size: 0x07
	struct FString ResumeAudioEventStr_11_39DCED4016A6B2F577D61FC0033F9BF2; // Offset: 0x80 // Size: 0x10
	struct FString PauseAudioEventStr_12_33FB508043E3B4821D1DEA4805A954F2; // Offset: 0x90 // Size: 0x10
	int32_t DyDownloadid_13_51F9964045DD6EAD29A1AC5C05764824; // Offset: 0xa0 // Size: 0x04
};

