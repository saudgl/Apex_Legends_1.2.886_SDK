#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct HTN.EQSParametrizedQueryExecutionRequestHTN
// Size: 0x58 // Inherited bytes: 0x58
struct FEQSParametrizedQueryExecutionRequestHTN : FEQSParametrizedQueryExecutionRequest {
};

// Object Name: ScriptStruct HTN.HNTIntervalCountdown
// Size: 0x08 // Inherited bytes: 0x00
struct FHNTIntervalCountdown {
	// Fields
	float Interval; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct HTN.WorldstateSetValueContainer
// Size: 0x40 // Inherited bytes: 0x00
struct FWorldstateSetValueContainer {
	// Fields
	int32_t IntValue; // Offset: 0x00 // Size: 0x04
	float FloatValue; // Offset: 0x04 // Size: 0x04
	struct FVector VectorValue; // Offset: 0x08 // Size: 0x0c
	struct FRotator RotatorValue; // Offset: 0x14 // Size: 0x0c
	struct FString StringValue; // Offset: 0x20 // Size: 0x10
	struct FName NameValue; // Offset: 0x30 // Size: 0x08
	struct UObject* ObjectValue; // Offset: 0x38 // Size: 0x08
};

