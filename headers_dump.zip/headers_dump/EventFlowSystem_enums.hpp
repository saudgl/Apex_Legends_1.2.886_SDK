#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum EventFlowSystem.EEventFlowState
enum class EEventFlowState : uint8 {
	Unactived = 0,
	Actived = 1,
	Finished = 2,
	EEventFlowState_MAX = 3
};

// Object Name: Enum EventFlowSystem.EEventFlowElementLogic
enum class EEventFlowElementLogic : uint8 {
	And = 0,
	Or = 1,
	EEventFlowElementLogic_MAX = 2
};

