#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum ChaosSolverEngine.EClusterConnectionTypeEnum
enum class EClusterConnectionTypeEnum : uint8 {
	Chaos_PointImplicit = 1,
	Chaos_DelaunayTriangulation = 2,
	Chaos_MinimalSpanningSubsetDelaunayTriangulation = 3,
	Chaos_PointImplicitAugmentedWithMinimalDelaunay = 4,
	Chaos_None = 0,
	Chaos_EClsuterCreationParameters_Max = 1,
	Chaos_MAX = 5
};

