#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PandoraComponent.LuaActor
// Size: 0x2e8 // Inherited bytes: 0x268
struct ALuaActor : AActor {
	// Fields
	char pad_0x268[0x60]; // Offset: 0x268 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x2c8 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x2d8 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.LuaActor.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args); // Offset: 0x10206512c // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.LuaPawn
// Size: 0x348 // Inherited bytes: 0x2c8
struct ALuaPawn : APawn {
	// Fields
	char pad_0x2C8[0x60]; // Offset: 0x2c8 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x328 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x338 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.LuaPawn.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args); // Offset: 0x102065864 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.LuaCharacter
// Size: 0x710 // Inherited bytes: 0x690
struct ALuaCharacter : ACharacter {
	// Fields
	char pad_0x690[0x58]; // Offset: 0x690 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x6e8 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x6f8 // Size: 0x10
	char pad_0x708[0x8]; // Offset: 0x708 // Size: 0x08

	// Functions

	// Object Name: Function PandoraComponent.LuaCharacter.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args); // Offset: 0x102065e54 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.LuaController
// Size: 0x3b0 // Inherited bytes: 0x330
struct ALuaController : AController {
	// Fields
	char pad_0x330[0x60]; // Offset: 0x330 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x390 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x3a0 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.LuaController.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args); // Offset: 0x102066504 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.LuaPlayerController
// Size: 0x6e8 // Inherited bytes: 0x668
struct ALuaPlayerController : APlayerController {
	// Fields
	char pad_0x668[0x60]; // Offset: 0x668 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x6c8 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x6d8 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.LuaPlayerController.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args); // Offset: 0x102066b88 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.LuaActorComponent
// Size: 0x1a0 // Inherited bytes: 0xf0
struct ULuaActorComponent : UActorComponent {
	// Fields
	char pad_0xF0[0x90]; // Offset: 0xf0 // Size: 0x90
	struct FString LuaFilePath; // Offset: 0x180 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x190 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.LuaActorComponent.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args); // Offset: 0x102067474 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.LuaGameModeBase
// Size: 0x450 // Inherited bytes: 0x3d0
struct ALuaGameModeBase : AGameModeBase {
	// Fields
	char pad_0x3D0[0x60]; // Offset: 0x3d0 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x430 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x440 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.LuaGameModeBase.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args); // Offset: 0x1020679b8 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.LuaHUD
// Size: 0x3d8 // Inherited bytes: 0x358
struct ALuaHUD : AHUD {
	// Fields
	char pad_0x358[0x60]; // Offset: 0x358 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x3b8 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x3c8 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.LuaHUD.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args); // Offset: 0x102068030 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.LuaTableObjectInterface
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaTableObjectInterface : UInterface {
};

// Object Name: Class PandoraComponent.LuaBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.GetStringFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetStringFromVar(struct FLuaBPVar Value, int32_t Index); // Offset: 0x102068bb0 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.GetObjectFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* GetObjectFromVar(struct FLuaBPVar Value, int32_t Index); // Offset: 0x102068998 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.GetNumberFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetNumberFromVar(struct FLuaBPVar Value, int32_t Index); // Offset: 0x102068d18 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.GetIntFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetIntFromVar(struct FLuaBPVar Value, int32_t Index); // Offset: 0x102068e24 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.GetBoolFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetBoolFromVar(struct FLuaBPVar Value, int32_t Index); // Offset: 0x102068aa4 // Return & Params: Num(3) Size(0x25)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.CreateVarFromString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLuaBPVar CreateVarFromString(struct FString Value); // Offset: 0x10206913c // Return & Params: Num(2) Size(0x30)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.CreateVarFromObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLuaBPVar CreateVarFromObject(struct UObject* Value); // Offset: 0x102068f30 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.CreateVarFromNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLuaBPVar CreateVarFromNumber(float Value); // Offset: 0x102069090 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.CreateVarFromInt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLuaBPVar CreateVarFromInt(int32_t Value); // Offset: 0x102069294 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.CreateVarFromBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLuaBPVar CreateVarFromBool(bool Value); // Offset: 0x102068fdc // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.CallToLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallToLuaWithArgs(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args, struct FString StateName); // Offset: 0x102069580 // Return & Params: Num(4) Size(0x50)

	// Object Name: Function PandoraComponent.LuaBlueprintLibrary.CallToLua
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLuaBPVar CallToLua(struct FString FunctionName, struct FString StateName); // Offset: 0x102069340 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.LuaDelegate
// Size: 0x38 // Inherited bytes: 0x28
struct ULuaDelegate : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.LuaDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EventTrigger(); // Offset: 0x102069de4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class PandoraComponent.LuaUserWidget
// Size: 0x2f0 // Inherited bytes: 0x240
struct ULuaUserWidget : UUserWidget {
	// Fields
	char pad_0x240[0x58]; // Offset: 0x240 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x298 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x2a8 // Size: 0x10
	char pad_0x2B8[0x38]; // Offset: 0x2b8 // Size: 0x38

	// Functions

	// Object Name: Function PandoraComponent.LuaUserWidget.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FLuaBPVar>& Args); // Offset: 0x10206a0b0 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraBpFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UPandoraBpFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.Tnm2Test
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Tnm2Test(struct FString errMsg, int32_t iId, int32_t iType, bool bSend); // Offset: 0x10206a6a8 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.SetGameInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetGameInstance(struct UGameInstance* Instance); // Offset: 0x10206b520 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.OnClickOpenPop
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString OnClickOpenPop(); // Offset: 0x10206b628 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.OnClickInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString OnClickInit(); // Offset: 0x10206b6bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.OnClickClose
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString OnClickClose(); // Offset: 0x10206b594 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.LogoutPandora
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LogoutPandora(); // Offset: 0x10206a80c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.InitPandora
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool InitPandora(struct FString InOpenId, struct FString InRoleId, struct FString InAppId, struct FString InPlatId, struct FString InAccType, struct FString InArea, struct FString InPartion, struct FString InCloudTest, struct FString InAccessToken, struct FString InSdkVersion, struct FString InGameVersion, struct FString InServiceType, struct FString InQQInstalled, struct FString InWXInstalled); // Offset: 0x10206a820 // Return & Params: Num(15) Size(0xe1)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.GetHappyMessage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetHappyMessage(); // Offset: 0x10206b750 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class PandoraComponent.PandoraSceneComponent
// Size: 0x260 // Inherited bytes: 0x260
struct UPandoraSceneComponent : USceneComponent {
};

