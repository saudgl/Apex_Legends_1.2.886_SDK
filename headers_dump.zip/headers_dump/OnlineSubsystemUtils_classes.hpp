#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class OnlineSubsystemUtils.AchievementBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAchievementBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementProgress
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetCachedAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, float& Progress); // Offset: 0x102491650 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementDescription
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetCachedAchievementDescription(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, struct FText& Title, struct FText& LockedDescription, struct FText& UnlockedDescription, bool& bHidden); // Offset: 0x10249129c // Return & Params: Num(8) Size(0x69)
};

// Object Name: Class OnlineSubsystemUtils.AchievementQueryCallbackProxy
// Size: 0x60 // Inherited bytes: 0x28
struct UAchievementQueryCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x18]; // Offset: 0x48 // Size: 0x18

	// Functions

	// Object Name: Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievements
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAchievementQueryCallbackProxy* CacheAchievements(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x102491b8c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievementDescriptions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAchievementQueryCallbackProxy* CacheAchievementDescriptions(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x102491ad0 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.AchievementWriteCallbackProxy
// Size: 0x78 // Inherited bytes: 0x28
struct UAchievementWriteCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x30]; // Offset: 0x48 // Size: 0x30

	// Functions

	// Object Name: Function OnlineSubsystemUtils.AchievementWriteCallbackProxy.WriteAchievementProgress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAchievementWriteCallbackProxy* WriteAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementName, float Progress, int32_t UserTag); // Offset: 0x10249206c // Return & Params: Num(6) Size(0x28)
};

// Object Name: Class OnlineSubsystemUtils.ConnectionCallbackProxy
// Size: 0x70 // Inherited bytes: 0x28
struct UConnectionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x28]; // Offset: 0x48 // Size: 0x28

	// Functions

	// Object Name: Function OnlineSubsystemUtils.ConnectionCallbackProxy.ConnectToService
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UConnectionCallbackProxy* ConnectToService(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x1024925c8 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.CreateSessionCallbackProxy
// Size: 0x90 // Inherited bytes: 0x28
struct UCreateSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x48]; // Offset: 0x48 // Size: 0x48

	// Functions

	// Object Name: Function OnlineSubsystemUtils.CreateSessionCallbackProxy.CreateSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UCreateSessionCallbackProxy* CreateSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32_t PublicConnections, bool bUseLAN); // Offset: 0x102492a0c // Return & Params: Num(5) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.DestroySessionCallbackProxy
// Size: 0x70 // Inherited bytes: 0x28
struct UDestroySessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x28]; // Offset: 0x48 // Size: 0x28

	// Functions

	// Object Name: Function OnlineSubsystemUtils.DestroySessionCallbackProxy.DestroySession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UDestroySessionCallbackProxy* DestroySession(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x102492ee8 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.EndMatchCallbackProxy
// Size: 0x78 // Inherited bytes: 0x28
struct UEndMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x30]; // Offset: 0x48 // Size: 0x30

	// Functions

	// Object Name: Function OnlineSubsystemUtils.EndMatchCallbackProxy.EndMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UEndMatchCallbackProxy* EndMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<ITurnBasedMatchInterface> MatchActor, struct FString MatchID, enum class EMPMatchOutcome LocalPlayerOutcome, enum class EMPMatchOutcome OtherPlayersOutcome); // Offset: 0x10249332c // Return & Params: Num(7) Size(0x40)
};

// Object Name: Class OnlineSubsystemUtils.EndTurnCallbackProxy
// Size: 0x70 // Inherited bytes: 0x28
struct UEndTurnCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x28]; // Offset: 0x48 // Size: 0x28

	// Functions

	// Object Name: Function OnlineSubsystemUtils.EndTurnCallbackProxy.EndTurn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UEndTurnCallbackProxy* EndTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, struct TScriptInterface<ITurnBasedMatchInterface> TurnBasedMatchInterface); // Offset: 0x1024938fc // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class OnlineSubsystemUtils.FindSessionsCallbackProxy
// Size: 0x88 // Inherited bytes: 0x28
struct UFindSessionsCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x40]; // Offset: 0x48 // Size: 0x40

	// Functions

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetServerName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString GetServerName(struct FBlueprintSessionResult& Result); // Offset: 0x10249415c // Return & Params: Num(2) Size(0xc8)

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetPingInMs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t GetPingInMs(struct FBlueprintSessionResult& Result); // Offset: 0x102494290 // Return & Params: Num(2) Size(0xbc)

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetMaxPlayers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t GetMaxPlayers(struct FBlueprintSessionResult& Result); // Offset: 0x102493f8c // Return & Params: Num(2) Size(0xbc)

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetCurrentPlayers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t GetCurrentPlayers(struct FBlueprintSessionResult& Result); // Offset: 0x102494074 // Return & Params: Num(2) Size(0xbc)

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.FindSessions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UFindSessionsCallbackProxy* FindSessions(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32_t MaxResults, bool bUseLAN); // Offset: 0x102494378 // Return & Params: Num(5) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy
// Size: 0x80 // Inherited bytes: 0x28
struct UFindTurnBasedMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x38]; // Offset: 0x48 // Size: 0x38

	// Functions

	// Object Name: Function OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy.FindTurnBasedMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UFindTurnBasedMatchCallbackProxy* FindTurnBasedMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<ITurnBasedMatchInterface> MatchActor, int32_t MinPlayers, int32_t MaxPlayers, int32_t PlayerGroup, bool ShowExistingMatches); // Offset: 0x1024949d0 // Return & Params: Num(8) Size(0x38)
};

// Object Name: Class OnlineSubsystemUtils.InAppPurchaseCallbackProxy
// Size: 0x80 // Inherited bytes: 0x28
struct UInAppPurchaseCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x38]; // Offset: 0x48 // Size: 0x38

	// Functions

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy.CreateProxyObjectForInAppPurchase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UInAppPurchaseCallbackProxy* CreateProxyObjectForInAppPurchase(struct APlayerController* PlayerController, struct FInAppPurchaseProductRequest& ProductRequest); // Offset: 0x102494fd0 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy
// Size: 0x90 // Inherited bytes: 0x28
struct UInAppPurchaseQueryCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x48]; // Offset: 0x48 // Size: 0x48

	// Functions

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy.CreateProxyObjectForInAppPurchaseQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UInAppPurchaseQueryCallbackProxy* CreateProxyObjectForInAppPurchaseQuery(struct APlayerController* PlayerController, struct TArray<struct FString>& ProductIdentifiers); // Offset: 0x102495464 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy
// Size: 0x90 // Inherited bytes: 0x28
struct UInAppPurchaseRestoreCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x48]; // Offset: 0x48 // Size: 0x48

	// Functions

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy.CreateProxyObjectForInAppPurchaseRestore
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UInAppPurchaseRestoreCallbackProxy* CreateProxyObjectForInAppPurchaseRestore(struct TArray<struct FInAppPurchaseProductRequest>& ConsumableProductFlags, struct APlayerController* PlayerController); // Offset: 0x10249592c // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.IpConnection
// Size: 0x1a48 // Inherited bytes: 0x19a8
struct UIpConnection : UNetConnection {
	// Fields
	char pad_0x19A8[0x90]; // Offset: 0x19a8 // Size: 0x90
	float SocketErrorDisconnectDelay; // Offset: 0x1a38 // Size: 0x04
	char pad_0x1A3C[0xc]; // Offset: 0x1a3c // Size: 0x0c
};

// Object Name: Class OnlineSubsystemUtils.IpNetDriver
// Size: 0x830 // Inherited bytes: 0x7e0
struct UIpNetDriver : UNetDriver {
	// Fields
	char NetEncryptionType; // Offset: 0x7dd // Size: 0x01
	char LogPortUnreach : 1; // Offset: 0x7de // Size: 0x01
	char AllowPlayerPortUnreach : 1; // Offset: 0x7de // Size: 0x01
	uint32_t MaxPortCountToTry; // Offset: 0x7e0 // Size: 0x04
	char pad_0x7E5_2 : 6; // Offset: 0x7e5 // Size: 0x01
	char pad_0x7E6[0xe]; // Offset: 0x7e6 // Size: 0x0e
	uint32_t ServerDesiredSocketReceiveBufferBytes; // Offset: 0x7f4 // Size: 0x04
	uint32_t ServerDesiredSocketSendBufferBytes; // Offset: 0x7f8 // Size: 0x04
	uint32_t ClientDesiredSocketReceiveBufferBytes; // Offset: 0x7fc // Size: 0x04
	uint32_t ClientDesiredSocketSendBufferBytes; // Offset: 0x800 // Size: 0x04
	char pad_0x804[0x4]; // Offset: 0x804 // Size: 0x04
	double MaxSecondsInReceive; // Offset: 0x808 // Size: 0x08
	int32_t NbPacketsBetweenReceiveTimeTest; // Offset: 0x810 // Size: 0x04
	char pad_0x814[0x14]; // Offset: 0x814 // Size: 0x14
	bool bResolveRemoteHostOnRecreateSocket; // Offset: 0x828 // Size: 0x01
	char pad_0x829[0x7]; // Offset: 0x829 // Size: 0x07
};

// Object Name: Class OnlineSubsystemUtils.JoinSessionCallbackProxy
// Size: 0x128 // Inherited bytes: 0x28
struct UJoinSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0xe0]; // Offset: 0x48 // Size: 0xe0

	// Functions

	// Object Name: Function OnlineSubsystemUtils.JoinSessionCallbackProxy.JoinSession
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UJoinSessionCallbackProxy* JoinSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FBlueprintSessionResult& SearchResult); // Offset: 0x102496194 // Return & Params: Num(4) Size(0xd0)
};

// Object Name: Class OnlineSubsystemUtils.LeaderboardBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct ULeaderboardBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function OnlineSubsystemUtils.LeaderboardBlueprintLibrary.WriteLeaderboardInteger
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool WriteLeaderboardInteger(struct APlayerController* PlayerController, struct FName StatName, int32_t StatValue); // Offset: 0x102496680 // Return & Params: Num(4) Size(0x15)
};

// Object Name: Class OnlineSubsystemUtils.LeaderboardFlushCallbackProxy
// Size: 0x68 // Inherited bytes: 0x28
struct ULeaderboardFlushCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x20]; // Offset: 0x48 // Size: 0x20

	// Functions

	// Object Name: Function OnlineSubsystemUtils.LeaderboardFlushCallbackProxy.CreateProxyObjectForFlush
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULeaderboardFlushCallbackProxy* CreateProxyObjectForFlush(struct APlayerController* PlayerController, struct FName SessionName); // Offset: 0x1024969f0 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.LeaderboardQueryCallbackProxy
// Size: 0x98 // Inherited bytes: 0x28
struct ULeaderboardQueryCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x50]; // Offset: 0x48 // Size: 0x50

	// Functions

	// Object Name: Function OnlineSubsystemUtils.LeaderboardQueryCallbackProxy.CreateProxyObjectForIntQuery
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULeaderboardQueryCallbackProxy* CreateProxyObjectForIntQuery(struct APlayerController* PlayerController, struct FName StatName); // Offset: 0x102496e60 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.LogoutCallbackProxy
// Size: 0x68 // Inherited bytes: 0x30
struct ULogoutCallbackProxy : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 // Size: 0x18

	// Functions

	// Object Name: Function OnlineSubsystemUtils.LogoutCallbackProxy.Logout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULogoutCallbackProxy* Logout(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x1024972d0 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.OnlineBeacon
// Size: 0x298 // Inherited bytes: 0x268
struct AOnlineBeacon : AActor {
	// Fields
	char pad_0x268[0x8]; // Offset: 0x268 // Size: 0x08
	float BeaconConnectionInitialTimeout; // Offset: 0x270 // Size: 0x04
	float BeaconConnectionTimeout; // Offset: 0x274 // Size: 0x04
	struct UNetDriver* NetDriver; // Offset: 0x278 // Size: 0x08
	char pad_0x280[0x18]; // Offset: 0x280 // Size: 0x18
};

// Object Name: Class OnlineSubsystemUtils.OnlineBeaconClient
// Size: 0x2e8 // Inherited bytes: 0x298
struct AOnlineBeaconClient : AOnlineBeacon {
	// Fields
	struct AOnlineBeaconHostObject* BeaconOwner; // Offset: 0x298 // Size: 0x08
	struct UNetConnection* BeaconConnection; // Offset: 0x2a0 // Size: 0x08
	enum class EBeaconConnectionState ConnectionState; // Offset: 0x2a8 // Size: 0x01
	char pad_0x2A9[0x3f]; // Offset: 0x2a9 // Size: 0x3f

	// Functions

	// Object Name: Function OnlineSubsystemUtils.OnlineBeaconClient.ClientOnConnected
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetClient]
	void ClientOnConnected(); // Offset: 0x1024978f4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class OnlineSubsystemUtils.OnlineBeaconHost
// Size: 0x350 // Inherited bytes: 0x298
struct AOnlineBeaconHost : AOnlineBeacon {
	// Fields
	int32_t ListenPort; // Offset: 0x298 // Size: 0x04
	char pad_0x29C[0x4]; // Offset: 0x29c // Size: 0x04
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // Offset: 0x2a0 // Size: 0x10
	char pad_0x2B0[0xa0]; // Offset: 0x2b0 // Size: 0xa0
};

// Object Name: Class OnlineSubsystemUtils.OnlineBeaconHostObject
// Size: 0x290 // Inherited bytes: 0x268
struct AOnlineBeaconHostObject : AActor {
	// Fields
	struct FString BeaconTypeName; // Offset: 0x268 // Size: 0x10
	struct AOnlineBeaconClient* ClientBeaconActorClass; // Offset: 0x278 // Size: 0x08
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // Offset: 0x280 // Size: 0x10
};

// Object Name: Class OnlineSubsystemUtils.OnlineEngineInterfaceImpl
// Size: 0x128 // Inherited bytes: 0x28
struct UOnlineEngineInterfaceImpl : UOnlineEngineInterface {
	// Fields
	struct FName VoiceSubsystemNameOverride; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0xf8]; // Offset: 0x30 // Size: 0xf8
};

// Object Name: Class OnlineSubsystemUtils.OnlinePIESettings
// Size: 0x50 // Inherited bytes: 0x38
struct UOnlinePIESettings : UDeveloperSettings {
	// Fields
	bool bOnlinePIEEnabled; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct TArray<struct FPIELoginSettingsInternal> Logins; // Offset: 0x40 // Size: 0x10
};

// Object Name: Class OnlineSubsystemUtils.OnlineSessionClient
// Size: 0x190 // Inherited bytes: 0x28
struct UOnlineSessionClient : UOnlineSession {
	// Fields
	char pad_0x28[0x160]; // Offset: 0x28 // Size: 0x160
	bool bIsFromInvite; // Offset: 0x188 // Size: 0x01
	bool bHandlingDisconnect; // Offset: 0x189 // Size: 0x01
	char pad_0x18A[0x6]; // Offset: 0x18a // Size: 0x06
};

// Object Name: Class OnlineSubsystemUtils.PartyBeaconClient
// Size: 0x3a8 // Inherited bytes: 0x2e8
struct APartyBeaconClient : AOnlineBeaconClient {
	// Fields
	char pad_0x2E8[0x30]; // Offset: 0x2e8 // Size: 0x30
	struct FString DestSessionId; // Offset: 0x318 // Size: 0x10
	struct FPartyReservation PendingReservation; // Offset: 0x328 // Size: 0x50
	enum class EClientRequestType RequestType; // Offset: 0x378 // Size: 0x01
	bool bPendingReservationSent; // Offset: 0x379 // Size: 0x01
	bool bCancelReservation; // Offset: 0x37a // Size: 0x01
	char pad_0x37B[0x2d]; // Offset: 0x37b // Size: 0x2d

	// Functions

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ServerUpdateReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerUpdateReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate); // Offset: 0x102498928 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ServerReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerReservationRequest(struct FString SessionId, struct FPartyReservation Reservation); // Offset: 0x102498ad0 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ServerCancelReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl PartyLeader); // Offset: 0x1024987e4 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationUpdates
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSendReservationUpdates(int32_t NumRemainingReservations); // Offset: 0x102498c94 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationFull
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSendReservationFull(); // Offset: 0x102498c78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ClientReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientReservationResponse(enum class EPartyReservationResult ReservationResponse); // Offset: 0x102498d9c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ClientCancelReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientCancelReservationResponse(enum class EPartyReservationResult ReservationResponse); // Offset: 0x102498d18 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class OnlineSubsystemUtils.PartyBeaconHost
// Size: 0x308 // Inherited bytes: 0x290
struct APartyBeaconHost : AOnlineBeaconHostObject {
	// Fields
	struct UPartyBeaconState* State; // Offset: 0x290 // Size: 0x08
	char pad_0x298[0x60]; // Offset: 0x298 // Size: 0x60
	bool bLogoutOnSessionTimeout; // Offset: 0x2f8 // Size: 0x01
	char pad_0x2F9[0x3]; // Offset: 0x2f9 // Size: 0x03
	float SessionTimeoutSecs; // Offset: 0x2fc // Size: 0x04
	float TravelSessionTimeoutSecs; // Offset: 0x300 // Size: 0x04
	char pad_0x304[0x4]; // Offset: 0x304 // Size: 0x04
};

// Object Name: Class OnlineSubsystemUtils.PartyBeaconState
// Size: 0x78 // Inherited bytes: 0x28
struct UPartyBeaconState : UObject {
	// Fields
	struct FName SessionName; // Offset: 0x28 // Size: 0x08
	int32_t NumConsumedReservations; // Offset: 0x30 // Size: 0x04
	int32_t MaxReservations; // Offset: 0x34 // Size: 0x04
	int32_t NumTeams; // Offset: 0x38 // Size: 0x04
	int32_t NumPlayersPerTeam; // Offset: 0x3c // Size: 0x04
	struct FName TeamAssignmentMethod; // Offset: 0x40 // Size: 0x08
	int32_t ReservedHostTeamNum; // Offset: 0x48 // Size: 0x04
	int32_t ForceTeamNum; // Offset: 0x4c // Size: 0x04
	bool bRestrictCrossConsole; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
	struct TArray<struct FPartyReservation> Reservations; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x10]; // Offset: 0x68 // Size: 0x10
};

// Object Name: Class OnlineSubsystemUtils.QuitMatchCallbackProxy
// Size: 0x70 // Inherited bytes: 0x28
struct UQuitMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x28]; // Offset: 0x48 // Size: 0x28

	// Functions

	// Object Name: Function OnlineSubsystemUtils.QuitMatchCallbackProxy.QuitMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UQuitMatchCallbackProxy* QuitMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, enum class EMPMatchOutcome Outcome, int32_t TurnTimeoutInSeconds); // Offset: 0x10249a068 // Return & Params: Num(6) Size(0x30)
};

// Object Name: Class OnlineSubsystemUtils.ShowLoginUICallbackProxy
// Size: 0x60 // Inherited bytes: 0x30
struct UShowLoginUICallbackProxy : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10

	// Functions

	// Object Name: Function OnlineSubsystemUtils.ShowLoginUICallbackProxy.ShowExternalLoginUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UShowLoginUICallbackProxy* ShowExternalLoginUI(struct UObject* WorldContextObject, struct APlayerController* InPlayerController); // Offset: 0x10249a5e4 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.SpectatorBeaconClient
// Size: 0x3d0 // Inherited bytes: 0x2e8
struct ASpectatorBeaconClient : AOnlineBeaconClient {
	// Fields
	char pad_0x2E8[0x30]; // Offset: 0x2e8 // Size: 0x30
	struct FString DestSessionId; // Offset: 0x318 // Size: 0x10
	struct FSpectatorReservation PendingReservation; // Offset: 0x328 // Size: 0x78
	enum class ESpectatorClientRequestType RequestType; // Offset: 0x3a0 // Size: 0x01
	bool bPendingReservationSent; // Offset: 0x3a1 // Size: 0x01
	bool bCancelReservation; // Offset: 0x3a2 // Size: 0x01
	char pad_0x3A3[0x2d]; // Offset: 0x3a3 // Size: 0x2d

	// Functions

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ServerReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerReservationRequest(struct FString SessionId, struct FSpectatorReservation Reservation); // Offset: 0x10249ac28 // Return & Params: Num(2) Size(0x88)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ServerCancelReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl Spectator); // Offset: 0x10249aae4 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientSendReservationUpdates
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSendReservationUpdates(int32_t NumRemainingReservations); // Offset: 0x10249ae70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientSendReservationFull
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSendReservationFull(); // Offset: 0x10249ae54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientReservationResponse(enum class ESpectatorReservationResult ReservationResponse); // Offset: 0x10249af78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientCancelReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientCancelReservationResponse(enum class ESpectatorReservationResult ReservationResponse); // Offset: 0x10249aef4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class OnlineSubsystemUtils.SpectatorBeaconHost
// Size: 0x308 // Inherited bytes: 0x290
struct ASpectatorBeaconHost : AOnlineBeaconHostObject {
	// Fields
	struct USpectatorBeaconState* State; // Offset: 0x290 // Size: 0x08
	char pad_0x298[0x60]; // Offset: 0x298 // Size: 0x60
	bool bLogoutOnSessionTimeout; // Offset: 0x2f8 // Size: 0x01
	char pad_0x2F9[0x3]; // Offset: 0x2f9 // Size: 0x03
	float SessionTimeoutSecs; // Offset: 0x2fc // Size: 0x04
	float TravelSessionTimeoutSecs; // Offset: 0x300 // Size: 0x04
	char pad_0x304[0x4]; // Offset: 0x304 // Size: 0x04
};

// Object Name: Class OnlineSubsystemUtils.SpectatorBeaconState
// Size: 0x60 // Inherited bytes: 0x28
struct USpectatorBeaconState : UObject {
	// Fields
	struct FName SessionName; // Offset: 0x28 // Size: 0x08
	int32_t NumConsumedReservations; // Offset: 0x30 // Size: 0x04
	int32_t MaxReservations; // Offset: 0x34 // Size: 0x04
	bool bRestrictCrossConsole; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct TArray<struct FSpectatorReservation> Reservations; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10
};

// Object Name: Class OnlineSubsystemUtils.TestBeaconClient
// Size: 0x2e8 // Inherited bytes: 0x2e8
struct ATestBeaconClient : AOnlineBeaconClient {
	// Functions

	// Object Name: Function OnlineSubsystemUtils.TestBeaconClient.ServerPong
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerPong(); // Offset: 0x10249c01c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function OnlineSubsystemUtils.TestBeaconClient.ClientPing
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientPing(); // Offset: 0x10249c078 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class OnlineSubsystemUtils.TestBeaconHost
// Size: 0x290 // Inherited bytes: 0x290
struct ATestBeaconHost : AOnlineBeaconHostObject {
};

// Object Name: Class OnlineSubsystemUtils.TurnBasedBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UTurnBasedBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.RegisterTurnBasedMatchInterfaceObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RegisterTurnBasedMatchInterfaceObject(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct UObject* Object); // Offset: 0x10249c768 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetPlayerDisplayName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetPlayerDisplayName(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, int32_t PlayerIndex, struct FString& PlayerDisplayName); // Offset: 0x10249c554 // Return & Params: Num(5) Size(0x38)

	// Object Name: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetMyPlayerIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMyPlayerIndex(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, int32_t& PlayerIndex); // Offset: 0x10249c860 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetIsMyTurn
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetIsMyTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, bool& bIsMyTurn); // Offset: 0x10249ca20 // Return & Params: Num(4) Size(0x21)
};

// Object Name: Class OnlineSubsystemUtils.VoipListenerSynthComponent
// Size: 0x690 // Inherited bytes: 0x680
struct UVoipListenerSynthComponent : USynthComponent {
	// Fields
	char pad_0x680[0x10]; // Offset: 0x680 // Size: 0x10

	// Functions

	// Object Name: Function OnlineSubsystemUtils.VoipListenerSynthComponent.IsIdling
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsIdling(); // Offset: 0x10249cee8 // Return & Params: Num(1) Size(0x1)
};

