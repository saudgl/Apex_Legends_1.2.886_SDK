#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct UnrealArchExt.AETableDerivedRowDataQueryBP
// Size: 0xb0 // Inherited bytes: 0x00
struct FAETableDerivedRowDataQueryBP {
	// Fields
	char pad_0x0[0xb0]; // Offset: 0x00 // Size: 0xb0
};

// Object Name: ScriptStruct UnrealArchExt.AETableRowDataQueryBP
// Size: 0x10 // Inherited bytes: 0x00
struct FAETableRowDataQueryBP {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct UnrealArchExt.UserWidgetState
// Size: 0x28 // Inherited bytes: 0x00
struct FUserWidgetState {
	// Fields
	struct FString WidgetName; // Offset: 0x00 // Size: 0x10
	struct FName ContainerName; // Offset: 0x10 // Size: 0x08
	int32_t ZOrder; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct UUAEUserWidget* Widget; // Offset: 0x20 // Size: 0x08
};

