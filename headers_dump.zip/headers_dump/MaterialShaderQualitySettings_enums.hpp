#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum MaterialShaderQualitySettings.EMobileFogQuality
enum class EMobileFogQuality : uint8 {
	High = 0,
	Normal = 1,
	Low = 2,
	EMobileFogQuality_MAX = 3
};

// Object Name: Enum MaterialShaderQualitySettings.EMobileCSMQuality
enum class EMobileCSMQuality : uint8 {
	NoFiltering = 0,
	PCF_1x1 = 1,
	PCF_2x2 = 2,
	PCF_2x2_spot = 3,
	EMobileCSMQuality_MAX = 4
};

