#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass WaitingUI.WaitingUI_C
// Size: 0x3e8 // Inherited bytes: 0x3b0
struct UWaitingUI_C : UGameUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_loop; // Offset: 0x3b0 // Size: 0x08
	struct UWidgetAnimation* Anim_Waiting_Out; // Offset: 0x3b8 // Size: 0x08
	struct UWidgetAnimation* Anim_Waiting_In_Loop; // Offset: 0x3c0 // Size: 0x08
	struct UButton* Button_Mask; // Offset: 0x3c8 // Size: 0x08
	struct UImage* Image_bg_big; // Offset: 0x3d0 // Size: 0x08
	struct UImage* Img_OutCir_2; // Offset: 0x3d8 // Size: 0x08
	struct UCanvasPanel* RankCirPanel; // Offset: 0x3e0 // Size: 0x08

	// Functions

	// Object Name: Function WaitingUI.WaitingUI_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x10)
};

