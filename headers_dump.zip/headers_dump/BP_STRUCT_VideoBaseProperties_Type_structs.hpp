#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VideoBaseProperties_Type.BP_STRUCT_VideoBaseProperties_Type
// Size: 0xa4 // Inherited bytes: 0x00
struct FBP_STRUCT_VideoBaseProperties_Type {
	// Fields
	int32_t Id_114_31B9FF804B8B875E3B3D1A4E0374EBF2; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int32_t> SubtitleStartAndEndIds_115_75A2CE402863B6491E14706604515373; // Offset: 0x08 // Size: 0x10
	struct FString VideoSourcePath_116_6CE3C28029FE6DA8036A0ED809C9FF48; // Offset: 0x18 // Size: 0x10
	struct FString MediaPlayerPath_117_7E71DBC06E8E3DB717C44B550EC6E448; // Offset: 0x28 // Size: 0x10
	struct FString MediaTexturePath_118_5E6B7CC0163F76FD6F19987B0C914108; // Offset: 0x38 // Size: 0x10
	struct FString BgTexturePath_119_3199EF0012E76A3404B937DF099B5018; // Offset: 0x48 // Size: 0x10
	struct FString SoundBankArrStr_120_522B1E0021D70F3E2C8C8D6B0E36E942; // Offset: 0x58 // Size: 0x10
	struct FString SoundEventArrStr_121_31B9FF804B8B875E3B3D1A4E0374EBF2; // Offset: 0x68 // Size: 0x10
	bool IsShowFirstBg_122_4EB0E8C00F54875D0726F0B5025B8927; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x7]; // Offset: 0x79 // Size: 0x07
	struct FString ResumeAudioEventStr_123_3D4B2CC0372811CF589EF0B1012E2DF2; // Offset: 0x80 // Size: 0x10
	struct FString PauseAudioEventStr_125_51715000211ACE944183EB2105CA0F92; // Offset: 0x90 // Size: 0x10
	int32_t DyDownloadId_126_50620DC0193CC6E527CF83DE05555144; // Offset: 0xa0 // Size: 0x04
};

