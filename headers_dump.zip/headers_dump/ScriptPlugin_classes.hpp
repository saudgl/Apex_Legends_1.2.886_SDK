#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ScriptPlugin.ScriptBlueprint
// Size: 0xf0 // Inherited bytes: 0xd0
struct UScriptBlueprint : UBlueprint {
	// Fields
	struct TArray<char> ByteCode; // Offset: 0xd0 // Size: 0x10
	struct FString SourceCode; // Offset: 0xe0 // Size: 0x10
};

// Object Name: Class ScriptPlugin.ScriptBlueprintGeneratedClass
// Size: 0x440 // Inherited bytes: 0x400
struct UScriptBlueprintGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	struct TArray<char> ByteCode; // Offset: 0x400 // Size: 0x10
	struct FString SourceCode; // Offset: 0x410 // Size: 0x10
	struct TArray<struct UProperty*> ScriptProperties; // Offset: 0x420 // Size: 0x10
	char pad_0x430[0x10]; // Offset: 0x430 // Size: 0x10
};

// Object Name: Class ScriptPlugin.ScriptContext
// Size: 0x30 // Inherited bytes: 0x28
struct UScriptContext : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function ScriptPlugin.ScriptContext.CallScriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CallScriptFunction(struct FString FunctionName); // Offset: 0x1060f8640 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class ScriptPlugin.ScriptContextComponent
// Size: 0xf8 // Inherited bytes: 0xf0
struct UScriptContextComponent : UActorComponent {
	// Fields
	char pad_0xF0[0x8]; // Offset: 0xf0 // Size: 0x08

	// Functions

	// Object Name: Function ScriptPlugin.ScriptContextComponent.CallScriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CallScriptFunction(struct FString FunctionName); // Offset: 0x1060f8934 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class ScriptPlugin.ScriptPluginComponent
// Size: 0xf8 // Inherited bytes: 0xf0
struct UScriptPluginComponent : UActorComponent {
	// Fields
	char pad_0xF0[0x8]; // Offset: 0xf0 // Size: 0x08

	// Functions

	// Object Name: Function ScriptPlugin.ScriptPluginComponent.CallScriptFunction
	// Flags: [Native|Public|BlueprintCallable]
	bool CallScriptFunction(struct FString FunctionName); // Offset: 0x1060f8c40 // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class ScriptPlugin.ScriptTestActor
// Size: 0x280 // Inherited bytes: 0x268
struct AScriptTestActor : AActor {
	// Fields
	struct FString TestString; // Offset: 0x268 // Size: 0x10
	float TestValue; // Offset: 0x278 // Size: 0x04
	bool TestBool; // Offset: 0x27c // Size: 0x01
	char pad_0x27D[0x3]; // Offset: 0x27d // Size: 0x03

	// Functions

	// Object Name: Function ScriptPlugin.ScriptTestActor.TestFunction
	// Flags: [Final|Native|Public]
	float TestFunction(float InValue, float InFactor, bool bMultiply); // Offset: 0x1060f8f54 // Return & Params: Num(4) Size(0x10)
};

