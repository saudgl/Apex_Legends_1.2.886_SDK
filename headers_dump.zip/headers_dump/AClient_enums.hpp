#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum AClient.EPlayerBattleBehState
enum class EPlayerBattleBehState : uint8 {
	Normal = 0,
	Dying = 1,
	Rescuing = 2,
	RescuingSelf = 3,
	RescuingOther = 4,
	DoFinisher = 5,
	BeFinisher = 6,
	Respawning = 7,
	RespawnTimeout = 8,
	RespawnTeammate = 9,
	Dead = 10,
	EPlayerBattleBehState_MAX = 11
};

// Object Name: Enum AClient.EApexSkillEvent
enum class EApexSkillEvent : uint8 {
	ApexSkillEvent_None = 0,
	Caustic_Dirty_Bomb_Weapon_Spawn = 1,
	Caustic_Dirty_Bomb_Weapon_Aiming = 2,
	Caustic_Dirty_Bomb_Weapon_Throw = 3,
	Caustic_Dirty_Bomb_Weapon_Interupted = 4,
	Caustic_Dirty_Bomb_Weapon_StartFly = 5,
	Caustic_Dirty_Bomb_Weapon_Sync_Location_Complete = 6,
	Caustic_Dirty_Bomb_Weapon_Bounce = 7,
	Caustic_Dirty_Bomb_Weapon_Land = 8,
	Caustic_Dirty_Bomb_Weapon_Deploy = 9,
	Caustic_Dirty_Bomb_Weapon_Deploy_Failed = 10,
	Caustic_Dirty_Bomb_Weapon_Ready = 11,
	Caustic_Dirty_Bomb_Weapon_PickeUp = 12,
	Caustic_Dirty_Bomb_Weapon_PickeUp_UI_Show = 13,
	Caustic_Dirty_Bomb_Weapon_PickeUp_UI_Hide = 14,
	Caustic_Dirty_Bomb_Weapon_Activate = 15,
	Caustic_Dirty_Bomb_Weapon_Has_Target = 16,
	Caustic_Dirty_Bomb_Weapon_Posion_Target = 17,
	Caustic_Dirty_Bomb_Weapon_Target_Enter_Gas = 18,
	Caustic_Dirty_Bomb_Weapon_Target_Leave_Gas = 19,
	Caustic_Dirty_Bomb_Weapon_Destroy_From_Deploy = 20,
	Caustic_Dirty_Bomb_Weapon_Destroy = 21,
	Caustic_Dirty_Bomb_Weapon_TakeDamage = 22,
	Caustic_Gas_Grenade_Weapon_Spawn = 23,
	Caustic_Gas_Grenade_Weapon_Aiming = 24,
	Caustic_Gas_Grenade_Weapon_Throw = 25,
	Caustic_Gas_Grenade_Weapon_StartFly = 26,
	Caustic_Gas_Grenade_Weapon_Bounce = 27,
	Caustic_Gas_Grenade_Weapon_Land = 28,
	Caustic_Gas_Grenade_Weapon_Activate = 29,
	Caustic_Gas_Grenade_Weapon_Target_Leave_Gas = 30,
	Caustic_Gas_Grenade_Weapon_Target_Enter_Gas = 31,
	Caustic_Gas_Grenade_Weapon_Interupted = 32,
	Caustic_Gas_Grenade_Weapon_Destroy = 33,
	Caustic_Gas_Grenade_Weapon_Activate_Complete = 34,
	Bangalore_Smoke_Bomb_Weapon_Spawn = 35,
	Bangalore_Smoke_Bomb_Weapon_Throw = 36,
	Bangalore_Smoke_Bomb_Weapon_Land = 37,
	Bangalore_Smoke_Bomb_Weapon_Deploy = 38,
	Bangalore_Smoke_Bomb_Weapon_Ready = 39,
	Bangalore_Smoke_Bomb_Weapon_Activate = 40,
	Bangalore_Smoke_Bomb_Weapon_Destroy = 41,
	Bangalore_Smoke_Bomb_Weapon_TakeDamage = 42,
	Mirage_Decoy_MoveToScreenCenter = 43,
	Mirage_Decoy_MoveAhead = 44,
	Mirage_Decoy_MoveToScreenCenterWithCtl = 45,
	Mirage_Decoy_FallingHighToGround = 46,
	Mirage_Decoy_FallingLowToGround = 47,
	Mirage_PassiveSkill_Bleedingout = 48,
	Mirage_PassiveSkill_Rescue = 49,
	Mirage_PassiveSkill_RecoverFromInvisible = 50,
	Mirage_PassiveSkill_BeaconRespawn = 51,
	Mirage_PassiveSkill = 52,
	Mirage_Ultimate_Invisible_Enter = 53,
	Mirage_Ultimate_Invisible_Leave = 54,
	Mirage_Decoy_SwitchPlayerControlEnable = 55,
	Mirage_Decoy_SwitchPlayerControlDisable = 56,
	Mirage_Decoy_MoveStopped = 57,
	Mirage_Decoy_RequestPlayerControlState = 58,
	Mirage_Tactical_SpawnTeam = 59,
	Mirage_CustomEvent = 60,
	Mirage_Invisible_Perk = 61,
	Mirage_PassiveSkill_Rescue_Perk = 62,
	Mirage_PassiveSkill_Rescue_Invisible = 63,
	Mirage_PassiveSkill_BeRescue_Invisible = 64,
	Mirage_PassiveSkill_BeaconRespawn_Invisible = 65,
	Wraith_Stop_Tactical_Skill = 66,
	Wraith_Start_Transfer = 67,
	BloodHound_Stop_Tactical_Skill = 68,
	UseSurveyBeaconSetPosFinish = 69,
	UseSurveyBeaconSuccess = 70,
	PhantomSelfCancelBraid = 71,
	Loba_BurglarsBestFriend_TeleportSucced = 72,
	Loba_BurglarsBestFriend_TeleportFailed = 73,
	Loba_BurglarsBestFriend_GoDownEvent = 74,
	Loba_BurglarsBestFriend_Bracelet_Spawn = 75,
	Loba_Ultimate_BlackMarket_Spawn = 76,
	Loba_BlackMarket_StealfromTreasureDoor = 77,
	Hero09_Stim_Active_Complete = 78,
	Octane_Stim_Active_Begin = 79,
	Octane_Stim_Active_Pause = 80,
	Octane_Stim_Active_Resume = 81,
	Ash_DataKnife_Begin = 82,
	Ash_DataKnife_Active = 83,
	Ash_PhaseBreach_Active = 84,
	Ash_PhaseBreach_PreSpawn_VoidDoor = 85,
	Ash_PhaseBreach_Spawn_VoidDoor = 86,
	Ash_PhaseBreach_Pre_Transfer = 87,
	Ash_PhaseBreach_Begin_Transfer = 88,
	Ash_PhaseBreach_Begin_FOVAdjust = 89,
	EApexSkillEvent_MAX = 90
};

// Object Name: Enum AClient.EPickerSignalType
enum class EPickerSignalType : uint8 {
	None = 0,
	PickerFinishWithValidTargets = 1,
	PickerFinishWithoutValidTargets = 2,
	MaxNum = 3,
	EPickerSignalType_MAX = 4
};

// Object Name: Enum AClient.EUAESkillEvent
enum class EUAESkillEvent : uint8 {
	UAESkillEvent_None = 0,
	GrenadeModeChange = 1,
	GrenadePinPull = 2,
	ThrowGrenade = 3,
	GrenadeTimeOut = 4,
	SkillInterrupt = 5,
	SkillPlayerDieInterrupt = 6,
	PickItem = 7,
	MovementActive = 8,
	MovementInactive = 9,
	MovementBounce = 10,
	MovementStop = 11,
	MovementCrouch = 12,
	AutoSPrintStart = 13,
	RemoveArmor = 14,
	SkillPawnStateLeft = 15,
	GrenadeThrowCancel = 16,
	DestroyPredictActor = 17,
	GrenadeHold = 18,
	GrenadeLand = 19,
	GrenadeDeploy = 20,
	GrenadeReady = 21,
	GrenadeActivate = 22,
	GrenadeDestroy = 23,
	PhantomBraidFinish = 24,
	ShowPredictionLine = 25,
	ClearPredictionLine = 26,
	StartAimStatus = 27,
	EndAimStatus = 28,
	EUAESkillEvent_MAX = 29
};

// Object Name: Enum AClient.EApexPostSignificanceType
enum class EApexPostSignificanceType : uint8 {
	None = 0,
	Concurrent = 1,
	Sequential = 2,
	EApexPostSignificanceType_MAX = 3
};

// Object Name: Enum AClient.EApexSignificanceByType
enum class EApexSignificanceByType : uint8 {
	Distance = 0,
	Distance2D = 1,
	ScreenSize = 2,
	Custom = 3,
	EApexSignificanceByType_MAX = 4
};

// Object Name: Enum AClient.EDamageType
enum class EDamageType : int32 {
	InvalidDamageType = 0,
	ShootDamage = 1,
	BombDamage = 2,
	PoisonDamage = 13,
	DrowningDamage = 14,
	FallingDamage = 15,
	MeleeDamage = 16,
	GrenadeRadiusDamage = 17,
	BurningDamage = 18,
	AirAttackDamage = 19,
	VehicleDamage = 20,
	VehicleExplodeRadiusDamage = 21,
	WinnerFakeDeath = 23,
	PoisonWaterDamage = 24,
	ElectricDamage = 25,
	ZombieDamage = 26,
	LowTemperatureDamage = 27,
	TopFiveGaveUpDamage = 28,
	Resurrection = 29,
	TyrantMonsterStonedDamage = 30,
	DronesBombDamage = 31,
	ArcStarPlungeDamage = 32,
	FragGrenadeImpactDamage = 33,
	FlyingSkeletonImpactDamage = 34,
	FragGrenadeBombDamage = 51,
	ThermiteGrenadeBurningDamage = 52,
	ArcStarBombDamage = 53,
	SnowBallGrenadeBombDamage = 54,
	FlyingSkeletonBombDamage = 55,
	LastBreathWithoutRescue = 57,
	FollowTeamDead = 58,
	ExitGameDead = 59,
	BombCoronaDead = 60,
	FinisherDamage = 62,
	MagmaBurningDamage = 63,
	LeviathanTrample = 64,
	MagmaRiseDamage = 65,
	ActorSelfDestructionDamage = 66,
	Buff_BurningDamage = 101,
	Buff_HoverBurningDamage = 102,
	SkillDamageTypeMin = 10011,
	SmokeLauncherDamage = 60021,
	RollingThunderDamage = 60031,
	DefensiveBombDamage = 20031,
	PerimeterSecurityDamage = 100021,
	NoxGasTrapDamage = 70021,
	NoxGasGrenadeDamage = 70031,
	SilenceDamage = 120021,
	SilenceDoorDamage = 120022,
	CryptoDroneEmpDamage = 110039,
	CryptoDroneDyingBombDamage = 110040,
	CryptoDroneRocketBombDamage = 110041,
	PhantomBombDamage = 420031,
	OctaneStimDamage = 90021,
	LobaBlackMarketDamage = 130021,
	AshArcBoltDamage = 190021,
	SkillDamageTypeMax = 1000001,
	EDamageType_MAX = 1000002
};

// Object Name: Enum AClient.EAutoOpenBlockType
enum class EAutoOpenBlockType : uint8 {
	CD = 0,
	Lock = 1,
	EAutoOpenBlockType_MAX = 2
};

// Object Name: Enum AClient.EPawnState
enum class EPawnState : uint8 {
	Move = 0,
	Sprint = 1,
	Sliding = 2,
	Jump = 3,
	ClimbWall = 4,
	Hanging = 5,
	ClimbOver = 6,
	InAir = 7,
	OneKeyClimb = 8,
	Flying = 9,
	Stand = 11,
	Crouch = 12,
	Pick = 13,
	Born = 14,
	Stun = 15,
	Dying = 16,
	Dead = 17,
	Swim = 18,
	InParachute = 19,
	InPlane = 20,
	KnockDownShieldOn = 21,
	Rescue = 23,
	Zipline = 24,
	Finisher = 25,
	OnBeacon = 26,
	Runaway = 27,
	Lock = 29,
	SmallEye = 30,
	GunFire = 31,
	GunReload = 32,
	GunADS = 33,
	HoldingWeapon = 34,
	PutOnWeapon = 35,
	PutOffWeapon = 36,
	RaiseWeapon = 37,
	LowerWeapon = 38,
	EquipAttachment = 39,
	WeaponCharge = 40,
	PickUpList = 41,
	Bolt = 42,
	PlantBomb = 43,
	DefuseBomb = 44,
	BlockWeapon = 45,
	RecoverPropSyringe = 46,
	RecoverPropBattery = 47,
	PickBanner = 48,
	BackpackDropItem = 51,
	OpenTreasureDoor = 52,
	PropsWeaponRight = 53,
	EmojiAnimation = 54,
	UseReplicator = 55,
	InspectWeapon = 56,
	AutonomousSkillSlot1 = 59,
	AutonomousSkillSlot2 = 60,
	SkillSlot1 = 61,
	SkillSlot2 = 62,
	__MAX = 63,
	OnSurveyBeacon = 65,
	MeleeAttack = 71,
	SkillLeftHand = 72,
	SkillRightHand = 73,
	SkillTwoHand = 74,
	SkillVoid = 75,
	SkillTwoHandContinue = 76,
	SkillGrapplingHook = 77,
	SkillZiplineTwoHand = 78,
	SkillStimLeftHand = 79,
	SkillTunnelOpen = 80,
	SkillPreVoid = 81,
	SkillPhaseShift = 82,
	HoldGrenade = 83,
	HoldGrenadeAim = 84,
	UseSyringe = 85,
	UseBattery = 86,
	SkillHoldGastank = 87,
	SkillThrowGastank = 88,
	WattsonSkillReady = 89,
	SkillHoldGasGrenade = 90,
	SkillThrowGasGrenade = 91,
	RevenantDeathTotem = 92,
	CryptoDrone = 93,
	BloodhoundSkill = 94,
	SkillGrapplingHookPulling = 95,
	SkillStimOnZipline = 96,
	BloodhoundUltimate = 98,
	PowerJump = 99,
	ReidelTree = 100,
	PhantomVoid = 102,
	MirageInvisible = 103,
	PhantomVoid_Enemy = 104,
	BangaloreCallSmoke = 105,
	LobaBlackMarket = 106,
	LobaBracelet = 107,
	LobaBraceletWait = 108,
	LobaBlackMarketUse = 109,
	MirageUltimate = 110,
	DJTactical = 111,
	DJUltimate = 112,
	GibraltarDomeShield = 113,
	ValkyrieJetPack = 114,
	AshUseDataKnife = 115,
	AshUsePhaseBreach = 116,
	AshEnterPhaseBreach = 117,
	AshUseArcBolt = 118,
	EPawnState_Max = 119
};

// Object Name: Enum AClient.EDoorDataRepType
enum class EDoorDataRepType : uint8 {
	None = 0,
	SingleDoor = 1,
	DoubleDoor = 2,
	OppositeDoor = 3,
	TreasureDoor = 4,
	MoveDoor = 5,
	EDoorDataRepType_MAX = 6
};

// Object Name: Enum AClient.EDoorType
enum class EDoorType : uint8 {
	None = 0,
	Door = 1,
	Bin = 2,
	TreasureDoor = 3,
	EDoorType_MAX = 4
};

// Object Name: Enum AClient.EMHealthSyncInfo
enum class EMHealthSyncInfo : uint8 {
	None = 0,
	Health = 1,
	Shield = 2,
	HealthHealing = 3,
	ShieldHealing = 4,
	BatState = 5,
	ProtectedByTotem = 6,
	All = 7,
	Max = 8
};

// Object Name: Enum AClient.EMTeamSyncInfo
enum class EMTeamSyncInfo : uint8 {
	Health = 0,
	Shield = 1,
	UpgradeShieldRemain = 2,
	ShieldQuality = 3,
	HelmetQuality = 4,
	UpgradeShieldQuality = 5,
	TeamIdx = 6,
	Commander = 7,
	ProtectedByTotem = 8,
	HealthHealing = 9,
	ShieldHealing = 10,
	IsSingleParachute = 11,
	ChooseLegendId = 12,
	ConfirmLegendId = 13,
	LegendId = 14,
	LegendSkin = 15,
	ValidSkins = 16,
	BackpackLevel = 17,
	KnockDownShieldLevel = 18,
	BatState = 19,
	NetLost = 20,
	BannerState = 21,
	SyncDyingRealTime = 22,
	SyncRespawningRealTime = 23,
	AIHostPlayerKey = 24,
	AIHosting = 25,
	AIHostFunc = 26,
	SecIconChange = 27,
	NextLifeState = 28,
	NextLifeRespawnState = 29,
	All = 30,
	EMTeamSyncInfo_MAX = 31
};

// Object Name: Enum AClient.EKillKingMessageType
enum class EKillKingMessageType : uint8 {
	None = 0,
	KillKingAchieved = 1,
	KillKillKing = 2,
	KillDefenders = 3,
	Max = 4
};

// Object Name: Enum AClient.EPlayerKillMessageType
enum class EPlayerKillMessageType : uint8 {
	None = 0,
	ToDying = 1,
	ToDie = 2,
	Finisher = 3,
	Ace = 4,
	KillKing = 5,
	SecondLife = 6,
	Max = 7
};

// Object Name: Enum AClient.ETurnTableType
enum class ETurnTableType : uint8 {
	None = 0,
	Emoji = 1,
	Projectile = 2,
	Consumables = 3,
	ETurnTableType_MAX = 4
};

// Object Name: Enum AClient.EWeaponAutoAimMode
enum class EWeaponAutoAimMode : uint8 {
	None = 1,
	WaitAimFire = 2,
	ImmediatelyFire = 3,
	Blend = 4,
	EWeaponAutoAimMode_MAX = 5
};

// Object Name: Enum AClient.ESettingConfig
enum class ESettingConfig : uint8 {
	Common_AssistOn = 0,
	Common_AimSingleShoot = 1,
	Common_AimAutoShoot = 2,
	Common_AimPostFire = 3,
	Common_AimCanRotate = 4,
	Common_AutoShooting = 5,
	Common_AutoClamp = 6,
	Common_ClampUseTPP = 7,
	Common_OneKeyToClimb = 8,
	Common_CrouchControlType = 9,
	Common_LeftSliding = 10,
	Common_SlidingButtonVeer = 11,
	Common_ClimbCancelMode = 12,
	Common_SlideJumpMode = 13,
	Function_ShowPing = 14,
	Function_PingAlphaPercent = 15,
	Function_ShowFastRun = 16,
	Function_AutoSwitchWeaponOnBulletOut = 17,
	Function_SwitchDrugAutoUse = 18,
	Function_DrugRecommend = 19,
	Function_DrugLongPressed = 20,
	Function_ContinuousUseShieldBattery = 21,
	Function_ContinuousUseMedKit = 22,
	Function_QuickProjectile = 23,
	Function_FightTips = 24,
	Level_Sensitivity = 25,
	Value_FirstPersonLensSensitivity = 26,
	Value_ThirdPersonLensSensitivity = 27,
	Value_OneMultLensSensitivity = 28,
	Value_TwoMultLensSensitivity = 29,
	Value_ThreeMultLensSensitivity = 30,
	Value_FourMultLensSensitivity = 31,
	Value_SixMultLensSensitivity = 32,
	Value_EightMultLensSensitivity = 33,
	Value_TenMultLensSensitivity = 34,
	Value_FirstPersonShootSensitivity = 35,
	Value_ThirdPersonShootSensitivity = 36,
	Value_OneMultShootSensitivity = 37,
	Value_TwoMultShootSensitivity = 38,
	Value_ThreeMultShootSensitivity = 39,
	Value_FourMultShootSensitivity = 40,
	Value_SixMultShootSensitivity = 41,
	Value_EightMultShootSensitivity = 42,
	Value_TenMultShootSensitivity = 43,
	Mode_GlobalSensitivity = 44,
	Mode_ESliderAccelerated = 45,
	Mode_CrossHairDamageFeedback = 46,
	Mode_DamageFeedback = 47,
	Mode_HarmFeedback = 48,
	DrawQuality_BR = 49,
	DrawQuality_TDM = 50,
	DrawQuality_PVP = 51,
	Value_bQualityMonitorEnabled = 52,
	PickupTip = 53,
	PlayerSetupSkillAssist = 54,
	ESettingConfig_MAX = 55
};

// Object Name: Enum AClient.ECrossHairMode
enum class ECrossHairMode : uint8 {
	XCrossHairWithIcon = 1,
	XCrossHair = 2,
	OFF = 3,
	ECrossHairMode_MAX = 4
};

// Object Name: Enum AClient.EDamageFeedbackMode
enum class EDamageFeedbackMode : uint8 {
	OFF = 1,
	Overlay = 2,
	Float = 3,
	Merge = 4,
	EDamageFeedbackMode_MAX = 5
};

// Object Name: Enum AClient.EDamageTipType
enum class EDamageTipType : uint8 {
	NONE = 0,
	TipType2 = 1,
	TipType3 = 2,
	TipType23 = 3,
	EDamageTipType_MAX = 4
};

// Object Name: Enum AClient.EScopeFireMode
enum class EScopeFireMode : uint8 {
	Classic = 0,
	Shoulder = 1,
	Mix = 2,
	Mode_Max = 3,
	EScopeFireMode_MAX = 4
};

// Object Name: Enum AClient.EMainUILeftShootButtonShowMode
enum class EMainUILeftShootButtonShowMode : uint8 {
	Always = 1,
	Aim = 2,
	Close = 3,
	EMainUILeftShootButtonShowMode_MAX = 4
};

// Object Name: Enum AClient.EWeaponShotGunFireMode
enum class EWeaponShotGunFireMode : uint8 {
	None = 1,
	ReleaseFire = 2,
	AimReleaseFire = 3,
	EWeaponShotGunFireMode_MAX = 4
};

// Object Name: Enum AClient.ESliderAcceleratedMode
enum class ESliderAcceleratedMode : uint8 {
	Accelerated = 1,
	FixedDistance = 2,
	Fixed = 3,
	ESliderAcceleratedMode_MAX = 4
};

// Object Name: Enum AClient.EGameplayViewTargetType
enum class EGameplayViewTargetType : uint8 {
	NONE = 0,
	MyPawn = 1,
	OBTarget = 2,
	RespwanTarget = 3,
	GMSet = 4,
	MAX = 32
};

// Object Name: Enum AClient.EPropsWeaponType
enum class EPropsWeaponType : uint8 {
	None = 0,
	RespawnBeaconPistol = 1,
	FragGrenade = 2,
	ThermiteGrenade = 3,
	ArcStarGrenade = 4,
	HeatShield = 5,
	SnowBallGrenade = 6,
	SkeletonGrenade = 7,
	Max = 8
};

// Object Name: Enum AClient.EPropsWeaponEndReason
enum class EPropsWeaponEndReason : uint8 {
	None = 0,
	UnEquip = 1,
	Fire = 2,
	Dispose = 3,
	Turn = 4,
	AimExplode = 5,
	TempUnEquip = 6,
	EPropsWeaponEndReason_MAX = 7
};

// Object Name: Enum AClient.EStateSourceType
enum class EStateSourceType : uint8 {
	StateMachineComponent_StartMachine = 0,
	StateMachineComponent_FinishMachine = 1,
	ParachutePointComp_AttachedCharacterStartParachute = 2,
	RespawnAircraftCharacter_LoadCharacters1 = 3,
	RespawnAircraftCharacter_LoadCharacters2 = 4,
	TriggerAction_StartParachute_Excute = 5,
	MagmaRiseVolume_NotifyActorBeginOverlap = 6,
	VoidDoorActor_DoParachuteJum = 7,
	ControllerMagmaComponent_PlayerGoToLanding = 8,
	PlayerControllerStateFollow_FollowOperation = 9,
	ApexCharacter_GotoDying = 10,
	ApexCharacter_GotoDie = 11,
	GameModeStage_MsgToAllPlayerControllers = 12,
	GameModeStage_MsgToPlayerController = 13,
	ApexCharacter_OnMagmaRiseMoveHit = 14,
	GameModePlaneComponent_NotifyPlayersEnterPlane = 15,
	ParachutePointComp_OnCharacterAttached_Implementation = 16,
	CharacterParachuteComponent_ServerDoExpression_Implementation = 17,
	ApexPlayerController_RecoverPlayerState = 18,
	ApexPlayerController_DoParachuteExpression = 19,
	ControllerCheatHelper_SetAIState_Implementation = 20,
	ApexAIController_SetCurStateType = 21,
	ApexGameMode_OnSpawnAI = 22,
	MultiplayerRespawnComponent_RespawnRealPlayer = 23,
	MultiplayerRespawnComponent_RespawnAIPlayer = 24,
	GameModePlaneComponent_NotifyAIsEnterPlane = 25,
	UCharacterParachuteComponent_Reconnected = 26,
	MidfielederJoin_RespawnMidJoinPlayer = 27,
	MidfielederJoin_OnChooseLegendFinish = 28,
	RespawnOperateComponent_RespawnCharacter = 29,
	MultiLevelGameMode_PlayerTimeOver = 30,
	ApexPlayerState_NextLifeRespawn = 31,
	WeekChallenge_Restart = 32,
	EStateSourceType_MAX = 33
};

// Object Name: Enum AClient.EMsgType
enum class EMsgType : uint8 {
	None = 0,
	EMsg_GMEnterActive = 1,
	EMsg_GMExitActive = 2,
	EMsg_GMEnterSelect = 3,
	EMsg_GMExitSelect = 4,
	EMsg_GMEnterReady = 5,
	EMsg_GMExitReady = 6,
	EMsg_GMEnterFight = 7,
	EMsg_GMExitFight = 8,
	EMsg_GMEnterFinish = 9,
	EMsg_GMExit = 10,
	EMsg_GMEnterMidJoin = 11,
	EMsg_PCGotoFight = 12,
	EMsg_PCGotoReady = 13,
	EMsg_PCDie = 14,
	EMsg_PCDying = 15,
	EMsg_PCRespawn = 16,
	EMsg_PCGotoMagmaRise = 17,
	EMsg_PCGotoMidJoin = 18,
	EMsgType_MAX = 19
};

// Object Name: Enum AClient.ERescuingEndReason
enum class ERescuingEndReason : uint8 {
	Normal = 0,
	Break = 1,
	ERescuingEndReason_MAX = 2
};

// Object Name: Enum AClient.EPlayerAudioType
enum class EPlayerAudioType : uint8 {
	Knockdown = 0,
	Kill = 1,
	TeamKill = 2,
	TeamMateDown = 3,
	TeamMateDeath = 4,
	EPlayerAudioType_MAX = 5
};

// Object Name: Enum AClient.EBroadcastMsgType
enum class EBroadcastMsgType : uint8 {
	PropsWeaponAim = 0,
	EBroadcastMsgType_MAX = 1
};

// Object Name: Enum AClient.EEnterOBReason
enum class EEnterOBReason : uint8 {
	None = 0,
	UnDefine = 1,
	TryOBTeammate = 2,
	TryOBAnyOne = 3,
	EEnterOBReason_MAX = 4
};

// Object Name: Enum AClient.EStateType
enum class EStateType : uint8 {
	State_None = 0,
	State_Initial = 1,
	State_Ready = 2,
	State_Fight = 3,
	State_ParachuteOpen = 4,
	State_Dead = 5,
	State_Finish = 6,
	State_MagmaRise = 7,
	State_MidJoin = 8,
	State_MAX = 9
};

// Object Name: Enum AClient.EGameViewType
enum class EGameViewType : uint8 {
	ViewTypeNone = 0,
	ViewTypeTPP = 1,
	ViewTypeFPP = 2,
	EGameViewType_MAX = 3
};

// Object Name: Enum AClient.ECharacterViewSide
enum class ECharacterViewSide : uint8 {
	NONE = 0,
	Left = 1,
	Right = 2,
	ECharacterViewSide_MAX = 3
};

// Object Name: Enum AClient.EBattleItemOperationType
enum class EBattleItemOperationType : uint8 {
	Pickup = 0,
	Drop = 1,
	Use = 2,
	Disuse = 3,
	Enable = 4,
	Disable = 5,
	EBattleItemOperationType_MAX = 6
};

// Object Name: Enum AClient.EKnockdownReviveOpCode
enum class EKnockdownReviveOpCode : uint8 {
	ReviveOther = 0,
	ReviveSelf = 1,
	ReviveCancel = 2,
	EKnockdownReviveOpCode_MAX = 3
};

// Object Name: Enum AClient.EKnockdownShieldOpCode
enum class EKnockdownShieldOpCode : uint8 {
	Activation = 0,
	Revive = 1,
	Cancel = 2,
	Release = 3,
	EKnockdownShieldOpCode_MAX = 4
};

// Object Name: Enum AClient.ERespawnTeammateOpCode
enum class ERespawnTeammateOpCode : uint8 {
	RespawnTeammate = 0,
	RespawnCancel = 1,
	ERespawnTeammateOpCode_MAX = 2
};

// Object Name: Enum AClient.EHitPingType
enum class EHitPingType : uint8 {
	None = 0,
	Ground = 1,
	Item = 2,
	Emeny = 3,
	Looting = 4,
	Attacking = 5,
	Activity = 6,
	Defending = 7,
	Watching = 8,
	Survive = 9,
	Door = 10,
	CarePackage = 11,
	TiaoSanTa = 12,
	SaveBox = 13,
	Bin_Box = 14,
	Respawn_Beacon = 15,
	Loot_Drones = 16,
	Loot_Roller = 17,
	Tomb_Box = 18,
	Survey_Beacon = 19,
	Zip_Line = 20,
	Fly_Dragon = 21,
	Hot_Balloon = 22,
	ForceField = 23,
	Train = 24,
	HealingRobot = 25,
	RespawnAircrash = 26,
	RespawnBanner = 27,
	Dynamic_Respawn_Beacon = 28,
	FirstAid = 29,
	Respawn = 30,
	VoidDoor = 50,
	Loot_BinCreeps = 52,
	DirtyBomb = 53,
	DeathTotem = 55,
	OctaneLaunchPad = 56,
	Leviathan = 58,
	HoverTank = 60,
	Harvester = 61,
	Replicator = 62,
	GamblingMachine = 65,
	HeatShieldStartup = 66,
	HeatShield = 67,
	LobaMarket = 68,
	IceBinLocked = 69,
	IceBinOpend = 70,
	AdvancedVIPBinLocked = 71,
	AdvancedVIPBinOpend = 72,
	VIPBinLocked = 73,
	VIPBinOpend = 74,
	Loot_VIPBinCreeps = 75,
	RevenantSilencer = 76,
	ReviveEnemy = 77,
	FlyingSkeletonTeammate = 78,
	DataKnifeEnemy = 79,
	DataKnifeTombBox = 80,
	GhostBinLocked = 81,
	GhostBinOpen = 82,
	ColosseumActor = 83,
	ColosseumLauncherConsoleOpen = 84,
	ColosseumLauncherConsoleClose = 85,
	ColosseumParachuteCannonActor = 86,
	ColosseumParachuteLootRoller = 87,
	FlyingSkeletonEnemy = 89,
	Others = 255,
	EHitPingType_MAX = 256
};

// Object Name: Enum AClient.EBattleItemDropReason
enum class EBattleItemDropReason : uint8 {
	Manually = 0,
	Associated = 1,
	AutoEquipAndDrop = 2,
	AutoEquipFailed = 3,
	CapacityExceeded = 4,
	UsedUp = 5,
	Force = 6,
	DropWithWeapon = 7,
	PlayerDeaded = 8,
	NoDrop = 9,
	SwapNoDrop = 10,
	AIDrop = 11,
	EBattleItemDropReason_MAX = 12
};

// Object Name: Enum AClient.EWeaponSaveSlot
enum class EWeaponSaveSlot : uint8 {
	WSS_None = 0,
	WSS_MainSlot1 = 1,
	WSS_MainSlot2 = 2,
	WSS_MeleeSlot = 3,
	WSS_Max = 4
};

// Object Name: Enum AClient.EBattleResultType
enum class EBattleResultType : uint8 {
	None = 0,
	Person = 1,
	Team = 2,
	EBattleResultType_MAX = 3
};

// Object Name: Enum AClient.ESignTypeFor
enum class ESignTypeFor : uint8 {
	Self = 1,
	Team = 2,
	All = 3,
	ESignTypeFor_MAX = 4
};

// Object Name: Enum AClient.ESignType
enum class ESignType : uint8 {
	Default = 1,
	WEStation = 2,
	WETrainArea = 3,
	WattsonWireHit = 5,
	Mirage_DecoyVanished = 6,
	Crypto_EnemyTriangle = 7,
	Mirage_DecoyPosTip = 8,
	Crypto_DronePlayerPos = 9,
	BloodHound_EnemyTriangle = 10,
	PlayerDeadSign = 11,
	ReplicatorSign = 12,
	BloodHound_Perk_100102004 = 13,
	ValkyrieEnemyTriangle = 14,
	RhapsodyTacticalPreCastTriangle = 15,
	CryptoScanHealthCountDown = 16,
	Ash_MarkTombBox = 17,
	Ash_MarkTombBoxNone = 18,
	Ash_ArcBoltHit = 19,
	ESignType_MAX = 20
};

// Object Name: Enum AClient.EBattleItemUseReason
enum class EBattleItemUseReason : uint8 {
	Manually = 0,
	Associated = 1,
	AutoEquipAndDrop = 2,
	Swapped = 3,
	Initial = 4,
	BackpackOperate = 5,
	Max = 16
};

// Object Name: Enum AClient.EBattleItemDisuseReason
enum class EBattleItemDisuseReason : uint8 {
	Manually = 0,
	Associated = 1,
	Excluded = 2,
	Swapped = 3,
	AssociateSwapped = 4,
	Dropped = 5,
	Force = 6,
	PlayerDeaded = 7,
	Max = 16
};

// Object Name: Enum AClient.EAttachSocketType
enum class EAttachSocketType : uint8 {
	None = 0,
	Grip = 1,
	Magazine = 2,
	Gunstock = 3,
	OpticalSight = 4,
	Support = 5,
	GunPoint = 6,
	Ammo = 7,
	Pendant = 8,
	HopUp = 9,
	SniperScope = 10,
	ADSMesh = 11,
	Charge = 12,
	Battery = 13,
	Thermal = 14,
	Max = 15
};

// Object Name: Enum AClient.EVirtualJoyStickHiddenSource
enum class EVirtualJoyStickHiddenSource : uint8 {
	NONE = 0,
	HiddenFromUIState = 1,
	HiddenFromSelectLegend = 2,
	HiddenFromLua = 3,
	HiddenFromParachuteTeamControl = 4,
	Simulate = 5,
	RescueSelf = 6,
	MAX = 32
};

// Object Name: Enum AClient.EScreenLeftOperateMode
enum class EScreenLeftOperateMode : uint8 {
	Joystick = 1,
	Joystick_Dynamic = 2,
	Joystick_AllLeft = 3,
	View_AllLeft = 4,
	View_DynamicPosition = 5,
	EScreenLeftOperateMode_MAX = 6
};

// Object Name: Enum AClient.EScreenRightOperateMode
enum class EScreenRightOperateMode : uint8 {
	View_AllRight = 1,
	View_FireFollow = 2,
	View_MAX = 3
};

// Object Name: Enum AClient.EUploadDebugMsgType
enum class EUploadDebugMsgType : uint8 {
	StuckSlide = 0,
	SimulateLongDistance = 1,
	SimulateMeshLongDistance = 2,
	DieMoreState = 3,
	EUploadDebugMsgType_MAX = 4
};

// Object Name: Enum AClient.EScreenOperateMode
enum class EScreenOperateMode : uint8 {
	Mode1 = 1,
	Mode2 = 2,
	Mode3 = 3,
	EScreenOperateMode_MAX = 4
};

// Object Name: Enum AClient.eInGameRecoverItemGuidType
enum class eInGameRecoverItemGuidType : uint8 {
	eShield = 0,
	eHealth = 1,
	eInGameRecoverItemGuidType_MAX = 2
};

// Object Name: Enum AClient.EBattleItemPickupReason
enum class EBattleItemPickupReason : uint8 {
	Manually = 0,
	Associated = 1,
	AutoPickup = 2,
	Initial = 3,
	Replace = 4,
	DefaultItem = 5,
	EBattleItemPickupReason_MAX = 6
};

// Object Name: Enum AClient.EBattleItemOperationFailedReason
enum class EBattleItemOperationFailedReason : uint8 {
	PickupFailed_Default = 0,
	PickupFailed_CapacityExceeded = 1,
	DropFailed_Default = 16,
	UseFailed_Default = 32,
	UseFailed_CapacityExceeded = 33,
	DisuseFailed_Default = 48,
	DisuseFailed_CapacityExceeded = 49,
	EBattleItemOperationFailedReason_MAX = 50
};

// Object Name: Enum AClient.EAttrOperator
enum class EAttrOperator : uint8 {
	Set = 0,
	Plus = 1,
	Multiply = 2,
	EAttrOperator_MAX = 3
};

// Object Name: Enum AClient.EApexAttrType
enum class EApexAttrType : uint8 {
	Attr_None = 0,
	Attr_Health = 1,
	Attr_ShieldValue = 2,
	Attr_ShieldValueMax = 3,
	Attr_SkillSpeedScale = 4,
	Attr_KnockdownSpeedScale = 5,
	Attr_SkillDamageScale = 6,
	Attr_AIDamageScale = 7,
	Attr_MoveShowDistanceScale = 8,
	Attr_FireShowDistanceScale = 9,
	Attr_HealShowDistanceScale = 10,
	Attr_PawnBackpackCapacity = 11,
	Attr_HeadDamageReduce = 12,
	Attr_BodyDamageReduce = 13,
	Attr_BodyDuability = 14,
	Attr_ShieldLevel = 15,
	Attr_HelmetLevel = 16,
	Attr_KnockDownShieldLevel = 17,
	Attr_BackpackLevel = 18,
	Attr_TacticsCDScale = 19,
	Attr_UltimateCDScale = 20,
	Attr_TreatmentMul = 21,
	Attr_WalkSpeed = 22,
	Attr_SkillForbidSprint = 23,
	Attr_IsImmuneHitSlowdown = 24,
	Attr_RescueMultiplier = 25,
	Attr_RescueSelfMultiplier = 26,
	Attr_IsIndiviRescue = 27,
	Attr_MaxWalkSpeedLimit = 28,
	Attr_ViewScrollSpeedScale = 29,
	Attr_SpreadScale = 30,
	Attr_TacticsCDScaleBloodhound = 31,
	Attr_BaseSpeedScale = 32,
	Attr_WeaponSpeedScale = 33,
	Attr_JumpHeightScale = 34,
	Attr_ParachuteJump = 35,
	Attr_ParachuteOpen = 36,
	Attr_ClimbVelocityScale = 37,
	Attr_MAX = 38
};

// Object Name: Enum AClient.EAttrVariableType
enum class EAttrVariableType : uint8 {
	Int = 0,
	Float = 1,
	Resource = 2,
	EAttrVariableType_MAX = 3
};

// Object Name: Enum AClient.EAttributeCaptureSource
enum class EAttributeCaptureSource : uint8 {
	Source = 0,
	Target = 1,
	EAttributeCaptureSource_MAX = 2
};

// Object Name: Enum AClient.eOperationSrcType
enum class eOperationSrcType : uint8 {
	eNone = 0,
	eClient = 1,
	eServer = 2,
	eOperationSrcType_MAX = 3
};

// Object Name: Enum AClient.EWeaponDataSlot
enum class EWeaponDataSlot : uint8 {
	Slot1 = 0,
	Slot2 = 1,
	Slot3 = 2,
	SlotMax = 3,
	SlotNone = 4,
	EWeaponDataSlot_MAX = 5
};

// Object Name: Enum AClient.EOperationType
enum class EOperationType : uint8 {
	EOT_None = 0,
	EOT_Skill = 1,
	EOT_Weapon = 2,
	EOT_Climb = 3,
	EOT_Zipline = 4,
	EOT_PawnState = 5,
	EOT_MainHandThrow = 6,
	EOT_PropsWeapon = 7,
	EOT_Finish = 8,
	EOT_RecoverProp = 9,
	EOT_MeleeWeapon = 10,
	EOT_KnockdownShieldOn = 11,
	EOT_ForbiddenZone = 12,
	EOT_MAX = 13
};

// Object Name: Enum AClient.EMeleeAttackPose
enum class EMeleeAttackPose : uint8 {
	StandAttack = 0,
	SprintAttack = 1,
	CrouchAttack = 2,
	SlidingAttack = 3,
	InAirAttack = 4,
	EMeleeAttackPose_MAX = 5
};

// Object Name: Enum AClient.EStateRemovedReason
enum class EStateRemovedReason : uint8 {
	Manually = 0,
	Interrupted = 1,
	Disabled = 2,
	Replicated = 3,
	EStateRemovedReason_MAX = 4
};

// Object Name: Enum AClient.EItemAdditionalType
enum class EItemAdditionalType : uint8 {
	IAT_None = 0,
	IAT_InitBulletNum = 1,
	IAT_WeaponSkinID = 2,
	IAT_DeriveId = 3,
	IAT_ExtraBulletNum = 4,
	IAT_SpecialBulletNum = 5,
	IAT_bUseSpecialBullet = 6,
	IAT_AttachList = 7,
	IAT_RemainingDuability = 8,
	IAT_RemainingBattery = 9,
	IAT_RemainingExp = 10,
	IAT_SkinOwnerKey = 11,
	IAT_CumulativeKill = 12,
	IAT_SpawnSource = 13,
	IAT_MAX = 14
};

// Object Name: Enum AClient.EPickupLockedReason
enum class EPickupLockedReason : uint8 {
	None = 0,
	Duplicator = 1,
	Manually = 2,
	EPickupLockedReason_MAX = 3
};

// Object Name: Enum AClient.EPickUpOutLineType
enum class EPickUpOutLineType : uint8 {
	POT_Default = 0,
	POT_Aim = 1,
	POT_MAX = 2
};

// Object Name: Enum AClient.EPickupItemRegionType
enum class EPickupItemRegionType : uint8 {
	None = 0,
	Static = 1,
	Dynamic = 2,
	CheckOnLand = 3,
	Max = 4
};

// Object Name: Enum AClient.EItemSpawnReason
enum class EItemSpawnReason : uint8 {
	None = 0,
	Normal = 1,
	Bin = 2,
	LootRoller = 3,
	PlayerDrop = 4,
	CarePackage = 5,
	AirDrop = 6,
	GunRack = 7,
	KillDrop = 8,
	Upgrade = 9,
	LootBinCreeps = 10,
	GM = 11,
	TreasureDoor = 12,
	BinTreasurePackage = 13,
	EnergyShield = 14,
	GamblingMachine = 15,
	Replicator = 16,
	IceBin = 17,
	Rowdy = 18,
	Downgrade = 19,
	DJStage = 20,
	GhostBin = 21,
	NewbieScript = 22,
	Max = 23
};

// Object Name: Enum AClient.ECharacterEquipAttachment
enum class ECharacterEquipAttachment : uint8 {
	PropsWeapon = 0,
	ECharacterEquipAttachment_MAX = 1
};

// Object Name: Enum AClient.EHealthChangeWithoutRecommendType
enum class EHealthChangeWithoutRecommendType : uint8 {
	eOctance_Passive = 0,
	eOctance_MAX = 1
};

// Object Name: Enum AClient.ERespawnType
enum class ERespawnType : uint8 {
	Normal = 0,
	NextLife = 1,
	ERespawnType_MAX = 2
};

// Object Name: Enum AClient.EParachuteState
enum class EParachuteState : uint8 {
	PS_None = 0,
	PS_FreeFall = 1,
	PS_Opening = 2,
	PS_Landing = 3,
	PS_MAX = 4
};

// Object Name: Enum AClient.ECancelBtnReason
enum class ECancelBtnReason : uint8 {
	Projectile = 0,
	ShootWeapon = 1,
	ECancelBtnReason_MAX = 2
};

// Object Name: Enum AClient.ECharacterUIState
enum class ECharacterUIState : uint8 {
	NoWeaponState = 0,
	Dying = 2,
	Dead = 3,
	GunADS = 4,
	ZiplineTwoHand = 5,
	AircraftRespawn = 6,
	SkillVoid = 7,
	SkillPhaseShift = 8,
	CryptoDrone = 9,
	Normal = 10,
	OB = 11,
	DoFinisher = 12,
	VehicleBoarding = 13,
	VehicleDrive = 14,
	VehicleRide = 15,
	Replay = 16,
	ValkyrieSkywardDiveStart = 17,
	JoinSkywardDiveTeam = 18,
	ValkyrieSkywardDiveLaunch = 19,
	InPlane = 20,
	InParachute = 21,
	Replicator = 22,
	PureSpectator = 23,
	MAX = 32
};

// Object Name: Enum AClient.EAvatarDamagePosition
enum class EAvatarDamagePosition : uint8 {
	Non = 0,
	BigHead = 1,
	BigThighs = 2,
	BigBody = 3,
	BigHand = 4,
	BigFoot = 5,
	Wheel0 = 6,
	Wheel1 = 7,
	Wheel2 = 8,
	Wheel3 = 9,
	EAvatarDamagePosition_MAX = 10
};

// Object Name: Enum AClient.EInGameGuideHandGuideType
enum class EInGameGuideHandGuideType : uint8 {
	Slide = 0,
	Touch = 1,
	EInGameGuideHandGuideType_MAX = 2
};

// Object Name: Enum AClient.EInGameGuideDirection
enum class EInGameGuideDirection : uint8 {
	Left = 0,
	Right = 1,
	Top = 2,
	Bottom = 3,
	EInGameGuideDirection_MAX = 4
};

// Object Name: Enum AClient.EInGameGuideType
enum class EInGameGuideType : uint8 {
	GlobalGuide = 0,
	ActionGuide = 1,
	PointGuide = 2,
	PictureGuide = 3,
	NoAnyEffectGuide = 4,
	EInGameGuideType_MAX = 5
};

// Object Name: Enum AClient.ETouchTakeOverType
enum class ETouchTakeOverType : uint8 {
	None = 0,
	RightShoot = 1,
	LeftShoot = 2,
	ViceShoot = 3,
	AimButton = 4,
	SmallSkill = 5,
	Crouch = 6,
	Jump = 7,
	Common = 9,
	Max = 10
};

// Object Name: Enum AClient.EPickupPanelPingState
enum class EPickupPanelPingState : uint8 {
	None = 0,
	PPPS_SelfPing = 1,
	PPPS_OtherPing = 2,
	PPPS_SelfReserve = 3,
	PPPS_OtherReserve = 4,
	EPickupPanelPingState_MAX = 5
};

// Object Name: Enum AClient.EPickupGroup
enum class EPickupGroup : uint8 {
	None = 0,
	PG_ActivityTop = 1,
	PG_Weapon = 2,
	PG_Ammo = 3,
	PG_Equipment = 4,
	PG_Attachment = 5,
	PG_Consumables = 6,
	PG_Grenades = 7,
	PG_Tactics = 8,
	PG_ActivityBottom = 9,
	PG_Other = 10,
	PG_Drop = 11,
	EPickupGroup_MAX = 12
};

// Object Name: Enum AClient.EApexSoundType
enum class EApexSoundType : uint8 {
	ApexSoundNone = 0,
	ApexWorldObject = 1,
	ApexWorldBGM = 2,
	ApexWorldAmb = 3,
	ApexWorldUI = 4,
	ApexWorldLegendSound = 5,
	ApexWorldCircle = 6,
	ApexLegendFootStep = 7,
	ApexLegendClimb = 8,
	ApexLegendSlide = 9,
	ApexLegendMainSkill = 10,
	ApexLegendSmallSkill = 11,
	ApexLegendNegativeSkill = 12,
	ApexShootWeaponFire = 13,
	ApexShootWeaponReload = 14,
	ApexGrenade = 15,
	ApexHealing = 16,
	Broadcast = 17,
	EApexSoundType_MAX = 18
};

// Object Name: Enum AClient.ECharacterAnimType
enum class ECharacterAnimType : uint8 {
	ECharAnim_Move = 0,
	ECharAnim_Aim = 1,
	ECharAnim_ToStand = 2,
	ECharAnim_ToCrouch = 3,
	ECharAnim_Hurt = 4,
	ECharAnim_Reload = 5,
	ECharAnim_TacticsReload = 6,
	ECharAnim_Fire_Single = 7,
	ECharAnim_Fire_Scope = 8,
	ECharAnim_PullingPlug = 9,
	ECharAnim_PutUpWeapon = 10,
	ECharAnim_PutDownWeapon = 11,
	ECharAnim_PickWeapon = 12,
	ECharAnim_ForegripAnim = 13,
	ECharAnim_WeaponIdle = 14,
	ECharAnim_Turn_L = 15,
	ECharAnim_Turn_R = 16,
	ECharAnim_Shovel = 17,
	ECharAnim_Climb = 18,
	ECharAnim_Hang = 19,
	ECharAnim_Vault = 20,
	ECharAnim_AIM_Move = 21,
	ECharAnim_ADSON_MTG = 22,
	ECharAnim_ADSOFF_MTG = 23,
	ECharAnim_Sprint_BS = 24,
	ECharAnim_Breathe_SEQ = 25,
	ECharAnim_Death_MTG = 26,
	ECharAnim_NormalMoveBack_BS = 27,
	ECharAnim_AimMoveBack_BS = 28,
	ECharAnim_Frisk_SEQ = 29,
	ECharAnim_ShootType_Automatic = 30,
	ECharAnim_ShootType_Single = 31,
	ECharAnim_ShootType_Multiple = 32,
	ECharAnim_Skill_LeftHand = 33,
	ECharAnim_Skill_RightHand = 34,
	ECharAnim_Skill_BothHands = 35,
	ECharAnim_Rescue_Other = 36,
	ECharAnim_Rescue_Self = 37,
	ECharAnim_Rescue_BeRescue = 38,
	ECharAnim_Slide_Start = 39,
	ECharAnim_Slide_Loop = 40,
	ECharAnim_Slide_End = 41,
	ECharAnim_Slide_Aim = 42,
	ECharAnim_Pick_Banner = 43,
	ECharAnim_ADS_LeftShield = 44,
	ECharAnim_ADS_BreatheAdd = 45,
	ECharAnim_FoldGun = 46,
	ECharAnim_EquipAttachment = 47,
	ECharAnim_SprintPutOnWeapon = 48,
	ECharAnim_SprintPutOffWeapon = 49,
	ECharAnim_SingleRightHandGun = 50,
	ECharAnim_SwitchGun = 51,
	ECharAnim_ToSingleBothHand = 52,
	ECharAnim_GoUpZipline = 53,
	ECharAnim_LoopZipline = 54,
	ECharAnim_GoDownZipline = 55,
	ECharAnim_WeaponCharge = 56,
	ECharAnim_Fire_Auto = 57,
	ECharAnim_Fire_Burst = 58,
	ECharAnim_ADS_Fire_Auto = 59,
	ECharAnim_ADS_Fire_Burst = 60,
	ECharAnim_UnEquipToUnArm = 61,
	ECharAnim_PreFire = 62,
	ECharAnim_OrientationWarpingMove_BS = 63,
	ECharAnim_FakeUnEquipHeirloom = 64,
	ECharAnim_OrientationWarpingMoveWhenADS = 65,
	ECharAnim_PutUpProps = 66,
	ECharAnim_PutDownProps = 67,
	ECharAnim_SkillAo = 68,
	ECharAnim_SkillBs = 69,
	ECharAnim_SkillSeq = 70,
	ECharAnim_GroundSlideStart = 71,
	ECharAnim_Display1 = 72,
	ECharAnim_AimPullingPlug = 73,
	ECharAnim_SniperPullingPlug = 74,
	ECharAnim_Display2 = 75,
	ECharAnim_EnterSprint = 76,
	ECharAnim_KeepSprintPose = 77,
	ECharAnim_LeaveSprintInStand = 78,
	ECharAnim_LeaveSprintInSlide = 79,
	ECharAnim_EnterZiplineWeapon = 80,
	ECharAnim_KeepZiplineWeaponPose = 81,
	ECharAnim_LeaveZiplineWeapon = 82,
	ECharAnim_MovingUpBodyOverlay = 83,
	ECharAnim_MeleeAttackBack = 84,
	ECharAnim_SprintMeleeAttackBack = 85,
	ECharAnim_Max = 86
};

// Object Name: Enum AClient.EAnimLayerType
enum class EAnimLayerType : uint8 {
	EAnimLayer_Char = 0,
	EAnimLayer_Weapon = 1,
	EAnimLayer_Skill = 2,
	EAnimLayer_Indivi = 3,
	EAnimLayer_Inspect = 4,
	EAnimLayer_Max = 5
};

// Object Name: Enum AClient.ECharacterPoseType
enum class ECharacterPoseType : uint8 {
	ECharPose_Stand = 0,
	ECharPose_Crouch = 1,
	ECharPose_SingleStand = 2,
	ECharPose_SingleCrouch = 3,
	ECharPose_Max = 4
};

// Object Name: Enum AClient.EAuraTargetLimitType
enum class EAuraTargetLimitType : uint8 {
	None = 0,
	Nearest = 1,
	EAuraTargetLimitType_MAX = 2
};

// Object Name: Enum AClient.EPickerTargetType
enum class EPickerTargetType : uint8 {
	None = 0,
	Self = 1,
	TeamMate = 2,
	Group = 3,
	Enemy = 4,
	Other = 5,
	All = 6,
	TeamMateNotSelf = 7,
	TeamMateIncludeDecoy = 8,
	MaxNum = 9,
	EPickerTargetType_MAX = 10
};

// Object Name: Enum AClient.EFreshWeaponStateType
enum class EFreshWeaponStateType : uint8 {
	FreshWeaponStateType_None = 0,
	FreshWeaponStateType_Inactive = 1,
	FreshWeaponStateType_Idle = 2,
	FreshWeaponStateType_IdleToBackpack = 3,
	FreshWeaponStateType_Backpack = 4,
	FreshWeaponStateType_BackpackToIdle = 5,
	FreshWeaponStateType_Fire = 6,
	FreshWeaponStateType_Reload = 7,
	FreshWeaponStateType_PreFire = 8,
	FreshWeaponStateType_PostFire = 9,
	FreshWeaponStateType_PostReload = 10,
	FreshWeaponStateType_InClimb = 11,
	Max = 12
};

// Object Name: Enum AClient.EWeaponAttchSocketPosition
enum class EWeaponAttchSocketPosition : uint8 {
	None = 0,
	Back_ShortLeft = 1,
	Back_ShortRight = 2,
	Back_LongLeft = 3,
	Back_LongRight = 4,
	Hand_Equip = 5,
	Hand_Equip2 = 6,
	Back_Melee1 = 7,
	Back_Melee2 = 8,
	MAX = 9
};

// Object Name: Enum AClient.ECharacterHealthStatus
enum class ECharacterHealthStatus : uint8 {
	HealthyAlive = 0,
	HasLastBreath = 1,
	FinishedLastBreath = 2,
	Max = 3
};

// Object Name: Enum AClient.EWeaponSpecificType
enum class EWeaponSpecificType : uint8 {
	None = 0,
	VK47 = 1,
	G7 = 2,
	R301 = 3,
	Hemlok = 4,
	Havoc = 5,
	R99 = 6,
	Alternator = 7,
	Prowler = 8,
	Volt = 9,
	M600 = 10,
	LStar = 11,
	Devotion = 12,
	PeaceKeeper = 13,
	Mozambique = 14,
	EVA8 = 15,
	Mastiff = 16,
	Longbow = 17,
	TripleTake = 18,
	ChargeRifle = 19,
	Sentinel = 20,
	Kraber = 21,
	AWM = 22,
	P2020 = 23,
	RE45 = 24,
	WingMan = 25,
	P3030 = 26,
	Rampage = 27,
	DevotionWithTurbo = 28,
	RE45WithHammerPoint = 29,
	RampageWithThermitGrenade = 30,
	EWeaponSpecificType_MAX = 31
};

// Object Name: Enum AClient.ESimuWeaponFollowState
enum class ESimuWeaponFollowState : uint8 {
	SWFS_None = 0,
	SWFS_Near = 1,
	SWFS_Far = 2,
	SWFS_SuperFar = 3,
	SWFS_MAX = 4
};

// Object Name: Enum AClient.EDisplayCharStateMode
enum class EDisplayCharStateMode : uint8 {
	None = 0,
	Idle = 1,
	RandomIdle = 2,
	PlayMontage = 3,
	Sprint = 4,
	Fire = 5,
	Reload = 6,
	Switch = 7,
	FireLoop = 8,
	EDisplayCharStateMode_MAX = 9
};

// Object Name: Enum AClient.EDisplayCharMeshMode
enum class EDisplayCharMeshMode : uint8 {
	Top = 0,
	Mid = 1,
	Low = 2,
	Compressed = 3,
	Default = 4,
	EDisplayCharMeshMode_MAX = 5
};

// Object Name: Enum AClient.EDisplaySceneMode
enum class EDisplaySceneMode : uint8 {
	Lobby = 0,
	WeaponLib = 1,
	EDisplaySceneMode_MAX = 2
};

// Object Name: Enum AClient.ELegendType
enum class ELegendType : uint8 {
	LegendNone = 0,
	Bangalore = 1,
	Bloodhound = 2,
	Caustic = 3,
	Crypto = 4,
	Gibraltar = 5,
	Lifeline = 6,
	Mirage = 7,
	Octane = 8,
	Pathfinder = 9,
	Revenant = 10,
	Wattson = 11,
	Loba = 12,
	Valkyrie = 13,
	Wraith = 14,
	DJ = 15,
	Phantom = 16,
	MonkeyKing = 17,
	Decoy = 18,
	Seeker = 19,
	Reidel = 20,
	Spider = 21,
	Horizon = 22,
	Ash = 23,
	ELegendType_MAX = 24
};

// Object Name: Enum AClient.EHoverTankMoveType
enum class EHoverTankMoveType : uint8 {
	None = 0,
	Normal = 1,
	Landing = 2,
	Parking = 3,
	EHoverTankMoveType_MAX = 4
};

// Object Name: Enum AClient.EHoverTankPathPointType
enum class EHoverTankPathPointType : uint8 {
	None = 0,
	StartPoint = 1,
	EndPoint = 2,
	StopPoint = 3,
	NormalPoint = 4,
	ZipLinePoint = 5,
	EHoverTankPathPointType_MAX = 6
};

// Object Name: Enum AClient.EApgameDeathRecallDamageSourceType
enum class EApgameDeathRecallDamageSourceType : uint8 {
	Other = 0,
	Player = 1,
	Fall = 2,
	Magma = 3,
	PoisonCircle = 4,
	Melee = 5,
	ForbiddenZone = 6,
	EApgameDeathRecallDamageSourceType_MAX = 7
};

// Object Name: Enum AClient.EControllableAreaStatus
enum class EControllableAreaStatus : uint8 {
	None = 0,
	Free = 1,
	Releasing = 2,
	Fighting = 3,
	Converting = 4,
	Controlling = 5,
	FullControlled = 6,
	EControllableAreaStatus_MAX = 7
};

// Object Name: Enum AClient.EApexInteractType
enum class EApexInteractType : uint8 {
	OpenDoor = 0,
	CloseDoor = 1,
	OpenBin = 2,
	OpenBinBottom = 3,
	ZiplineRide = 4,
	ZiplineDown = 5,
	OpenCarePackage = 6,
	EApexInteractType_MAX = 7
};

// Object Name: Enum AClient.ECharacterVehicleState
enum class ECharacterVehicleState : uint8 {
	None = 0,
	GetingOn = 1,
	OnVehicle = 2,
	GetingOff = 3,
	ECharacterVehicleState_MAX = 4
};

// Object Name: Enum AClient.EParachuteTriggerReason
enum class EParachuteTriggerReason : uint8 {
	NONE = 0,
	GM_Instruction = 1,
	JumpFromPlane = 2,
	JumpFromPoint = 3,
	JumpFromHotBalloon = 4,
	JumpFromSteamPad = 5,
	JumpFromFountain = 6,
	JumpFromRespawn = 7,
	JumpFromValkyrieUltimate = 8,
	JumpFromVoidDoor = 9,
	JumpFromParachuteCannon = 10,
	EParachuteTriggerReason_MAX = 11
};

// Object Name: Enum AClient.EDingType
enum class EDingType : uint8 {
	None = 0,
	DingOK = 1,
	ICant = 2,
	DingNO = 3,
	Ding = 4,
	Delete = 5,
	Join = 6,
	CancelDing = 7,
	CantDing = 8,
	CantDelete = 9,
	EDingType_MAX = 10
};

// Object Name: Enum AClient.EMGameModeStage
enum class EMGameModeStage : uint8 {
	None = 0,
	Active = 1,
	SelectLegend = 2,
	Ready = 3,
	Fighting = 4,
	Finished = 5,
	Max = 6
};

// Object Name: Enum AClient.EDynamicItemType
enum class EDynamicItemType : uint8 {
	Unknown = 0,
	RespawnBeacon = 1,
	SurveyBeacon = 2,
	GunRack = 3,
	CureBeacon = 4,
	Spore = 5,
	Workbench = 6,
	Harvester = 7,
	WinterWarfareBin = 8,
	DiamondCollect = 9,
	Rowdy = 10,
	VIPBin = 11,
	ColosseumLauncherConsole = 12,
	HalloweenBin = 13,
	EDynamicItemType_MAX = 14
};

// Object Name: Enum AClient.ESelectLegendStage
enum class ESelectLegendStage : uint8 {
	None = 0,
	ShowCurtain = 1,
	ChooseLegend = 2,
	FreezeLegend = 3,
	QuitChooseLegend = 4,
	ChooseSkin = 5,
	ShowSkin = 6,
	ShowTeam = 7,
	ShowDefender = 8,
	ShowEnemy = 9,
	AniCutTo = 10,
	FadeOut = 11,
	Repick = 12,
	ESelectLegendStage_MAX = 13
};

// Object Name: Enum AClient.ERoundResultReason
enum class ERoundResultReason : uint8 {
	None = 0,
	ControlArea = 1,
	RemainOneCamp = 2,
	ERoundResultReason_MAX = 3
};

// Object Name: Enum AClient.EGamepadKeyType
enum class EGamepadKeyType : uint8 {
	eNone = 0,
	eGamepad_LeftX_Press = 1,
	eGamepad_LeftX_Release = 2,
	eGamepad_LeftX_Axis = 3,
	eGamepad_LeftY_Press = 4,
	eGamepad_LeftY_Release = 5,
	eGamepad_LeftY_Axis = 6,
	eGamepad_RightX_Press = 7,
	eGamepad_RightX_Release = 8,
	eGamepad_RightX_Axis = 9,
	eGamepad_RightY_Press = 10,
	eGamepad_RightY_Release = 11,
	eGamepad_RightY_Axis = 12,
	eGamepad_LeftTriggerAxis_Press = 13,
	eGamepad_LeftTriggerAxis_Release = 14,
	eGamepad_LeftTriggerAxis = 15,
	eGamepad_RightTriggerAxis_Press = 16,
	eGamepad_RightTriggerAxis_Release = 17,
	eGamepad_RightTriggerAxis = 18,
	eGamepad_LeftThumbstick_Press = 19,
	eGamepad_LeftThumbstick_Release = 20,
	eGamepad_RightThumbstick_Press = 21,
	eGamepad_RightThumbstick_Release = 22,
	eGamepad_Special_Left_Press = 23,
	eGamepad_Special_Left_Release = 24,
	eGamepad_Special_Left_X_Press = 25,
	eGamepad_Special_Left_X_Release = 26,
	eGamepad_Special_Left_Y_Press = 27,
	eGamepad_Special_Left_Y_Release = 28,
	eGamepad_Special_Right_Press = 29,
	eGamepad_Special_Right_Release = 30,
	eGamepad_FaceButton_Bottom_Press = 31,
	eGamepad_FaceButton_Bottom_Release = 32,
	eGamepad_FaceButton_Right_Press = 33,
	eGamepad_FaceButton_Right_Release = 34,
	eGamepad_FaceButton_Left_Press = 35,
	eGamepad_FaceButton_Left_Release = 36,
	eGamepad_FaceButton_Top_Press = 37,
	eGamepad_FaceButton_Top_Release = 38,
	eGamepad_LeftShoulder_Press = 39,
	eGamepad_LeftShoulder_Release = 40,
	eGamepad_RightShoulder_Press = 41,
	eGamepad_RightShoulder_Release = 42,
	eGamepad_LeftTrigger_Press = 43,
	eGamepad_LeftTrigger_Release = 44,
	eGamepad_RightTrigger_Press = 45,
	eGamepad_RightTrigger_Release = 46,
	eGamepad_DPad_Up_Press = 47,
	eGamepad_DPad_Up_Release = 48,
	eGamepad_DPad_Down_Press = 49,
	eGamepad_DPad_Down_Release = 50,
	eGamepad_DPad_Right_Press = 51,
	eGamepad_DPad_Right_Release = 52,
	eGamepad_DPad_Left_Press = 53,
	eGamepad_DPad_Left_Release = 54,
	eGamepad_LeftStick_Up_Press = 55,
	eGamepad_LeftStick_Up_Release = 56,
	eGamepad_LeftStick_Down_Press = 57,
	eGamepad_LeftStick_Down_Release = 58,
	eGamepad_LeftStick_Right_Press = 59,
	eGamepad_LeftStick_Right_Release = 60,
	eGamepad_LeftStick_Left_Press = 61,
	eGamepad_LeftStick_Left_Release = 62,
	eGamepad_RightStick_Up_Press = 63,
	eGamepad_RightStick_Up_Release = 64,
	eGamepad_RightStick_Down_Press = 65,
	eGamepad_RightStick_Down_Release = 66,
	eGamepad_RightStick_Right_Press = 67,
	eGamepad_RightStick_Right_Release = 68,
	eGamepad_RightStick_Left_Press = 69,
	eGamepad_RightStick_Left_Release = 70,
	eGamepad_CombineRelease_2 = 71,
	eGamepad_CombineRelease_3 = 72,
	eGamepad_CombineRelease_4 = 73,
	eMax = 74,
	EGamepadKeyType_MAX = 75
};

// Object Name: Enum AClient.EGamepadUserKeyType
enum class EGamepadUserKeyType : uint8 {
	eSpecialLeft = 0,
	eSpecialRight = 1,
	eLT = 2,
	eRT = 3,
	eLB = 4,
	eRB = 5,
	eLeftJoystick = 6,
	eRightJoystick = 7,
	eCrossUp = 8,
	eCrossDown = 9,
	eCrossLeft = 10,
	eCrossRight = 11,
	eY = 12,
	eB = 13,
	eA = 14,
	eX = 15,
	eMax = 16,
	EGamepadUserKeyType_MAX = 17
};

// Object Name: Enum AClient.EGamepadType
enum class EGamepadType : uint8 {
	eNone = 0,
	eXBox = 1,
	ePS4 = 2,
	eMax = 3,
	EGamepadType_MAX = 4
};

// Object Name: Enum AClient.EAniType
enum class EAniType : uint8 {
	UpIn = 0,
	UpOut = 1,
	DownOut = 2,
	DownIn = 3,
	FadeIn = 4,
	FadeOut = 5,
	Flicker = 6,
	None = 7,
	EAniType_MAX = 8
};

// Object Name: Enum AClient.TTOColosseumStage
enum class TTOColosseumStage : uint8 {
	Default = 0,
	Disable = 1,
	Ready = 2,
	Active = 3,
	Settlement = 4,
	CD = 5,
	Max = 6
};

// Object Name: Enum AClient.EBattleResultModeType
enum class EBattleResultModeType : uint8 {
	None = 0,
	BR = 1,
	MP = 2,
	EBattleResultModeType_MAX = 3
};

// Object Name: Enum AClient.EGamepadActionType
enum class EGamepadActionType : uint8 {
	eNone = 0,
	eBPActionType1 = 1,
	eBPActionType2 = 2,
	eBPActionType3 = 3,
	eBPActionType4 = 4,
	eBPActionType5 = 5,
	eBPActionType6 = 6,
	eBPActionType7 = 7,
	eBPActionType8 = 8,
	eBPActionType9 = 9,
	eBPActionType10 = 10,
	eBPActionType11 = 11,
	eBPActionType12 = 12,
	eBPActionType13 = 13,
	eBPActionType14 = 14,
	eBPActionType15 = 15,
	eBPActionType16 = 16,
	eBPActionType17 = 17,
	eBPActionType18 = 18,
	eBPActionType19 = 19,
	eBPActionType20 = 20,
	eBPActionType21 = 21,
	eBPActionType22 = 22,
	eBPActionType23 = 23,
	eBPActionType24 = 24,
	eBPActionType25 = 25,
	eBPActionType26 = 26,
	eBPActionType27 = 27,
	eBPActionType28 = 28,
	eBPActionType29 = 29,
	eBPActionType30 = 30,
	eBPActionType31 = 31,
	eBPActionType32 = 32,
	eBPActionType33 = 33,
	eBPActionType34 = 34,
	eBPActionType35 = 35,
	eBPActionType36 = 36,
	eBPActionType37 = 37,
	eBPActionType38 = 38,
	eBPActionType39 = 39,
	eBPActionType40 = 40,
	eBPActionType41 = 41,
	eBPActionType42 = 42,
	eBPActionType43 = 43,
	eBPActionType44 = 44,
	eBPActionType45 = 45,
	eBPActionType46 = 46,
	eBPActionType47 = 47,
	eBPActionType48 = 48,
	eBPActionType49 = 49,
	eBPActionType50 = 50,
	eBPActionType51 = 51,
	eBPActionType52 = 52,
	eBPActionType53 = 53,
	eBPActionType54 = 54,
	eBPActionType55 = 55,
	eBPActionType56 = 56,
	eBPActionType57 = 57,
	eBPActionType58 = 58,
	eBPActionType59 = 59,
	eBPActionType60 = 60,
	eBPActionType61 = 61,
	eBPActionType62 = 62,
	eBPActionType63 = 63,
	eBPActionType64 = 64,
	eBPActionType65 = 65,
	eBPActionType66 = 66,
	eBPActionType67 = 67,
	eBPActionType68 = 68,
	eBPActionType69 = 69,
	eBPActionType70 = 70,
	eBPActionType71 = 71,
	eBPActionType72 = 72,
	eBPActionType73 = 73,
	eBPActionType74 = 74,
	eBPActionType75 = 75,
	eBPActionType76 = 76,
	eBPActionType77 = 77,
	eBPActionType78 = 78,
	eBPActionType79 = 79,
	eBPActionType80 = 80,
	eBPActionType81 = 81,
	eBPActionType82 = 82,
	eBPActionType83 = 83,
	eBPActionType84 = 84,
	eBPActionType85 = 85,
	eBPActionType86 = 86,
	eBPActionType87 = 87,
	eBPActionType88 = 88,
	eBPActionType89 = 89,
	eBPActionType90 = 90,
	eBPActionType91 = 91,
	eBPActionType92 = 92,
	eBPActionType93 = 93,
	eBPActionType94 = 94,
	eBPActionType95 = 95,
	eBPActionType96 = 96,
	eBPActionType97 = 97,
	eBPActionType98 = 98,
	eBPActionType99 = 99,
	eBPActionType100 = 100,
	eOpenDoor = 101,
	eCloseDoor = 102,
	eBin = 103,
	eTreasureDoor = 104,
	eCancelTreasureDoor = 105,
	eExtract = 106,
	eReplicator = 107,
	eFinish = 108,
	eFinishCancel = 109,
	eRescue = 110,
	eRescueCancel = 111,
	eRescueSelf = 112,
	eKnockdownShieldOnOff = 113,
	eRespawnTeamMate = 114,
	eRespawnTeamMateCancel = 115,
	eSurveyBeaconUsed = 116,
	eSurveyBeaconCancel = 117,
	eCausticDirtyBombRecycle = 118,
	eRideZipline = 119,
	eDownZipline = 120,
	eOpenCarePackage = 121,
	eStageSwitch = 122,
	eMirageStageSwitch = 123,
	eMoveForward = 124,
	eMoveRight = 125,
	eTurn = 126,
	eTitl = 127,
	eRun = 128,
	eAutoRun = 129,
	eJumpPressed = 130,
	eJumpReleased = 131,
	eCrouchPressed = 132,
	eCrouchReleased = 133,
	eOpenMiniMap = 134,
	eOpenBackpack = 135,
	eCloseBackpack = 136,
	eActiveColosseumLauncherConsole = 137,
	eColosseumJumpConsole = 138,
	eMouseMoveHorizontal = 139,
	eMouseMoveVertical = 140,
	eMouseMoveVerticalReverse = 141,
	eMouseDown = 142,
	eMouseUp = 143,
	ePressedPing = 144,
	eReleasedPing = 145,
	eHorizontalMovePing = 146,
	eVerticalMovePing = 147,
	eTestForceFeedback = 148,
	ePressedMedical = 149,
	eReleasedMedical = 150,
	ePressedProjectile = 151,
	eReleasedProjectile = 152,
	eHorizontalMoveTurnTable = 153,
	eVerticalMoveTurnTable = 154,
	ePressedPickUpListUp = 155,
	ePressedPickUpListDown = 156,
	ePressedPickUpListLeft = 157,
	ePressedPickUpListRight = 158,
	ePressedPickUp = 159,
	ePressedPickUpPing = 160,
	ePressedPickUpSwitch = 161,
	ePressedSwitchWeapon = 162,
	ePressedPutOutWeapon = 163,
	ePressedSwitchWeaponBtn = 164,
	eReleasedSwitchWeaponBtn = 165,
	ePressedSwitchFireMode = 166,
	ePressedWeaponReloadBtn = 167,
	ePressedTacticsSkillBtn = 168,
	eReleasedTacticsSkillBtn = 169,
	eClickedTacticsSkillCancel = 170,
	eClickedTacticsSkillUndo = 171,
	ePressedUltimateSkillBtn = 172,
	eReleasedUltimateSkillBtn = 173,
	eClickedUltimateSkillCancel = 174,
	eClickedUltimateSkillUndo = 175,
	eClickedSkillAncillaryBtn = 176,
	eClickedParachuteSkillBtn = 177,
	ePressedMeleeAttackBtn = 178,
	eReleasedMeleeAttackBtn = 179,
	ePressedEmojiBtn = 180,
	eReleasedEmojiBtn = 181,
	ePressSpecialForBackpackAndSettingUI = 182,
	eReleaseSpecialForBackpackAndSettingUI = 183,
	eOpenLobaBlackmark = 184,
	eFoldLobaBlackmark = 185,
	eMirageConnectDecoy = 186,
	eMirageSendDecoyOnParachute = 187,
	eHero02GunShield = 188,
	ePressedDroneFlyUp = 189,
	eReleasedDroneFlyUp = 190,
	ePressedDroneFlyDown = 191,
	eReleasedDroneFlyDown = 192,
	eDroneCallBack = 193,
	eNotifySquadAround = 194,
	eCryptoTaticsSkillTurnTableHorizontalMove = 195,
	eCryptoTaticsSkillTurnTableVerticalMove = 196,
	eDropBombActor = 197,
	ePlantBombActor = 198,
	eCancelPlantBombActor = 199,
	eDefuseBombActor = 200,
	eCancelDefuseBombActor = 201,
	eCryptoDroneBeacon = 202,
	eCryptoDroneRecover = 203,
	eCryptoDroneBin = 204,
	eCryptoDroneOpenDoor = 205,
	eCryptoDroneCloseDoor = 206,
	eCryptoDroneCarepackage = 207,
	eCryptoDroneRepawn = 208,
	eCryptoDroneLaunchRocketPressed = 209,
	eCryptoDroneLaunchRocketReleased = 210,
	eHero03ReviveTeamateCancelPressed = 211,
	eSurveyBeaconOpenMapPressed = 212,
	eAshTacticalSkillAuxiliaryPressed = 213,
	eAshTacticalSkillAuxiliaryReleased = 214,
	eAshTacticalSkillHorizontalMove = 215,
	eAshDataKnife = 216,
	eEmptyAction = 217,
	eMax = 218,
	EGamepadActionType_MAX = 219
};

// Object Name: Enum AClient.EForbiddenFunctionType
enum class EForbiddenFunctionType : uint8 {
	None = 0,
	Move = 1,
	View = 2,
	MoveAndView = 3,
	EForbiddenFunctionType_MAX = 4
};

// Object Name: Enum AClient.ERunState
enum class ERunState : uint8 {
	None = 0,
	Still = 1,
	Accelerate = 2,
	SlowDown = 3,
	UniformSpeed = 4,
	ERunState_MAX = 5
};

// Object Name: Enum AClient.EAshArcBoltState
enum class EAshArcBoltState : uint8 {
	None = 0,
	Flying = 1,
	Deploy = 2,
	Active = 3,
	DeActive = 4,
	EAshArcBoltState_MAX = 5
};

// Object Name: Enum AClient.ETrackingPOIPriority
enum class ETrackingPOIPriority : uint8 {
	NONE = 0,
	VERY_LOW = 1,
	LOW = 2,
	NORMAL = 3,
	HIGH = 4,
	VERY_HIGH = 5,
	MAX = 6
};

// Object Name: Enum AClient.ETrackingVisionPOITypes
enum class ETrackingVisionPOITypes : uint8 {
	DROPPOD = 0,
	TITANFALL = 1,
	TITAN_EMBARK = 2,
	TITAN_DISEMBARK = 3,
	DOOR_USE = 4,
	DOOR_DESTROYED = 5,
	PLAYER_CLASS_DEPLOYABLE = 6,
	PLAYER_DEATH = 7,
	PLAYER_KILLER = 8,
	PLAYER_HEAL = 9,
	PLAYER_RELOAD = 10,
	PLAYER_STARTBLEEDOUT = 11,
	PLAYER_TOOK_DAMAGE = 12,
	PLAYER_FIRE_WEAPON_BULLET = 13,
	PLAYER_FIRE_WEAPON_GRENADE = 14,
	PLAYER_OPENDROPPOD = 15,
	PLAYER_LOOTBIN_USED = 16,
	PLAYER_RECOVERBANNER_USED = 17,
	PLAYER_TRAVERSAL_ZIPLINE_START = 18,
	PLAYER_TRAVERSAL_ZIPLINE_STOP = 19,
	PLAYER_TRAVERSAL_FOOTPRINT = 20,
	PLAYER_TRAVERSAL_SLIDE = 21,
	PLAYER_TRAVERSAL_CLIMB = 22,
	PLAYER_TRAVERSAL_MANTLE = 23,
	PLAYER_TRAVERSAL_JUMP_DOWN_START = 24,
	PLAYER_TRAVERSAL_JUMP_DOWN_STOP = 25,
	PLAYER_TRAVERSAL_LAUNCH_PAD = 26,
	PLAYER_ABILITIES_PHASE_DASH_START = 27,
	PLAYER_ABILITIES_PHASE_DASH_STOP = 28,
	PLAYER_ABILITIES_SMOKE = 29,
	PLAYER_ABILITIES_GAS = 30,
	PLAYER_LOOT_PICKUP = 31,
	PLAYER_LOOT_PICKUP_AMMO = 32,
	PLAYER_LOOT_PICKUP_ARMOR = 33,
	PLAYER_LOOT_PICKUP_ATTACHMENT = 34,
	PLAYER_LOOT_PICKUP_WEAPON = 35,
	PLAYER_LOOT_PICKUP_GRENADE = 36,
	PLAYER_LOOT_PICKUP_JUMPKIT = 37,
	PLAYER_LOOT_PICKUP_HEALTH = 38,
	PLAYER_LOOT_PICKUP_HELMET = 39,
	PLAYER_LOOT_PICKUP_BACKPACK = 40,
	PLAYER_LOOT_PICKUP_BANDOLIER = 41,
	PLAYER_LOOT_PICKUP_INCAPSHIELD = 42,
	PLAYER_LOOT_PICKUP_KNOCKDOWNSHIELD = 43,
	PLAYER_LOOT_PICKUP_DATAKNIFE = 44,
	PLAYER_LOOT_EXCHANGE_ARMOR = 45,
	PLAYER_LOOT_EXCHANGE_WEAPON = 46,
	PLAYER_LOOT_EXCHANGE_JUMPKIT = 47,
	PLAYER_LOOT_EXCHANGE_HELMET = 48,
	PLAYER_LOOT_EXCHANGE_BACKPACK = 49,
	PLAYER_LOOT_EXCHANGE_BANDOLIER = 50,
	PLAYER_LOOT_EXCHANGE_INCAPSHIELD = 51,
	PLAYER_LOOT_EXCHANGE_KNOCKDOWNSHIELD = 52,
	PLAYER_LOOT_EXCHANGE_AMMO = 53,
	PLAYER_LOOT_EXCHANGE_ATTACHMENT = 54,
	PLAYER_LOOT_EXCHANGE_GRENADE = 55,
	PLAYER_LOOT_EXCHANGE_HEALTH = 56,
	PLAYER_LOOT_DROP = 57,
	PLAYER_LOOT_DROP_AMMO = 58,
	PLAYER_LOOT_DROP_ARMOR = 59,
	PLAYER_LOOT_DROP_ATTACHMENT = 60,
	PLAYER_LOOT_DROP_WEAPON = 61,
	PLAYER_LOOT_DROP_GRENADE = 62,
	PLAYER_LOOT_DROP_JUMPKIT = 63,
	PLAYER_LOOT_DROP_HEALTH = 64,
	PLAYER_LOOT_DROP_HELMET = 65,
	PLAYER_LOOT_DROP_BACKPACK = 66,
	PLAYER_LOOT_DROP_BANDOLIER = 67,
	PLAYER_LOOT_DROP_INCAPSHIELD = 68,
	PLAYER_LOOT_DROP_KNOCKDOWNSHIELD = 69,
	PLAYER_LOOT_DROP_DATAKNIFE = 70,
	PLAYER_ABILITY_DEPLOYABLE_MEDIC = 71,
	PLAYER_ABILITY_JUMP_PAD = 72,
	PLAYER_ABILITY_BUBBLE_BUNKER = 73,
	PLAYER_ABILITY_TESLA_TRAP = 74,
	PLAYER_ABILITY_TROPHY_SYSTEM = 75,
	PLAYER_ABILITY_DEBRIS_TRAP = 76,
	PLAYER_ABILITY_PHASE_ENTER_GATE = 77,
	PLAYER_ABILITY_PHASE_EXIT_GATE = 78,
	PLAYER_ABILITY_PHASE_GATE = 79,
	PLAYER_ABILITY_MOTION_SENSOR = 80,
	PLAYER_ABILITY_USE_DEATH_TOTEM = 81,
	PLAYER_ABILITY_THEDOME_GIBRALTAR = 82,
	PLAYER_ABILITY_BLACKMARKET_LOBA = 83,
	PLAYER_ABILITY_BRACELETSTART_LOBA = 84,
	PLAYER_ABILITY_BRACELETSTOP_LOBA = 85,
	PLAYER_ABILITY_ARC_BOLT_DEPLOY = 86,
	PLAYER_ABILITY_BLACK_HOLE = 87,
	PLAYER_ABILITY_BLACK_HOLE_DESTROYED = 88,
	PLAYER_ABILITY_GRAVITY_LIFT = 89,
	PLAYER_ABILITY_GRAVITY_LIFT_DESTROYED = 90,
	_count = 91,
	ETrackingVisionPOITypes_MAX = 92
};

// Object Name: Enum AClient.EMiniMapDynamicType
enum class EMiniMapDynamicType : uint8 {
	None = 0,
	CausticDirtyBomb = 1,
	CryptoDrone = 2,
	WattsonInterceptionPylon = 3,
	WattsonTeslaNode = 4,
	WattsonTeslaWire = 5,
	DeathTotem = 6,
	LobaBlackMarket = 7,
	EnemyArea = 8,
	AshBox = 9,
	MAX = 10
};

// Object Name: Enum AClient.ECharacterCameraMode
enum class ECharacterCameraMode : uint8 {
	NONE = 0,
	TPP = 1,
	FPP = 2,
	PARACHUTE = 3,
	ECharacterCameraMode_MAX = 4
};

// Object Name: Enum AClient.EUAESkillUIEvent
enum class EUAESkillUIEvent : uint8 {
	UAESkillUIEvent_None = 0,
	NotifyHandleUIPopFireBtnStatus_Deprecated = 1,
	NotifyGrapplingHookAimSightState_Deprecated = 2,
	NotifyGibraltarShieldOpened_Deprecated = 3,
	NotifyTransmitSurveyBeacon_Deprecated = 4,
	NotifyDirtyBombPickerUpUIShow_Deprecated = 5,
	NotifyDirtyBombPickerUpUIHide_Deprecated = 6,
	NotifyGrapplinghookHideAimSight_Deprecated = 7,
	EUAESkillUIEvent_MAX = 8
};

// Object Name: Enum AClient.ESkillActorType
enum class ESkillActorType : uint8 {
	None = 0,
	Bangalore_SmokeGrenade = 1,
	Bangalore_SmokeBomb = 2,
	Bangalore_UltimateGrenade = 3,
	Bangalore_UltimateBomb = 4,
	Caustic_DirtyBomb = 5,
	Caustic_GasGrenade = 6,
	Crypto_Drone = 7,
	Crypto_Drone_RocketBomb = 8,
	Gibraltar_DomeGrenade = 9,
	Gibraltar_DomeShield = 10,
	Gibraltar_GunShield = 11,
	Gibraltar_DefenseGrenade = 12,
	Gibraltar_DefenseBomb = 13,
	Lifeline_HealingDrone = 14,
	Lifeline_CarePackage = 15,
	Lifeline_ProtectiveShield = 16,
	Octane_JumpPad = 17,
	Octane_Stim = 18,
	Octane_ProjectilePad = 19,
	Octane_PadJumpEffect = 20,
	Mirage_InvisibleEffect = 21,
	Pathfinder_Zipline = 22,
	Pathfinder_GrapplingHook = 23,
	Wattson_TeslaNode = 24,
	Wattson_TeslaWire = 25,
	Wattson_InterceptionPylon = 26,
	Wraith_VoidDoor = 27,
	Wraith_InVoid = 28,
	Revenant_DeathTotem = 29,
	Revenant_SilencerSpawner = 30,
	Horizon_GravityLift = 31,
	Horizon_BlackHole = 32,
	Loba_Market = 33,
	Loba_Bracelet = 34,
	Ash_VoidDoor = 35,
	Ash_ArcBolt = 36,
	Valkyrie_SkywardDiveLauncher = 37,
	MK_LittleGoldenCudgel = 38,
	ML_BigGoldenCudgel = 39,
	Consumable_APM = 40,
	Consumable_ArcStar = 41,
	Consumable_Battery = 42,
	Consumable_BatteryBig = 43,
	Consumable_FragGrenade = 44,
	Consumable_Medkit = 45,
	Consumable_Phoenix = 46,
	Consumable_Syringe = 47,
	Consumable_ThermiteGrenade = 48,
	InvalidType = 49,
	ESkillActorType_MAX = 50
};

// Object Name: Enum AClient.EPingButtonClickType
enum class EPingButtonClickType : uint8 {
	Down = 0,
	Up = 1,
	DragEnd = 2,
	EPingButtonClickType_MAX = 3
};

// Object Name: Enum AClient.eInGameStageType
enum class eInGameStageType : uint8 {
	eReady = 0,
	eRunning = 1,
	eEnd = 2,
	eMax = 3,
	eInGameStageType_MAX = 4
};

// Object Name: Enum AClient.EMiniMapStaticType
enum class EMiniMapStaticType : uint8 {
	TreasureDoor = 0,
	SurveyBeacon = 1,
	RespawnBeacon = 2,
	CureBeacon = 3,
	Harvester3V3 = 4,
	LootBinCreeps = 5,
	TownTakeOver = 6,
	BinActor = 7,
	Harvester = 8,
	Replicator = 9,
	AirDropReplicator = 10,
	IceBinActor = 11,
	GhostBinActor = 12,
	BombSite = 13,
	ColosseumActor = 14,
	NewHarvester = 15,
	MAX = 16
};

// Object Name: Enum AClient.EMiniMapPlayerState
enum class EMiniMapPlayerState : uint8 {
	Normal = 0,
	Dying = 1,
	Respawning = 2,
	Dead = 3,
	Dispear = 4,
	EMiniMapPlayerState_MAX = 5
};

// Object Name: Enum AClient.EMiniMapPlayerType
enum class EMiniMapPlayerType : uint8 {
	Teammate = 0,
	Enermy = 1,
	EMiniMapPlayerType_MAX = 2
};

// Object Name: Enum AClient.EPlayerRespawnState
enum class EPlayerRespawnState : uint8 {
	None = 0,
	CanPick = 1,
	Picked = 2,
	Respawning = 3,
	RespawnFail = 4,
	EPlayerRespawnState_MAX = 5
};

// Object Name: Enum AClient.EPlayerBannerState
enum class EPlayerBannerState : uint8 {
	Normal = 0,
	Dropped = 1,
	BePicked = 2,
	InUsing = 3,
	Invalid = 4,
	EPlayerBannerState_MAX = 5
};

// Object Name: Enum AClient.ERespawnTeammateEndReason
enum class ERespawnTeammateEndReason : uint8 {
	Normal = 0,
	Break = 1,
	ERespawnTeammateEndReason_MAX = 2
};

// Object Name: Enum AClient.EPingButtonVisualType
enum class EPingButtonVisualType : uint8 {
	Ping = 1,
	Delete = 2,
	Ding = 3,
	CancelDing = 4,
	CantDing = 5,
	OK = 6,
	HadOK = 7,
	CantDelete = 8,
	EmojiOK = 9,
	FirstAid = 10,
	Respawn = 11,
	JumpPing = 12,
	DingEnemy = 13,
	DingGrould = 14,
	Survive = 15,
	Enemy = 16,
	Activity = 17,
	Watching = 18,
	Looting = 19,
	Defending = 20,
	Attacking = 21,
	EPingButtonVisualType_MAX = 22
};

// Object Name: Enum AClient.EChargePhase
enum class EChargePhase : uint8 {
	None = 0,
	CantCharge = 1,
	CanCharge = 2,
	ChargeBegin = 3,
	Charging = 4,
	ChargeEnd = 5,
	EChargePhase_MAX = 6
};

// Object Name: Enum AClient.EWeaponFrameEffectEvent
enum class EWeaponFrameEffectEvent : uint8 {
	None = 0,
	WFEE_Default = 1,
	WFEE_Fire = 2,
	WFEE_Fire_WithCharge = 3,
	WFEE_ADSOn = 4,
	WFEE_ADSOff = 5,
	WFEE_EquipWeapon = 6,
	WFEE_EquipChargedWeapon = 7,
	WFEE_PostEquipWeapon = 8,
	WFEE_PostEquipChargedWeapon = 9,
	WFEE_UnEquipWeapon = 10,
	WFEE_PickUp = 11,
	WFEE_Drop = 12,
	WFEE_Hit = 13,
	WFEE_BulletTrail = 14,
	WFEE_Charge = 15,
	WFEE_ChargeEnd = 16,
	WFEE_HeatDecrease = 17,
	WFEE_HeatFull = 18,
	WFEE_HeatNotFull = 19,
	WFEE_HeatChange = 20,
	WFEE_ReloadStart = 21,
	WFEE_ReloadEnd = 22,
	WFEE_AimChargeLevelChange = 23,
	WFEE_CumulativeKillChange = 24,
	WFEE_LensShoot = 25,
	WFEE_ChargeState_NotCharge = 26,
	WFEE_ChargeState_BeginCharge = 27,
	WFEE_ChargeState_Charging = 28,
	WFEE_ChargeState_HasCharged = 29,
	EWeaponFrameEffectEvent_MAX = 30
};

// Object Name: Enum AClient.EWeaponAction
enum class EWeaponAction : uint8 {
	WA_None = 0,
	WA_FirstPick = 1,
	WA_Equip = 2,
	WA_UnEquip = 3,
	WA_Raise = 4,
	WA_Lower = 5,
	WA_Shoot = 6,
	WA_AutoShoot = 7,
	WA_AutoFirstShoot = 8,
	WA_AutoLastShoot = 9,
	WA_EmptyShoot = 10,
	WA_ShellDrop = 11,
	WA_Reload = 12,
	WA_ShootTypeSwitch = 13,
	WA_ScopeOn = 14,
	WA_ScopeOff = 15,
	WA_ChargeIn = 16,
	WA_ChargeOut = 17,
	WA_ChargeFire = 18,
	WA_AimChargeUp = 19,
	WA_AimChargeDown = 20,
	WA_AimChargeLevel1 = 21,
	WA_AimChargeLevel2 = 22,
	WA_AimChargeLevel3 = 23,
	WA_LensShoot = 24,
	WA_AimChargeFullDown = 25,
	WA_AimChargeStart = 26,
	WA_AimChargeFull = 27,
	WA_AimChargeShoot = 28,
	WA_MAX = 29
};

// Object Name: Enum AClient.EClampVaultNavLinkProxyType
enum class EClampVaultNavLinkProxyType : uint8 {
	JumpOrClimb = 0,
	Zipline = 1,
	EClampVaultNavLinkProxyType_MAX = 2
};

// Object Name: Enum AClient.EPawnActionFilterType
enum class EPawnActionFilterType : uint8 {
	eTurn = 0,
	eAutoRun = 1,
	eEnableDamage = 2,
	eEnableCastTechnicalSkill = 3,
	eEnableCastUltimateSkill = 4,
	eEnableCastPassiveSkill = 5,
	eMax = 64,
	EPawnActionFilterType_MAX = 65
};

// Object Name: Enum AClient.EFollowType
enum class EFollowType : uint8 {
	FollowPlayerControllerState = 0,
	FollowParachute = 1,
	EFollowType_MAX = 2
};

// Object Name: Enum AClient.EAdvanceTrainingTLogType
enum class EAdvanceTrainingTLogType : uint8 {
	DoorTutorial = 0,
	ClimbingTutorial = 1,
	WeaponTutorial = 2,
	EAdvanceTrainingTLogType_MAX = 3
};

// Object Name: Enum AClient.EAdvancedTrainType
enum class EAdvancedTrainType : uint8 {
	CLIMBING = 1,
	DOOR = 2,
	WEAPON = 3,
	EAdvancedTrainType_MAX = 4
};

// Object Name: Enum AClient.EAIABTestValueType
enum class EAIABTestValueType : uint8 {
	None = 0,
	A = 1,
	B = 2,
	EAIABTestValueType_MAX = 3
};

// Object Name: Enum AClient.EAIABTestType
enum class EAIABTestType : uint8 {
	MirageTutorial = 1,
	NewBRAISpawnRule = 13,
	FirstBRAIBehavior = 14,
	EAIABTestType_MAX = 15
};

// Object Name: Enum AClient.EAIGetItemType
enum class EAIGetItemType : uint8 {
	None = 0,
	BinActor = 1,
	CarePackage = 2,
	TombBox = 3,
	Item = 4,
	PickObject = 5,
	EAIGetItemType_MAX = 6
};

// Object Name: Enum AClient.EShadowMirageTutorialType
enum class EShadowMirageTutorialType : uint8 {
	None = 0,
	PoisonRing = 1,
	HotBalloon = 2,
	ZipLine = 3,
	Climb = 4,
	Slide = 5,
	Aid = 6,
	WinCondition = 7,
	Max = 8
};

// Object Name: Enum AClient.EAIType
enum class EAIType : uint8 {
	JumperAI = 1,
	NormalAI = 2,
	DeliverAI = 3,
	TDMAI = 4,
	TestAI = 5,
	TeamMateAI = 6,
	SkillTestAI = 7,
	ShootTestAI = 8,
	PerformanceTestAI = 9,
	ShadowMirageTutorialAI = 10,
	BaseLineTestAI = 11,
	TDMTestAI = 12,
	ScriptBRAI = 13,
	EAIType_MAX = 14
};

// Object Name: Enum AClient.EDebugInfoType
enum class EDebugInfoType : uint8 {
	Recycle = 1,
	FakeBroad = 2,
	Active = 3,
	EDebugInfoType_MAX = 4
};

// Object Name: Enum AClient.EDynamicDmgCurveType
enum class EDynamicDmgCurveType : uint8 {
	AILevelDamage = 0,
	AILevelHit = 1,
	AI2PlayerDamage = 2,
	AI2PlayerHit = 3,
	AI2AIDamage = 4,
	AI2AIHit = 5,
	AIVelocityFixHit = 6,
	AIDistanceFixHit = 7,
	EDynamicDmgCurveType_MAX = 8
};

// Object Name: Enum AClient.EFireMode
enum class EFireMode : uint8 {
	Single = 0,
	Burst = 1,
	EFireMode_MAX = 2
};

// Object Name: Enum AClient.EAIMovePose
enum class EAIMovePose : uint8 {
	Sprint = 0,
	Walk = 1,
	Crouch = 2,
	KeepCurrentPose = 3,
	EAIMovePose_MAX = 4
};

// Object Name: Enum AClient.EAIMovetoVolume
enum class EAIMovetoVolume : uint8 {
	None = 0,
	Moveto = 1,
	BeginSearch = 2,
	EAIMovetoVolume_MAX = 3
};

// Object Name: Enum AClient.EAIJumpPhase
enum class EAIJumpPhase : uint8 {
	Init = 0,
	PrepareJump = 1,
	FreeFalling = 2,
	OpenParachute = 3,
	Landing = 4,
	EAIJumpPhase_MAX = 5
};

// Object Name: Enum AClient.EAIPhase
enum class EAIPhase : uint8 {
	Born = 0,
	InPlane = 1,
	FreeFall = 2,
	InFighting = 3,
	NearDeath = 4,
	Death = 5,
	EAIPhase_MAX = 6
};

// Object Name: Enum AClient.EAirdropWorkbenchState
enum class EAirdropWorkbenchState : uint8 {
	Landing = 0,
	Idle = 1,
	EAirdropWorkbenchState_MAX = 2
};

// Object Name: Enum AClient.EAIItemScoreType
enum class EAIItemScoreType : uint8 {
	ItemType_Weapon = 1,
	ItemType_Ammo = 2,
	ItemType_Grenades = 3,
	ItemType_Helmet = 4,
	ItemType_Armor = 5,
	ItemType_KnockdownShield = 6,
	ItemType_Backpack = 7,
	ItemType_Consumable = 8,
	ItemType_WeaponAttachment = 9,
	ItemType_Specific = 16,
	ItemType_Activity = 17,
	ItemType_MAX = 18
};

// Object Name: Enum AClient.EEQSTestActorType
enum class EEQSTestActorType : uint8 {
	AllPawn = 0,
	HumanPlayer = 1,
	Enemy = 2,
	EEQSTestActorType_MAX = 3
};

// Object Name: Enum AClient.EWeaponNameType
enum class EWeaponNameType : uint8 {
	VK_47_FLATLINE = 0,
	G7_SCOUT = 1,
	R_301_CARBINE = 2,
	HEMLOK_BURST_AR = 3,
	HAVOC_RIFLE = 4,
	R_100 = 5,
	ALTERNATOR_SMG = 6,
	PROWLER_BURST_PDW = 7,
	Volt = 8,
	M600_SPITFIRE = 9,
	L_STAR_EMG = 10,
	DEVOTION_LMG = 11,
	PEACEKEEPER = 12,
	MOZAMBIQUE_SHOTGUN = 13,
	EVA_8_AUTO = 14,
	MASTIFF_SHOTGUN = 15,
	LONGBOW_DMR = 16,
	TRIPLE_TAKE = 17,
	CHARGE_RIFLE = 18,
	SENTINEL = 19,
	KRABER50_CAL_SNIPER = 20,
	P2020 = 21,
	RE_45_AUTO = 22,
	WINGMAN = 23,
	Repeater3030 = 24,
	EWeaponNameType_MAX = 25
};

// Object Name: Enum AClient.EPawnStateOP
enum class EPawnStateOP : uint8 {
	CancelSprint = 0,
	EPawnStateOP_MAX = 1
};

// Object Name: Enum AClient.EAIChangeMoveStateReason
enum class EAIChangeMoveStateReason : uint8 {
	LowArea = 0,
	Slide = 1,
	Attack = 2,
	SwitchAnimState = 3,
	FuncMoveto = 4,
	SCC = 5,
	Max = 6
};

// Object Name: Enum AClient.EAIMaxShieldMode
enum class EAIMaxShieldMode : uint8 {
	MaxShield_CurShield = 0,
	MaxShield_MaxLevel = 1,
	MaxShield_SetValue = 2,
	MaxShield_MAX = 3
};

// Object Name: Enum AClient.EAIHearingType
enum class EAIHearingType : uint8 {
	None = 0,
	Weapon = 1,
	Footstep = 2,
	Ballistic = 3,
	EAIHearingType_MAX = 4
};

// Object Name: Enum AClient.EIndiviAnimContainerType
enum class EIndiviAnimContainerType : uint8 {
	None = 0,
	Rescue = 1,
	BeRescued = 2,
	EIndiviAnimContainerType_MAX = 3
};

// Object Name: Enum AClient.EWeaponAnimationType
enum class EWeaponAnimationType : uint8 {
	WeaponAnimationType_Reload_Charge = 0,
	WeaponAnimationType_Reload_Tactical = 1,
	WeaponAnimationType_Pickup = 2,
	WeaponAnimationType_Idle = 3,
	WeaponAnimationType_DisruptorCharging = 4,
	WeaponAnimationType_DisruptorChargedLoop = 5,
	WeaponAnimationType_DisruptorMagazine = 6,
	WeaponAnimationType_DisruptorMagazineIdle = 7,
	WeaponAnimationType_Bolt = 8,
	WeaponAnimationType_AimBolt = 9,
	WeaponAnimationType_SniperBolt = 10,
	WeaponAnimationType_Inspect = 11,
	WeaponAnimationType_KeepIdlePose = 12,
	WeaponAnimationType_EnterSprint = 13,
	WeaponAnimationType_KeepSprintPose = 14,
	WeaponAnimationType_LeaveSprintInStand = 15,
	WeaponAnimationType_LeaveSprintInSlide = 16,
	WeaponAnimationType_EnterZiplineWeapon = 17,
	WeaponAnimationType_KeepZiplineWeaponPose = 18,
	WeaponAnimationType_LeaveZiplineWeapon = 19,
	WeaponAnimationType_PutOn = 20,
	WeaponAnimationType_SprintPutOn = 21,
	WeaponAnimationType_BackIdlePose = 22,
	WeaponAnimationType_MeleeAttackBack = 23,
	WeaponAnimationType_SprintMeleeAttackBack = 24,
	WeaponAnimationType_SwitchToStand = 25,
	WeaponAnimationType_SwitchToCrouch = 26,
	WeaponAnimationType_JumpStart = 27,
	WeaponAnimationType_Falling = 28,
	WeaponAnimationType_LightLanding = 29,
	WeaponAnimationType_HardLanding = 30,
	WeaponAnimationType_Max = 31
};

// Object Name: Enum AClient.ECharAnimClimbOverType
enum class ECharAnimClimbOverType : uint8 {
	Below = 0,
	Level = 1,
	Above = 2,
	High = 3,
	ECharAnimClimbOverType_MAX = 4
};

// Object Name: Enum AClient.ECharAnimRescueType
enum class ECharAnimRescueType : uint8 {
	None = 0,
	Rescuing = 1,
	RescuingOther = 2,
	RescuingSelf = 3,
	ECharAnimRescueType_MAX = 4
};

// Object Name: Enum AClient.ECharAnimDeadType
enum class ECharAnimDeadType : uint8 {
	Normal = 0,
	DyingDead = 1,
	ECharAnimDeadType_MAX = 2
};

// Object Name: Enum AClient.ECharAnimSkillHandType
enum class ECharAnimSkillHandType : uint8 {
	None = 0,
	Left = 1,
	Right = 2,
	Both = 3,
	ECharAnimSkillHandType_MAX = 4
};

// Object Name: Enum AClient.ECharParachuteAnimType
enum class ECharParachuteAnimType : uint8 {
	ECharParachuteAnimType_XFreeFalling = 0,
	ECharParachuteAnimType_YFreeFalling = 1,
	ECharParachuteAnimType_PreOpen = 2,
	ECharParachuteAnimType_PostOpen = 3,
	ECharParachuteAnimType_Land = 4,
	ECharParachuteAnimType_Wing = 5,
	ECharParachuteAnimType_Max = 6
};

// Object Name: Enum AClient.ECharAnimEventType
enum class ECharAnimEventType : uint8 {
	ECharAnimEvent_PoseChange = 0,
	ECharAnimEvent_PickUp = 1,
	ECharAnimEvent_Fire = 2,
	ECharAnimEvent_Reload = 3,
	ECharAnimEvent_Switch = 4,
	ECharAnimEvent_Bolt = 7,
	ECharAnimEvent_Max = 8
};

// Object Name: Enum AClient.EVehicleSeatType
enum class EVehicleSeatType : uint8 {
	EVehSeatType_Driver = 0,
	EVehSeatType_Left = 1,
	EVehSeatType_Right = 2,
	EVehSeatType_Max = 3
};

// Object Name: Enum AClient.EVehicleType
enum class EVehicleType : uint8 {
	EVehType_Buggy = 0,
	EVehType_UAZ = 1,
	EVehType_Motorcycle = 2,
	EVehType_Dacia = 3,
	EVehType_PG_118 = 4,
	EVehType_Max = 5
};

// Object Name: Enum AClient.ECharacterJumpType
enum class ECharacterJumpType : uint8 {
	ECharJump_ADSForward = 0,
	ECharJump_Forward = 1,
	ECharJump_Back = 2,
	ECharJump_SprintForward = 3,
	ECharJump_Max = 4
};

// Object Name: Enum AClient.ECharacterJumpPhase
enum class ECharacterJumpPhase : uint8 {
	EJumpPhase_PreJump = 0,
	EJumpPhase_FallLoop0 = 1,
	EJumpPhase_Land0 = 2,
	EJumpPhase_Land1 = 3,
	EJumpPhase_Max = 4
};

// Object Name: Enum AClient.ECharacterCameraPoseType
enum class ECharacterCameraPoseType : uint8 {
	Stand = 0,
	Crouch = 1,
	Dying = 2,
	Sliding = 3,
	AirCrouch = 4,
	Max = 5
};

// Object Name: Enum AClient.ECharaAnimListType
enum class ECharaAnimListType : uint8 {
	ECharaAnimListType_TPP = 1,
	ECharaAnimListType_FPP = 2,
	ECharaAnimListType_Jump = 3,
	ECharaAnimListType_JumpFPP = 4,
	ECharaAnimListType_Parachute = 5,
	ECharaAnimListType_WeaponTPP = 6,
	ECharaAnimListType_WeaponFPP = 7,
	ECharaAnimListType_Max = 8
};

// Object Name: Enum AClient.EApexAnimBPType
enum class EApexAnimBPType : uint8 {
	EApexAnimBP_None = 0,
	EApexAnimBP_TPP = 1,
	EApexAnimBP_FPP = 2,
	EApexAnimBP_Max = 3
};

// Object Name: Enum AClient.ESightType
enum class ESightType : uint8 {
	SightIron = 0,
	SightX1 = 1,
	SightX2 = 2,
	SightX3 = 3,
	SightX4 = 4,
	SightX6 = 6,
	SightX8 = 8,
	SightX10 = 10,
	SightMax = 99,
	ESightType_MAX = 100
};

// Object Name: Enum AClient.EAnimSignificanceType
enum class EAnimSignificanceType : uint8 {
	Level_1 = 0,
	Level_2 = 1,
	Level_3 = 2,
	Level_MAX = 3
};

// Object Name: Enum AClient.EPawnHoldWeaponType
enum class EPawnHoldWeaponType : uint8 {
	Unarmed = 0,
	Pistol = 1,
	LongGun = 2,
	EPawnHoldWeaponType_MAX = 3
};

// Object Name: Enum AClient.ELODDeviceGrade
enum class ELODDeviceGrade : uint8 {
	VeryLow = 0,
	Low = 1,
	Middle = 2,
	High = 3,
	ELODDeviceGrade_MAX = 4
};

// Object Name: Enum AClient.EApexFootprintsType
enum class EApexFootprintsType : uint8 {
	Footprints_None = 0,
	Footprints_LeftFoot = 1,
	Footprints_RightFoot = 2,
	Footprints_LeftKnee = 3,
	Footprints_RightKnee = 4,
	Footprints_MAX = 5
};

// Object Name: Enum AClient.EAnimNotifySoundGroupType
enum class EAnimNotifySoundGroupType : uint8 {
	None = 0,
	Default = 1,
	FPP = 2,
	TPP = 3,
	EAnimNotifySoundGroupType_MAX = 4
};

// Object Name: Enum AClient.EAnimNotifySoundPlayType
enum class EAnimNotifySoundPlayType : uint8 {
	EANSP_FPP = 0,
	EANSP_TPP = 1,
	EANSP_MAX = 2
};

// Object Name: Enum AClient.ESoundModuleEffectType
enum class ESoundModuleEffectType : uint8 {
	None = 0,
	GunFire = 1,
	UnGunFire = 2,
	ESoundModuleEffectType_MAX = 3
};

// Object Name: Enum AClient.EAudioAmbientZoneAction
enum class EAudioAmbientZoneAction : uint8 {
	In = 0,
	Out = 1,
	EAudioAmbientZoneAction_MAX = 2
};

// Object Name: Enum AClient.EHouseSoundType
enum class EHouseSoundType : uint8 {
	None = 0,
	Small_Dull = 1,
	Small_Bright = 2,
	Med_Dull = 3,
	Med_Bright = 4,
	Large_Dull = 5,
	Large_Bright = 6,
	EHouseSoundType_MAX = 7
};

// Object Name: Enum AClient.EStateSound
enum class EStateSound : uint8 {
	None = 0,
	PlaySlide = 1,
	StopSlide = 2,
	RideZipline = 3,
	DownZipline = 4,
	LoopZipline = 5,
	RushZipline = 6,
	PlayStand = 7,
	PlayCrouch = 8,
	LandingLight = 9,
	LandingHard = 10,
	PlayClimb = 11,
	PlayFallingDown = 12,
	StopFallingDown = 13,
	Jump = 14,
	ClimbBigJump = 15,
	Hanging = 16,
	EStateSound_MAX = 17
};

// Object Name: Enum AClient.EValidityTimeScaleChangeType
enum class EValidityTimeScaleChangeType : uint8 {
	None = 0,
	ApplyNum = 1,
	EValidityTimeScaleChangeType_MAX = 2
};

// Object Name: Enum AClient.EViewTargetAddBuffRole
enum class EViewTargetAddBuffRole : uint8 {
	Disabled = 0,
	ViewTarget_Self = 1,
	ViewTarget_Enemy = 2,
	ViewTarget_Friend = 3,
	EViewTargetAddBuffRole_MAX = 4
};

// Object Name: Enum AClient.ESimulateAddBuffRole
enum class ESimulateAddBuffRole : uint8 {
	AddBuffRole_All = 0,
	AddBuffRole_Self = 1,
	AddBuffRole_Firend = 2,
	AddBuffRole_Enermy = 3,
	AddBuffRole_MAX = 4
};

// Object Name: Enum AClient.EActionActiveRole
enum class EActionActiveRole : uint8 {
	ACTIVE_ALL = 0,
	ACTIVE_SELF = 1,
	ACTIVE_TEAM = 2,
	ACTIVE_ENEMY = 3,
	ACTIVE_MAX = 4
};

// Object Name: Enum AClient.EFormulaType
enum class EFormulaType : uint8 {
	FORMULA_CURVE_DISTANCE_BETWEEN_OWNER_AND_TARGET = 0,
	FORMULA_CURVE_TIME = 1,
	FORMULA_TIME_DELTA = 2,
	FORMULA_MAX = 3
};

// Object Name: Enum AClient.EAttrType
enum class EAttrType : uint8 {
	ATTR_STEPBYSTEP = 0,
	ATTR_INSTANT = 1,
	ATTR_FORMULA = 2,
	ATTR_MAX = 3
};

// Object Name: Enum AClient.EModifyCDType
enum class EModifyCDType : uint8 {
	Reduce_MaxEnergy = 0,
	Reduce_Threshold = 1,
	ReduceTo_MaxEnergy = 2,
	ReduceTo_Threshold = 3,
	Reset = 4,
	EModifyCDType_MAX = 5
};

// Object Name: Enum AClient.EPlayUIEffectParamsType
enum class EPlayUIEffectParamsType : uint8 {
	EPT_ScalarParameter = 0,
	EPT_VectorParameter = 1,
	EPT_MAX = 2
};

// Object Name: Enum AClient.ERecoveryValuePerSecondChangeType
enum class ERecoveryValuePerSecondChangeType : uint8 {
	None = 0,
	ByDefault = 1,
	ByInitDistanceSquared = 2,
	ByDistanceSquared = 3,
	ERecoveryValuePerSecondChangeType_MAX = 4
};

// Object Name: Enum AClient.EAPBuffRegistEvent
enum class EAPBuffRegistEvent : uint8 {
	None = 0,
	TakeDamage = 1,
	EAPBuffRegistEvent_MAX = 2
};

// Object Name: Enum AClient.EReloadWeapon
enum class EReloadWeapon : uint8 {
	AllWeapon = 0,
	LastWeapon = 1,
	EReloadWeapon_MAX = 2
};

// Object Name: Enum AClient.ELegendGenius
enum class ELegendGenius : uint8 {
	None = 0,
	Scout = 1,
	Default = 0,
	ELegendGenius_MAX = 2
};

// Object Name: Enum AClient.EViewInputType
enum class EViewInputType : uint8 {
	NONE = 0,
	InputFromScreen = 1,
	InputFromGyroscope = 2,
	InputFromMotionController = 3,
	InputFromSimulator = 4,
	EViewInputType_MAX = 5
};

// Object Name: Enum AClient.EViewControlType
enum class EViewControlType : uint8 {
	NormalSpeed = 0,
	SpeedupByDistance = 1,
	SpeedupBySpeed = 2,
	EViewControlType_MAX = 3
};

// Object Name: Enum AClient.EPhoneOrientationControlType
enum class EPhoneOrientationControlType : uint8 {
	NONE = 0,
	OnlyAiming = 1,
	Always = 2,
	EPhoneOrientationControlType_MAX = 3
};

// Object Name: Enum AClient.EButtonPassType
enum class EButtonPassType : uint8 {
	None = 0,
	Normal = 1,
	Forbidden = 2,
	EButtonPassType_MAX = 3
};

// Object Name: Enum AClient.EIconType
enum class EIconType : uint8 {
	IconNone = 0,
	IconGunFire = 1,
	IconMove = 2,
	IconConsume = 3,
	IconSmallMove = 4,
	IconDJUltimateItem = 5,
	IconAndroid = 6,
	MAX_ = 7,
	EIconType_MAX = 8
};

// Object Name: Enum AClient.EApexCameraLerpType
enum class EApexCameraLerpType : uint8 {
	None = 0,
	CameraRelativeLocation = 1,
	CameraRelativeRotation = 2,
	SpringArmRelativeLocation = 3,
	SpringArmLength = 4,
	Fov = 5,
	SeparateFov = 6,
	_Max = 7,
	EApexCameraLerpType_MAX = 8
};

// Object Name: Enum AClient.EApexCameraModifyType
enum class EApexCameraModifyType : uint8 {
	None = 0,
	Add = 1,
	Multiply = 2,
	MultiplicativeAdd = 3,
	Override = 4,
	EApexCameraModifyType_MAX = 5
};

// Object Name: Enum AClient.ESTECharacterType
enum class ESTECharacterType : uint8 {
	Player = 1,
	Zombie = 2,
	ESTECharacterType_MAX = 3
};

// Object Name: Enum AClient.EApexCharacterShieldLevel
enum class EApexCharacterShieldLevel : uint8 {
	NONE = 0,
	WhiteArmor = 1,
	BlueArmor = 2,
	PurpleArmor = 3,
	GoldArmor = 4,
	RedArmor = 5,
	GunShield = 6,
	EApexCharacterShieldLevel_MAX = 7
};

// Object Name: Enum AClient.ESTEScopeType
enum class ESTEScopeType : uint8 {
	Normal = 0,
	ProneMove = 1,
	InFold = 2,
	AutoCollapsed = 3,
	ESTEScopeType_MAX = 4
};

// Object Name: Enum AClient.ESTEScopeState
enum class ESTEScopeState : uint8 {
	ScopeOut = 0,
	ScopeIn = 1,
	ESTEScopeState_MAX = 2
};

// Object Name: Enum AClient.ESTEPoseState
enum class ESTEPoseState : uint8 {
	Stand = 0,
	Crouch = 1,
	Prone = 2,
	Sprint = 3,
	CrouchSprint = 4,
	Crawl = 5,
	Swim = 6,
	SwimSprint = 7,
	Dying = 8,
	ESTEPoseState_MAX = 9
};

// Object Name: Enum AClient.EApexCharacterComponentKey
enum class EApexCharacterComponentKey : uint8 {
	CharacterInputComponent = 1,
	AnimationComponent = 2,
	AnimationListComponent = 3,
	WeaponAnimationListComponent = 4,
	StateManagerComponent = 5,
	PropertyComponent = 6,
	ApexCharacterMovenetComponent = 7,
	EApexCharacterComponentKey_MAX = 8
};

// Object Name: Enum AClient.EChildNodeTag
enum class EChildNodeTag : uint8 {
	EChildNodeTag_None = 0,
	EChildNodeTag_WarningNode = 1,
	EChildNodeTag_ScreenNode = 2,
	EChildNodeTag_MAX = 3
};

// Object Name: Enum AClient.ECharacterSensitivityType
enum class ECharacterSensitivityType : uint8 {
	NONE = 0,
	Ability = 1,
	Throw = 2,
	GrappleHookAim = 3,
	GrappleHookMove = 4,
	ECharacterSensitivityType_MAX = 5
};

// Object Name: Enum AClient.EFPPMeshFreeSource
enum class EFPPMeshFreeSource : uint8 {
	NONE = 0,
	SmallEye = 1,
	Hanging = 2,
	Climb = 3,
	Skill = 4,
	EFPPMeshFreeSource_MAX = 5
};

// Object Name: Enum AClient.EFreeCameraSource
enum class EFreeCameraSource : uint8 {
	NONE = 0,
	SmallEye = 1,
	Movement = 2,
	Skill = 3,
	Rescue = 4,
	BombHandle = 5,
	PhantomBraid = 6,
	Emoji = 7,
	Parachute = 8,
	EFreeCameraSource_MAX = 9
};

// Object Name: Enum AClient.ECharacterMoveDir
enum class ECharacterMoveDir : uint8 {
	NONE = 0,
	Forward = 1,
	Right = 2,
	Back = 3,
	ECharacterMoveDir_MAX = 4
};

// Object Name: Enum AClient.EAnimationParamMovementMode
enum class EAnimationParamMovementMode : uint8 {
	EAnimationParamMovementMode_None = 0,
	EAnimationParamMovementMode_Walking = 1,
	EAnimationParamMovementMode_NavWalking = 2,
	EAnimationParamMovementMode_Falling = 3,
	EAnimationParamMovementMode_Swimming = 4,
	EAnimationParamMovementMode_Flying = 5,
	EAnimationParamMovementMode_Climbing = 6,
	EAnimationParamMovementMode_ClimbingOver = 7,
	EAnimationParamMovementMode_Hanging = 8,
	EAnimationParamMovementMode_Sliding = 9,
	EAnimationParamMovementMode_Custom = 10,
	EAnimationParamMovementMode_MAX = 11
};

// Object Name: Enum AClient.ECustomMoveModeType
enum class ECustomMoveModeType : uint8 {
	ECustomMoveMode_None = 0,
	ECustomMoveMode_Hang = 1,
	ECustomMoveMode_ClimbOver = 2,
	ECustomMoveMode_Slide = 3,
	ECustomMoveMode_ApexFlying = 4,
	ECustomMoveMode_Max = 5
};

// Object Name: Enum AClient.EClimbOverFrom
enum class EClimbOverFrom : uint8 {
	EClimbOverFrom_Falling = 0,
	EClimbOverFrom_Climbing = 1,
	EClimbOverFrom_Hanging = 2,
	EClimbOverFrom_Max = 3
};

// Object Name: Enum AClient.ESlidingFormula
enum class ESlidingFormula : uint8 {
	Gravity = 1,
	ExpDecay = 2,
	ConstDecay = 3,
	WantToStopDecay = 4,
	PlayerControlAcceleration = 5,
	PlayerControlAccelerationAffectDir = 6,
	ESlidingFormula_MAX = 7
};

// Object Name: Enum AClient.EViewControlReason
enum class EViewControlReason : uint8 {
	PlayerInput = 1,
	FireRecoil = 2,
	FireSpring = 3,
	AutoAim = 4,
	AutoControl = 5,
	GrappleHook = 6,
	EViewControlReason_MAX = 7
};

// Object Name: Enum AClient.EMotionMovementWarpingType
enum class EMotionMovementWarpingType : uint8 {
	EMotionMovementWarpingType_None = 0,
	EMotionMovementWarpingType_EndWarping = 1,
	EMotionMovementWarpingType_PathWarping = 2,
	EMotionMovementWarpingType_MAX = 3
};

// Object Name: Enum AClient.EMotionMovementLocationProcessingType
enum class EMotionMovementLocationProcessingType : uint8 {
	EMotionMovementLocationProcessingType_UseMotionLocation = 0,
	EMotionMovementLocationProcessingType_AddtiveLocation = 1,
	EMotionMovementLocationProcessingType_MAX = 2
};

// Object Name: Enum AClient.EMotionMovementSimulateMode
enum class EMotionMovementSimulateMode : uint8 {
	EMotionMovementSimulateMode_MotionSimulate = 0,
	EMotionMovementSimulateMode_DRSimulate = 1,
	EMotionMovementSimulateMode_MAX = 2
};

// Object Name: Enum AClient.EMotionMovementWarpingNetMode
enum class EMotionMovementWarpingNetMode : uint8 {
	EMotionMovementWarpingNetMode_MovementMode = 0,
	EMotionMovementWarpingNetMode_LocalMotionMode = 1,
	EMotionMovementWarpingNetMode_MAX = 2
};

// Object Name: Enum AClient.EMonsterStateTranfromType
enum class EMonsterStateTranfromType : uint8 {
	Error = 0,
	Pose = 1,
	Pendant = 2,
	Behavior = 3,
	EMonsterStateTranfromType_MAX = 4
};

// Object Name: Enum AClient.EProwlerAnimState
enum class EProwlerAnimState : uint8 {
	E_Relaxing = 0,
	E_Dead = 1,
	E_Peace = 2,
	E_Alartness = 3,
	E_Move = 4,
	E_Jump = 5,
	E_Climb = 6,
	E_Idle = 7,
	E_MAX = 8
};

// Object Name: Enum AClient.EApexPostProcessType
enum class EApexPostProcessType : uint8 {
	None = 0,
	GreyScreen = 1,
	Arc = 2,
	Max = 3
};

// Object Name: Enum AClient.EJoystickUIState
enum class EJoystickUIState : uint8 {
	Close = 1,
	Open = 2,
	Auto = 3,
	Lock = 4,
	EJoystickUIState_MAX = 5
};

// Object Name: Enum AClient.EApexControllerComponentKey
enum class EApexControllerComponentKey : uint8 {
	DefaultComponent = 1,
	StateMachineComp = 2,
	BackpackComp = 3,
	LoadoutComp = 4,
	ParachuteComp = 5,
	PlaneComp = 6,
	MagmaRiseComp = 7,
	EApexControllerComponentKey_MAX = 8
};

// Object Name: Enum AClient.EDisplayWeaponStateMode
enum class EDisplayWeaponStateMode : uint8 {
	None = 0,
	Idle = 1,
	Fire = 2,
	Reload = 3,
	MagazineMontage = 4,
	EDisplayWeaponStateMode_MAX = 5
};

// Object Name: Enum AClient.EDynamicRespawnBeaconState
enum class EDynamicRespawnBeaconState : uint8 {
	Landing = 0,
	Idle = 1,
	Dispose = 2,
	EDynamicRespawnBeaconState_MAX = 3
};

// Object Name: Enum AClient.EEmojiFlowAddendaOpType
enum class EEmojiFlowAddendaOpType : uint8 {
	None = 0,
	EmojiUse = 1,
	EmojiLike = 2,
	EmojiLiked = 3,
	EEmojiFlowAddendaOpType_MAX = 4
};

// Object Name: Enum AClient.EEmojiFlowAddendaType
enum class EEmojiFlowAddendaType : uint8 {
	None = 0,
	EmojiAnimation = 13,
	Emoji3DPaint = 14,
	Emoji2DSprite = 15,
	EEmojiFlowAddendaType_MAX = 16
};

// Object Name: Enum AClient.EEmojiType
enum class EEmojiType : uint8 {
	NONE = 0,
	Emoji2D = 1,
	EmojiDecal = 2,
	Emoji3D = 3,
	EmojiAnimation = 4,
	DisplayAnimation = 5,
	MAX = 16
};

// Object Name: Enum AClient.ECreditTactics
enum class ECreditTactics : uint8 {
	None = 0,
	AddCredit = 1,
	PickUpDistance = 2,
	PickUpCount = 3,
	WeapnBullet = 4,
	WeaponAttachments = 5,
	Safe_BulletValidNum = 10,
	Safe_BulletCostNum = 11,
	Safe_ShootSpeed = 12,
	Safe_ShootStartPos = 13,
	Safe_ShootEndPos = 14,
	Safe_ShootHitBody = 15,
	Safe_ShootObstacle = 16,
	Safe_ShootForward = 17,
	Safe_PlayerForward = 18,
	Safe_ShootDistance = 19,
	Safe_ShootHitScale = 20,
	Safe_ShootImPactPoint = 21,
	Safe_ShootViewMove = 22,
	Safe_ShootPlayerLuffy = 23,
	Safe_ShootDataRedo = 24,
	Safe_ShootChargeLens = 25,
	Move_SimpleMoveCheat = 100,
	Move_ZMoveDistanceCheat = 101,
	Move_FallingCheat = 102,
	Move_TimeSpeedCheat = 103,
	Move_PowerCheat = 104,
	Move_UseRecoveryCheat = 105,
	Shoot_CallDelete = 106,
	Shoot_Same = 107,
	Shoot_Multi = 108,
	Shoot_UploadNumNoSame = 109,
	View_FOV = 200,
	View_TeamID = 201,
	LogReport = 202,
	Max = 203
};

// Object Name: Enum AClient.ECreditScoreType
enum class ECreditScoreType : uint8 {
	None = 0,
	Movement = 1,
	Weapon = 2,
	Pickup = 3,
	Max = 4
};

// Object Name: Enum AClient.EGameFlowProcessor
enum class EGameFlowProcessor : uint8 {
	eNone = 0,
	eAppInit = 1,
	eGameFlowWorld = 2,
	eInGame = 3,
	eLobby = 4,
	eLaunch = 5,
	eMax = 6,
	EGameFlowProcessor_MAX = 7
};

// Object Name: Enum AClient.EGameflowProcessorCreateType
enum class EGameflowProcessorCreateType : uint8 {
	eOnlyDS = 0,
	eOnlyClient = 1,
	eAll = 2,
	EGameflowProcessorCreateType_MAX = 3
};

// Object Name: Enum AClient.EGameFlowMangerPhase
enum class EGameFlowMangerPhase : uint8 {
	eLoadTable = 0,
	eInitData = 1,
	eMax = 2,
	EGameFlowMangerPhase_MAX = 3
};

// Object Name: Enum AClient.EGameFlowPhase
enum class EGameFlowPhase : uint8 {
	eNone = 0,
	eAppInit = 1,
	eGameFlowWorld = 2,
	eLaunch = 3,
	eUpdate = 4,
	eLogin = 5,
	eLobby = 6,
	eInGame = 7,
	eMax = 8,
	EGameFlowPhase_MAX = 9
};

// Object Name: Enum AClient.EGameHUDItemType
enum class EGameHUDItemType : uint8 {
	None = 0,
	Zone = 1,
	EGameHUDItemType_MAX = 2
};

// Object Name: Enum AClient.EAPGameDeviceQualityLevel
enum class EAPGameDeviceQualityLevel : uint8 {
	QUALITY_LEVEL_LOW = 0,
	QUALITY_LEVEL_MID = 1,
	QUALITY_LEVEL_HIGH = 2,
	QUALITY_LEVEL_MAX = 3
};

// Object Name: Enum AClient.EApexHeatShieldState
enum class EApexHeatShieldState : uint8 {
	Init = 0,
	Startup = 1,
	AtWork = 2,
	Destroy = 3,
	EApexHeatShieldState_MAX = 4
};

// Object Name: Enum AClient.EScreenSlideType
enum class EScreenSlideType : uint8 {
	LeftSlide = 0,
	RightSlide = 1,
	None = 2,
	EScreenSlideType_MAX = 3
};

// Object Name: Enum AClient.EApexRegionEnum
enum class EApexRegionEnum : uint8 {
	ROW = 0,
	PDCC = 1,
	All = 2,
	Unknown = 3,
	EApexRegionEnum_MAX = 4
};

// Object Name: Enum AClient.EMirageDecoyDieReasonType
enum class EMirageDecoyDieReasonType : uint8 {
	EMirageDecoyDieType_None = 0,
	EMirageDecoyDieType_Crushed = 1,
	EMirageDecoyDieType_Killed = 2,
	EMirageDecoyDieType_OverTime = 3,
	EMirageDecoyDieType_MAX = 4
};

// Object Name: Enum AClient.EMirageDecoyEndType
enum class EMirageDecoyEndType : uint8 {
	Default = 0,
	Kill = 1,
	Overtime = 2,
	EMirageDecoyEndType_MAX = 3
};

// Object Name: Enum AClient.EMirage_DecoySourceType
enum class EMirage_DecoySourceType : uint8 {
	DecoySourceType_None = 0,
	DecoySourceType_Tactics = 1,
	DecoySourceType_Ultimate = 2,
	DecoySourceType_Passive = 3,
	DecoySourceType_Perk = 4,
	AirParachuteTactics = 5,
	EMirage_MAX = 6
};

// Object Name: Enum AClient.EMirage_InvisibleType
enum class EMirage_InvisibleType : uint8 {
	InvisibleType_None = 0,
	InvisibleType_Passive = 1,
	InvisibleType_Rescue = 2,
	InvisibleType_BeaconRespawn = 3,
	InvisibleType_Ultimate = 4,
	InvisibleType_Perk = 5,
	InvisibleType_MAX = 6
};

// Object Name: Enum AClient.EApexNavLinkEndType
enum class EApexNavLinkEndType : uint8 {
	Default = 0,
	AllowEndInvalid = 1,
	EApexNavLinkEndType_MAX = 2
};

// Object Name: Enum AClient.EApexNavLinkProxyType
enum class EApexNavLinkProxyType : uint8 {
	Walk = 0,
	Jump = 1,
	Climb = 2,
	Zipline = 3,
	Door = 4,
	Anchor = 5,
	Portal = 6,
	Banned = 7,
	HotBalloonZipline = 8,
	Fly = 9,
	Max = 10,
	Invalid = 255
};

// Object Name: Enum AClient.EApexNavMeshDynamicObstacleCalculateType
enum class EApexNavMeshDynamicObstacleCalculateType : uint8 {
	Stop = 0,
	TriggerMove = 1,
	EApexNavMeshDynamicObstacleCalculateType_MAX = 2
};

// Object Name: Enum AClient.EApexNavMeshDynamicObstacleMoveStatus
enum class EApexNavMeshDynamicObstacleMoveStatus : uint8 {
	Stop = 0,
	Move = 1,
	EApexNavMeshDynamicObstacleMoveStatus_MAX = 2
};

// Object Name: Enum AClient.EApexNavMeshModifierShape
enum class EApexNavMeshModifierShape : uint8 {
	Box = 0,
	Cylinder = 1,
	EApexNavMeshModifierShape_MAX = 2
};

// Object Name: Enum AClient.ELostConnectionToDSReason
enum class ELostConnectionToDSReason : uint8 {
	LostConnectionToDSReason_None = 0,
	LostConnectionToDSReason_TravelFailure_Default = 1,
	LostConnectionToDSReason_LocalConnectionLost = 2,
	LostConnectionToDSReason_LocalDetectedTimeout = 3,
	LostConnectionToDSReason_NMTFailure_Default = 4,
	LostConnectionToDSReason_MAX = 5
};

// Object Name: Enum AClient.EApexRepathReason
enum class EApexRepathReason : uint8 {
	Block = 0,
	RecalculateNavMesh = 1,
	FollowActor = 2,
	GoalChange = 3,
	ShiftPath = 4,
	EApexRepathReason_MAX = 5
};

// Object Name: Enum AClient.EApexRaycastResult
enum class EApexRaycastResult : uint8 {
	Raycast_Success = 0,
	Raycast_SysErr = 1,
	Raycast_StartLoc_Invalid = 2,
	Raycast_MAX = 3
};

// Object Name: Enum AClient.EPlayerStartType
enum class EPlayerStartType : uint8 {
	Common = 0,
	Start = 1,
	Respawn = 2,
	Init = 3,
	EPlayerStartType_MAX = 4
};

// Object Name: Enum AClient.EClassRepNodeMapping
enum class EClassRepNodeMapping : uint8 {
	NotRouted = 0,
	RelevantAllConnections = 1,
	RelevantOwnerConnection = 2,
	Dependent = 3,
	Spatialize_Static = 4,
	Spatialize_Dynamic = 5,
	Spatialize_Dormancy = 6,
	PickUp = 7,
	EClassRepNodeMapping_MAX = 8
};

// Object Name: Enum AClient.EPerkTriggerTarget
enum class EPerkTriggerTarget : uint8 {
	None = 0,
	Myself = 1,
	Teammate = 2,
	Others = 3,
	EPerkTriggerTarget_MAX = 4
};

// Object Name: Enum AClient.ESkillPickerSortPolicy
enum class ESkillPickerSortPolicy : uint8 {
	None = 0,
	SortByDistance = 1,
	ESkillPickerSortPolicy_MAX = 2
};

// Object Name: Enum AClient.ESkillShapeType
enum class ESkillShapeType : uint8 {
	None = 0,
	Line = 1,
	Box = 2,
	Sphere = 3,
	Capsule = 4,
	Cylinder = 5,
	SkillPicker = 6,
	ESkillShapeType_MAX = 7
};

// Object Name: Enum AClient.EPickerDescriptionType
enum class EPickerDescriptionType : uint8 {
	None = 0,
	EPickerDescriptionType_MAX = 1
};

// Object Name: Enum AClient.ESkillConfigKey
enum class ESkillConfigKey : uint8 {
	CausticDirtyBombMaxNum = 0,
	CausticDirtyBombClearOnTDMRespawn = 1,
	CausticGrenadeClearOnTDMRespawn = 2,
	CausticDirtyBombClearOnTDMLegendChange = 3,
	CausticGrenadeClearOnTDMLegendChange = 4,
	ESkillConfigKey_MAX = 5
};

// Object Name: Enum AClient.EImpactType
enum class EImpactType : uint8 {
	SelfFppView = 0,
	SelfTppView = 1,
	EnemyFppView = 2,
	EnemyTppView = 3,
	AllyFppView = 4,
	AllyTppView = 5,
	EnemyAndCauserEnemyFppView = 6,
	EnemyAndCauserEnemyTppView = 7,
	EnemyAndCauserAllyFppView = 8,
	EnemyAndCauserAllyTppView = 9,
	AllyAndCauserEnemyFppView = 10,
	AllyAndCauserEnemyTppView = 11,
	AllyAndCauserAllyFppView = 12,
	AllyAndCauserAllyTppView = 13,
	AllyAndCauserSelfFppView = 14,
	AllyAndCauserSelfTppView = 15,
	EnemyAndCauserSelfFppView = 16,
	EnemyAndCauserSelfTppView = 17,
	Default = 63,
	EImpactType_MAX = 64
};

// Object Name: Enum AClient.ETrainStartUpType
enum class ETrainStartUpType : uint8 {
	Still = 0,
	StartUpWithSpecificRail = 1,
	StartUpWithRandomRail = 2,
	ETrainStartUpType_MAX = 3
};

// Object Name: Enum AClient.ETreasureDoorState
enum class ETreasureDoorState : uint8 {
	Break = 0,
	Opening = 1,
	Active = 2,
	ETreasureDoorState_MAX = 3
};

// Object Name: Enum AClient.ELODTransmitSource
enum class ELODTransmitSource : uint8 {
	NONE = 0,
	SLIDE = 1,
	BloodHoundHunting = 2,
	MaxIndex = 3,
	ELODTransmitSource_MAX = 4
};

// Object Name: Enum AClient.EAsyncLoadPriority
enum class EAsyncLoadPriority : uint8 {
	EDefault = 0,
	EAboveLevelStream = 1,
	EOtherAvatar = 99,
	ELeadingAvatar = 100,
	EUImage = 101,
	EAsyncLoadPriority_MAX = 102
};

// Object Name: Enum AClient.EAdaptationModuleType
enum class EAdaptationModuleType : uint8 {
	Common = 0,
	Particle = 1,
	UMGAni = 2,
	CommonBtnUMGAni = 3,
	EAdaptationModuleType_MAX = 4
};

// Object Name: Enum AClient.EApgameSignatureDynamicSoundType
enum class EApgameSignatureDynamicSoundType : uint8 {
	Attack = 0,
	Inspect = 1,
	EApgameSignatureDynamicSoundType_MAX = 2
};

// Object Name: Enum AClient.EApgameSignatureDynamicPSCType
enum class EApgameSignatureDynamicPSCType : uint8 {
	AttackTail = 0,
	Attack = 1,
	EApgameSignatureDynamicPSCType_MAX = 2
};

// Object Name: Enum AClient.EApgameSkinMemMgrSkinType
enum class EApgameSkinMemMgrSkinType : uint8 {
	Unknown = 0,
	Hero = 1,
	Weapon = 2,
	Pickup = 3,
	WeaponAttachment = 4,
	SignatureWeapon = 5,
	MaxType = 6,
	EApgameSkinMemMgrSkinType_MAX = 7
};

// Object Name: Enum AClient.EPerkInitPlatform
enum class EPerkInitPlatform : uint8 {
	Authority = 0,
	Autonomous = 1,
	Simulated = 2,
	EPerkInitPlatform_MAX = 3
};

// Object Name: Enum AClient.EPerkRecoverType
enum class EPerkRecoverType : uint8 {
	NONE = 0,
	RecoverHealth = 1,
	RecoverShield = 2,
	RecoverHealthThenShield = 3,
	RecoverShieldThenHealth = 4,
	RecoverAllShield = 5,
	EPerkRecoverType_MAX = 6
};

// Object Name: Enum AClient.ERecoverSkillBoolOperator
enum class ERecoverSkillBoolOperator : uint8 {
	None = 0,
	Or = 1,
	And = 2,
	ERecoverSkillBoolOperator_MAX = 3
};

// Object Name: Enum AClient.EInGausticGasType
enum class EInGausticGasType : uint8 {
	Enemy = 0,
	Teammate = 1,
	All = 2,
	EInGausticGasType_MAX = 3
};

// Object Name: Enum AClient.Trigger_ParaChuteType
enum class Trigger_ParaChuteType : uint8 {
	NotParaChute = 0,
	ParaChuteTower = 1,
	Geyser = 2,
	Plane = 3,
	VoidDoor = 4,
	Trigger_MAX = 5
};

// Object Name: Enum AClient.Trigger_RadiationCircleProgress
enum class Trigger_RadiationCircleProgress : uint8 {
	Equal = 0,
	Greater = 1,
	Less = 2,
	GreaterEqual = 3,
	LessEqual = 4,
	Trigger_MAX = 5
};

// Object Name: Enum AClient.Trigger_RadiationCircleType
enum class Trigger_RadiationCircleType : uint8 {
	InRadiationCircle = 0,
	OutRadiationCircle = 1,
	Trigger_MAX = 2
};

// Object Name: Enum AClient.ETeamColorIndex
enum class ETeamColorIndex : uint8 {
	None = 0,
	Green = 1,
	Orange = 2,
	Blue = 3,
	TDMGreen = 4,
	TDMBlue = 5,
	Max = 6
};

// Object Name: Enum AClient.EMLastTimeCharDataSaveReason
enum class EMLastTimeCharDataSaveReason : uint8 {
	None = 0,
	Respawn = 1,
	RoundRestart = 2,
	ChangeLegend = 3,
	MAX = 64
};

// Object Name: Enum AClient.EMColorInTeam
enum class EMColorInTeam : uint8 {
	None = 0,
	White = 0,
	Green = 1,
	Orange = 2,
	Blue = 3,
	Max = 4
};

// Object Name: Enum AClient.ELastKillerFrom
enum class ELastKillerFrom : uint8 {
	TombBox = 0,
	Statistics = 1,
	ELastKillerFrom_MAX = 2
};

// Object Name: Enum AClient.EModifyAttributeNetExecutionPolicy
enum class EModifyAttributeNetExecutionPolicy : uint8 {
	LocalPredicted = 0,
	ServerInitiated = 1,
	EModifyAttributeNetExecutionPolicy_MAX = 2
};

// Object Name: Enum AClient.EVariableCompareType
enum class EVariableCompareType : uint8 {
	None = 0,
	Bigger = 1,
	Smaller = 2,
	Equal = 3,
	BiggerOrEqual = 4,
	SmallerOrEqual = 5,
	EVariableCompareType_MAX = 6
};

// Object Name: Enum AClient.EAttributeBasedFloatCalculationType
enum class EAttributeBasedFloatCalculationType : uint8 {
	AttributeMagnitude = 0,
	AttributeBaseValue = 1,
	AttributeBonusMagnitude = 2,
	AttributeMagnitudeEvaluatedUpToChannel = 3,
	EAttributeBasedFloatCalculationType_MAX = 4
};

// Object Name: Enum AClient.EAttributeModifyMagnitudeCalculation
enum class EAttributeModifyMagnitudeCalculation : uint8 {
	ScalableFloat = 0,
	AttributeBased = 1,
	CustomCalculationClass = 2,
	SetByCaller = 3,
	EAttributeModifyMagnitudeCalculation_MAX = 4
};

// Object Name: Enum AClient.EAttrModifyReplicationMode
enum class EAttrModifyReplicationMode : uint8 {
	Minimal = 0,
	Mixed = 1,
	Full = 2,
	EAttrModifyReplicationMode_MAX = 3
};

// Object Name: Enum AClient.EModifyByPawnState
enum class EModifyByPawnState : uint8 {
	Default = 0,
	PoseState = 1,
	MoveDir = 2,
	ADS = 3,
	Sprint = 4,
	Combination = 5,
	EModifyByPawnState_MAX = 6
};

// Object Name: Enum AClient.EChangeType
enum class EChangeType : uint8 {
	None = 0,
	Time = 1,
	DistanceFromSourceToTarget = 2,
	InitDistanceFromSourceToTarget = 3,
	EChangeType_MAX = 4
};

// Object Name: Enum AClient.EDurationType
enum class EDurationType : uint8 {
	Infinite = 0,
	HasDuration = 1,
	EDurationType_MAX = 2
};

// Object Name: Enum AClient.EAttributeSumOperator
enum class EAttributeSumOperator : uint8 {
	Additive = 0,
	Multiplicitive = 1,
	Minimum = 2,
	Maxnimum = 3,
	Dynamic = 4,
	Count = 5,
	EAttributeSumOperator_MAX = 6
};

// Object Name: Enum AClient.EAttributeModifyOperator
enum class EAttributeModifyOperator : uint8 {
	Additive = 0,
	Multiplicitive = 1,
	Division = 2,
	Override = 3,
	Count = 4,
	EAttributeModifyOperator_MAX = 5
};

// Object Name: Enum AClient.EModifyEvaluationChannel
enum class EModifyEvaluationChannel : uint8 {
	Channel0 = 0,
	Channel1 = 1,
	Channel2 = 2,
	Channel3 = 3,
	Channel4 = 4,
	Channel5 = 5,
	Channel6 = 6,
	Channel7 = 7,
	Channel8 = 8,
	Channel9 = 9,
	Channel_MAX = 10,
	EModifyEvaluationChannel_MAX = 11
};

// Object Name: Enum AClient.EMAudioAttachMode
enum class EMAudioAttachMode : uint8 {
	Owner = 0,
	PlayerCameraManager = 1,
	Character = 2,
	EMAudioAttachMode_MAX = 3
};

// Object Name: Enum AClient.EAudioRegionEventType
enum class EAudioRegionEventType : uint8 {
	Enter = 0,
	Exit = 1,
	EAudioRegionEventType_MAX = 2
};

// Object Name: Enum AClient.AudioRegionProcessorType
enum class AudioRegionProcessorType : uint8 {
	AudioRegion = 1,
	AudioRegionEnemy = 2,
	RiverAmbient = 3,
	MagmaAmbient = 4,
	RemoteWeapon = 5,
	AudioRegionProcessorType_MAX = 6
};

// Object Name: Enum AClient.EAutoTraceFileType
enum class EAutoTraceFileType : uint8 {
	AutoTraceType_None = 0,
	AutoTraceType_Memreport = 1,
	AutoTraceType_MemoryCallStack = 2,
	AutoTraceType_Insights = 3,
	AutoTraceType_Stats = 4,
	AutoTraceType_MAX = 5
};

// Object Name: Enum AClient.EAutoTestInstanceType
enum class EAutoTestInstanceType : uint8 {
	AutoTestInstanceType_None = 0,
	AutoTestCharacterType_Smoke = 1,
	AutoTestCharacterType_Fight = 2,
	AutoTestCharacterType_PSO = 3,
	AutoTestCharacterType_GatherSyncLoad = 4,
	AutoTestCharacterType_ASAN = 5,
	EAutoTestInstanceType_MAX = 6
};

// Object Name: Enum AClient.ESyncOperation
enum class ESyncOperation : uint8 {
	PutOn = 0,
	PutOff = 1,
	ApplyHead = 2,
	ESyncOperation_MAX = 3
};

// Object Name: Enum AClient.EApexMeshType
enum class EApexMeshType : uint8 {
	Skeletal = 0,
	Static = 1,
	SkeletalWithSocket = 2,
	EApexMeshType_MAX = 3
};

// Object Name: Enum AClient.EAvatarAttachmentSlot
enum class EAvatarAttachmentSlot : uint8 {
	NONE = 0,
	Magazine = 1,
	MAX = 2
};

// Object Name: Enum AClient.EReplaceSlot
enum class EReplaceSlot : uint8 {
	EReplaceType_NONE = 0,
	EReplaceType_HeadEquipemtSlot = 1,
	EReplaceType_HairEquipemtSlot = 2,
	EReplaceType_HatEquipemtSlot = 3,
	EReplaceType_FaceEquipemtSlot = 4,
	EReplaceType_ClothesEquipemtSlot = 5,
	EReplaceType_PantsEquipemtSlot = 6,
	EReplaceType_ShoesEquipemtSlot = 7,
	EReplaceType_BackpackEquipemtSlot = 8,
	EReplaceType_HelmetEquipemtSlot = 9,
	EReplaceType_ArmorEquipemtSlot = 10,
	EReplaceType_ParachuteEquipemtSlot = 11,
	ESubSlot_HairOrnament = 65,
	EReplaceType_VeilSlot = 70,
	EReplaceType_HoodSlot = 75,
	EReplaceType_SilkStockingSlot = 80,
	EReplaceType_StockingSlot = 85,
	EReplaceType_BootsSlot = 86,
	EReplaceSlot_MAX = 87
};

// Object Name: Enum AClient.EAvatarSubSlot
enum class EAvatarSubSlot : uint8 {
	ESubSlot_None = 0,
	ESubSlot_HairOrnament = 65,
	ESubSlot_VeilSlot = 70,
	ESubSlot_HoodSlot = 75,
	ESubSlot_SilkStockingSlot = 80,
	ESubSlot_StockingSlot = 85,
	ESubSlot_BootsSlot = 86,
	ESubSlot_MAX = 87
};

// Object Name: Enum AClient.EAvatarSlotType
enum class EAvatarSlotType : uint8 {
	EAvatarSlotType_NONE = 0,
	EAvatarSlotType_HeadEquipemtSlot = 1,
	EAvatarSlotType_HairEquipemtSlot = 2,
	EAvatarSlotType_HatEquipemtSlot = 3,
	EAvatarSlotType_FaceEquipemtSlot = 4,
	EAvatarSlotType_ClothesEquipemtSlot = 5,
	EAvatarSlotType_PantsEquipemtSlot = 6,
	EAvatarSlotType_ShoesEquipemtSlot = 7,
	EAvatarSlotType_BackpackEquipemtSlot = 8,
	EAvatarSlotType_HelmetEquipemtSlot = 9,
	EAvatarSlotType_ArmorEquipemtSlot = 10,
	EAvatarSlotType_ParachuteEquipemtSlot = 11,
	EAvatarSlotType_GlassEquipemtSlot = 12,
	EAvatarSlotType_NightVisionEquipemtSlot = 13,
	EAvatarSlotType_WingClothesDataEquipemtSlot = 14,
	EAvatarSlotType_BackPack_PendantSlot = 15,
	EAvatarSlotType_Hand_HostileTipsLSlot = 16,
	EAvatarSlotType_Hand_HostileTipsRSlot = 17,
	EAvatarSlotType_FacePainting = 18,
	EAvatarSlotType_Max = 19
};

// Object Name: Enum AClient.EBackpackCapacityTipItemState
enum class EBackpackCapacityTipItemState : uint8 {
	Normal = 1,
	AlmostFull = 2,
	Full = 3,
	Empty = 4,
	EBackpackCapacityTipItemState_MAX = 5
};

// Object Name: Enum AClient.EBackpackPointState
enum class EBackpackPointState : uint8 {
	Empty = 0,
	NonEmpty = 1,
	Full = 2,
	EBackpackPointState_MAX = 3
};

// Object Name: Enum AClient.EBackpackDragState
enum class EBackpackDragState : uint8 {
	None = 0,
	DragBegin = 1,
	DragEnd = 2,
	EBackpackDragState_MAX = 3
};

// Object Name: Enum AClient.EBackpackPartItemType
enum class EBackpackPartItemType : uint8 {
	None = 0,
	Helmet = 1,
	Armor = 2,
	Shield = 3,
	Bag = 4,
	Tactics = 5,
	EBackpackPartItemType_MAX = 6
};

// Object Name: Enum AClient.EMeshTypes
enum class EMeshTypes : uint8 {
	Skeletal = 0,
	Static = 1,
	SkeletalWithSocket = 2,
	EMeshTypes_MAX = 3
};

// Object Name: Enum AClient.EDragState
enum class EDragState : uint8 {
	Normal = 0,
	Active = 1,
	Focus = 2,
	EDragState_MAX = 3
};

// Object Name: Enum AClient.EOpticalSocketType
enum class EOpticalSocketType : uint8 {
	OpticalDefault = 0,
	Optical1X = 1,
	Optical2X = 2,
	Optical3X = 3,
	Optical4X = 4,
	Optical6X = 6,
	Optical8X = 8,
	Optical10X = 10,
	EOpticalSocketType_MAX = 11
};

// Object Name: Enum AClient.EBattleItemQuality
enum class EBattleItemQuality : uint8 {
	White = 0,
	Blue = 1,
	Purple = 2,
	Gold = 3,
	EBattleItemQuality_MAX = 4
};

// Object Name: Enum AClient.EBattleKillMessageType
enum class EBattleKillMessageType : uint8 {
	Kill = 0,
	Assist = 1,
	Dying = 2,
	EBattleKillMessageType_MAX = 3
};

// Object Name: Enum AClient.EBattleResultGameEndReason
enum class EBattleResultGameEndReason : uint8 {
	None = 0,
	Normal = 1,
	TimeOut = 2,
	CampLeave = 3,
	EBattleResultGameEndReason_MAX = 4
};

// Object Name: Enum AClient.EMBGMType
enum class EMBGMType : uint8 {
	None = 0,
	Basic = 1,
	RoleSelect = 2,
	SelfTeamFlag = 3,
	Parachute = 4,
	PlayerInFight = 5,
	PlayerInDie = 6,
	EMBGMType_MAX = 7
};

// Object Name: Enum AClient.EBinOpenReason
enum class EBinOpenReason : uint8 {
	Normal = 0,
	PickUpTrigger = 1,
	EBinOpenReason_MAX = 2
};

// Object Name: Enum AClient.ESetIDReason
enum class ESetIDReason : uint8 {
	None = 0,
	Generate = 1,
	DynamicItemBin = 2,
	ESetIDReason_MAX = 3
};

// Object Name: Enum AClient.EBinOpenState
enum class EBinOpenState : uint8 {
	Closed = 0,
	Openning = 1,
	Openned = 2,
	EBinOpenState_MAX = 3
};

// Object Name: Enum AClient.EIceBinState
enum class EIceBinState : uint8 {
	Freeze = 0,
	Freezing = 1,
	UnFreeze = 2,
	EIceBinState_MAX = 3
};

// Object Name: Enum AClient.EBinType
enum class EBinType : uint8 {
	Normal = 0,
	IceBin = 1,
	VIPBin = 2,
	AdvancedVIPBin = 3,
	GhostBin = 4,
	EBinType_MAX = 5
};

// Object Name: Enum AClient.EValueComparer
enum class EValueComparer : uint8 {
	VE_E = 0,
	VE_NE = 1,
	VE_LT = 2,
	VE_LTE = 3,
	VE_GT = 4,
	VE_GTE = 5,
	VE_IN = 6,
	VE_MAX = 7
};

// Object Name: Enum AClient.EBlackboardValueType
enum class EBlackboardValueType : uint8 {
	Int = 0,
	Float = 1,
	Bool = 2,
	String = 3,
	Object = 4,
	Vector = 5,
	Rotator = 6,
	Class = 7,
	Name = 8,
	Max = 9
};

// Object Name: Enum AClient.EBombStatus
enum class EBombStatus : uint8 {
	None = 0,
	Timing = 1,
	Defusing = 2,
	Defused = 3,
	Blasted = 4,
	Idle = 5,
	Planting = 6,
	EBombStatus_MAX = 7
};

// Object Name: Enum AClient.EBackpackMetric
enum class EBackpackMetric : uint8 {
	ItemCount = 0,
	ItemPile = 1,
	Max = 2
};

// Object Name: Enum AClient.EBackpackType
enum class EBackpackType : uint8 {
	Any = 0,
	Real = 1,
	Cheat = 2,
	EBackpackType_MAX = 3
};

// Object Name: Enum AClient.ECheckWeaponSlot
enum class ECheckWeaponSlot : uint8 {
	VE_Main = 0,
	VE_Secondary = 1,
	VE_Current = 2,
	VE_MAX = 3
};

// Object Name: Enum AClient.EExpressionForceResult
enum class EExpressionForceResult : uint8 {
	Nop = 0,
	Succeeded = 1,
	Failed = 2,
	EExpressionForceResult_MAX = 3
};

// Object Name: Enum AClient.EResultOverwrite
enum class EResultOverwrite : uint8 {
	VE_AlwaysSuccess = 0,
	VE_AlwaysFail = 1,
	VE_MAX = 2
};

// Object Name: Enum AClient.EHoldLastRangeSight
enum class EHoldLastRangeSight : uint8 {
	Fist = 0,
	LastWeapon = 1,
	LongestWeapon = 2,
	EHoldLastRangeSight_MAX = 3
};

// Object Name: Enum AClient.ESelfDamageType
enum class ESelfDamageType : uint8 {
	EShieldDamage = 0,
	EHPDamage = 1,
	ENormalDamage = 2,
	ESelfDamageType_MAX = 3
};

// Object Name: Enum AClient.EFindNearMeshMode
enum class EFindNearMeshMode : uint8 {
	VE_Extent = 0,
	VE_Area = 1,
	VE_MAX = 2
};

// Object Name: Enum AClient.ESafeAreaType
enum class ESafeAreaType : uint8 {
	VE_WhiteCircle = 0,
	VE_BlueCircle = 1,
	VE_MAX = 2
};

// Object Name: Enum AClient.EEQSMoveStat
enum class EEQSMoveStat : uint8 {
	Init = 0,
	EnterEQSRange = 1,
	LeaveEQSRange = 2,
	EEQSMoveStat_MAX = 3
};

// Object Name: Enum AClient.ECheckSafeAreaMode
enum class ECheckSafeAreaMode : uint8 {
	CheckSafeAreaMode_Strict = 0,
	CheckSafeAreaMode_Priotity = 1,
	CheckSafeAreaMode_None = 2,
	CheckSafeAreaMode_MAX = 3
};

// Object Name: Enum AClient.EGetRandLocDirectedMode
enum class EGetRandLocDirectedMode : uint8 {
	VE_Raycast = 0,
	VE_Reachable = 1,
	VE_Any = 2,
	VE_MAX = 3
};

// Object Name: Enum AClient.EOperateTargetType
enum class EOperateTargetType : uint8 {
	ERespawnBeacon = 0,
	EOperateTargetType_MAX = 1
};

// Object Name: Enum AClient.ESpawnState
enum class ESpawnState : uint8 {
	Stand = 0,
	KnockDown = 1,
	ESpawnState_MAX = 2
};

// Object Name: Enum AClient.ESpawnTeam
enum class ESpawnTeam : uint8 {
	TeamMate = 0,
	Enemy = 1,
	PlayerTeamMate = 2,
	ESpawnTeam_MAX = 3
};

// Object Name: Enum AClient.EAirNavMethod
enum class EAirNavMethod : uint8 {
	Voxel = 0,
	NavMesh = 1,
	EAirNavMethod_MAX = 2
};

// Object Name: Enum AClient.EAnimState
enum class EAnimState : uint8 {
	VE_NotSet = 63,
	VE_Stand = 11,
	VE_Crouch = 12,
	VE_Sprint = 1,
	VE_MAX = 64
};

// Object Name: Enum AClient.ESwitchWeaponSlot
enum class ESwitchWeaponSlot : uint8 {
	VE_Main = 0,
	VE_Secondary = 1,
	VE_Throw = 2,
	VE_Empty = 3,
	VE_Alternative = 4,
	VE_AUTO = 5,
	VE_MAX = 6
};

// Object Name: Enum AClient.EMedicineItem
enum class EMedicineItem : uint8 {
	VE_Syringe = 0,
	VE_1stAidBox = 1,
	VE_ShieldCell = 2,
	VE_ShieldBattery = 3,
	VE_PhoenixKit = 4,
	VE_InfSyringe = 5,
	VE_InfShieldCell = 6,
	VE_MAX = 7
};

// Object Name: Enum AClient.ETimeCounterMode
enum class ETimeCounterMode : uint8 {
	Default = 0,
	OneShot = 1,
	DefaultInverted = 2,
	OneShotInverted = 3,
	ETimeCounterMode_MAX = 4
};

// Object Name: Enum AClient.EVoxCheckSafeAreaMode
enum class EVoxCheckSafeAreaMode : uint8 {
	CheckSafeAreaMode_Strict = 0,
	CheckSafeAreaMode_Priotity = 1,
	CheckSafeAreaMode_None = 2,
	CheckSafeAreaMode_MAX = 3
};

// Object Name: Enum AClient.EVoxGetRandLocDirectedMode
enum class EVoxGetRandLocDirectedMode : uint8 {
	Vox_Raycast = 0,
	Vox_Reachable = 1,
	Vox_Any = 2,
	Vox_MAX = 3
};

// Object Name: Enum AClient.ECagedFlyersState
enum class ECagedFlyersState : uint8 {
	Normal = 0,
	Caution = 1,
	Anger = 2,
	ECagedFlyersState_MAX = 3
};

// Object Name: Enum AClient.ECPProgressChangeCondition
enum class ECPProgressChangeCondition : uint8 {
	OnlyOneCamp = 0,
	MostMemers = 1,
	ECPProgressChangeCondition_MAX = 2
};

// Object Name: Enum AClient.ECPAddHealthCondition
enum class ECPAddHealthCondition : uint8 {
	Capturing = 0,
	Captured = 1,
	ECPAddHealthCondition_MAX = 2
};

// Object Name: Enum AClient.ECarePackageOpenReason
enum class ECarePackageOpenReason : uint8 {
	Normal = 0,
	PickUpTrigger = 1,
	ECarePackageOpenReason_MAX = 2
};

// Object Name: Enum AClient.ECarePackageDoorType
enum class ECarePackageDoorType : uint8 {
	TableItemRandom = 0,
	LifelineBetterShield = 1,
	LifelineBetterEquip = 2,
	LifelineBetterGun = 3,
	Invalid = 4,
	ECarePackageDoorType_MAX = 5
};

// Object Name: Enum AClient.ECarePackageLootType
enum class ECarePackageLootType : uint8 {
	None = 0,
	ItemTableRandom = 1,
	ItemTableRandomAE = 2,
	LifelineTeamBetter = 3,
	DropList = 4,
	EachDoorCustom = 5,
	ExternalSet = 6,
	Max = 7
};

// Object Name: Enum AClient.CausticBombDestroyStage
enum class CausticBombDestroyStage : uint8 {
	Normal = 0,
	Explode = 1,
	StopCollision = 2,
	CausticBombDestroyStage_MAX = 3
};

// Object Name: Enum AClient.CausticExternalEvent
enum class CausticExternalEvent : uint8 {
	Deploy = 0,
	Active = 1,
	PickedUp = 2,
	DestroyByDamage = 3,
	CausticExternalEvent_MAX = 4
};

// Object Name: Enum AClient.EAnimDataLoadRequestFlag
enum class EAnimDataLoadRequestFlag : uint8 {
	AnimDataMap = 0,
	EAnimDataLoadRequestFlag_MAX = 1
};

// Object Name: Enum AClient.EMBuffOverlapType
enum class EMBuffOverlapType : uint8 {
	NoOverlap = 0,
	SingleEffect = 1,
	OverlapEffect = 2,
	OverlapEffect_Individual = 3,
	EMBuffOverlapType_MAX = 4
};

// Object Name: Enum AClient.EBattleItemUseEventType
enum class EBattleItemUseEventType : uint8 {
	None = 0,
	USE_Start = 1,
	USE_Interrupt = 2,
	USE_End = 3,
	EBattleItemUseEventType_MAX = 4
};

// Object Name: Enum AClient.ECircleInfo
enum class ECircleInfo : uint8 {
	None = 0,
	PreInitBlueCircle = 1,
	SafeZoneTips = 2,
	BlueCirclePreWarning = 3,
	BlueCircleRun = 4,
	CurWaveOver = 5,
	AllCircleEnd = 6,
	ECircleInfo_MAX = 7
};

// Object Name: Enum AClient.UCircleType
enum class UCircleType : uint8 {
	Normal = 0,
	ABLine = 1,
	WidgetMap = 2,
	UCircleType_MAX = 3
};

// Object Name: Enum AClient.ColosseumInvincibleStage
enum class ColosseumInvincibleStage : uint8 {
	WaitActive = 0,
	Active = 1,
	CD = 2,
	ColosseumInvincibleStage_MAX = 3
};

// Object Name: Enum AClient.ECommDiscardMagSkeletalMeshType
enum class ECommDiscardMagSkeletalMeshType : uint8 {
	G7 = 0,
	Triple = 1,
	ECommDiscardMagSkeletalMeshType_MAX = 2
};

// Object Name: Enum AClient.EGenerateObjectType
enum class EGenerateObjectType : uint8 {
	Bin = 0,
	LootRoller = 1,
	EGenerateObjectType_MAX = 2
};

// Object Name: Enum AClient.ECommonSignDirection
enum class ECommonSignDirection : uint8 {
	None = 0,
	Top = 1,
	Bottom = 2,
	Left = 3,
	Right = 4,
	ECommonSignDirection_MAX = 5
};

// Object Name: Enum AClient.ESignHandleType
enum class ESignHandleType : uint8 {
	Create = 1,
	Delete = 2,
	ESignHandleType_MAX = 3
};

// Object Name: Enum AClient.EConditionPoseType
enum class EConditionPoseType : uint8 {
	HoldWeapon = 0,
	SkillBothHands = 1,
	SkillLeftHand = 2,
	SkillRightHand = 3,
	Sliding = 4,
	ZipLine = 5,
	EConditionPoseType_MAX = 6
};

// Object Name: Enum AClient.EConditionCharAnimOp
enum class EConditionCharAnimOp : uint8 {
	Or = 0,
	And = 1,
	OrNot = 2,
	AndNot = 3,
	EConditionCharAnimOp_MAX = 4
};

// Object Name: Enum AClient.ECountDownTimerRepMode
enum class ECountDownTimerRepMode : uint8 {
	None = 0,
	Broadcast = 1,
	Client = 2,
	ECountDownTimerRepMode_MAX = 3
};

// Object Name: Enum AClient.ECryptoDrone_AutoMode
enum class ECryptoDrone_AutoMode : uint8 {
	Hover = 0,
	Auto = 1,
	Follow = 2,
	FollowToAuto = 3,
	ECryptoDrone_MAX = 4
};

// Object Name: Enum AClient.ECustomCollisionType
enum class ECustomCollisionType : uint8 {
	EventClosed = 0,
	EventReceiver = 1,
	EventGenerator = 2,
	ECustomCollisionType_MAX = 3
};

// Object Name: Enum AClient.ECustomVectorOP
enum class ECustomVectorOP : uint8 {
	Add = 0,
	Sub = 1,
	Cross = 2,
	Dot = 3,
	Distance = 4,
	ECustomVectorOP_MAX = 5
};

// Object Name: Enum AClient.EDebugArrowDrawMode
enum class EDebugArrowDrawMode : uint8 {
	straight = 0,
	smooth = 1,
	EDebugArrowDrawMode_MAX = 2
};

// Object Name: Enum AClient.ECustomWidgetVisual
enum class ECustomWidgetVisual : uint8 {
	None = 0,
	HiddenInGame = 1,
	HiddenInBasic = 2,
	HiddenInCustom = 3,
	HiddenInGM = 4,
	MaxIndex = 63,
	ECustomWidgetVisual_MAX = 64
};

// Object Name: Enum AClient.EDamageNumShowType
enum class EDamageNumShowType : uint8 {
	DamageNumShowType_None = 0,
	DamageNumShowType_Add = 1,
	DamageNumShowType_Float = 2,
	DamageNumShowType_Both = 3,
	DamageNumShowType_MAX = 4
};

// Object Name: Enum AClient.EReportMode
enum class EReportMode : uint8 {
	Immediately = 0,
	OnPlayerExit = 1,
	OnGameEnd = 2,
	EReportMode_MAX = 3
};

// Object Name: Enum AClient.EReportType
enum class EReportType : uint8 {
	NONE = 0,
	GameStatisticsReport = 1,
	TrackerManager = 2,
	EReportType_MAX = 3
};

// Object Name: Enum AClient.EWatchStat
enum class EWatchStat : uint8 {
	NONE = 0,
	SwitchCount = 1,
	SwitchEnemyCount = 2,
	MarkBoxCount = 3,
	MarkBeaconCount = 4,
	HitFlagCount = 5,
	AddFriendCount = 6,
	ChatCount = 7,
	SeeWatcherCount = 8,
	IsLastDead = 9,
	IsWatchAllies = 10,
	IsExitWatchAllies = 11,
	IsRevivable = 12,
	IsAced = 13,
	IsWatchEnemies = 14,
	IsExitWatchEnemies = 15,
	EWatchStat_MAX = 16
};

// Object Name: Enum AClient.EDeathBoxFlyerType
enum class EDeathBoxFlyerType : uint8 {
	CirclingFlyer = 0,
	PerchedFlyer = 1,
	EDeathBoxFlyerType_MAX = 2
};

// Object Name: Enum AClient.EApexMoveGait
enum class EApexMoveGait : uint8 {
	Walk = 0,
	Sprint = 1,
	EApexMoveGait_MAX = 2
};

// Object Name: Enum AClient.EBlockDoorType
enum class EBlockDoorType : uint8 {
	BlockAll = 0,
	MoveDoubleDoorBlockToDestroy = 1,
	MoveDoorBlockToDestroy = 2,
	DoubleDoorBlockToDestroy = 4,
	SingleDoorBlockToDestroy = 8,
	OnlyBlockRotateDoor = 16,
	OnlyBlockMoveDoor = 32,
	EBlockDoorType_MAX = 33
};

// Object Name: Enum AClient.EDoorBlockType
enum class EDoorBlockType : uint8 {
	Block = 0,
	Push = 1,
	EDoorBlockType_MAX = 2
};

// Object Name: Enum AClient.EDoorTranslateType
enum class EDoorTranslateType : uint8 {
	X = 0,
	Y = 1,
	Z = 2,
	EDoorTranslateType_MAX = 3
};

// Object Name: Enum AClient.EDoorRotateType
enum class EDoorRotateType : uint8 {
	Yaw = 0,
	Roll = 1,
	Pitch = 2,
	EDoorRotateType_MAX = 3
};

// Object Name: Enum AClient.EDoorMoveType
enum class EDoorMoveType : uint8 {
	Rotate = 0,
	Translate = 1,
	EDoorMoveType_MAX = 2
};

// Object Name: Enum AClient.EDoorState
enum class EDoorState : uint8 {
	None = 0,
	Closing = 1,
	Closed = 2,
	Opening = 3,
	Bouncing = 4,
	Opened = 5,
	EDoorState_MAX = 6
};

// Object Name: Enum AClient.EDrugRecommendType
enum class EDrugRecommendType : uint8 {
	Health = 0,
	Shield = 1,
	Both = 2,
	EDrugRecommendType_MAX = 3
};

// Object Name: Enum AClient.EDynamicItemSpawnType
enum class EDynamicItemSpawnType : uint8 {
	None = 0,
	Region = 1,
	FullCreate = 2,
	EDynamicItemSpawnType_MAX = 3
};

// Object Name: Enum AClient.EApexLightType
enum class EApexLightType : uint8 {
	LightNone = 0,
	DirLight = 1,
	SkyLight = 2,
	SpotLight = 3,
	EApexLightType_MAX = 4
};

// Object Name: Enum AClient.EPathMoveDir
enum class EPathMoveDir : uint8 {
	Forward = 0,
	Reverse = 1,
	EPathMoveDir_MAX = 2
};

// Object Name: Enum AClient.EPathMoveLoopMode
enum class EPathMoveLoopMode : uint8 {
	None = 0,
	LoopFromStart = 1,
	FinishTurnBack = 2,
	EPathMoveLoopMode_MAX = 3
};

// Object Name: Enum AClient.EEffectLoaderPickerType
enum class EEffectLoaderPickerType : uint8 {
	EELP_Functionality = 0,
	EELP_NoFunctionality = 1,
	EELP_MAX = 2
};

// Object Name: Enum AClient.EEncomyExchangeType
enum class EEncomyExchangeType : uint8 {
	None = 0,
	WeaponSet = 1,
	Item = 2,
	Skill = 3,
	EEncomyExchangeType_MAX = 4
};

// Object Name: Enum AClient.EEncomyCostReason
enum class EEncomyCostReason : uint8 {
	None = 0,
	Exchange = 1,
	Replicator = 2,
	EEncomyCostReason_MAX = 3
};

// Object Name: Enum AClient.EEncomyAddReason
enum class EEncomyAddReason : uint8 {
	None = 0,
	SupplyBin = 1,
	MaterialStation = 2,
	Kill = 3,
	Assist = 4,
	Start = 5,
	Victory = 6,
	Defeat = 7,
	Return = 8,
	Residue = 9,
	Round = 10,
	GM = 11,
	PlantSuccess = 12,
	DesualSuccess = 13,
	BombBlast = 14,
	NewMaterialStation = 15,
	MAX = 16
};

// Object Name: Enum AClient.EShieldState
enum class EShieldState : uint8 {
	Unknown = 0,
	NormalOpened = 1,
	NormalClosed = 2,
	Recover = 3,
	Broken = 4,
	Max = 5
};

// Object Name: Enum AClient.EEnmityType
enum class EEnmityType : uint8 {
	eWeapon = 0,
	eSkill = 1,
	EEnmityType_MAX = 2
};

// Object Name: Enum AClient.EEQSBallGeneratorMethod
enum class EEQSBallGeneratorMethod : uint8 {
	Random = 0,
	MeshGrid = 1,
	Sphere = 2,
	Isotropy = 3,
	Poisson = 4,
	EEQSBallGeneratorMethod_MAX = 5
};

// Object Name: Enum AClient.EEQSCubeGeneratorMethod
enum class EEQSCubeGeneratorMethod : uint8 {
	Random = 0,
	MeshGrid = 1,
	Poisson = 2,
	EEQSCubeGeneratorMethod_MAX = 3
};

// Object Name: Enum AClient.CircleTypeEnum
enum class CircleTypeEnum : uint8 {
	WhiteCircle = 0,
	BlueCircle = 1,
	CircleTypeEnum_MAX = 2
};

// Object Name: Enum AClient.EFireRangeGameType
enum class EFireRangeGameType : uint8 {
	None = 0,
	ShootGame = 1,
	SingleTarget = 2,
	GuardWarGame = 3,
	EFireRangeGameType_MAX = 4
};

// Object Name: Enum AClient.EFireRangeTargetAttackFrequency
enum class EFireRangeTargetAttackFrequency : uint8 {
	Negative = 0,
	Hardly = 1,
	Sometime = 2,
	Often = 3,
	EFireRangeTargetAttackFrequency_MAX = 4
};

// Object Name: Enum AClient.EFireRangeShootGameType
enum class EFireRangeShootGameType : uint8 {
	None = 0,
	Simple = 1,
	Common = 2,
	Miserable = 3,
	Custom = 4,
	SingleTarget = 5,
	Drone = 6,
	SupplyBox = 7,
	Combat = 8,
	Cover = 9,
	GuardWar = 10,
	TargetPractice = 11,
	TargetPractice2 = 12,
	ChasingPractice = 13,
	ChasingPractice2 = 14,
	TransferPractice = 15,
	TransferPractice2 = 16,
	EFireRangeShootGameType_MAX = 17
};

// Object Name: Enum AClient.EFireRangeTargetType
enum class EFireRangeTargetType : uint8 {
	SquareTarget = 0,
	Character = 1,
	LootDrone = 2,
	CryptoDrone = 3,
	EFireRangeTargetType_MAX = 4
};

// Object Name: Enum AClient.EFireRangeEndCondition
enum class EFireRangeEndCondition : uint8 {
	CountdownEnd = 1,
	PlayerDie = 2,
	AchieveEnoughScore = 4,
	ShootEnoughTarget = 8,
	EFireRangeEndCondition_MAX = 9
};

// Object Name: Enum AClient.EFireRangeTargetPostureType
enum class EFireRangeTargetPostureType : uint8 {
	Stand = 0,
	Crouch = 1,
	Sliding = 2,
	ADS = 3,
	PostureRand = 4,
	EFireRangeTargetPostureType_MAX = 5
};

// Object Name: Enum AClient.EFireRangeTargetHealthType
enum class EFireRangeTargetHealthType : uint8 {
	Default = 0,
	Unlimited = 1,
	EFireRangeTargetHealthType_MAX = 2
};

// Object Name: Enum AClient.EFireRangeTargetGaitType
enum class EFireRangeTargetGaitType : uint8 {
	Idle = 0,
	ADS = 1,
	Walk = 2,
	Run = 3,
	EFireRangeTargetGaitType_MAX = 4
};

// Object Name: Enum AClient.EFlyingSkeletonState
enum class EFlyingSkeletonState : uint8 {
	Init = 0,
	RiseUp = 1,
	PrePatrol = 2,
	Patrol = 3,
	Chase = 4,
	Fall = 5,
	PreExplosion = 6,
	End = 7,
	EFlyingSkeletonState_MAX = 8
};

// Object Name: Enum AClient.EFollowState
enum class EFollowState : uint8 {
	None = 0,
	Leader = 1,
	Follower = 2,
	EFollowState_MAX = 3
};

// Object Name: Enum AClient.EGamblingMachineMesType
enum class EGamblingMachineMesType : uint8 {
	Succeed = 0,
	NoSpawableItems = 1,
	NoUseTimes = 2,
	PlayerNoUseTimes = 3,
	InUse = 4,
	CDCooling = 5,
	Error = 6,
	EGamblingMachineMesType_MAX = 7
};

// Object Name: Enum AClient.EAirDropAreaType
enum class EAirDropAreaType : uint8 {
	None = 0,
	RoundStart = 1,
	RoundLessen = 2,
	Max = 3
};

// Object Name: Enum AClient.EAirDropActorType
enum class EAirDropActorType : uint8 {
	None = 0,
	Normal = 1,
	Replicator = 2,
	Max = 3
};

// Object Name: Enum AClient.EAirDropType
enum class EAirDropType : uint8 {
	None = 0,
	RoundStart = 1,
	RoundLessen = 2,
	Max = 3
};

// Object Name: Enum AClient.EDsFunctionId
enum class EDsFunctionId : uint8 {
	ShadowMirage = 1,
	NaviGuide = 2,
	MLAILevel = 3,
	EDsFunctionId_MAX = 4
};

// Object Name: Enum AClient.EKickOutReason
enum class EKickOutReason : uint8 {
	ReasonNone = 0,
	ReasonCheatOB = 1,
	ReasonChat = 2,
	ReasonNoPerceptionChat = 3,
	EKickOutReason_MAX = 4
};

// Object Name: Enum AClient.EHoverTankAreaType
enum class EHoverTankAreaType : uint8 {
	None = 0,
	SafeZone = 1,
	InsideSafeZone = 2,
	OutSideSafeZone = 3,
	All = 4,
	Max = 5
};

// Object Name: Enum AClient.EActivityItemDropReason
enum class EActivityItemDropReason : uint8 {
	None = 0,
	SelfPlayerDrop = 1,
	SelfPlayerDeadDrop = 2,
	Max = 3
};

// Object Name: Enum AClient.EActivityItemPikcupReason
enum class EActivityItemPikcupReason : uint8 {
	Normal = 0,
	PickupEnemyPlayerItem = 1,
	PickupTeamPlayerDropItem = 2,
	IceBinDrop = 3,
	GhostBinDrop = 4,
	Max = 5
};

// Object Name: Enum AClient.EPickupActivityItemResult
enum class EPickupActivityItemResult : uint8 {
	Sucess = 0,
	CD = 1,
	Max = 2,
	MaxGame = 3,
	MaxDay = 4,
	MaxWeek = 5,
	MaxTotal = 6,
	NotActivityItem = 7
};

// Object Name: Enum AClient.ENewbieScriptReportType
enum class ENewbieScriptReportType : uint8 {
	None = 0,
	StartScript = 1,
	EndScript = 2,
	Max = 3
};

// Object Name: Enum AClient.EOperateStatisticsCountType
enum class EOperateStatisticsCountType : uint8 {
	RescueTeamMate = 0,
	PickTeamMateBanner = 1,
	UseRespawnBeacon = 2,
	UseRespawnBeaconSuccess = 3,
	UseDynamicRespawnBeacon = 4,
	UseDynamicRespawnBeaconSuccess = 5,
	InstallDynamicRespawnBeacon = 6,
	EOperateStatisticsCountType_MAX = 7
};

// Object Name: Enum AClient.EMPMateNameCampRole
enum class EMPMateNameCampRole : uint8 {
	Normal = 0,
	BombCarrier = 1,
	EMPMateNameCampRole_MAX = 2
};

// Object Name: Enum AClient.EGamepadMainUIType
enum class EGamepadMainUIType : uint8 {
	eNone = 0,
	eLobbyMain = 1,
	eInGameMain = 2,
	eDisableProcessor = 3,
	EGamepadMainUIType_MAX = 4
};

// Object Name: Enum AClient.EGamepadMouseVisibility
enum class EGamepadMouseVisibility : uint8 {
	eNone = 0,
	eVisible = 1,
	eHidden = 2,
	EGamepadMouseVisibility_MAX = 3
};

// Object Name: Enum AClient.EGamepadButtonEventType
enum class EGamepadButtonEventType : uint8 {
	ePressed = 0,
	eReleased = 1,
	eClicked = 2,
	EGamepadButtonEventType_MAX = 3
};

// Object Name: Enum AClient.EGamepadPlayerStateType
enum class EGamepadPlayerStateType : uint8 {
	eNone = 0,
	eNormal = 1,
	eDying = 2,
	eRescuing = 3,
	eRescuingSelf = 4,
	eRescuingOther = 5,
	eDoFinisher = 6,
	eBeFinisher = 7,
	eRespawning = 8,
	eRespawnTimeout = 9,
	eRespawnTeammate = 10,
	eDead = 11,
	eMax = 12,
	eUnknown = 13,
	EGamepadPlayerStateType_MAX = 14
};

// Object Name: Enum AClient.EGamepadProcessorType
enum class EGamepadProcessorType : uint8 {
	eNone = 0,
	eMain = 1,
	eBackpack = 2,
	eMouseControl = 3,
	ePing = 4,
	eTurnTable = 5,
	ePickUp = 6,
	eMax = 7,
	EGamepadProcessorType_MAX = 8
};

// Object Name: Enum AClient.EReplayType
enum class EReplayType : uint8 {
	EReplay_None = 0,
	EReplay_Death = 1,
	EReplay_Complete = 2,
	EReplay_Http = 3,
	EReplay_MAX = 4
};

// Object Name: Enum AClient.InGameRegionType
enum class InGameRegionType : uint8 {
	None = 0,
	PickUpItem = 1,
	TombBox = 2,
	Max = 3
};

// Object Name: Enum AClient.EMultiplayerUIStatus
enum class EMultiplayerUIStatus : uint8 {
	None = 0,
	RoundBegin = 1,
	LoadoutChoose = 2,
	ReadyCountdown = 3,
	EMultiplayerUIStatus_MAX = 4
};

// Object Name: Enum AClient.ESelectExtraType
enum class ESelectExtraType : uint8 {
	None = 0,
	ExtraSlot = 1,
	ExtraSlot1 = 2,
	ExtraSlot2 = 3,
	ExtraSlot3 = 4,
	ESelectExtraType_MAX = 5
};

// Object Name: Enum AClient.ESelectLegendRandomMode
enum class ESelectLegendRandomMode : uint8 {
	Off = 0,
	AllSame = 1,
	AllDifferent = 2,
	TeamDifferent = 3,
	ESelectLegendRandomMode_MAX = 4
};

// Object Name: Enum AClient.EColosseumTipsAreaType
enum class EColosseumTipsAreaType : uint8 {
	TotalArea = 0,
	InBounding = 1,
	InTriggerArea = 2,
	EColosseumTipsAreaType_MAX = 3
};

// Object Name: Enum AClient.ColosseumTipsType
enum class ColosseumTipsType : uint8 {
	Tips = 0,
	CountDownType = 1,
	ColosseumTipsType_MAX = 2
};

// Object Name: Enum AClient.EWinterWarfareActivateState
enum class EWinterWarfareActivateState : uint8 {
	None = 0,
	WaitForActivate = 1,
	Activate = 2,
	Max = 3
};

// Object Name: Enum AClient.EScoringReason
enum class EScoringReason : uint8 {
	Default = 0,
	RoundEnd = 1,
	Kill = 2,
	Ace = 3,
	Destroy = 4,
	Defuse = 5,
	CapturePoint = 6,
	EScoringReason_MAX = 7
};

// Object Name: Enum AClient.EDataStatisticsType
enum class EDataStatisticsType : uint8 {
	None = 0,
	SecAntiData = 1,
	SecAtackFlow = 2,
	SecHurtFlow = 3,
	SecReviveFlow = 4,
	SecPlayerWatchBattleFlow = 5,
	SecWatchSpectatingFlow = 6,
	SecGameEndWatchFlow = 7,
	SecCircleFlow = 8,
	SecJumpFlow = 9,
	SecClientNetworkFlow = 10,
	SecPlayerMoveRouteFlow = 11,
	SecMrpcsFlow = 12,
	SecRoundLeftFlow = 13,
	BotFlow = 14,
	TutorialFlow = 15,
	OP_TutorialFlow = 16,
	PlayerRangeTargetShootingFlow = 17,
	RandomFightResult = 18,
	PlayerRangeEndFlow = 19,
	WeeklyTrainingFlow = 20,
	ItemPickDropFlow = 21,
	BagFlow = 22,
	LegendFlow = 23,
	ZoneLootFlow = 24,
	ZoneLootCombineFlow = 25,
	DSFPSFlow = 26,
	PlayerReconnectBattleFlow = 27,
	AirlineFlow = 28,
	CircleDataFlow = 29,
	PlayerJumpFlow = 30,
	PingFlow = 31,
	WeaponFlow = 32,
	WeaponDetailAttachFlow = 33,
	DSPlayerChatFlow = 34,
	ItemUseFlow = 35,
	ThrowingFlow = 36,
	PickBeaconFlow = 37,
	DeathPawnStateFlow = 38,
	BackpackItemFlow = 39,
	RespawnBeaconFlow = 40,
	LegendAddendaDsFlow = 41,
	BattleStateFlow = 42,
	BRChooseLegendFlow = 43,
	TrainRunFlow = 44,
	TrainOperationFlow = 45,
	PlayerTrainFlow = 46,
	PlayerMove = 47,
	PlayerStateFlow = 48,
	MiniMapFlow = 49,
	MiniMapZoomFlow = 50,
	MiniMapPingFlow = 51,
	MiniMapDelPingFlow = 52,
	AIMonitorFlow = 53,
	AISystemFlow = 54,
	ZipLineFlow = 55,
	PlayerPerspectFlow = 56,
	CryptoDroneFlow = 57,
	AirDropFlow = 58,
	AirDropDataFlow = 59,
	PlayerExitGame = 60,
	DeathTotemFlow = 61,
	DirtyBombFlow = 62,
	GasGrenadeFlow = 63,
	PathfinderFlow = 64,
	DecoyFlow = 65,
	LaunchpadFlow = 66,
	LegendSkillGuideFlow = 67,
	BombDefusalRoundFlow = 68,
	BombDefusalRoundPlayerFlow = 69,
	SkillFlow = 70,
	WraithFlow = 71,
	DimensionalRiftFlow = 72,
	GameStat = 73,
	GameStatisticsFlow = 74,
	DronesFlow = 75,
	RollerFlow = 76,
	PlayerDoorFlow = 77,
	DoorStat4HeatMap = 78,
	WatchStat = 79,
	DSAdjustFlow = 80,
	PawnStateStatistics = 81,
	KillKDERFlow = 82,
	HoverTankFlow = 83,
	MPRoundPlayerBuyPropsFlow = 84,
	MPRoundEndFlow = 85,
	LootBinCreepFlow = 86,
	OneRoundLootBinCreepFlow = 87,
	AIHostUseFlow = 88,
	SecurityScoreFlow = 89,
	ApplyMidJoinFlow = 90,
	AIHostAttackFlow = 91,
	ActivityPickDropFlow = 92,
	WinterWarfareRoundFlow = 93,
	PlayerWorkbenchFlow = 94,
	EachReplicatorFlow = 95,
	EachHarvesterFlow = 96,
	WorkbenchReplicateFlow = 97,
	RowdyFlow = 98,
	AdvancedTrainingFlow = 99,
	LegendTrainingFlow = 100,
	LootBinFlow = 101,
	UpgradeArmorFlow = 102,
	PhantomFlow = 103,
	RoundEquipFlow = 104,
	UnfoldAppointmentDsFlow = 105,
	MoveAntiLegendSpeedFlow = 106,
	DSDebugFlow = 107,
	AIEventFlow = 108,
	GameReplayFlow = 109,
	LobaUltimateFlow = 110,
	VIPFlow = 111,
	VoiceEventState = 112,
	ArmsRaceDataFlow = 113,
	StageSwitchFlow = 114,
	StageFiveSecondFlow = 115,
	StageFlow = 116,
	PlayerInStageFlow = 117,
	PartySwitchFlow = 118,
	StaticBinDestroyFlow = 119,
	DynamicBinDestroyFlow = 120,
	RespawnNextLifeFlow = 121,
	RhapsodyFlow = 122,
	WeaponUseTimeFlow = 123,
	ColosseumFlow = 124,
	ClientReportErrorFlow = 125,
	PlayerScriptGameFlow = 126,
	Max = 127
};

// Object Name: Enum AClient.EDragContentUsingType
enum class EDragContentUsingType : uint8 {
	LeftPing = 1,
	RightPing = 2,
	SmallEye = 3,
	Emoji = 4,
	Projectile = 5,
	Consumable = 6,
	CryptoDrone = 7,
	EDragContentUsingType_MAX = 8
};

// Object Name: Enum AClient.EGeneralPosWidgetState
enum class EGeneralPosWidgetState : uint8 {
	None = 0,
	RangeTrigger = 1,
	ScopeOpenedAndRangeTriger = 2,
	Normal = 3,
	Invisible = 4,
	Covered = 5,
	OutViewport = 6,
	EGeneralPosWidgetState_MAX = 7
};

// Object Name: Enum AClient.EHoverTankZiplineType
enum class EHoverTankZiplineType : uint8 {
	None = 0,
	Left = 1,
	Right = 2,
	Back = 3,
	EHoverTankZiplineType_MAX = 4
};

// Object Name: Enum AClient.EHoverTankAnimationState
enum class EHoverTankAnimationState : uint8 {
	None = 0,
	Horizontal = 1,
	Convert = 2,
	Landing = 3,
	EHoverTankAnimationState_MAX = 4
};

// Object Name: Enum AClient.EHUDType
enum class EHUDType : uint8 {
	KillLeaderAchievedTip = 0,
	KillLeaderKilledTip = 1,
	ExplosionTimeTips = 2,
	EHUDType_MAX = 3
};

// Object Name: Enum AClient.ETextVertPos
enum class ETextVertPos : uint8 {
	Top = 0,
	Center = 1,
	Bottom = 2,
	MAX = 3
};

// Object Name: Enum AClient.ETextHorzPos
enum class ETextHorzPos : uint8 {
	Left = 0,
	Center = 1,
	Right = 2,
	MAX = 3
};

// Object Name: Enum AClient.EIndiviAnimDimension
enum class EIndiviAnimDimension : uint8 {
	Light = 0,
	Medium = 1,
	Heavy = 2,
	EIndiviAnimDimension_MAX = 3
};

// Object Name: Enum AClient.EInGameSendType
enum class EInGameSendType : uint8 {
	Team = 1,
	All = 2,
	Camp = 3,
	EInGameSendType_MAX = 4
};

// Object Name: Enum AClient.EInGameChatFromType
enum class EInGameChatFromType : uint8 {
	Normal = 1,
	Pings = 2,
	Parachuting = 3,
	CustomChat = 4,
	SelectLegend = 5,
	System = 6,
	ShortSelectLegend = 7,
	Require = 8,
	QuickMsg = 9,
	ChangeLegendMsg = 10,
	BombRequst = 11,
	Others = 20,
	EInGameChatFromType_MAX = 21
};

// Object Name: Enum AClient.EInGameGuideReportType
enum class EInGameGuideReportType : uint8 {
	Trigger = 1,
	Appear = 2,
	Finished = 3,
	EInGameGuideReportType_MAX = 4
};

// Object Name: Enum AClient.EUILayerType
enum class EUILayerType : uint8 {
	BackGround = 1,
	Low = 2,
	Dock = 3,
	Exclusive = 4,
	LowWindow = 5,
	Window = 6,
	HighWindow = 7,
	TopestWindow = 8,
	Dialog = 9,
	Top = 10,
	TopShow = 11,
	Guide = 12,
	Tips = 13,
	Loading = 14,
	HighLoading = 15,
	ReplayLoading = 16,
	TopTips = 17,
	ErrorTips = 18,
	EUILayerType_MAX = 19
};

// Object Name: Enum AClient.EInGameGuideFailReason
enum class EInGameGuideFailReason : uint8 {
	None = 0,
	NotInGuideList = 1,
	IsHadExec = 2,
	MaxNumIsFail = 3,
	MaxExecNumFail = 4,
	LegendUsedNumFail = 5,
	MaxGameNumFail = 6,
	LevelLimitFail = 7,
	DurationNumStartFail = 8,
	DurationNumEndFail = 9,
	NotInProgressList = 10,
	PCFail = 11,
	PSFail = 12,
	EInGameGuideFailReason_MAX = 13
};

// Object Name: Enum AClient.EInGameGuideID
enum class EInGameGuideID : int32 {
	PARACHUTE = 1001,
	PickUpGradeArmor = 1027,
	GetUpGradeArmorExp = 1028,
	PickKnockdownShield = 1029,
	UseKnockdownShield = 1030,
	UseGrenade = 1035,
	Guide_PingGroundWhenJump = 1036,
	Guide_PingItem = 1037,
	Guide_PingEnemy = 1038,
	Guide_PingBubble = 1039,
	AmmoNotEnough = 1046,
	PackupWeapon = 1052,
	ReplaceOptical1 = 1053,
	ReplaceOptical2 = 1054,
	StrengthenSentinel = 1055,
	StrengthenBaozou = 1056,
	FindTombBox = 1057,
	RescueTeamMate = 1060,
	PickTeamMateRespawnBanner = 1061,
	PingMyRespawnBanner = 1062,
	TipRespawnBeacon = 1063,
	FindRespawnBeacon = 1064,
	PingRespawnBeacon = 1065,
	PackupWeaponSlot1WithHUD1 = 1069,
	PackupWeaponSlot2WithHUD1 = 1070,
	PackupWeaponSlotWithHUD2 = 1071,
	DiamondGuide = 1073,
	StrengthenSentinel1WithHUD1 = 1074,
	StrengthenSentinel2WithHUD1 = 1075,
	StrengthenSentinelWithHUD2 = 1076,
	OpenMedicalTurnTable = 1077,
	OpenProjectileTurnTable = 1078,
	Guide_FriendPingItem = 1079,
	Guide_Mozambique = 1080,
	Guide_PingMozambique = 1081,
	RequireBullet = 1082,
	RequireConsumable = 1083,
	RequireBackpack = 1084,
	RequireUpgradeArmor = 1085,
	DrugRecommend = 1094,
	ScriptRescueTeamMate = 1100,
	ScriptPickTeamMateRespawnBanner = 1101,
	ScriptTipRespawnBeacon = 1102,
	ScriptTipKnockdownShield = 1103,
	AmmoNotEnough1WithHUD1 = 1104,
	AmmoNotEnough2WithHUD1 = 1105,
	AmmoNotEnoughWithHUD2 = 1106,
	BatteryRecommend = 1107,
	EInGameGuideID_MAX = 1108
};

// Object Name: Enum AClient.EInGameLodRegionType
enum class EInGameLodRegionType : uint8 {
	NoneRegion = 0,
	WeaponWrapper = 1,
	Character = 2,
	EInGameLodRegionType_MAX = 3
};

// Object Name: Enum AClient.EItemContrainerType
enum class EItemContrainerType : uint8 {
	None = 0,
	Ground = 1,
	TombBox = 2,
	AirDrop = 3,
	CarePackage = 4,
	BackPack = 5,
	Max = 6
};

// Object Name: Enum AClient.EKillDropItemType
enum class EKillDropItemType : uint8 {
	None = 0,
	Weapon = 1,
	WeaponAttachment = 2,
	Ammo = 3,
	Grenades = 4,
	Equipped = 5,
	Consumable = 6,
	Special = 7,
	Max = 8
};

// Object Name: Enum AClient.EKnockdownShieldBtnOperateType
enum class EKnockdownShieldBtnOperateType : uint8 {
	Open = 0,
	Cancel = 1,
	EKnockdownShieldBtnOperateType_MAX = 2
};

// Object Name: Enum AClient.ESelectLegendUIType
enum class ESelectLegendUIType : uint8 {
	None = 0,
	LobbyScene = 1,
	BRSelect = 2,
	TDMSelect = 3,
	RePick = 4,
	ESelectLegendUIType_MAX = 5
};

// Object Name: Enum AClient.EBlackMarketGroupType
enum class EBlackMarketGroupType : uint8 {
	EBlackMarketGroupType_None = 0,
	EBlackMarketGroupType_Weapon = 1,
	EBlackMarketGroupType_Ammunition = 2,
	EBlackMarketGroupType_Attachment = 3,
	EBlackMarketGroupType_Special = 4,
	EBlackMarketGroupType_Consume = 5,
	EBlackMarketGroupType_Equipment = 6,
	EBlackMarketGroupType_Other = 7,
	EBlackMarketGroupType_Recommend = 8,
	EBlackMarketGroupType_MAX = 9
};

// Object Name: Enum AClient.ETeleportState
enum class ETeleportState : uint8 {
	ETeleportState_None = 0,
	ETeleportState_Failed = 1,
	ETeleportState_Succed = 2,
	ETeleportState_MAX = 3
};

// Object Name: Enum AClient.ELockLootType
enum class ELockLootType : uint8 {
	None = 0,
	PickUp = 1,
	AirdropPickUp = 2,
	DynamicBinPickUp = 3,
	AirdropPoint = 4,
	Circle = 5,
	PlaneRoute = 6,
	TrainStartStation = 7,
	LootDronePickUp = 8,
	LootDronePoint = 9,
	Max = 10
};

// Object Name: Enum AClient.EVIPLootCreepsRegion
enum class EVIPLootCreepsRegion : uint8 {
	None = 0,
	MirageShip = 1,
	Airport = 2,
	EVIPLootCreepsRegion_MAX = 3
};

// Object Name: Enum AClient.ELootCreepsSpecialType
enum class ELootCreepsSpecialType : uint8 {
	NormalCreeps = 0,
	VIPCreeps = 1,
	ELootCreepsSpecialType_MAX = 2
};

// Object Name: Enum AClient.ELootCreepsType
enum class ELootCreepsType : uint8 {
	SPIDER = 0,
	INFECTED = 1,
	ELootCreepsType_MAX = 2
};

// Object Name: Enum AClient.ELootType
enum class ELootType : uint8 {
	Default = 0,
	MirageStatic = 1,
	MirageDynamic = 2,
	ELootType_MAX = 3
};

// Object Name: Enum AClient.ELootZoneNameType
enum class ELootZoneNameType : uint8 {
	None = 0,
	Low = 1,
	Mid = 2,
	High = 3,
	Max = 4
};

// Object Name: Enum AClient.ELowAmmoTextState
enum class ELowAmmoTextState : uint8 {
	General = 1,
	NeedReload = 2,
	LowAmmo = 3,
	LowAmmoRed = 4,
	Empty = 5,
	ELowAmmoTextState_MAX = 6
};

// Object Name: Enum AClient.ELuaLaunchEventType
enum class ELuaLaunchEventType : uint8 {
	EVENTID_GAMEUPDATE_INIT = 0,
	EVENTID_GAMEUPDATE_PROGRESS = 1,
	EVENTID_GAMEUPDATE_SUCCESS = 2,
	EVENTID_GAMEUPDATE_FAILED = 3,
	EVENTID_GAMEUPDATE_START = 4,
	EVENTID_GAMEUPDATE_OPENAPPSTORE = 5,
	EVENTID_GAMEUPDATE_INSTALLAPK = 7,
	EVENTID_GAMEUPDATE_CHECK = 9,
	EVENTID_RESUPDATE_CHECK = 10,
	EVENTID_RESUPDATE_START = 11,
	EVENTID_RESUPDATE_STOP = 12,
	EVENTID_RESUPDATE_NOTUPDATE = 13,
	EVENTID_RESUPDATE_SUCCESS = 14,
	EVENTID_RESUPDATE_FAIL = 15,
	EVENTID_PSO_PRECOMPILE_END = 16,
	EVENTID_BACKGROUND_DOWNLOAD_START = 17,
	EVENTID_BACKGROUND_DOWNLOAD_END = 18,
	EVENTID_PUFFER_DIFF_INIT = 101,
	EVENTID_PUFFER_DIFF_START = 102,
	EVENTID_PUFFER_DIFF_PROGRESS = 103,
	EVENTID_PUFFER_DIFF_RESULT = 104,
	EVENTID_PUFFER_DIFF_MERGE = 110,
	EVENTID_MAX = 111
};

// Object Name: Enum AClient.ELuaLobbyEventType
enum class ELuaLobbyEventType : uint8 {
	EVENTID_GAMEUPDATE_INIT = 0,
	EVENTID_GAMEUPDATE_PROGRESS = 1,
	EVENTID_GAMEUPDATE_SUCCESS = 2,
	EVENTID_GAMEUPDATE_FAILED = 3,
	EVENTID_GAMEUPDATE_START = 4,
	EVENTID_GAMEUPDATE_OPENAPPSTORE = 5,
	EVENTID_STORESEQUENCE_FINISH = 6,
	EVENTID_GAMEUPDATE_INSTALLAPK = 7,
	EVENTID_GAMEUPDATE_TSSREPORTDATA = 8,
	EVENTID_GAMEUPDATE_CHECK = 9,
	EVENTID_RESUPDATE_CHECK = 10,
	EVENTID_RESUPDATE_START = 11,
	EVENTID_RESUPDATE_STOP = 12,
	EVENTID_RESUPDATE_NOTUPDATE = 13,
	EVENTID_RESUPDATE_SUCCESS = 14,
	EVENTID_RESUPDATE_FAIL = 15,
	EVENTTD_TRANSLATION_RESULT = 20,
	EVENTID_PUFFER_DIFF_MERGE = 110,
	EVENTID_HTTP_RSP = 140,
	EVENTID_TGPA_DOWNCLOCK = 200,
	ELuaLobbyEventType_MAX = 201
};

// Object Name: Enum AClient.ELuaInGameNetEventType
enum class ELuaInGameNetEventType : uint8 {
	InGameNetEvent_RemoteHostResolved = 1,
	InGameNetEvent_NetworkEstablished = 2,
	InGameNetEvent_NetworkRecovered = 3,
	InGameNetEvent_NetworkPing = 4,
	InGameNetEvent_LongTimeBadPing = 5,
	InGameNetEvent_PingRecovered = 6,
	InGameNetException_EngineNetworkFailure = 7,
	InGameNetException_EngineTravelFailure = 8,
	InGameNetException_CriticalSocketError = 9,
	InGameNetException_ConnectingTimeout = 10,
	InGameNetException_ConnectionClosed = 11,
	InGameNetException_ConnectionLongTimeNoReceived = 12,
	InGameNetException_ActorChannelError = 13,
	ELuaInGameNetEventType_MAX = 14
};

// Object Name: Enum AClient.ELuaApplicationEventType
enum class ELuaApplicationEventType : uint8 {
	EVENTID_APP_Will_Deactivate = 1,
	EVENTID_APP_Has_Reactivated = 2,
	EVENTID_APP_Will_Enter_Background = 3,
	EVENTID_APP_Has_Entered_Foreground = 4,
	EVENTID_APP_Will_Terminate = 5,
	EVENTID_APP_Should_Unload_Resources = 6,
	EVENTID_APP_AudioSession_InterruptionBegan = 7,
	EVENTID_APP_AudioSession_InterruptionEnded = 8,
	EVENTID_APP_MAX = 9
};

// Object Name: Enum AClient.ELuaCppEventType
enum class ELuaCppEventType : int32 {
	EVENTID_NONE = 1,
	EVENTID_FIGHTING_STAGE_CHANGED = 2,
	EVENTID_FIGHTING_TEAMID_CHANGED = 3,
	EVENTID_SHIELD_VALUE = 4,
	EVENTID_HEALTH_VALUE = 5,
	EVENTID_SHOOT_TYPE = 7,
	EVENTID_SHOOT_TYPE_UNLOCK = 8,
	EVENTID_EQUIP_WEAPON = 9,
	EVENTID_TEAMINFO_SYNC = 10,
	EVENTID_AIM_CHANGE = 11,
	EVENTID_ENERGY_SHIELD = 12,
	EVENTID_HEALTH_HEALING = 13,
	EVENTID_LAND_SELECTION = 14,
	EVENTID_NEAR_CARE_PACKAGE = 15,
	EVENTID_PACKAGE_SERVER_LANDING = 16,
	EVENTID_TEAMINFO_USEITEM = 17,
	EVENTID_AUTO_SPRINT_CHANGE = 18,
	EVENTID_TEAMMATELIST_UPDATE = 19,
	EVENTID_CAMPMATELIST_UPDATE = 20,
	EVNETID_SKILL_START = 21,
	EVNETID_SKILL_STOP = 22,
	EVNETID_SKILL_RELEASED = 23,
	EVNETID_SKILL_CD = 24,
	EVNETID_BANGALORE_PASSIVE_ENABLE = 25,
	EVNETID_BANGALORE_PASSIVE_DISABLE = 26,
	EVENTID_SCREEN_RIGHT_OPERATE_STATE = 27,
	EVENTID_SCREEN_RIGHT_DRAG_BEGIN = 29,
	EVENTID_SCREEN_RIGHT_DRAG_MOVING = 30,
	EVENTID_SCREEN_RIGHT_DRAG_END = 31,
	EVENTID_ATTACH_SKILL_UI = 32,
	EVENTID_ATTACH_ALL_SKILL_UI = 33,
	EVENTID_DETACH_ALL_SKILL_UI = 34,
	EVENTID_PLAYER_STATE_CHANGE = 38,
	EVENTID_MOVEMENT_PLAYER_STATE_CHANGE = 39,
	EVENTID_DAMAGETip2D = 40,
	EVENTID_USESYRINGEHEALTH = 41,
	EVENTID_USEBATTERY = 42,
	EVENTID_ZIPLINEGUN_SELECTION = 43,
	EVENTID_SKILL_START_GUNADS = 44,
	EVENTID_SKILL_STOP_GUNADS = 45,
	EVENTID_SHIELD_FILL = 46,
	EVENTID_MONKEYKING_TACTICAL_LAND = 47,
	EVENTID_CAMERAMODE_CHANGE = 55,
	EVENTID_CONTROLMONITOR = 60,
	EVENTID_ChangeMONITORTXT = 61,
	EVENTID_CLICKMONITORFORGAMEPAD = 62,
	EVENTID_SHOWRECOVERBANNERBTN = 86,
	EVENTID_HIDERECOVERBANNERBTN = 87,
	EVENTID_SHOWCROSSHAIRTEXTTIP = 91,
	EVENTID_HIDECROSSHAIRTEXTTIP = 92,
	EVENTID_SHOWFINISHERBTN = 95,
	EVENTID_HIDEFINISHERBTN = 96,
	EVENTID_SHOWCANCELFINISHERBTN = 97,
	EVENTID_HIDECANCELFINISHERBTN = 98,
	EVENTID_SHOWOPENBIGMAPBTN = 99,
	EVENTID_SHOW_MAINSUBUI = 100,
	EVENTID_HIDE_MAINSUBUI = 101,
	EVENTID_PICKUP_UI_MOVE = 107,
	EVENTID_PICKUP_BOX_SELECT = 110,
	EVENTID_OPEN_BIG_MAP = 118,
	EVENTID_SPRINT_UI_STATE = 120,
	EVENTID_DELETE_SKILL = 130,
	EVENTID_INIT_OB_SKILL_UI = 131,
	EVENTID_SKILL_PAUSE = 132,
	EVENTID_SKILL_RESUME = 133,
	EVENTID_SKILL_JUMP_PHASE = 134,
	EVENTID_DRUG_RECOMMEND = 140,
	EVENTID_SKILL_COMMON_TIPS = 141,
	EVENTID_PLAYER_START_PARACHUTE = 200,
	EVENTID_PLAYER_UPDATE_PARACHUTE = 201,
	EVENTID_PLAYER_STOP_PARACHUTE = 202,
	EVENTID_CIRCLE_SAVEZONE_APPRER = 203,
	EVENTID_CIRCLE_BLUE_WARNING = 204,
	EVENTID_CIRCLE_BLUE_RUN = 205,
	EVENTID_PARACHUTE_ENTER_PLANE = 206,
	EVENTID_PARACHUTE_CAN_JUMP = 207,
	EVENTID_PLANE_START = 208,
	EVENTID_PLANE_UPDATE = 209,
	EVENTID_PLANE_END = 210,
	EVENTID_CIRCLE_BACK_TO_SAVE_AREA_TIPS = 211,
	EVENTID_CIRCLE_ARRIVE_IN_SAVE_AREA_TIPS = 212,
	EVENTID_CIRCLE_PLAYER_TO_WHITE_CIRCLE_LINE = 213,
	EVENTID_CIRCLE_HIDE_PLAYER_TO_WHITE_CIRCLE_LINE = 214,
	EVENTID_PARACHUTE_TEAM_REFRESH_LEADER = 215,
	EVENTID_PARACHUTE_TEAM_REFRESH_IN_TEAM_STATUS = 216,
	EVENTID_PLANE_COUNT_DOWN_TIME = 220,
	EVENTID_PLANE_REMAINING_PLAYER_NUM = 221,
	EVENTID_CIRCLE_BLUE_TICK_TIP = 223,
	EVENTID_CIRCLE_BLUE_RUN_END = 224,
	EVENTID_RESET_MINIMAP_SCALE = 225,
	EVENTID_PLAYER_START_MAGMARISE = 226,
	EVENTID_PLAYER_STOP_MAGMARISE = 227,
	EVENTID_CIRCLE_FINISHED = 228,
	EVENTID_GM_SET_BIGMAP_DRAG_MINDST = 229,
	EVENTID_MINIMAP_SAVEZONE_APPRER_NEXTWAVE = 230,
	EVENTID_CIRCLE_PRE_INIT_BLUE_CIRCLE = 231,
	EVENTID_MINIMAP_STATICITEM_VISIBLE = 232,
	EVENTID_MINIMAP_STATICITEM_STATE = 233,
	EVENTID_PLAYER_GOTO_LAND = 234,
	EVENTID_PLANE_EXPRESSION_SHOWORHIDE = 235,
	EVENTID_PLAYER_JUMP_FORM_PLANE = 236,
	EVENTID_PLAYER_JUMP_UI_ICON_FLYOVER = 237,
	EVENTID_PLAYER_JUMP_UI_ICON_WORKBENCH_MARK = 240,
	EVENTID_OPEN_RENDERSETTING_UI = 301,
	EVENTID_HIDE_RENDERSETTING_UI = 302,
	EVENTID_APPLY_SETTING = 303,
	EVENTID_NOTIFICATION_SETTING = 305,
	EVENTID_FORBIDDENZONETIME_ONREP = 311,
	EVENTID_MSDK_NOTICE_NOTICEINFO = 330,
	EVENTID_MSDK_FRIEND_DELIVERMESSAGE = 331,
	EVENTID_PUFFER_INIT_RETURN = 332,
	EVENTID_PUFFER_DOWNLOAD_RETURN = 333,
	EVENTID_PUFFER_DOWNLOAD_PROGRESS = 334,
	EVENTID_PUFFER_RESTORE_RETURN = 335,
	EVENTID_PUFFER_RESTORE_PROGRESS = 336,
	EVENTID_PUFFER_BATCH_RETURN = 337,
	EVENTID_PUFFER_BATCH_PROGRESS = 338,
	EVENTID_PUFFER_DOWNLOAD_IOSBACKGROUND = 339,
	EVENTID_POSTLOWBLOOD_EFFECT = 340,
	EVENTID_POPUPDEATHRESPAWNTIME = 345,
	EVENTID_SHOWTOPBOTTOMBLACK = 346,
	EVENTID_HIDE_PING_ITEM = 353,
	EVENTID_PING_AIMED = 355,
	EVENTID_PING_AIMED_RESET = 356,
	EVENTID_RESPONSE_PING_ITEM = 357,
	EVENTID_CREATE_PING_ITEM_FROM_PICKUP = 358,
	EVENTID_CREATE_TEMP_PING_ITEM = 359,
	EVENTID_MARK_PING_REVERSE = 360,
	EVENTID_TOUCH_MOVING = 361,
	EVENTID_PING_CREATE_UNAVALIBLE = 362,
	EVENTID_PING_AIMED_STATE_CHANGE = 363,
	EVENTID_RESET_PING_ITEM_TIME = 365,
	EVENTID_SMALLEYE_MOVE_EVENT = 370,
	EVENTID_SMALLEYE_ENABLE = 371,
	EVENTID_LEFTPING_VISIBLE_CHANGE = 376,
	EVENTID_SKILL_CONDITION_ERROR = 377,
	EVENTID_BACKPACK_REFRESHCAPACITY = 402,
	EVENTID_BACKPACK_COMPONENTMODIFY = 403,
	EVENTID_BACKPACK_USESKILLITEMFAILED = 412,
	EVENTID_BACKPACK_ITEMUSEFINISHED = 413,
	EVENTID_BACKPACK_OnDropItemSuccess = 414,
	EVENTID_BACKPACK_OnUseItem = 460,
	EVENTID_INGAME_HUDSchemeChange = 417,
	EVENTID_INGAME_PREMAINUICLOSE = 418,
	EVENTID_BACKPACK_RequestPartItem = 430,
	EVENTID_BACKPACK_ShowOperationMenu = 431,
	EVENTID_BACKPACK_FullTip = 432,
	EVENTID_USE_PROJECTILE = 433,
	EVENTID_BACKPACK_OPENCLOSE = 434,
	EVENTID_BACKPACK_OPEN = 435,
	EVENTID_BACKPACK_CLOSE = 436,
	EVENTID_INGAME_BroadCast_Show = 451,
	EVENTID_INGAME_BroadCast_Hide = 452,
	EVENTID_INGAME_THUNERDOMESCREEN = 470,
	EVENTID_INGAME_CHATMSG_NEW_ITEM = 500,
	EVENTID_INGAME_BROADCAST_UPDATE_CHATMSG = 501,
	EVENTID_START_SENDMSG_COOLING = 502,
	EVENTID_INGAME_BROADCAST_SELECT_LEGEND = 503,
	EVENTID_INGAME_CHATCONTENT_FILTER = 504,
	EVENTID_INGAME_SENDMSG_GETITEM = 505,
	EVENTID_INGAME_SENDMSG_STATE = 506,
	EVENTID_STAGE_CHANGE = 550,
	EVENTID_UDP_PING_ONE_FINISHED = 560,
	EVENTID_UDP_PING_ALL_FINISHED = 561,
	EVENTID_TDM_CAMPSCORING = 600,
	EVENTID_TDM_UPDATE_GAMESCORE = 601,
	EVENTID_TDM_START_RESPAWN_TIMER = 602,
	EVENTID_TDM_UPDATE_GAMEPROPERTIES = 603,
	EVENTID_TDM_CHOOSE_EQUIP = 604,
	EVENTID_LOADOUT_UPDATE_CHOOSEWEAPONLIST = 605,
	EVENTID_MULTIPLAYER_UI_STATUS = 606,
	EVENTID_LOADOUT_UPDATE_LOADOUTTABLE = 607,
	EVENTID_CAMPROLE_SWITCH = 608,
	EVENTID_BD_ATTACKER_STATUS_CHANGED = 609,
	EVENTID_BD_DEFENDER_STATUS_CHANGED = 610,
	EVENTID_BD_BOMBSITE_INCREASE = 611,
	EVENTID_BD_BOMBSITE_DECREASE = 612,
	EVENTID_BD_BOMBWRAPPER_INCREASE = 613,
	EVENTID_BD_BOMBWRAPPER_DECREASE = 614,
	EVENTID_BD_BOMBACTOR_INCREASE = 615,
	EVENTID_BD_BOMBACTOR_DECREASE = 616,
	EVENTID_BD_BOMBACTOR_CHANGED = 617,
	EVENTID_BD_BOMBCARRIER_CHANGED = 618,
	EVENTID_MP_SELECTLEGEND_STAGECHANGED = 619,
	EVENTID_VEHICLE_RIDE_SWITCH = 620,
	EVENTID_VEHICLE_DRIVER_SWITCH = 621,
	EVENTID_TDM_UPDATE_MPWEAPONINFO = 622,
	EVENTID_LOADOUT_UPDATE_SHOW_SELECT_LOADOUT = 623,
	EVENTID_ARMSRACE_UPDATE_WEAPON_LV = 624,
	EVENTID_ARMSRACE_SET_LEVEL_ICON = 625,
	EVENTID_ARMSRACE_UPDATE_CAMP_MAX_SCORE = 626,
	EVENTID_NETWORK_STATE_CHANGE_NOTIFY = 627,
	EVENTID_COLOSSEUM_SHOWTIPS = 630,
	EVENTID_COLOSSEUM_SHOW_COUNTDOWNTIPS = 631,
	EVENTID_INBATTLECOMMON_TargetPonit_INCREASE = 700,
	EVENTID_INBATTLECOMMON_TargetPonit_DECREASE = 701,
	EVENTID_NETWORKMISMATCHL = 801,
	EVENTID_NETWORK_UDPPing_RESULT = 802,
	EVENTID_BIGMAP_PING_CLICK = 903,
	EVENTID_MINIMAP_ADD_ACTOR_ITEM = 914,
	EVENTID_MINIMAP_REMOVE_ACTOR_ITEM = 915,
	EVENTID_MINIMAP_UPDATE_ACTOR_ITEM = 916,
	EVENTID_MINIMAP_GM_SHOW_AI_LOC = 919,
	EVENTID_MINIMAP_GM_REMOVE_AI_LOC = 920,
	EVENTID_MINIMAP_RED_CIRCLE_SHOW = 921,
	EVENTID_MINIMAP_WHITE_CIRCLE_SHOW = 922,
	EVENTID_MINIMAP_RED_CIRCLE_SHRINKING = 923,
	EVENTID_MINIMAP_RED_CIRCLE_SHRINKING_PLAYER_UPDATE = 924,
	EVENTID_FIGHTSTATICS_KILLNUM = 1001,
	EVENTID_FIGHTSTATICS_SURVIVE_CHANGE = 1002,
	EVENTID_FIGHTSTATICS_VISITOR_CHANGE = 1003,
	EVENTID_FIGHTSTATICS_RATINGKILLASSISTSCORE_CHANGE = 1004,
	EVENTID_FIGHTSTATICS_DAMAGE = 1005,
	EVENTID_PAWN_RECEIVE = 1100,
	EVENTID_GAMESTATE_END = 1101,
	EVENTID_PLAYER_DEAD = 1102,
	EVENTID_PLAYER_DESTROY = 1103,
	EVENTID_PAWN_CHANGE = 1104,
	EVENTID_GAMESTATE_START = 1105,
	EVENTID_TEST_OPEN_RESULT_WINDOW = 1106,
	EVENTID_NOTIFY_WINTEAM = 1107,
	EVENTID_NOTIFY_BATTLERESULT = 1108,
	EVENTID_TEST_OPEN_REWARD_WINDOW = 1109,
	EVENTID_NOTIFY_SIMPLE_RESULTDATA = 1110,
	EVENTID_LBSIPINFORET = 1990,
	EVENTID_PINCHGESTURE = 2001,
	EVENTID_PINCHGESTURE_START = 2002,
	EVENTID_PINCHGESTURE_END = 2003,
	EVENTID_LOBBY_WEAPON_MOVE = 2004,
	EVENTID_LOBBY_WEAPON_MOVE_END = 2005,
	EVENTID_LOBBY_LEGEND_CLICK = 2006,
	EVENTID_LOBBY_TOUCH_NONE_MOVE = 2007,
	EVENTID_LOBBY_TOUCH_NONE_MOVE_END = 2008,
	EVENTID_LOBBY_CONTAINER_TOUCH_END = 2009,
	EVENTID_UISTATE_CHANGE = 2050,
	EVENTID_GUNSHIELD_ENDPLAY = 2069,
	EVENTID_ZIPLINE_CHANGE = 2070,
	EVENTID_CAREPACKAGE_BTNSTATE_CHANGE = 2071,
	EVENTID_INGAME_JUMP_PRESSED = 2072,
	EVENTID_INGAME_JUMP_RELEASED = 2073,
	EVENTID_OPEN_SURVEY_BEACON = 2074,
	EVENTID_TESLA_TRAP_LAND = 2075,
	EVENTID_TESLA_TRAP_PICK = 2076,
	EVENTID_DIRTY_BOMB_PICK_UI_SHOW = 2077,
	EVENTID_CRYPTO_DRONE_INTO_MODE = 2079,
	EVENTID_CLOSE_MIRAGE_DECOY_CONTROL_BTN = 2080,
	EVENTID_CRYPTO_DRONE_EXIT_MODE = 2081,
	EVENTID_CRYPTO_DRONE_INTO_MODE_START = 2082,
	EVENTID_CRYPTO_DRONE_EXIT_MODE_START = 2083,
	EVENTID_CRYPTO_DRONE_TRIANGLE_UI = 2084,
	EVENTID_CRYPTO_DRONE_ENEMY_BEGIN = 2085,
	EVENTID_CRYPTO_DRONE_ENEMY_END = 2086,
	EVENTID_CRYPTO_DRONE_RELOAD_WEAPON = 2087,
	EVENTID_OPEN_MIRAGE_DECOY_CONTROL_BTN = 2088,
	EVENTID_REOPEN_MIRAGE_DECOY_CONTROL_BTN = 2089,
	EVENTID_REOPEN_MIRAGE_DECOY_UNCONTROL_BTN = 2090,
	EVENTID_Hero03_RESCUE_ROBOTS_CHANGED = 2091,
	EVENTID_CRYPTO_DRONE_DYING_BOMB = 2092,
	EVENTID_CRYPTO_DRONE_ROCKET_BOMB = 2093,
	EVENTID_PlayerState_Changed = 2100,
	EVENTID_PLAYERSTATE_RECEIVED = 2101,
	EVENTID_PLAYERSTATE_INCREASE = 2102,
	EVENTID_PLAYERSTATE_DECREASE = 2103,
	EVENTID_PLAYERSTATE_CONFIRMLEGEND = 2104,
	EVENTID_PLAYER_CHANGE_SKIN = 2210,
	EVENTID_DATA_REPORT = 2310,
	EVENTID_TSS_REPORT_DATA = 2311,
	EVENTID_BATTLE_RESULT_DATA = 2312,
	EVENTID_BATTLE_RESULT_TEAMDATA = 2313,
	EVENTID_BATTLE_RESULT_EAPIN = 2324,
	EVENTID_NOTIFY_SKILL_UI_EVENT = 2400,
	EVENTID_INGAME_Hero10_TESLA_DAMAGE = 2409,
	EVENTID_Hero10_PLACE_PYLON = 2412,
	EVENTID_Hero10_PLACE_PYLON_FAILED = 2413,
	EVENTID_WRAITH_TPP_EFFECT_START = 2414,
	EVENTID_WRAITH_TPP_EFFECT_LOOP = 2415,
	EVENTID_WRAITH_TPP_EFFECT_END = 2416,
	EVENTID_SHOW_SURVEY_BEACON_PROGRASS = 2420,
	EVENTID_LOBA_BLACKMARKET_PICK = 2431,
	EVENTID_LOBA_BLACKMARKET_OPEN = 2432,
	EVENTID_LOBA_BLACKMARKET_LAND = 2433,
	EVENTID_LOBA_BLACKMARKET_MAXDISTANCETOCLOSE = 2434,
	EVENTID_LOBA_BLACKMARKET_INITUI = 2435,
	EVENTID_LOBA_BLACKMARKET_WORKINGTARGET = 2436,
	EVENTID_LOBA_BLACKMARKET_ITEMCLICK = 2437,
	EVENTID_MINIMAP_ADDSTATICITEM = 3101,
	EVENTID_MINIMAP_REMOVESTATICITEM = 3102,
	EVENTID_TARGET_POINT_UPDATE = 3105,
	EVENTID_OB_NEW_TARGET = 3201,
	EVENTID_OB_END = 3202,
	EVENTID_OB_ENTER_RESULT = 3203,
	EVENTID_OB_CANOBCAMERA_CHANGE = 3204,
	EVENTID_OB_TARGET_TEAMMATE_NUMBER_CHANGE = 3303,
	EVENTID_OB_CHARACTER_STATE_CHANGE = 3301,
	EVENTID_NEXTLIFE_30S_TIP = 3402,
	EVENTID_NEXTLIFE_EXPIRED_TIP = 3403,
	EVENTID_NEXTLIFE_120S_TIP = 3404,
	EVENTID_NEXTLIFE_10S_TIP = 3405,
	EVENTID_REPLAY_START = 3501,
	EVENTID_REPLAY_END = 3502,
	EVENTID_REPLAY_VIEWTARGET_CHANGE = 3503,
	EVENTID_REPLAY_RESET_UI = 3504,
	EVENTID_REPLAY_LOADING_UI = 3505,
	EVENTID_GHOST_CHANGE = 4000,
	EVENTID_ONEKEYCLIMB_CHANGE = 4200,
	EVENTID_SPRINTSLIDE_CHANGE = 4201,
	EVENTID_SPRINTDIVE_CHANGE = 4202,
	EVENTID_DEATH_TOTEM_PROTECT = 4203,
	EVENTID_COMMONSIGN_CREATE = 4500,
	EVENTID_COMMONSIGN_DELETE = 4501,
	EVENTID_SETAIMBUTTON_VISIBLE = 4510,
	EVENTID_CONTROLAREA_ACTIVATETIME_UPDATE = 5001,
	EVENTID_CONTROLAREA_CONTROLCAMP_CHNAGED = 5002,
	EVENTID_CONTROLAREA_CONTROLLINGCAMPS_CHANGED = 5003,
	EVENTID_CONTROLAREA_AREASTATUS_CHANGED = 5004,
	EVENTID_WE_UPDATE_CAMP_STATE = 5103,
	EVENTID_WE_UPDATE_OVERTIME = 5104,
	EVENTID_WE_SHOW_ROUND_RESULT = 5105,
	EVENTID_LOOTZONE_SHOWAREANAME = 5200,
	EVENTID_LOOTZONE_SetHotZoneEffect = 5201,
	EVENTID_AIRDROP_SHOWAIRDROPEFFECT = 5210,
	EVENTID_AIRDROP_HIDEAIRDROPEFFECT = 5211,
	EVENTID_AIRDROP_SHOWAIRDROPAREAEFFECT = 5212,
	EVENTID_AIRDROP_SHOWAIRDROPAREAFIRSTEFFECT = 5213,
	EVENTID_HOVERTANK_ADDICON = 5230,
	EVENTID_HOVERTANK_REMOVEICON = 5231,
	EVENTID_UPDATE_ACTIONBUTTONSTATE = 5232,
	EVENTID_UPDATE_ACTIONBUTTON_RENDEROPACITY = 5233,
	EVENTID_SCOPEZOOM_OPEN = 6100,
	EVENTID_SCOPEZOOM_CLOSE = 6101,
	EVENTID_EQUIPSCOPESHORTCUT = 6102,
	EVENTID_CLOSEEQUIPSCOPESHORTCUT = 6103,
	EVENTID_PAWNSTATE_ENTER = 6104,
	EVENTID_UPDATEWEAPONCHARGEBAR = 6105,
	EVENTID_PLAY_SOUND = 7001,
	EVENTID_BLOOD_HOUND_INITIAL_DETECT_COUNT = 7002,
	EVENTID_BLOOD_HOUND_DETECT_ANYONE = 7003,
	EVENTID_BEEN_REVEALED_BY_BLOOD_HOUND = 7004,
	EVENTID_TARGET_BEEN_REVEALED_BY_US_BLOOD_HOUND = 7005,
	EVENTID_BLOOD_HOUND_IS_DETECTING = 7006,
	EVENTID_BLOOD_HOUND_IS_HUNTING = 7007,
	EVENTID_BLOOD_HOUND_LEAVE_HUNTING = 7008,
	EVENTID_BLOOD_HOUND_SHOW_TRACKING_VISION_DETAIL = 7009,
	EVENTID_AUDIO_QUALITY_CHANGE = 7100,
	EVENTID_AUDIO_VOICE_MY_VOLUME_CHANGE = 7200,
	EVENTID_AUDIO_VOICE_TEAMMATE_VOLUME_CHANGE = 7201,
	EVENTID_SHOW_EMOTE_TIP = 7301,
	EVENTID_BUFF_DJ_TECTICAL_SPEEDUP_ADD = 7900,
	EVENTID_BUFF_DJ_TECTICAL_SPEEDUP_REMOVE = 7901,
	EVENTID_BUFF_DJ_ULTIMATE_SPEEDDOWN_ADD = 7902,
	EVENTID_BUFF_DJ_ULTIMATE_SPEEDDOWN_REMOVE = 7903,
	EVENTID_BUFF_DJ_ULTIMATE_VIEWSCROLL_SPEEDDOWN_ADD = 7904,
	EVENTID_BUFF_DJ_ULTIMATE_VIEWSCROLL_SPEEDDOWN_REMOVE = 7905,
	EVENTID_SKILL_POST_MESSAGE_ITEM = 8000,
	EVENTID_BUFF_Hero07_POISON_ADD = 8001,
	EVENTID_BUFF_Hero07_POISON_REMOVE = 8002,
	EVENTID_BUFF_SMOKE_EFFECT_ADD = 8003,
	EVENTID_BUFF_SMOKE_EFFECT_REMOVE = 8004,
	EVENTID_BUFF_CRYPTO_DRONE_EMP_ATTACT_EFFECT = 8009,
	EVENTID_BUFF_CRYPTO_DRONE_EMP_ALERT_EFFECT = 8010,
	EVENTID_BUFF_SNOWBALL_SCREEN_HURT_START = 8013,
	EVENTID_BUFF_SNOWBALL_SCREEN_HURT_END = 8014,
	EVENTID_INGAME_DOUBLEJUMP_START = 7011,
	EVENTID_INGAME_DOUBLEJUMP_END = 7012,
	EVENTID_INGAME_Hero09_Q_EFFECT_START = 7013,
	EVENTID_TIME_TRAVEL_START_DECOY_VANISH = 7014,
	EVENTID_TIME_TRAVEL_STOP_DECOY_VANISH = 7015,
	EVENTID_ASH_SHOW_KILLER_DETAIL = 7016,
	EVENTID_SCREEN_BLUR_ADD = 7017,
	EVENTID_SCREEN_BLUR_REMOVE = 7018,
	EVENTID_SHOW_UI = 7019,
	EVENTID_REFRESH_PLAYER_HUD = 7020,
	EVENTID_COUNTDOWN_START = 7021,
	EVENTID_COUNTDOWN_INTERVAL = 7022,
	EVENTID_COUNTDOWN_STOP = 7023,
	EVENTID_COUNTDOWN_FINISH = 7024,
	EVENTID_CIRCLE_REFRESH = 7025,
	EVENTID_CIRCLE_SYNCTIME = 7026,
	EVENTID_NEWSTOREITEM_UPDATE = 7027,
	EVENTID_TEAMMATE_KILL_CHANGED = 7028,
	EVENTID_TEAMMATE_DAMAGE_CHANGED = 7029,
	EVENTID_TEAMMATE_ASSIST_CHANGED = 7030,
	EVENTID_INIT_JOYTICK_FINISH = 7031,
	EVENTID_MANIFIER_CHANGE_COMPLETE = 7032,
	EVENTID_COMMONSIGN_CREATE_LOCAL = 7033,
	EVENTID_COMMONSIGN_DELETE_LOCAL = 7034,
	EVENTID_SCENE_CAM_MOVE_OVER = 7035,
	EVENTID_SWITCHHUD = 7036,
	EVENTID_RESETUI = 7037,
	EVENTID_SELF_TRACKER_DATA_INIT = 7038,
	EVENTID_SELF_TRACKER_DATA_REPORT = 7039,
	EVENTID_BD_BOMB_PLANT = 7040,
	EVENTID_BD_BOMB_DEFUSE = 7041,
	EVENTID_SKILL_UI_DISABLED_BY_PAWNSTATE = 7042,
	EVENTID_FINISHER_WHITE_LIGHT_STAR = 7043,
	EVENTID_FINISHER_WHITE_LIGHT_END = 7044,
	EVENTID_FINISHER_LOBBY_SEQUENCE = 7045,
	EVENTID_INGAMEGUIDE_EVENT = 7046,
	EVENTID_INGAMEGUIDE_START_STEP = 7047,
	EVENTID_INGAMEGUIDE_FINISH = 7048,
	EVENTID_INGAMEGUIDE_START = 7049,
	EVENTID_INGAMEGUIDE_EXECLUA = 7050,
	EVENTID_INGAMEGUIDE_DATAINIT = 7051,
	EVENTID_INGAMEGUIDE_HIDECURRENTSTEPEFFECT = 7052,
	EVENTID_BAN_DS = 7053,
	EVENTID_BAN_CLIENT_TIP = 7054,
	EVENTID_BAN_CLIENT_TIP_IMMEDITATELY = 7055,
	EVENTID_PSO_PRECOMPILE_END = 7056,
	EVENTID_PLAYER_BEHSTATE_CHANGE = 7057,
	EVENTID_ENCOMY_EXCHANGER_OPEN = 7058,
	EVENTID_ENCOMY_CURRENCY_CHANGE = 7059,
	EVENTID_ENCOMY_CURRENCY_GET = 7060,
	EVENTID_ENCOMY_CURRENCY_ClOSEUI = 7061,
	EVENTID_ENCOMY_EXCHANGERREWARD_RESULT = 7062,
	EVENTID_ENCOMY_RETURNRREWARD_RESULT = 7063,
	EVENTID_ENCOMY_REQUSTCALLBACK = 7064,
	EVENTID_ENCOMY_REQUSTBUYRESULT = 7065,
	EVENTID_ENCOMY_REQUSTCALLBACK_BYOTHER = 7066,
	EVENTID_ENCOMY_BUYTOMATE_CALLBACK = 7067,
	EVENTID_ENCOMY_PLAYERINFO_CALLBACK = 7068,
	AutonomousProxy_INVINCIBLE_CHANGE = 7069,
	EVENTID_QUALITY_MONITOR_INIT = 7070,
	EVENTID_TUTORIAL_GUIDE_VISIBLE = 7071,
	EVENTID_TUTORIAL_GUIDE_START_OR_FINISH = 7072,
	EVENTID_SCREENT_POSION_START = 7073,
	EVENTID_SCREENT_POSION_END = 7074,
	EVENTID_PLAYERSTATE_ROLLBACK_UPDATE_HISTORY = 7075,
	EVENTID_GAMESHOTSCREEN_CAPTURE = 7076,
	EVENTID_RECEIVE_DEATHRECALL_RECORD_BEFORE_BATTLERESULT = 7077,
	EVENTID_LOBBY_WEAPON_MONTAGE_END = 7078,
	EVENTID_PERK_PUT_ON_ID_CHANGED = 7079,
	EVENTID_PERK_ACTIVATE = 7080,
	EVENTID_PERK_TIPS_DATA_CHANGED = 7081,
	EVENTID_CG_MOVIECLIP_FINISHED = 7082,
	EVENTID_CG_MOVIEPLAYBACK_FINISHED = 7083,
	EVENTID_INGAMEGUIDE_DATAINIT_GETLEGENDUSENUM = 7084,
	EVENTID_AVATAR_SKIN_LOADED = 7085,
	EVENTID_TARGET_CHARACTER_GEN = 7086,
	EVENTID_TARGET_CHARACTER_DESTROY = 7087,
	EVENTID_TARGET_HIDDENSTATECHANGE = 7088,
	EVENTID_DELETE_DOCUMENT_AND_PAK = 7089,
	EVENTID_LOBBY_WEAPON_SKIN_MONTAGE_FINISH = 7090,
	EVENTID_SUBJOIN_OB = 7091,
	EVENTID_CP_CAPTUREPOINT_INCREASE = 7092,
	EVENTID_CP_CAPTUREPOINT_DECREASE = 7093,
	EVENTID_CP_CAPTURE_START = 7094,
	EVENTID_CP_CAPTURE_END = 7095,
	EVENTID_FIGHTING_REPORT_START = 7096,
	EVENTID_FIGHTING_REPORT_ENDED = 7097,
	EVENTID_TRACEROUTE_DONE = 7098,
	EVENTID_SPAWN_ACTOR_FINISH_LOBBY = 7099,
	EVENTID_GUNFIGHT_ROUNDITEMID = 7100,
	EVENTID_GUNFIGHT_CLOSEREADYUI = 7101,
	EVENTID_FOH_OPENUI = 7102,
	EVENTID_GAMEPAD_BUTTON_CHANGE = 7103,
	EVENTID_GAMEPAD_ATTACH_CHANGE = 7104,
	EVENTID_SLIDEJUMP_BEGIN = 7105,
	EVENTID_MP_SELECT_INGAME = 7106,
	EVENTID_MAINUI_PRELOAD = 7107,
	EVENTID_CREATE_MAINUI = 7108,
	EVENTID_OPEN_BIGMAP = 7109,
	ELuaCppEventType_MAX = 8015
};

// Object Name: Enum AClient.EMainHandActionType
enum class EMainHandActionType : uint8 {
	ePush = 0,
	ePop = 1,
	eInsert = 2,
	eClear = 3,
	EMainHandActionType_MAX = 4
};

// Object Name: Enum AClient.EMainHandConnectStage
enum class EMainHandConnectStage : uint8 {
	eActive = 0,
	eLost = 1,
	eSendStack = 2,
	EMainHandConnectStage_MAX = 3
};

// Object Name: Enum AClient.EFreeBattleModeType
enum class EFreeBattleModeType : uint8 {
	Mode_2 = 0,
	Mode_3 = 1,
	Mode_4 = 2,
	Mode_5 = 3,
	Mode_6 = 4,
	Mode_MAX = 5
};

// Object Name: Enum AClient.EFireRangePlayerOperatorType
enum class EFireRangePlayerOperatorType : uint8 {
	ClickMenu = 1,
	ChangeSensitivity = 2,
	ChangeLegend = 3,
	EnableReloadNotReduceAmmo = 4,
	DisableReloadNotReduceAmmo = 5,
	EnableShowDistance = 6,
	DisableShowDistance = 7,
	EnableShowHp = 8,
	DisableShowHp = 9,
	EnableShowDamage = 10,
	DisableShowDamage = 11,
	Exit = 12,
	Help = 13,
	ToolbarCollapse = 14,
	TargetDistanceCollapse = 15,
	DragMenu = 16,
	EnableViewAssist = 17,
	DisableViewAssist = 18,
	EFireRangePlayerOperatorType_MAX = 19
};

// Object Name: Enum AClient.EMainTownGameType
enum class EMainTownGameType : uint8 {
	None = 0,
	FreeBattle = 1,
	ShootGame = 2,
	AdvancedGame = 3,
	EMainTownGameType_MAX = 4
};

// Object Name: Enum AClient.EMapPlayerInfoMask
enum class EMapPlayerInfoMask : uint8 {
	Default = 0,
	ValkyrieScan = 1,
	EMapPlayerInfoMask_MAX = 2
};

// Object Name: Enum AClient.EMiniMapCryptoDroneState
enum class EMiniMapCryptoDroneState : uint8 {
	DeActive = 0,
	Active = 1,
	EMiniMapCryptoDroneState_MAX = 2
};

// Object Name: Enum AClient.EMiniMapCausticDirtyBombState
enum class EMiniMapCausticDirtyBombState : uint8 {
	DeActive = 0,
	Active = 1,
	EMiniMapCausticDirtyBombState_MAX = 2
};

// Object Name: Enum AClient.EMiniMapColosseumActorState
enum class EMiniMapColosseumActorState : uint8 {
	Default = 0,
	ActiveOpen = 1,
	ActiveClose = 2,
	Settlment = 3,
	End = 4,
	EMiniMapColosseumActorState_MAX = 5
};

// Object Name: Enum AClient.EMiniMapIceBinActorState
enum class EMiniMapIceBinActorState : uint8 {
	Freezing = 0,
	UnFreezed = 1,
	EMiniMapIceBinActorState_MAX = 2
};

// Object Name: Enum AClient.EMiniMapHarvesterState
enum class EMiniMapHarvesterState : uint8 {
	Normal = 0,
	Extracted = 1,
	EMiniMapHarvesterState_MAX = 2
};

// Object Name: Enum AClient.EMiniMapTreasureDoorState
enum class EMiniMapTreasureDoorState : uint8 {
	Locked = 0,
	Open = 1,
	EMiniMapTreasureDoorState_MAX = 2
};

// Object Name: Enum AClient.EMirageState
enum class EMirageState : uint8 {
	Normal = 0,
	Party = 1,
	None = 2,
	EMirageState_MAX = 3
};

// Object Name: Enum AClient.EChangeState
enum class EChangeState : uint8 {
	Set = 0,
	Remove = 1,
	EChangeState_MAX = 2
};

// Object Name: Enum AClient.EBehavior
enum class EBehavior : uint8 {
	Empty = 0,
	Shoot = 1,
	UnarmedAttacks = 2,
	Pick = 3,
	Zipline = 4,
	Rescue = 5,
	Finisher = 6,
	OnBeacon = 7,
	Runaway = 8,
	OnSurveyBeacon = 9,
	Lock = 10,
	SmallEye = 11,
	GunFire = 12,
	GunReload = 13,
	GunADS = 14,
	HoldingWeapon = 15,
	PutOnWeapon = 16,
	PutOffWeapon = 17,
	RaiseWeapon = 18,
	LowerWeapon = 19,
	EquipAttachment = 20,
	WeaponCharge = 21,
	PickUpList = 22,
	Bolt = 23,
	PlantBomb = 24,
	DefuseBomb = 25,
	BackpackDropItem = 26,
	OpenTreasureDoor = 27,
	EBehavior_MAX = 28
};

// Object Name: Enum AClient.EPendant
enum class EPendant : uint8 {
	Empty = 0,
	Handgun_2 = 1,
	Handgun_3 = 1,
	Shotgun = 2,
	Shield = 3,
	EPendant_MAX = 4
};

// Object Name: Enum AClient.EPose
enum class EPose : uint8 {
	Stand = 0,
	Move = 1,
	Run = 2,
	Jump = 3,
	Grovel = 4,
	Crawl = 5,
	Fly = 6,
	Crouch = 7,
	Sprint = 8,
	Dead = 9,
	Sliding = 10,
	ClimbWall = 11,
	Hanging = 12,
	ClimbOver = 13,
	InAir = 14,
	OneKeyClimb = 15,
	Flying = 16,
	Born = 17,
	Stun = 18,
	Dying = 19,
	Swim = 20,
	InParachute = 21,
	InPlane = 22,
	Scare = 23,
	Backofft = 24,
	Backoff_Left = 25,
	Backoff_Right = 26,
	Tumble = 27,
	Attck_01 = 28,
	Attck_02 = 29,
	Attck_03 = 30,
	Hit_01 = 31,
	Hit_02 = 32,
	Hit_03 = 33,
	Fight_Idle_01 = 34,
	Fight_Idle_02 = 35,
	Fight_Idle_03 = 36,
	Fight_Idle_04 = 37,
	EPose_MAX = 38
};

// Object Name: Enum AClient.EHealth
enum class EHealth : uint8 {
	RightHand = 0,
	LeftHand = 1,
	LeftFoot = 2,
	RightFoot = 3,
	EHealth_MAX = 4
};

// Object Name: Enum AClient.EMotionGroupAssetLoadStage
enum class EMotionGroupAssetLoadStage : uint8 {
	eNotBegin = 0,
	eLoading = 1,
	eSucceed = 2,
	EMotionGroupAssetLoadStage_MAX = 3
};

// Object Name: Enum AClient.EMotionAssetLifeCycleType
enum class EMotionAssetLifeCycleType : uint8 {
	eTemporary = 0,
	eCharacterAsset = 1,
	eWorldAsset = 2,
	eGameAsset = 3,
	EMotionAssetLifeCycleType_MAX = 4
};

// Object Name: Enum AClient.EMovementFallingAction
enum class EMovementFallingAction : uint8 {
	None = 0,
	Default = 1,
	SlidingJump = 2,
	JumpPadPreJump = 3,
	JumpPadRealJump = 4,
	JumpPadAirJump = 5,
	JumpPadLandJump = 6,
	GrapplingHook = 7,
	ZipLine = 8,
	Fountain = 9,
	VoidMover = 10,
	ParachuteCannon = 11,
	EMovementFallingAction_MAX = 12
};

// Object Name: Enum AClient.EMovementAttribute
enum class EMovementAttribute : uint8 {
	BaseSpeedScale = 0,
	WeaponSpeedScale = 1,
	EMovementAttribute_MAX = 2
};

// Object Name: Enum AClient.EMPMateNameStatus
enum class EMPMateNameStatus : uint8 {
	None = 0,
	Normal = 1,
	Invisible = 2,
	OverDistance = 3,
	OutViewport = 4,
	EMPMateNameStatus_MAX = 5
};

// Object Name: Enum AClient.EVOSoundType
enum class EVOSoundType : uint8 {
	Other = 0,
	Bc = 1,
	Ping = 2,
	EVOSoundType_MAX = 3
};

// Object Name: Enum AClient.EMsgPlayer
enum class EMsgPlayer : uint8 {
	System = 0,
	Trigger = 1,
	Receiver = 2,
	Relevantor = 3,
	Enemy = 4,
	EMsgPlayer_MAX = 5
};

// Object Name: Enum AClient.EBroadcastType
enum class EBroadcastType : uint8 {
	Owner = 0,
	Team = 1,
	All = 2,
	Range = 3,
	Default = 4,
	EBroadcastType_MAX = 5
};

// Object Name: Enum AClient.EMsgTriggerConditionType
enum class EMsgTriggerConditionType : uint8 {
	None = 0,
	InRange = 1,
	EMsgTriggerConditionType_MAX = 2
};

// Object Name: Enum AClient.EMsgReceiverType
enum class EMsgReceiverType : uint8 {
	Owner = 0,
	Specific = 1,
	Team = 2,
	All = 3,
	Condition = 4,
	Enemy = 5,
	EMsgReceiverType_MAX = 6
};

// Object Name: Enum AClient.EMsgTriggerType
enum class EMsgTriggerType : uint8 {
	None = 0,
	Specific = 1,
	RandOneEachTeam = 2,
	RandOneInTeammate = 3,
	Condition = 4,
	RandOneEachTeamExclude = 5,
	RandOneInTeammateExclude = 6,
	EMsgTriggerType_MAX = 7
};

// Object Name: Enum AClient.EStateNetType
enum class EStateNetType : uint8 {
	Loacal = 0,
	Server = 1,
	Client = 2,
	EStateNetType_MAX = 3
};

// Object Name: Enum AClient.EOBUIPingBtnState
enum class EOBUIPingBtnState : uint8 {
	None = 0,
	PingSelf = 1,
	PingBeacon = 2,
	EOBUIPingBtnState_MAX = 3
};

// Object Name: Enum AClient.EOctaneStimActiveState
enum class EOctaneStimActiveState : uint8 {
	None = 0,
	Active = 1,
	Completed = 2,
	EOctaneStimActiveState_MAX = 3
};

// Object Name: Enum AClient.EOutlineEffectType
enum class EOutlineEffectType : uint8 {
	EOT_Invalid = 0,
	EOT_CharacterFriendly = 1,
	EOT_CausticDirtyBombYellow = 3,
	EOT_BloodHoundReveal = 4,
	EOT_BloodHoundHunting = 5,
	EOT_CryptoDroneSelf = 11,
	EOT_CryptoSpyOn = 12,
	EOT_CommonPing = 20,
	EOT_BloodHoundRevealAndHunting = 25,
	EOT_ItemFriendly = 26,
	EOT_BloodHoundSonar = 32,
	EOT_BloodHoundSelfHunting = 33,
	EOT_CasticPoisionYellow = 34,
	EOT_CausticDirtyBombRed = 35,
	EOT_CasticPoisionRed = 36,
	EOT_ItemEnemy = 38,
	EOT_CharacterEnemy = 59,
	EOT_MirageUltimate = 62,
	EOT_CryptoDronePlayer = 63,
	EOT_PhantomVoidEnemy = 67,
	EOT_PhantomVoidTeammate = 73,
	EOT_BinActor = 75,
	EOT_CryptoDroneSpyBin = 76,
	EOT_TPPCausticInGasEffect = 83,
	EOT_CasticPoisionRed_Perk = 87,
	EOT_CasticPoisionYellow_Perk = 88,
	EOT_ReplayTargetEnemy = 93,
	EOT_TPPAddSmokeEffect = 97,
	EOT_FirstPlayer = 99,
	EOT_MAX = 100
};

// Object Name: Enum AClient.EOutlineSourceType
enum class EOutlineSourceType : uint8 {
	EOST_Friendly = 0,
	EOST_Enemy = 1,
	EOST_Wattson = 2,
	EOST_Ping = 3,
	EOST_SmokeBomb = 4,
	EOST_CausticPosion = 5,
	EOST_CryptoDrone = 6,
	EOST_BloodHound = 7,
	EOST_DeathBox = 8,
	EOST_PickupItem = 9,
	EOST_MirageUltimate = 10,
	EOST_PhantomUltimate = 11,
	EOST_RespawnBeacon = 12,
	EOST_LoaPassive = 13,
	EOST_AshTactical = 14,
	EOST_HorizonBlackHole = 15,
	EOST_MAX = 32
};

// Object Name: Enum AClient.EParachuteTeamBtnType
enum class EParachuteTeamBtnType : uint8 {
	Leave = 0,
	Join = 1,
	EParachuteTeamBtnType_MAX = 2
};

// Object Name: Enum AClient.PartycleBoxKillType
enum class PartycleBoxKillType : uint8 {
	KillInside = 0,
	KillOutside = 1,
	PartycleBoxKillType_MAX = 2
};

// Object Name: Enum AClient.ESingleType
enum class ESingleType : uint8 {
	None = 0,
	Shoot = 1,
	Sight = 2,
	Max = 3
};

// Object Name: Enum AClient.ERoleType
enum class ERoleType : uint8 {
	None = 0,
	SimulatedProxy = 1,
	AutonomousProxy = 2,
	Max = 3
};

// Object Name: Enum AClient.EPersonalType
enum class EPersonalType : uint8 {
	None = 0,
	FPP = 1,
	TPP = 2,
	Max = 3
};

// Object Name: Enum AClient.EParticleSystemContainerType
enum class EParticleSystemContainerType : uint8 {
	None = 0,
	OpenFire = 1,
	Max = 2
};

// Object Name: Enum AClient.EPartyStageMeterialParamType
enum class EPartyStageMeterialParamType : uint8 {
	ELinearColorType = 0,
	EScalarValueType = 1,
	EPartyStageMeterialParamType_MAX = 2
};

// Object Name: Enum AClient.EPartyStageType
enum class EPartyStageType : uint8 {
	DJPartyStage = 0,
	EPartyStageType_MAX = 1
};

// Object Name: Enum AClient.EStageDeactiveReason
enum class EStageDeactiveReason : uint8 {
	NormalPhaseAllOver = 0,
	ForceDeactive = 1,
	EStageDeactiveReason_MAX = 2
};

// Object Name: Enum AClient.EStageActionType
enum class EStageActionType : uint8 {
	Animation = 0,
	MaterialChange = 1,
	MaterialColor = 2,
	StartStageSound = 3,
	StopStageSound = 4,
	ParticleShow = 5,
	SpawnSomeActor = 6,
	AddBuff = 7,
	RemoveBuff = 8,
	AddCureSelfBuff = 9,
	AddCureSelfBuffVolume = 10,
	RemoveCureSelfBuff = 11,
	ShowComponent = 12,
	HideComponent = 13,
	SpawnLoot = 14,
	Dither = 15,
	LevelSequence = 16,
	StopAnimation = 17,
	PlaySoundAtLoc = 18,
	MAX = 19
};

// Object Name: Enum AClient.EApexPathfinderMonitorPawnStateType
enum class EApexPathfinderMonitorPawnStateType : uint8 {
	PawnState_Sprint_Forward = 0,
	PawnState_Move_Backward = 1,
	PawnState_Crouch = 2,
	PawnState_Move = 3,
	PawnState_Max = 4
};

// Object Name: Enum AClient.EApexPathfinderMonitorType
enum class EApexPathfinderMonitorType : uint8 {
	Display_Happy = 0,
	Display_Laugh = 1,
	Display_Frightened = 2,
	Display_Blank = 3,
	Display_KO = 4,
	Display_Angry = 5,
	Display_Glitch = 6,
	Display_BlueScreen = 7,
	Display_Thinking = 8,
	Display_ThumbsUp = 9,
	Display_Love = 10,
	Display_Sad = 11,
	Display_Num = 12,
	Display_Idle = 13,
	Display_MAX = 14
};

// Object Name: Enum AClient.EGrapplingHookRole
enum class EGrapplingHookRole : uint8 {
	NotDefine = 0,
	Caster = 1,
	Victim = 2,
	EGrapplingHookRole_MAX = 3
};

// Object Name: Enum AClient.EGrapplingHookStringType
enum class EGrapplingHookStringType : uint8 {
	Linear_Bezier_Curves = 0,
	Quadratic_Bezier_Curves = 1,
	Cubic_Bezier_Curves = 2,
	EGrapplingHookStringType_MAX = 3
};

// Object Name: Enum AClient.EGrapplingHookProjectileEndReason
enum class EGrapplingHookProjectileEndReason : uint8 {
	None = 0,
	Blocking = 1,
	Overlaping = 2,
	Reach_Target = 3,
	Interupting = 4,
	EGrapplingHookProjectileEndReason_MAX = 5
};

// Object Name: Enum AClient.EGrapplingHookState
enum class EGrapplingHookState : uint8 {
	INVALID_STATE = 0,
	Not_Ready = 1,
	Preparing = 2,
	Targeting = 3,
	Launching = 4,
	Pulling = 5,
	Withdrawing = 6,
	Finishing = 7,
	STATE_NUM = 8,
	EGrapplingHookState_MAX = 9
};

// Object Name: Enum AClient.EGrapplingHookTargetStatus
enum class EGrapplingHookTargetStatus : uint8 {
	TargetNotFound = 0,
	TargetInvalid = 1,
	TargetValid = 2,
	SubTargetValid = 3,
	TargetStatusNum = 4,
	EGrapplingHookTargetStatus_MAX = 5
};

// Object Name: Enum AClient.EPerkTipType
enum class EPerkTipType : uint8 {
	None = 0,
	Perk = 1,
	BangalorePassive = 2,
	WraithPassive = 3,
	WattsonUltimate = 4,
	LobaTactics = 5,
	EPerkTipType_MAX = 6
};

// Object Name: Enum AClient.EPhantomRecordStatus
enum class EPhantomRecordStatus : uint8 {
	EPHANTOMRECORDSTATUS_UNKOWN = 0,
	EPHANTOMRECORDSTATUS_RECORDING = 1,
	EPHANTOMRECORDSTATUS_BRAID = 2,
	EPHANTOMRECORDSTATUS_MAX = 3
};

// Object Name: Enum AClient.EForbiddenDropItemReason
enum class EForbiddenDropItemReason : uint8 {
	None = 0,
	ExcerciseMode = 1,
	EForbiddenDropItemReason_MAX = 2
};

// Object Name: Enum AClient.EForbiddenPickupReason
enum class EForbiddenPickupReason : uint8 {
	None = 0,
	ExcerciseMode = 1,
	ValkyrieSkywardDive = 2,
	EForbiddenPickupReason_MAX = 3
};

// Object Name: Enum AClient.EPickupCheckType
enum class EPickupCheckType : uint8 {
	PCT_None = 0,
	PCT_CheckActor = 1,
	PCT_CheckActorBox = 2,
	PCT_ActorEffect = 3,
	PCT_PickupUI = 4,
	PCT_AutoPickup = 5,
	PCT_CombData = 6,
	PCT_ReLocation = 7,
	PCT_MAX = 8
};

// Object Name: Enum AClient.EPickupDistType
enum class EPickupDistType : uint8 {
	PDT_None = 0,
	PDT_AroundActor = 1,
	PDT_EffectActor = 2,
	PDT_AroundActorBox = 3,
	PDT_NotInTeam = 4,
	PDT_MAX = 5
};

// Object Name: Enum AClient.EItemPickUpableState
enum class EItemPickUpableState : uint8 {
	None = 0,
	Disable = 1,
	Click = 2,
	LongClick = 3,
	All = 4,
	EItemPickUpableState_MAX = 5
};

// Object Name: Enum AClient.EPickUpClientErrorCode
enum class EPickUpClientErrorCode : uint8 {
	HaveBetterArmor = 1,
	HaveThisEquipped = 2,
	HaveBetterHelmet = 3,
	HaveBetterBackpack = 4,
	HaveBetterKnockdownShield = 5,
	EPickUpClientErrorCode_MAX = 6
};

// Object Name: Enum AClient.EPickupShowState
enum class EPickupShowState : uint8 {
	PSS_Hide = 0,
	PSS_ShowTop = 1,
	PSS_ShowNear = 2,
	PSS_ShowTom = 3,
	PSS_MAX = 4
};

// Object Name: Enum AClient.FBuildingType
enum class FBuildingType : uint8 {
	BT_Normal = 0,
	BT_Bin = 1,
	BT_Max = 2
};

// Object Name: Enum AClient.FLootZoneType
enum class FLootZoneType : uint8 {
	None = 0,
	HotZone = 1,
	MediumZone = 2,
	LowZone = 3,
	Custom = 4,
	FLootZoneType_MAX = 5
};

// Object Name: Enum AClient.EPickupOutlineRenderLevel
enum class EPickupOutlineRenderLevel : uint8 {
	Rough = 0,
	Smooth = 1,
	Balance = 2,
	HD = 3,
	UltraHD = 4,
	ExtremeHD = 5,
	Original = 6,
	EPickupOutlineRenderLevel_MAX = 7
};

// Object Name: Enum AClient.EPickupItemReportType
enum class EPickupItemReportType : uint8 {
	None = 0,
	HoverTank = 1,
	LootBinDynamic = 2,
	LootBinDrawer = 3,
	TTOColosseum = 4,
	KillExtraDrop = 5,
	Max = 6
};

// Object Name: Enum AClient.EQuickReplaceItem
enum class EQuickReplaceItem : uint8 {
	BackPack = 0,
	Weapon1 = 1,
	Weapon2 = 2,
	EQuickReplaceItem_MAX = 3
};

// Object Name: Enum AClient.EPingDataReportObjectType
enum class EPingDataReportObjectType : uint8 {
	None = 0,
	Grould = 1,
	Enemy = 2,
	Item = 3,
	SceneObject = 4,
	BloodHound = 5,
	Others = 6,
	EPingDataReportObjectType_MAX = 7
};

// Object Name: Enum AClient.EPingDataReportType
enum class EPingDataReportType : uint8 {
	None = 0,
	ScreenClick = 1,
	QuickClick = 2,
	RoundClick = 3,
	ChatClick = 4,
	BubbleClick = 5,
	OtherResponse = 6,
	Others = 10,
	EPingDataReportType_MAX = 11
};

// Object Name: Enum AClient.EPingUIActionType
enum class EPingUIActionType : uint8 {
	Open = 1,
	Back = 2,
	Hover = 3,
	Conform = 4,
	EPingUIActionType_MAX = 5
};

// Object Name: Enum AClient.EFromMakeType
enum class EFromMakeType : uint8 {
	None = 0,
	Normal = 1,
	Jump = 2,
	BigMap = 3,
	AttackEnemy = 4,
	AutoMarkEnemy = 5,
	EFromMakeType_MAX = 6
};

// Object Name: Enum AClient.EPingActionType
enum class EPingActionType : uint8 {
	None = 0,
	Add = 1,
	Delete = 2,
	Delay = 3,
	Response = 4,
	CancelReserve = 5,
	Reset = 6,
	ClearByPlayerKey = 7,
	EPingActionType_MAX = 8
};

// Object Name: Enum AClient.EPingVisualType
enum class EPingVisualType : uint8 {
	Normal = 1,
	Item = 2,
	Weapon = 3,
	BigMap = 4,
	MiniMap = 5,
	Skill = 6,
	SkillCD = 7,
	EPingVisualType_MAX = 8
};

// Object Name: Enum AClient.EAxisType
enum class EAxisType : uint8 {
	None = 0,
	X = 1,
	Y = 2,
	Z = 3,
	EAxisType_MAX = 4
};

// Object Name: Enum AClient.EHitPositionDetailed
enum class EHitPositionDetailed : uint8 {
	None = 0,
	Head = 1,
	Body = 2,
	LeftArm = 3,
	RightArm = 4,
	LeftThigh = 5,
	RightThigh = 6,
	EHitPositionDetailed_MAX = 7
};

// Object Name: Enum AClient.EHitDamagePositionAI
enum class EHitDamagePositionAI : uint8 {
	Non = 0,
	Head = 1,
	Body = 2,
	LeftArm = 3,
	RightArm = 4,
	LeftThigh = 5,
	RightThigh = 6,
	EHitDamagePositionAI_MAX = 7
};

// Object Name: Enum AClient.EPlayerLoadoutStatus
enum class EPlayerLoadoutStatus : uint8 {
	None = 0,
	ChooseLoadout = 1,
	ChooseWeapon = 2,
	ChooseOver = 3,
	EPlayerLoadoutStatus_MAX = 4
};

// Object Name: Enum AClient.EPlayerTombBoxSpawnReason
enum class EPlayerTombBoxSpawnReason : uint8 {
	Normal = 0,
	FallingOutDeath = 1,
	LeviathanTrample = 2,
	ReSpawn = 3,
	EPlayerTombBoxSpawnReason_MAX = 4
};

// Object Name: Enum AClient.EHealingSelfType
enum class EHealingSelfType : uint8 {
	OnlyHp = 0,
	OnlyShield = 1,
	HpFirst = 2,
	ShieldFirst = 3,
	OnlyHpWithShieldBreak = 4,
	OnlyShieldWithShieldBreak = 5,
	HpFirstWithShieldBreak = 6,
	ShieldFirstWithShieldBreak = 7,
	EHealingSelfType_MAX = 8
};

// Object Name: Enum AClient.EOutUseReplicatorReason
enum class EOutUseReplicatorReason : uint8 {
	Normal = 0,
	ByRepByNoUsing = 1,
	ByTakeDamage = 2,
	ByLeaveState = 3,
	ByNetLost = 4,
	ByPlayerMoving = 5,
	ByCantEnterState = 6,
	ByConfigError = 7,
	EOutUseReplicatorReason_MAX = 8
};

// Object Name: Enum AClient.EUseReplicatorState
enum class EUseReplicatorState : uint8 {
	NoUsing = 0,
	ReadyToUsing = 1,
	Using = 2,
	EUseReplicatorState_MAX = 3
};

// Object Name: Enum AClient.EPlayerAddForceType
enum class EPlayerAddForceType : uint8 {
	OneDirection = 0,
	FromOnePoint = 1,
	EPlayerAddForceType_MAX = 2
};

// Object Name: Enum AClient.EInOutHeatShieldReason
enum class EInOutHeatShieldReason : uint8 {
	HeatShield = 0,
	DomeShield = 1,
	EInOutHeatShieldReason_MAX = 2
};

// Object Name: Enum AClient.ELutUseSource
enum class ELutUseSource : uint8 {
	None = 0,
	UseFromGamePlay = 1,
	UseFromSkill = 2,
	UseFromWraithTac = 3,
	UseFromTransfer = 4,
	UseFromPhantomTac = 5,
	UseFromPhantomUlt = 6,
	MaxIndex = 63,
	ELutUseSource_MAX = 64
};

// Object Name: Enum AClient.EMeshCollisionResponseSource
enum class EMeshCollisionResponseSource : uint8 {
	None = 0,
	EMeshCollisionResponseSource_MAX = 1
};

// Object Name: Enum AClient.EMeshDitherSource
enum class EMeshDitherSource : uint8 {
	None = 0,
	FromNearWall = 1,
	SkillAction = 2,
	VoidMover = 3,
	InvisibleEffect = 4,
	PhantomVoid = 5,
	CryptoDronePerk = 6,
	GM = 7,
	MaxIndex = 32,
	EMeshDitherSource_MAX = 33
};

// Object Name: Enum AClient.EMeshUseSource
enum class EMeshUseSource : uint8 {
	None = 0,
	UseFromCameraMode = 1,
	UseFromBombDefender = 2,
	UseFromEmoji = 3,
	UseFromCharacterMovement = 4,
	UseFromEnterVoid = 5,
	UseFromUseDrone = 6,
	UseFromPhantom = 7,
	UseFromRescue = 8,
	UseFromParachute = 9,
	UseFromSequencer = 10,
	UseFromAiming = 11,
	UseFromRespawn = 12,
	UseFromDeath = 13,
	UseFromInspectWeapon = 14,
	UseFromUseReplicator = 15,
	UseFromSkillAction = 16,
	UseFromNotViewTarget = 17,
	MaxIndex = 63,
	EMeshUseSource_MAX = 64
};

// Object Name: Enum AClient.EMeshHiddenSource
enum class EMeshHiddenSource : uint8 {
	None = 0,
	HiddenFromCameraMode = 1,
	HiddenFromDistance = 2,
	HiddenFromGM = 3,
	HiddenFromGuide = 4,
	HiddenFromCryptoSkill = 5,
	HiddenFromFinisherLobby = 6,
	HiddenFromFinisher = 7,
	HiddenFromPhantom = 8,
	HiddenFromClimbing = 9,
	HiddenFromActorHidden = 10,
	HiddenFormJumpPlane = 11,
	HiddenFromAntiPeek = 12,
	HiddenFromShadowTutorial = 13,
	HiddenFromTeamMate = 14,
	MaxIndex = 63,
	EMeshHiddenSource_MAX = 64
};

// Object Name: Enum AClient.EBattleCharacterType
enum class EBattleCharacterType : int32 {
	None = 0,
	BC_megaKill = 1001,
	BC_anotherSquadAttackingUs = 1002,
	BC_arcStar = 1003,
	BC_challengerEliminated = 1004,
	BC_championEliminated = 1005,
	BC_congratsKill = 1006,
	BC_damageEnemy = 1007,
	BC_enemyGrenade = 1008,
	BC_engagingEnemy = 1009,
	BC_firstBlood = 1010,
	BC_frag = 1011,
	BC_gotFriendlyBanner = 1012,
	BC_healing = 1013,
	BC_iBecomeKillLeader = 1014,
	BC_iDownedAnEnemy = 1015,
	BC_iDownedAnotherEnemy = 1016,
	BC_iDownedMultiple = 1017,
	BC_iKilledAnEnemy = 1018,
	BC_iKilledAnEnemyWithHeirloom = 1019,
	BC_imDown = 1020,
	BC_killLeaderNew = 1021,
	BC_legendsLeft2_solo = 1022,
	BC_legendsLeft3_solo = 1023,
	BC_legendsLeftHalf_solo = 1024,
	BC_reload = 1025,
	BC_returnFromRespawn = 1026,
	BC_reviveSelf = 1027,
	BC_reviveThanks = 1028,
	BC_revivingPlayer = 1029,
	BC_squadKill = 1030,
	BC_squadmateBecomesKillLeader = 1031,
	BC_squadsLeft2 = 1032,
	BC_squadsLeft3 = 1033,
	BC_squadsLeftHalf = 1034,
	BC_squadTeamWipe = 1035,
	BC_takingDamage = 1036,
	BC_takingFire = 1037,
	BC_thermite = 1038,
	BC_twoSquaddiesLeft = 1039,
	BC_usingShieldCell = 1040,
	BC_weAreChallengerSquad = 1041,
	BC_weAreChampionSquad = 1042,
	BC_weKilledChallenger = 1043,
	BC_weKilledChampion = 1044,
	BC_weKilledKillLeader = 1045,
	BC_weTookFirstBlood = 1046,
	BC_effort_land = 1047,
	BC_effort_landhigh = 1048,
	BC_effort_wallmantlebelow = 1049,
	BC_effort_climb = 1050,
	BC_effort_pain = 1051,
	BC_effort_death = 1052,
	BC_effort_cough = 1053,
	BC_effort_melee = 1054,
	BC_effort_meleestrong = 1055,
	BC_respawnBeaconDeploy = 1056,
	BC_UseEmoji3D = 1057,
	BC_UseEmojiAnimation = 1058,
	BC_revivingPlayerInBubble = 1059,
	BC_snowBall = 1060,
	BC_heatShieldDeploy = 1061,
	EBattleCharacterType_MAX = 1062
};

// Object Name: Enum AClient.EThrowablePropsPhase
enum class EThrowablePropsPhase : uint8 {
	Init = 0,
	HighAim = 1,
	LowAim = 2,
	Launch = 3,
	EThrowablePropsPhase_MAX = 4
};

// Object Name: Enum AClient.EFinisherEndState
enum class EFinisherEndState : uint8 {
	NoEnd = 0,
	Normal = 1,
	Interrupt = 2,
	SourceDead = 3,
	TargetDead = 4,
	InterruptByDamage = 5,
	EFinisherEndState_MAX = 6
};

// Object Name: Enum AClient.ERespawnOperateAudio
enum class ERespawnOperateAudio : uint8 {
	Begin = 0,
	End = 1,
	Success = 2,
	ERespawnOperateAudio_MAX = 3
};

// Object Name: Enum AClient.EPlayerNextLifeRespawnState
enum class EPlayerNextLifeRespawnState : uint8 {
	Normal = 0,
	WaitRespawn = 1,
	CanRespawn = 2,
	RespawnEnd = 3,
	EPlayerNextLifeRespawnState_MAX = 4
};

// Object Name: Enum AClient.EGrenadeType
enum class EGrenadeType : uint8 {
	UnknownGrenade = 0,
	StunGrenade = 1,
	FireGrenade = 2,
	SmokeGrenade = 3,
	FragGrenade = 4,
	AppleGrenade = 5,
	MagicDanceGrenade = 6,
	RainforcementGrenade = 7,
	CG_StunGrenade = 8,
	CG_FireGrenade = 9,
	CG_SmokeGrenade = 10,
	CG_FragGrenade = 11,
	CG_StinkGrenade = 12,
	CG_FireWorksGrenade = 13,
	CG_ToyApple = 14,
	CG_SingerDoll = 15,
	SnowballGrenade = 16,
	PumpkinGrenade = 17,
	ReservedGrenade1 = 18,
	ReservedGrenade2 = 19,
	ReservedGrenade3 = 20,
	ReservedGrenade4 = 21,
	GrenadeMax = 22,
	EGrenadeType_MAX = 23
};

// Object Name: Enum AClient.EThrowGrenadeMode
enum class EThrowGrenadeMode : uint8 {
	HighThrowMode = 0,
	LowThrowMode = 1,
	EThrowGrenadeMode_MAX = 2
};

// Object Name: Enum AClient.EParachuteEffectType
enum class EParachuteEffectType : uint8 {
	None = 0,
	Body = 1,
	BodySideL = 2,
	BodySideR = 3,
	LongTrail = 4,
	NormalTrailL = 5,
	NormalTrailR = 6,
	MAX = 7
};

// Object Name: Enum AClient.EMParticleEffectType
enum class EMParticleEffectType : int32 {
	None = -1,
	NoneScriptType = 0,
	CameraEffect_InCirclePoison = 1,
	CameraEffect_Max = 500,
	Max = 5000
};

// Object Name: Enum AClient.EProvingState
enum class EProvingState : uint8 {
	Ready = 0,
	Proving = 1,
	Finished = 2,
	Prohibit = 3,
	EProvingState_MAX = 4
};

// Object Name: Enum AClient.EPveRespawnType
enum class EPveRespawnType : uint8 {
	NO_RESPAWN = 0,
	RESPAWN_AT_START = 1,
	RESPAWN_KEEP_LOCATION = 2,
	EPveRespawnType_MAX = 3
};

// Object Name: Enum AClient.ERecoverPropRecoveryReasonType
enum class ERecoverPropRecoveryReasonType : uint8 {
	eMedicine = 0,
	eEnergy = 1,
	eRescueByTeammate = 2,
	eRevival = 3,
	eFinisher = 4,
	eMax = 5,
	ERecoverPropRecoveryReasonType_MAX = 6
};

// Object Name: Enum AClient.ERecoverPropBuffType
enum class ERecoverPropBuffType : uint8 {
	eDirectly = 0,
	eExtraPercent = 1,
	ERecoverPropBuffType_MAX = 2
};

// Object Name: Enum AClient.ERecoverPropStage
enum class ERecoverPropStage : uint8 {
	eNone = 0,
	eUsing = 1,
	eWaitServer = 2,
	ERecoverPropStage_MAX = 3
};

// Object Name: Enum AClient.ERecoverPropExecuteEnd
enum class ERecoverPropExecuteEnd : uint8 {
	eAll = 0,
	eClient = 1,
	eServer = 2,
	eAutonomous = 3,
	eSimulated = 4,
	ERecoverPropExecuteEnd_MAX = 5
};

// Object Name: Enum AClient.ERecoverPropPhaseType
enum class ERecoverPropPhaseType : uint8 {
	eNone = 0,
	eNormal = 1,
	eCancel = 2,
	ERecoverPropPhaseType_MAX = 3
};

// Object Name: Enum AClient.ERecoverPropUseType
enum class ERecoverPropUseType : uint8 {
	eUsingNew = 0,
	eUsingEnd = 1,
	eCancel = 2,
	eStartTimeAlignError = 3,
	eEndTimeAlignError = 4,
	eStartFailed = 5,
	eInterrupt = 6,
	eServerStartNew = 7,
	ERecoverPropUseType_MAX = 8
};

// Object Name: Enum AClient.ERecoverPropErrorCode
enum class ERecoverPropErrorCode : uint8 {
	eOK = 0,
	eFullHealth = 1,
	eUnequiped = 2,
	eFullArmor = 3,
	eHealthAndArmorFull = 4,
	eUltimateSkillReady = 5,
	eRecoverInUsing = 6,
	eInDeathProjectState = 7,
	eTotemSpaceLimited = 8,
	eInterrupt = 9,
	eTimeAlignError = 10,
	eEndTimeAlignError = 11,
	eError = 12,
	ERecoverPropErrorCode_MAX = 13
};

// Object Name: Enum AClient.EResCachePoolType
enum class EResCachePoolType : uint8 {
	Normal = 0,
	UIBP = 1,
	Weapon = 2,
	Skill = 3,
	EResCachePoolType_MAX = 4
};

// Object Name: Enum AClient.EAsyncLoadReason
enum class EAsyncLoadReason : uint8 {
	HandleIsInvalid = 0,
	AssetsIsInvalid = 1,
	WasCanceled = 2,
	WasReleased = 3,
	WasFinished = 4,
	UserCanceled = 5,
	EAsyncLoadReason_MAX = 6
};

// Object Name: Enum AClient.ERespawnCharacterState
enum class ERespawnCharacterState : uint8 {
	None = 0,
	AttachAircraft = 1,
	ExitHatch = 2,
	ERespawnCharacterState_MAX = 3
};

// Object Name: Enum AClient.ERespawnAircraftState
enum class ERespawnAircraftState : uint8 {
	Init = 0,
	Hover = 1,
	Exit = 2,
	Destroy = 3,
	ERespawnAircraftState_MAX = 4
};

// Object Name: Enum AClient.EBannerSpawnMethod
enum class EBannerSpawnMethod : uint8 {
	DoNotSpawn = 0,
	SpawnStatic = 1,
	SpawnDynamic = 2,
	EBannerSpawnMethod_MAX = 3
};

// Object Name: Enum AClient.EAIRetCode
enum class EAIRetCode : uint8 {
	SUCCESS = 0,
	EQS_FAILED = 1,
	AI_NOT_ENOUGH = 2,
	EAIRetCode_MAX = 3
};

// Object Name: Enum AClient.EQueryAINumType
enum class EQueryAINumType : uint8 {
	CanActiveScriptAICount = 1,
	ActiveAICount = 2,
	TotalRemainAICount = 3,
	EQueryAINumType_MAX = 4
};

// Object Name: Enum AClient.EWeaponHitFlowType
enum class EWeaponHitFlowType : uint8 {
	WHFT_None = 0,
	WHFT_Shoot = 1,
	WHFT_ShootBullet = 2,
	WHFT_ShootCost = 3,
	WHFT_Hit = 4,
	WHFT_HitHead = 5,
	WHFT_MAX = 6
};

// Object Name: Enum AClient.ESelectLegendMode
enum class ESelectLegendMode : uint8 {
	Sequence = 0,
	Parallel = 1,
	ESelectLegendMode_MAX = 2
};

// Object Name: Enum AClient.ESelectCatagory
enum class ESelectCatagory : uint8 {
	None = 0,
	SelectLegend = 1,
	Skin = 2,
	Show = 3,
	ESelectCatagory_MAX = 4
};

// Object Name: Enum AClient.ESkillOperationMode
enum class ESkillOperationMode : uint8 {
	StandardMode = 0,
	SimpleModel = 1,
	Mode_Max = 2,
	ESkillOperationMode_MAX = 3
};

// Object Name: Enum AClient.ESettingSensitivityLevel
enum class ESettingSensitivityLevel : uint8 {
	Low = 1,
	Middle = 2,
	Hight = 3,
	Custom = 4,
	ESettingSensitivityLevel_MAX = 5
};

// Object Name: Enum AClient.ESettingGroup
enum class ESettingGroup : uint8 {
	Basic = 0,
	Fuc = 1,
	Sensitivity = 2,
	Control = 3,
	Scope = 4,
	PickUp = 5,
	DrawQuality = 6,
	Languange = 7,
	Others = 8,
	Privacy = 9,
	Sound = 10,
	ESettingGroup_MAX = 11
};

// Object Name: Enum AClient.GlobalSensitivityMode
enum class GlobalSensitivityMode : uint8 {
	Low = 1,
	Mid = 2,
	High = 3,
	Custom = 4,
	GlobalSensitivityMode_MAX = 5
};

// Object Name: Enum AClient.EMForceFieldFalloff
enum class EMForceFieldFalloff : uint8 {
	Constant = 0,
	Liner = 1,
	Curve = 2,
	Max = 3
};

// Object Name: Enum AClient.EMAreaType
enum class EMAreaType : uint8 {
	None = 0,
	Interactive = 1,
	Region = 2,
	Dangerous = 3,
	EMAreaType_MAX = 4
};

// Object Name: Enum AClient.EMVectorComp
enum class EMVectorComp : uint8 {
	X = 0,
	Y = 1,
	Z = 2,
	EMVectorComp_MAX = 3
};

// Object Name: Enum AClient.EMShapeTriggerStatus
enum class EMShapeTriggerStatus : uint8 {
	None = 0,
	Enter = 1,
	In = 2,
	Exit = 3,
	EMShapeTriggerStatus_MAX = 4
};

// Object Name: Enum AClient.EMShapeTriggerType
enum class EMShapeTriggerType : uint8 {
	None = 0,
	GoToParachute = 1,
	Force = 2,
	EMShapeTriggerType_MAX = 3
};

// Object Name: Enum AClient.ECommonBaseAnimDataAssetIndex
enum class ECommonBaseAnimDataAssetIndex : uint8 {
	NoWeaponCharacter = 0,
	WeaponCharacter = 1,
	ECommonBaseAnimDataAssetIndex_MAX = 2
};

// Object Name: Enum AClient.EFireBtnDataId
enum class EFireBtnDataId : int32 {
	Fire = 10005,
	PropsWeapon = 10006,
	EFireBtnDataId_MAX = 10007
};

// Object Name: Enum AClient.EStoredBtnState
enum class EStoredBtnState : uint8 {
	None = 0,
	ShootWeapon = 1,
	Projectile = 2,
	EStoredBtnState_MAX = 3
};

// Object Name: Enum AClient.ESkillUIStatus
enum class ESkillUIStatus : uint8 {
	ESKILL_UI_CD = 0,
	ESKILL_UI_READY = 1,
	ESKILL_UI_ACTIVE = 2,
	ESKILL_UI_DURATION = 3,
	ESKILL_UI_DISABLED = 4,
	ESKILL_UI_SILENCED = 5,
	ESKILL_UI_READY_3 = 6,
	ESKILL_UI_MAX = 7
};

// Object Name: Enum AClient.EAPReplicationSettingType
enum class EAPReplicationSettingType : uint8 {
	ERST_UpdateFrequency = 0,
	ERST_CullDistance = 1,
	ERST_MAX = 2
};

// Object Name: Enum AClient.ESkillCmdType
enum class ESkillCmdType : uint8 {
	ECmd_None = 0,
	ECmd_TriggerEvent = 1,
	ECmd_StopSkillWithID = 2,
	ECmd_StopSkillSafely = 3,
	ECmd_StopSkillPhaseAttack = 4,
	ECmd_TriggerCurSkillString = 5,
	ECmd_TriggerCurSkillEvent = 6,
	ECmd_MAX = 7
};

// Object Name: Enum AClient.ETestCaseStatus
enum class ETestCaseStatus : uint8 {
	EStatus_None = 0,
	EStatus_Doing = 1,
	EStatus_Failed = 2,
	EStatus_MAX = 3
};

// Object Name: Enum AClient.ETestCaseResult
enum class ETestCaseResult : uint8 {
	EResult_Wait = 0,
	EResult_Succeed = 1,
	EResult_Failed = 2,
	EResult_MAX = 3
};

// Object Name: Enum AClient.EStageSwitchState
enum class EStageSwitchState : uint8 {
	On = 0,
	Off = 1,
	Error = 2,
	EStageSwitchState_MAX = 3
};

// Object Name: Enum AClient.EStatusHeadMapFlags
enum class EStatusHeadMapFlags : uint8 {
	Aid = 0,
	Retrieve = 1,
	Finisher = 2,
	EStatusHeadMapFlags_MAX = 3
};

// Object Name: Enum AClient.EStopBinState
enum class EStopBinState : uint8 {
	Sleep = 0,
	Active = 1,
	Rising = 2,
	Decilining = 3,
	EStopBinState_MAX = 4
};

// Object Name: Enum AClient.ETokenState
enum class ETokenState : uint8 {
	ReadyToUse = 0,
	NowUsing = 1,
	OverUsed = 2,
	ETokenState_MAX = 3
};

// Object Name: Enum AClient.EPawnStateChangeWay
enum class EPawnStateChangeWay : uint8 {
	Logic = 0,
	Interrupted = 1,
	Sync = 2,
	TimeOut = 3,
	BlockExit = 4,
	EPawnStateChangeWay_MAX = 5
};

// Object Name: Enum AClient.EAPGameMoveMaskFilter
enum class EAPGameMoveMaskFilter : uint8 {
	None = 0,
	AI = 1,
	EAPGameMoveMaskFilter_MAX = 2
};

// Object Name: Enum AClient.EOverheadReportType
enum class EOverheadReportType : uint8 {
	None = 0,
	LaunchGame = 1,
	Login = 2,
	Lobby = 3,
	BattleLoading = 4,
	InGame = 5,
	RoleSelect = 6,
	EnterFighting = 7,
	Plane = 8,
	Parachute = 9,
	EndParachute = 10,
	FinalPoisonCircle = 11,
	EnterObserve = 12,
	GameOver = 13,
	GameFlowMax = 14,
	MachineScope = 15,
	MagnifierOne = 16,
	MagnifierTwo = 17,
	MagnifierThree = 18,
	MagnifierFour = 19,
	MagnifierSix = 20,
	MagnifierEight = 21,
	MagnifierTen = 22,
	MinorSkill = 23,
	MajorSkill = 24,
	PassiveSkill = 25,
	Slide = 26,
	Climb = 27,
	Zipline = 28,
	OpenBox = 29,
	PickUp = 30,
	Fire = 31,
	HeavyFire = 32,
	KnockedDown = 33,
	Drive = 34,
	EOverheadReportType_MAX = 35
};

// Object Name: Enum AClient.EScreenState
enum class EScreenState : uint8 {
	KillKing = 1,
	Defenders = 2,
	FireRangeRankEmpty = 3,
	FireRangeRankThree = 4,
	FireRangeRankList = 5,
	EScreenState_MAX = 6
};

// Object Name: Enum AClient.ETimerType
enum class ETimerType : uint8 {
	Once = 0,
	Loop = 1,
	ETimerType_MAX = 2
};

// Object Name: Enum AClient.ETimeTrackType
enum class ETimeTrackType : uint8 {
	UI = 0,
	Logic = 1,
	Battle = 2,
	UIAnim = 3,
	Effect = 4,
	UeOrigin = 5,
	TickOnWorldPostActor = 6,
	Max = 7
};

// Object Name: Enum AClient.ETrackerOperateType
enum class ETrackerOperateType : uint8 {
	Add = 0,
	Set = 1,
	Delete = 2,
	ETrackerOperateType_MAX = 3
};

// Object Name: Enum AClient.ETrackTriggerType
enum class ETrackTriggerType : uint8 {
	Enter = 1,
	Exit = 2,
	Execute = 3,
	Custom = 4,
	ETrackTriggerType_MAX = 5
};

// Object Name: Enum AClient.ETrainingFieldAnimState
enum class ETrainingFieldAnimState : uint8 {
	None = 0,
	Opening = 1,
	OpenIdle = 2,
	Closing = 3,
	CloseIdle = 4,
	ETrainingFieldAnimState_MAX = 5
};

// Object Name: Enum AClient.ETrainStateType
enum class ETrainStateType : uint8 {
	None = 0,
	Departure = 1,
	Running = 2,
	Brake = 3,
	Parking = 4,
	ETrainStateType_MAX = 5
};

// Object Name: Enum AClient.ETutorialTLogType
enum class ETutorialTLogType : uint8 {
	None = 0,
	EA_Tutorial = 1,
	OP_Tutorial = 2,
	ETutorialTLogType_MAX = 3
};

// Object Name: Enum AClient.ECharacterAnimTypeAsynLoaded
enum class ECharacterAnimTypeAsynLoaded : uint8 {
	ECharAnimAsyn_Swim_Up = 0,
	ECharAnimAsyn_Swim_Down = 1,
	ECharAnimAsyn_Max = 2
};

// Object Name: Enum AClient.ECharacterViewType
enum class ECharacterViewType : uint8 {
	ECharacterView_TPPandFPP = 0,
	ECharacterView_TPP = 1,
	ECharacterView_FPP = 2,
	ECharacterView_Max = 3
};

// Object Name: Enum AClient.ESALCNavigate
enum class ESALCNavigate : uint8 {
	ESALCNavigate_Forward = 0,
	ESALCNavigate_Target = 1,
	ESALCNavigate_Caster = 2,
	ESALCNavigate_MAX = 3
};

// Object Name: Enum AClient.ESALCSpeedBlendMode
enum class ESALCSpeedBlendMode : uint8 {
	ESALCSpeedBlend_Override = 0,
	ESALCSpeedBlend_Additive = 1,
	ESALCSpeedBlend_MAX = 2
};

// Object Name: Enum AClient.ERecoveryReasonType
enum class ERecoveryReasonType : uint8 {
	ERecoveryReason_Medicine = 0,
	ERecoveryReason_Energy = 1,
	ERecoveryReason_RescueByTeammate = 2,
	ERecoveryReason_Revival = 3,
	ERecoveryReason_Finisher = 4,
	ERecoveryReason_Max = 5
};

// Object Name: Enum AClient.ESkillPawnState
enum class ESkillPawnState : uint8 {
	ESPS_Slot1 = 0,
	ESPS_Slot2 = 1,
	ESPS_MAX = 2
};

// Object Name: Enum AClient.ESkillMontageType
enum class ESkillMontageType : uint8 {
	SMT_None = 0,
	SMT_Stand = 1,
	SMT_Crouch = 2,
	SMT_Slide = 3,
	SMT_Sprint = 4,
	SMT_Jump = 5,
	SMT_Dying = 6,
	SMT_Max = 7
};

// Object Name: Enum AClient.ESkillPreloadPlatform
enum class ESkillPreloadPlatform : uint8 {
	All = 0,
	Client = 1,
	Simulated = 2,
	Autonomous = 3,
	Server = 4,
	ESkillPreloadPlatform_MAX = 5
};

// Object Name: Enum AClient.EVelocityChangeType
enum class EVelocityChangeType : uint8 {
	ESpeed_Up = 0,
	ESpeed_Down = 1,
	ESpeed_Both = 2,
	ESpeed_MAX = 3
};

// Object Name: Enum AClient.ESkillConditionCheckType
enum class ESkillConditionCheckType : uint8 {
	ECheck_Once = 0,
	ECheck_Continuous = 1,
	ECheck_MAX = 2
};

// Object Name: Enum AClient.ERecoveryType
enum class ERecoveryType : uint8 {
	ERecovery_AddDirectly = 0,
	ERecovery_AddTo = 1,
	ERecovery_MAX = 2
};

// Object Name: Enum AClient.EValueType
enum class EValueType : uint8 {
	EValueType_Percentage = 0,
	EValueType_Absolute = 1,
	EValueType_MAX = 2
};

// Object Name: Enum AClient.EOperatorType
enum class EOperatorType : uint8 {
	EOperator_Equal = 0,
	EOperator_Greater = 1,
	EOperator_Less = 2,
	EOperator_GreaterEqual = 3,
	EOperator_LessEqual = 4,
	EOperator_MAX = 5
};

// Object Name: Enum AClient.EUTSkillEntry
enum class EUTSkillEntry : uint8 {
	SkillEntry_None = 0,
	SkillEntry_Grenade_Down = 1,
	SkillEntry_Grenade_Up = 2,
	SkillEntry_Flash_Down = 3,
	SkillEntry_Flash_Up = 4,
	SkillEntry_Smoke_Down = 5,
	SkillEntry_Smoke_Up = 6,
	SkillEntry_Molotov_Down = 7,
	SkillEntry_Molotov_Up = 8,
	SkillEntry_Melee_Fist_Down = 9,
	SkillEntry_Melee_Fist_Up = 10,
	SkillEntry_Melee_Weapon_1_Down = 11,
	SkillEntry_Melee_Weapon_1_Up = 12,
	SkillEntry_Melee_Weapon_2_Down = 13,
	SkillEntry_Melee_Weapon_2_Up = 14,
	SkillEntry_Melee_Weapon_3_Down = 15,
	SkillEntry_Melee_Weapon_3_Up = 16,
	SkillEntry_Melee_Weapon_4_Down = 17,
	SkillEntry_Melee_Weapon_4_Up = 18,
	SkillEntry_Bandage_Down = 19,
	SkillEntry_EnergyDrink_Down = 20,
	SkillEntry_Painkiller_Down = 21,
	SkillEntry_AdrenalineSyringe_Down = 22,
	SkillEntry_FirstAidKit_Down = 23,
	SkillEntry_MedKit_Down = 24,
	SkillEntry_GasCan_Down = 25,
	SkillEntry_GrenadeApple_Down = 26,
	SkillEntry_GrenadeApple_Up = 27,
	SkillEntry_GrenadeDance_Down = 28,
	SkillEntry_GrenadeDance_Up = 29,
	SkillEntry_GrenadeRnfc_Down = 30,
	SkillEntry_GrenadeRnfc_Up = 31,
	SkillEntry_Melee_Weapon_5_Down = 32,
	SkillEntry_Melee_Weapon_5_Up = 33,
	SkillEntry_Melee_Weapon_6_Down = 34,
	SkillEntry_Melee_Weapon_6_Up = 35,
	SkillEntry_Melee_Weapon_7_Down = 36,
	SkillEntry_Melee_Weapon_7_Up = 37,
	SkillEntry_Melee_Weapon_8_Down = 38,
	SkillEntry_Melee_Weapon_8_Up = 39,
	SkillEntry_Melee_Weapon_9_Down = 40,
	SkillEntry_Melee_Weapon_9_Up = 41,
	SkillEntry_Melee_Weapon_10_Down = 42,
	SkillEntry_Melee_Weapon_10_Up = 43,
	SkillEntry_Bandage_Down_CG = 44,
	SkillEntry_EnergyDrink_Down_CG = 45,
	SkillEntry_Painkiller_Down_CG = 46,
	SkillEntry_AdrenalineSyringe_Down_CG = 47,
	SkillEntry_FirstAidKit_Down_CG = 48,
	SkillEntry_MedKit_Down_CG = 49,
	SkillEntry_GasCan_Down_CG = 50,
	SkillEntry_Grenade_Down_CG = 51,
	SkillEntry_Grenade_Up_CG = 52,
	SkillEntry_Flash_Down_CG = 53,
	SkillEntry_Flash_Up_CG = 54,
	SkillEntry_Smoke_Down_CG = 55,
	SkillEntry_Smoke_Up_CG = 56,
	SkillEntry_Molotov_Down_CG = 57,
	SkillEntry_Molotov_Up_CG = 58,
	SkillEntry_ShieldStun_Down = 59,
	SkillEntry_ShieldStun_Up = 60,
	SkillEntry_Shield_Melee_Down = 61,
	SkillEntry_Shield_Melee_Up = 62,
	SkillEntry_SmellyEgg_Down_CG = 63,
	SkillEntry_SmellyEgg_Up_CG = 64,
	SkillEntry_Fireworks_Down_CG = 65,
	SkillEntry_Fireworks_Up_CG = 66,
	SkillEntry_FirstAidKitFast_Down_CG = 67,
	SkillEntry_FirstAidKitFast_Up_CG = 68,
	SkillEntry_ToyApple_Down_CG = 69,
	SkillEntry_ToyApple_Up_CG = 70,
	SkillEntry_SingerDoll_Down_CG = 71,
	SkillEntry_SingerDoll_Up_CG = 72,
	SkillEntry_Snowball_Down = 73,
	SkillEntry_Snowball_Up = 74,
	SkillEntry_Pumpkin_Down = 75,
	SkillEntry_Pumpkin_Up = 76,
	SkillEntry_ReserveGrenade1_Down = 77,
	SkillEntry_ReserveGrenade1_Up = 78,
	SkillEntry_ReserveGrenade2_Down = 79,
	SkillEntry_ReserveGrenade2_Up = 80,
	SkillEntry_ReserveGrenade3_Down = 81,
	SkillEntry_ReserveGrenade3_Up = 82,
	SkillEntry_ReserveGrenade4_Down = 83,
	SkillEntry_ReserveGrenade4_Up = 84,
	SkillEntry_RapidAid_Down = 85,
	SkillEntry_Max = 86
};

// Object Name: Enum AClient.ESkillUIBtnStatus
enum class ESkillUIBtnStatus : uint8 {
	All = 0,
	CD = 1,
	ESkillUIBtnStatus_MAX = 2
};

// Object Name: Enum AClient.ESkillOperationType
enum class ESkillOperationType : uint8 {
	Click = 0,
	Drag = 1,
	Switch = 2,
	ESkillOperationType_MAX = 3
};

// Object Name: Enum AClient.ESkillUISlot
enum class ESkillUISlot : uint8 {
	None = 0,
	SkillMeleeSlot = 1,
	SkillTacticalSlot = 2,
	SkillUltimateSlot = 3,
	SkillCancelSlot = 4,
	SkillUndoSlot = 5,
	ESkillUISlot_MAX = 6
};

// Object Name: Enum AClient.ETableLoadPhase
enum class ETableLoadPhase : uint8 {
	eSelfControl = 0,
	eLaunch = 1,
	eLobby = 2,
	eEnterBattle = 3,
	eDSBattle = 4,
	ETableLoadPhase_MAX = 5
};

// Object Name: Enum AClient.EColosseumLootRollerSpawnStage
enum class EColosseumLootRollerSpawnStage : uint8 {
	Disable = 0,
	Default = 1,
	Settlement = 2,
	EColosseumLootRollerSpawnStage_MAX = 3
};

// Object Name: Enum AClient.EUpdatableCoreDataGroupType
enum class EUpdatableCoreDataGroupType : uint8 {
	ENone = 0,
	BlueprintCDOData = 1,
	BlueprintComponentData = 2,
	EUpdatableCoreDataGroupType_MAX = 3
};

// Object Name: Enum AClient.EUpgradeArmorExpFromType
enum class EUpgradeArmorExpFromType : uint8 {
	TrueRole = 0,
	AI = 1,
	NPC = 2,
	Perk = 3,
	EUpgradeArmorExpFromType_MAX = 4
};

// Object Name: Enum AClient.EUpGradeableArmorExpResult
enum class EUpGradeableArmorExpResult : uint8 {
	Create = 0,
	NoUpGrade = 1,
	UpGrade = 2,
	EUpGradeableArmorExpResult_MAX = 3
};

// Object Name: Enum AClient.EVehicleMotorDirectionType
enum class EVehicleMotorDirectionType : uint8 {
	eUp = 0,
	eForward = 1,
	eBack = 2,
	eLeft = 3,
	eRight = 4,
	EVehicleMotorDirectionType_MAX = 5
};

// Object Name: Enum AClient.ECharacterOnVehicleType
enum class ECharacterOnVehicleType : uint8 {
	None = 0,
	Driver = 1,
	Passager = 2,
	ECharacterOnVehicleType_MAX = 3
};

// Object Name: Enum AClient.EApexVehicleType
enum class EApexVehicleType : uint8 {
	None = 0,
	PhysicSimulationTrident = 1,
	LogicSimulationTrident = 2,
	ForceTrident = 3,
	Max = 4
};

// Object Name: Enum AClient.EViewAssistType
enum class EViewAssistType : uint8 {
	None = 0,
	QuickSnapping = 1,
	WeaponFire = 2,
	WeaponAim = 3,
	TickSnapping = 4,
	EdgePushing = 5,
	ProjectileReticle = 6,
	ProjectileLandingPoint = 7,
	EViewAssistType_MAX = 8
};

// Object Name: Enum AClient.ERecordStatus
enum class ERecordStatus : uint8 {
	ERECORDSTATUS_UNKOWN = 0,
	ERECORDSTATUS_RECORDING = 1,
	ERECORDSTATUS_COMPLETED = 2,
	ERECORDSTATUS_SUCCEED = 3,
	ERECORDSTATUS_FAILURE = 4,
	ERECORDSTATUS_EFFICIENT = 5,
	ERECORDSTATUS_WAITDESTORY = 6,
	ERECORDSTATUS_MAX = 7
};

// Object Name: Enum AClient.ELandingStateType
enum class ELandingStateType : uint8 {
	ELandingState_None = 0,
	ELandingState_LandTwoAndConnect = 1,
	ELandingState_LandOneAndConnect = 2,
	ELandingState_NoLandAndConnect = 3,
	ELandingState_MAX = 4
};

// Object Name: Enum AClient.EActiveType
enum class EActiveType : uint8 {
	DELAY = 0,
	LST_REMAIN_CNT = 1,
	LST_KEY_REAMIN_CNT = 2,
	EActiveType_MAX = 3
};

// Object Name: Enum AClient.EWeaponOrOwnerCondition
enum class EWeaponOrOwnerCondition : uint8 {
	NONE = 0,
	PlayerWithGoldArmor = 1,
	EWeaponOrOwnerCondition_MAX = 2
};

// Object Name: Enum AClient.EWeaponReloadStage
enum class EWeaponReloadStage : uint8 {
	None = 0,
	MagOut = 1,
	MagIn = 2,
	PullBolt = 3,
	FirstOneBulletCharge = 4,
	FirstOneBullet = 5,
	CirculateOneBullet = 6,
	ReloadEnd = 7,
	RandomOneBullet = 8,
	EWeaponReloadStage_MAX = 9
};

// Object Name: Enum AClient.EFillBulletWeapon
enum class EFillBulletWeapon : uint8 {
	AllWeapon = 0,
	LastWeapon = 1,
	EFillBulletWeapon_MAX = 2
};

// Object Name: Enum AClient.ESpringType
enum class ESpringType : uint8 {
	None = 0,
	Soft = 1,
	Hard = 2,
	Immediately = 3,
	ESpringType_MAX = 4
};

// Object Name: Enum AClient.ERecoilType
enum class ERecoilType : uint8 {
	None = 0,
	Soft = 1,
	Hard = 2,
	ERecoilType_MAX = 3
};

// Object Name: Enum AClient.ECrossHairSpreadType
enum class ECrossHairSpreadType : uint8 {
	ECHST_Offset = 0,
	ECHST_Scale = 1,
	ECHST_Damage = 2,
	ECHST_Rotate = 3,
	ECHST_Kill = 4,
	ECHST_MAX = 5
};

// Object Name: Enum AClient.EWeaponADSShoulderConfig
enum class EWeaponADSShoulderConfig : uint8 {
	None = 0,
	Shoulder = 1,
	ADS = 2,
	EWeaponADSShoulderConfig_MAX = 3
};

// Object Name: Enum AClient.EHavocEnergyState
enum class EHavocEnergyState : uint8 {
	HES_None = 0,
	HES_Up = 1,
	HES_Down = 2,
	HES_MAX = 3
};

// Object Name: Enum AClient.EChargeShootPhase
enum class EChargeShootPhase : uint8 {
	None = 0,
	Lens = 1,
	Final = 2,
	EChargeShootPhase_MAX = 3
};

// Object Name: Enum AClient.ETempWeaponEntityData
enum class ETempWeaponEntityData : uint8 {
	BaseImpactDamage = 0,
	WeaponHitPartCoff_Head = 1,
	WeaponHitPartCoff_Thighs = 2,
	Single_ShootInterval = 3,
	Single_FireInterval = 4,
	Single_LinkInterval = 5,
	Single_AutoAimShootWaitTime = 6,
	Multi_ShootInterval = 7,
	Multi_FireInterval = 8,
	Multi_LinkInterval = 9,
	Multi_AutoAimShootWaitTime = 10,
	Auto_ShootInterval = 11,
	Auto_FireInterval = 12,
	Auto_LinkInterval = 13,
	Auto_AutoAimShootWaitTime = 14,
	FirstPickupToIdleTime = 15,
	SwitchFromIdleToBackpackTime = 16,
	SwitchFromBackpackToIdleTime = 17,
	MaxRaiseWeaponTime = 18,
	MaxLowerWeaponTime = 19,
	AdsStartTime_NoAim = 20,
	AdsStartTime_1X = 21,
	AdsStartTime_2X = 22,
	AdsStartTime_3X = 23,
	AdsStartTime_4X = 24,
	AdsStartTime_6X = 25,
	AdsStartTime_8X = 26,
	AdsStartTime_10X = 27,
	AdsEndTime_NoAim = 28,
	AdsEndTime_1X = 29,
	AdsEndTime_2X = 30,
	AdsEndTime_3X = 31,
	AdsEndTime_4X = 32,
	AdsEndTime_6X = 33,
	AdsEndTime_8X = 34,
	AdsEndTime_10X = 35,
	EnableViewAssist = 36,
	EnableViewAssistDebug = 37,
	MaxViewAssistDistance = 38,
	BaseAccelerateSpeed = 39,
	AimingAccelerateFactor = 40,
	BaseDecelerateSpeed = 41,
	EnableAimSnapping = 42,
	EnableAimSnappingDebug = 43,
	BaseAimSnappingSpeed_Iron = 44,
	BaseAimSnappingSpeed_1X = 45,
	BaseAimSnappingSpeed_2X = 46,
	BaseAimSnappingSpeed_3X = 47,
	BaseAimSnappingSpeed_4X = 48,
	BaseAimSnappingSpeed_6X = 49,
	BaseAimSnappingSpeed_8X = 50,
	BaseAimSnappingSpeed_10X = 51,
	MaxAimSnappingDistance = 52,
	AimSnappingTime = 53,
	EnableFireSnapping = 54,
	EnableFireSnappingDebug = 55,
	BaseFireSnappingSpeed_Iron = 56,
	BaseFireSnappingSpeed_1X = 57,
	BaseFireSnappingSpeed_2X = 58,
	BaseFireSnappingSpeed_3X = 59,
	BaseFireSnappingSpeed_4X = 60,
	BaseFireSnappingSpeed_6X = 61,
	BaseFireSnappingSpeed_8X = 62,
	BaseFireSnappingSpeed_10X = 63,
	NoAimFireSnappingSpeed = 64,
	MaxFireSnappingDistance = 65,
	FireSnappingTime = 66,
	HitRecoilFactor = 67,
	RecoilFactorX_StandIdle_ADS = 68,
	RecoilFactorY_StandIdle_ADS = 69,
	RecoilRandomX_StandIdle_ADS = 70,
	RecoilRandomY_StandIdle_ADS = 71,
	RecoilFactorX_StandIdle_NoADS = 72,
	RecoilFactorY_StandIdle_NoADS = 73,
	RecoilRandomX_StandIdle_NoADS = 74,
	RecoilRandomY_StandIdle_NoADS = 75,
	RecoilFactorX_StandMove_ADS = 76,
	RecoilFactorY_StandMove_ADS = 77,
	RecoilRandomX_StandMove_ADS = 78,
	RecoilRandomY_StandMove_ADS = 79,
	RecoilFactorX_StandMove_NoADS = 80,
	RecoilFactorY_StandMove_NoADS = 81,
	RecoilRandomX_StandMove_NoADS = 82,
	RecoilRandomY_StandMove_NoADS = 83,
	RecoilFactorX_CrouchIdle_ADS = 84,
	RecoilFactorY_CrouchIdle_ADS = 85,
	RecoilRandomX_CrouchIdle_ADS = 86,
	RecoilRandomY_CrouchIdle_ADS = 87,
	RecoilFactorX_CrouchIdle_NoADS = 88,
	RecoilFactorY_CrouchIdle_NoADS = 89,
	RecoilRandomX_CrouchIdle_NoADS = 90,
	RecoilRandomY_CrouchIdle_NoADS = 91,
	RecoilFactorX_CrouchMove_ADS = 92,
	RecoilFactorY_CrouchMove_ADS = 93,
	RecoilRandomX_CrouchMove_ADS = 94,
	RecoilRandomY_CrouchMove_ADS = 95,
	RecoilFactorX_CrouchMove_NoADS = 96,
	RecoilFactorY_CrouchMove_NoADS = 97,
	RecoilRandomX_CrouchMove_NoADS = 98,
	RecoilRandomY_CrouchMove_NoADS = 99,
	RecoilFactorX_Jump_ADS = 100,
	RecoilFactorY_Jump_ADS = 101,
	RecoilRandomX_Jump_ADS = 102,
	RecoilRandomY_Jump_ADS = 103,
	RecoilFactorX_Jump_NoADS = 104,
	RecoilFactorY_Jump_NoADS = 105,
	RecoilRandomX_Jump_NoADS = 106,
	RecoilRandomY_Jump_NoADS = 107,
	RecoilFactorX_Fall_ADS = 108,
	RecoilFactorY_Fall_ADS = 109,
	RecoilRandomX_Fall_ADS = 110,
	RecoilRandomY_Fall_ADS = 111,
	RecoilFactorX_Fall_NoADS = 112,
	RecoilFactorY_Fall_NoADS = 113,
	RecoilRandomX_Fall_NoADS = 114,
	RecoilRandomY_Fall_NoADS = 115,
	RecoilFactorX_Sliding_ADS = 116,
	RecoilFactorY_Sliding_ADS = 117,
	RecoilRandomX_Sliding_ADS = 118,
	RecoilRandomY_Sliding_ADS = 119,
	RecoilFactorX_Sliding_NoADS = 120,
	RecoilFactorY_Sliding_NoADS = 121,
	RecoilRandomX_Sliding_NoADS = 122,
	RecoilRandomY_Sliding_NoADS = 123,
	EnableFireViewAssist = 124,
	EnableFireViewAssistDebug = 125,
	FireDecelerateRadius = 126,
	FireAccelerateRadius = 127,
	FireMaxDistance = 128,
	FireAccelerateFactor = 129,
	FireBaseDecelerateSpeed = 130,
	FireEdgeDecelerateWidth = 131,
	FireDecelerateTime = 132,
	EnableEdgePushing = 133,
	EnablePitchEdgePushing = 134,
	EnableDebugEdgePushing = 135,
	EdgePushingRadius = 136,
	EdgePushingWidth = 137,
	EdgePushingMaxDistance = 138,
	EdgePushingMinSpeed = 139,
	BaseEdgePushingSpeed = 140,
	EdgePushingTime = 141,
	EdgePushingCD = 142,
	KeepEdgePushingEvenAttach = 143,
	ETempWeaponEntityData_MAX = 144
};

// Object Name: Enum AClient.ERecoilPose
enum class ERecoilPose : uint8 {
	InAir = 0,
	Sliding = 1,
	StandMove = 2,
	StandIdle = 3,
	CrouchMove = 4,
	CrouchIdle = 5,
	Max = 6
};

// Object Name: Enum AClient.EWeaponFrameAudioEventType
enum class EWeaponFrameAudioEventType : uint8 {
	None = 0,
	PostEvent = 1,
	SetRTPC = 2,
	SetSwitch = 3,
	EWeaponFrameAudioEventType_MAX = 4
};

// Object Name: Enum AClient.ESwitchPhase
enum class ESwitchPhase : uint8 {
	None = 0,
	Equiping = 1,
	UnEquiping = 2,
	ESwitchPhase_MAX = 3
};

// Object Name: Enum AClient.EFireSection
enum class EFireSection : uint8 {
	None = 0,
	Start = 1,
	Loop = 2,
	End = 3,
	EFireSection_MAX = 4
};

// Object Name: Enum AClient.EAutoCrossHiarBehavior
enum class EAutoCrossHiarBehavior : uint8 {
	None = 0,
	Show = 1,
	Waiting = 2,
	Shooting = 3,
	Tips = 4,
	EAutoCrossHiarBehavior_MAX = 5
};

// Object Name: Enum AClient.EWeaponAutoShootState
enum class EWeaponAutoShootState : uint8 {
	Check = 0,
	WaitBegin = 1,
	Shooting = 2,
	WaitEnd = 3,
	End = 4,
	EWeaponAutoShootState_MAX = 5
};

// Object Name: Enum AClient.EBulletImpactDir
enum class EBulletImpactDir : uint8 {
	ImpactNormal = 1,
	ImpactShootDir = 2,
	EBulletImpactDir_MAX = 3
};

// Object Name: Enum AClient.EWeaponReloadMethod
enum class EWeaponReloadMethod : uint8 {
	ALL = 0,
	Tactical = 1,
	EWeaponReloadMethod_MAX = 2
};

// Object Name: Enum AClient.ESpecialBulletChange
enum class ESpecialBulletChange : uint8 {
	Init = 0,
	Mag_EquipAutoFill = 1,
	Reload = 2,
	Shoot = 3,
	StartFire = 4,
	StopFire = 5,
	Sync_Simulated = 6,
	ESpecialBulletChange_MAX = 7
};

// Object Name: Enum AClient.EBulletChangeReason
enum class EBulletChangeReason : uint8 {
	Init = 0,
	Mag_UnEquip = 1,
	Mag_EquipAutoFill = 2,
	Reload = 3,
	Shoot = 4,
	StartFire = 5,
	StopFire = 6,
	Sync_Simulated = 7,
	Item_Update = 8,
	EBulletChangeReason_MAX = 9
};

// Object Name: Enum AClient.EWeaponReloadType
enum class EWeaponReloadType : uint8 {
	Magzine = 0,
	OneByOne = 1,
	OneByOneAndClip = 2,
	EWeaponReloadType_MAX = 3
};

// Object Name: Enum AClient.EShootWeaponShootMode
enum class EShootWeaponShootMode : uint8 {
	SWST_MuzzleDirection = 0,
	SWST_TargetDirection = 1,
	SWST_AimDirection = 2,
	SWST_MAX = 3
};

// Object Name: Enum AClient.EWeaponUIScheme
enum class EWeaponUIScheme : uint8 {
	WUS_Normal = 0,
	WUS_Integrate = 1,
	WUS_MAX = 2
};

// Object Name: Enum AClient.EWeaponItemType
enum class EWeaponItemType : uint8 {
	AWT_None = 0,
	AWT_Rifle = 1,
	AWT_Submachine = 2,
	AWT_MachineGun = 3,
	AWT_ShotGun = 4,
	AWT_Sniper = 5,
	AWT_Pistol = 6,
	AWT_Melee = 7,
	AWT_Masksman = 8,
	AWT_Max = 9
};

// Object Name: Enum AClient.EWeaponFireMode
enum class EWeaponFireMode : uint8 {
	None = 0,
	OneBullet = 1,
	MultiBullets = 2,
	Auto = 3,
	Charge = 4,
	EWeaponFireMode_MAX = 5
};

// Object Name: Enum AClient.ESTEWeaponHoldType
enum class ESTEWeaponHoldType : uint8 {
	Hand = 0,
	Rifle = 1,
	Pistol = 2,
	Melee = 3,
	ESTEWeaponHoldType_MAX = 4
};

// Object Name: Enum AClient.EWeaponChargeBuffType
enum class EWeaponChargeBuffType : uint8 {
	NONE = 0,
	ShootInterval = 1,
	DamageDoor = 2,
	BreakShield = 3,
	DamageFactor = 4,
	ShieldDamageFactor = 5,
	MeshDamageFactor = 6,
	ThighsDamageFactor = 7,
	HeadDamageFactor = 8,
	BodyDamageFactor = 9,
	ShieldOverLoad = 10,
	EWeaponChargeBuffType_MAX = 11
};

// Object Name: Enum AClient.EWeapon3DUIType
enum class EWeapon3DUIType : uint8 {
	W3T_WeaponFPP = 0,
	W3T_WeaponTPP = 1,
	W3T_AttachFPP = 2,
	W3T_AttachTPP = 3,
	W3T_Sniper = 4,
	W3T_SpecialWeapon = 5,
	W3T_Max = 6
};

// Object Name: Enum AClient.EAttachToCharacterMode
enum class EAttachToCharacterMode : uint8 {
	NONE = 0,
	FPP = 1,
	TPP = 2,
	EAttachToCharacterMode_MAX = 3
};

// Object Name: Enum AClient.EWinterExpressPlayerStartType
enum class EWinterExpressPlayerStartType : uint8 {
	WinTeam = 0,
	FailTeamA = 1,
	FailTeamB = 2,
	EWinterExpressPlayerStartType_MAX = 3
};

// Object Name: Enum AClient.EReplicatingState
enum class EReplicatingState : uint8 {
	NoReplicating = 0,
	Replicating = 1,
	Opening = 2,
	EReplicatingState_MAX = 3
};

// Object Name: Enum AClient.EReplicatorType
enum class EReplicatorType : uint8 {
	Normal = 0,
	AirDrop = 1,
	EReplicatorType_MAX = 2
};

// Object Name: Enum AClient.ECantReplicateReason
enum class ECantReplicateReason : uint8 {
	None = 0,
	NoEnoughMatrial = 1,
	NoWeapon = 2,
	NoUpgradeShield = 3,
	ECantReplicateReason_MAX = 4
};

// Object Name: Enum AClient.EReplicateType
enum class EReplicateType : uint8 {
	OneDayRound = 0,
	OneWeekRound = 1,
	LockItem = 2,
	WeaponType = 3,
	UpGrade = 4,
	EReplicateType_MAX = 5
};

// Object Name: Enum AClient.EControllerMappingPriority
enum class EControllerMappingPriority : uint8 {
	NONE = 0,
	BackGround = 1,
	BaseInput = 2,
	UpBaseInput = 3,
	Window = 4,
	HighWindow = 5,
	TOP = 6,
	EControllerMappingPriority_MAX = 7
};

// Object Name: Enum AClient.EParachuteReportEvent
enum class EParachuteReportEvent : uint8 {
	Leave = 0,
	Join = 1,
	Transfer = 2,
	ShowWorkbenchMark = 3,
	UseCameraZoom = 4,
	UseSmallEye = 5,
	EParachuteReportEvent_MAX = 6
};

// Object Name: Enum AClient.EZiplinePhysicsMode
enum class EZiplinePhysicsMode : uint8 {
	LengthMode = 0,
	SpringMode = 1,
	MiddleMode = 2,
	NewLength = 3,
	EZiplinePhysicsMode_MAX = 4
};

// Object Name: Enum AClient.EZiplineDownPreset
enum class EZiplineDownPreset : uint8 {
	None = 0,
	Horizon_Init = 1,
	Horizon_Auto = 2,
	Vertical_Init = 3,
	Vertical_Auto_Down = 4,
	Vertical_Auto_Up = 5,
	Custom = 6,
	EZiplineDownPreset_MAX = 7
};

// Object Name: Enum AClient.EZiplineDirH
enum class EZiplineDirH : uint8 {
	SlideDir = 0,
	ViewDir = 1,
	ConstDir = 2,
	EZiplineDirH_MAX = 3
};

// Object Name: Enum AClient.EZiplineType
enum class EZiplineType : uint8 {
	ZiplineHorizon = 0,
	ZiplineVertical = 1,
	EZiplineType_MAX = 2
};

// Object Name: Enum AClient.EHolderType
enum class EHolderType : uint8 {
	Long = 0,
	Medium = 1,
	Short = 2,
	EHolderType_MAX = 3
};

// Object Name: Enum AClient.EZiplineState
enum class EZiplineState : uint8 {
	EZiplineState_Static = 0,
	EZiplineState_Dynamic = 1,
	EZiplineState_Ride = 3,
	EZiplineState_MAX = 4
};

