#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum FastPicture.EFastPictureCompareType
enum class EFastPictureCompareType : uint8 {
	CMP_Equal = 0,
	CMP_Less = 1,
	CMP_LessEqual = 2,
	CMP_Greater = 3,
	CMP_GreaterEqual = 4,
	CMP_NotEqual = 5,
	CMP_Regex = 6,
	CMP_MAX = 7
};

// Object Name: Enum FastPicture.EFastPictureSourceType
enum class EFastPictureSourceType : uint8 {
	SRC_PreviousRegexMatch = 0,
	SRC_GpuFamily = 1,
	SRC_GlVersion = 2,
	SRC_AndroidVersion = 3,
	SRC_iOSVersion = 4,
	SRC_DeviceMake = 5,
	SRC_DeviceModel = 6,
	SRC_VulkanVersion = 7,
	SRC_MemorySizeInGB = 8,
	SRC_CPUCoreNum = 9,
	SRC_CPUMaxFreq = 10,
	SRC_ProfileName = 11,
	SRC_RenderLevel = 12,
	SRC_Platform = 13,
	SRC_Grade = 14,
	SRC_GradeScore = 15,
	SRC_CVarsSwitch = 16,
	SRC_Chipset = 17,
	SRC_MAX = 18
};

// Object Name: Enum FastPicture.EFastPictureGradeScoreType
enum class EFastPictureGradeScoreType : uint8 {
	GST_GPU = 0,
	GST_Memory = 1,
	GST_CPUCore = 2,
	GST_CPUFreq = 3,
	GST_MAX = 4
};

