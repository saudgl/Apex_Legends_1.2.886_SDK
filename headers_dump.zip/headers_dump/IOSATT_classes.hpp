#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class IOSATT.IOSATLib
// Size: 0x28 // Inherited bytes: 0x28
struct UIOSATLib : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function IOSATT.IOSATLib.RequestIOSAppTracking
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t RequestIOSAppTracking(); // Offset: 0x101f36c70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function IOSATT.IOSATLib.GotoAppTrackingSettings
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GotoAppTrackingSettings(); // Offset: 0x101f36c28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function IOSATT.IOSATLib.GetIOSAppTrackingAuthStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t GetIOSAppTrackingAuthStatus(); // Offset: 0x101f36c3c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class IOSATT.IOSATSettings
// Size: 0x38 // Inherited bytes: 0x28
struct UIOSATSettings : UObject {
	// Fields
	struct FString TrackingRequestDescription; // Offset: 0x28 // Size: 0x10
};

