#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LaunchGameMode_BP.LaunchGameMode_BP_C
// Size: 0x3e0 // Inherited bytes: 0x3d0
struct ALaunchGameMode_BP_C : ALobbyGameMode {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d0 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3d8 // Size: 0x08

	// Functions

	// Object Name: Function LaunchGameMode_BP.LaunchGameMode_BP_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LaunchGameMode_BP.LaunchGameMode_BP_C.ReceiveEndPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LaunchGameMode_BP.LaunchGameMode_BP_C.ExecuteUbergraph_LaunchGameMode_BP
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_LaunchGameMode_BP(int32_t EntryPoint); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)
};

