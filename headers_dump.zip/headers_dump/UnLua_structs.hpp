#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct UnLua.PropertyCollector
// Size: 0x01 // Inherited bytes: 0x00
struct FPropertyCollector {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

