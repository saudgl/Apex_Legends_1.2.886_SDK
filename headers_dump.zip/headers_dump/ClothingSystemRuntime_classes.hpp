#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ClothingSystemRuntime.ClothingAssetCustomData
// Size: 0x28 // Inherited bytes: 0x28
struct UClothingAssetCustomData : UObject {
};

// Object Name: Class ClothingSystemRuntime.ClothingAsset
// Size: 0x178 // Inherited bytes: 0x48
struct UClothingAsset : UClothingAssetBase {
	// Fields
	struct UPhysicsAsset* PhysicsAsset; // Offset: 0x48 // Size: 0x08
	struct FClothConfig ClothConfig; // Offset: 0x50 // Size: 0xd4
	char pad_0x124[0x4]; // Offset: 0x124 // Size: 0x04
	struct TArray<struct FClothLODData> LODData; // Offset: 0x128 // Size: 0x10
	struct TArray<int32_t> LodMap; // Offset: 0x138 // Size: 0x10
	struct TArray<struct FName> UsedBoneNames; // Offset: 0x148 // Size: 0x10
	struct TArray<int32_t> UsedBoneIndices; // Offset: 0x158 // Size: 0x10
	int32_t ReferenceBoneIndex; // Offset: 0x168 // Size: 0x04
	char pad_0x16C[0x4]; // Offset: 0x16c // Size: 0x04
	struct UClothingAssetCustomData* CustomData; // Offset: 0x170 // Size: 0x08
};

// Object Name: Class ClothingSystemRuntime.ClothingSimulationFactoryNv
// Size: 0x28 // Inherited bytes: 0x28
struct UClothingSimulationFactoryNv : UClothingSimulationFactory {
};

// Object Name: Class ClothingSystemRuntime.ClothingSimulationInteractorNv
// Size: 0x40 // Inherited bytes: 0x30
struct UClothingSimulationInteractorNv : UClothingSimulationInteractor {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 // Size: 0x10

	// Functions

	// Object Name: Function ClothingSystemRuntime.ClothingSimulationInteractorNv.SetAnimDriveSpringStiffness
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimDriveSpringStiffness(float InStiffness); // Offset: 0x106057164 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClothingSystemRuntime.ClothingSimulationInteractorNv.SetAnimDriveDamperStiffness
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimDriveDamperStiffness(float InStiffness); // Offset: 0x1060570e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClothingSystemRuntime.ClothingSimulationInteractorNv.EnableGravityOverride
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void EnableGravityOverride(struct FVector& InVector); // Offset: 0x106057060 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function ClothingSystemRuntime.ClothingSimulationInteractorNv.DisableGravityOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DisableGravityOverride(); // Offset: 0x10605704c // Return & Params: Num(0) Size(0x0)
};

