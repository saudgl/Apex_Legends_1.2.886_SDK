#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UnLua.BTTask_LuaTaskBase
// Size: 0x148 // Inherited bytes: 0x128
struct UBTTask_LuaTaskBase : UBTTaskNode {
	// Fields
	char pad_0x128[0x8]; // Offset: 0x128 // Size: 0x08
	struct AActor* ActorOwner; // Offset: 0x130 // Size: 0x08
	bool ReceiveTickImplementations; // Offset: 0x138 // Size: 0x01
	bool ReceiveExecuteImplementations; // Offset: 0x139 // Size: 0x01
	bool ReceiveAbortImplementations; // Offset: 0x13a // Size: 0x01
	bool ReceiveTickInternalImplementations; // Offset: 0x13b // Size: 0x01
	float TickInternal; // Offset: 0x13c // Size: 0x04
	char pad_0x140[0x8]; // Offset: 0x140 // Size: 0x08

	// Functions

	// Object Name: Function UnLua.BTTask_LuaTaskBase.SetFinishOnMessageWithId
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetFinishOnMessageWithId(struct FName MessageName, int32_t RequestID); // Offset: 0x10219d804 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UnLua.BTTask_LuaTaskBase.SetFinishOnMessage
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetFinishOnMessage(struct FName MessageName); // Offset: 0x10219d8c4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnLua.BTTask_LuaTaskBase.ReceiveTickInternal
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveTickInternal(struct AActor* OwnerActor); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnLua.BTTask_LuaTaskBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Offset: 0x1043c773c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UnLua.BTTask_LuaTaskBase.ReceiveExecute
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecute(struct AActor* OwnerActor); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnLua.BTTask_LuaTaskBase.ReceiveAbort
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveAbort(struct AActor* OwnerActor); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnLua.BTTask_LuaTaskBase.IsTaskExecuting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	bool IsTaskExecuting(); // Offset: 0x10219d7d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnLua.BTTask_LuaTaskBase.IsTaskAborting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	bool IsTaskAborting(); // Offset: 0x10219d79c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnLua.BTTask_LuaTaskBase.FinishExecute
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void FinishExecute(bool bSuccess); // Offset: 0x10219d954 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnLua.BTTask_LuaTaskBase.FinishAbort
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void FinishAbort(); // Offset: 0x10219d940 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UnLua.UnLuaFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UUnLuaFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UnLua.UnLuaFunctionLibrary.RequestAsyncLoad
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString RequestAsyncLoad(struct FString Path, struct FDelegate Delegate, int32_t Priority, struct FString DebugName, bool bManageActiveHandle, bool bStartStalled); // Offset: 0x10219e554 // Return & Params: Num(7) Size(0x50)

	// Object Name: Function UnLua.UnLuaFunctionLibrary.OnAsyncLoadFinished
	// Flags: [Final|Native|Static|Public|HasDefaults]
	void OnAsyncLoadFinished(struct FDelegate Delegate, struct FSoftObjectPath Path, struct FString ReqID); // Offset: 0x10219e27c // Return & Params: Num(3) Size(0x38)

	// Object Name: Function UnLua.UnLuaFunctionLibrary.GetScriptRootPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetScriptRootPath(); // Offset: 0x10219e89c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaFunctionLibrary.GetFileLastModifiedTimestamp
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int64_t GetFileLastModifiedTimestamp(struct FString Path); // Offset: 0x10219e7b0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UnLua.UnLuaFunctionLibrary.CancelAsyncLoadReq
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CancelAsyncLoadReq(struct FString ReqID); // Offset: 0x10219e47c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UnLua.UnLuaInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUnLuaInterface : UInterface {
	// Functions

	// Object Name: Function UnLua.UnLuaInterface.GetModuleName
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x10219ec98 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UnLua.UnLuaManager
// Size: 0x518 // Inherited bytes: 0x28
struct UUnLuaManager : UObject {
	// Fields
	char pad_0x28[0x4f0]; // Offset: 0x28 // Size: 0x4f0

	// Functions

	// Object Name: Function UnLua.UnLuaManager.TriggerAnimNotify
	// Flags: [Event|Public|BlueprintEvent]
	void TriggerAnimNotify(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnLua.UnLuaManager.OnLatentActionCompleted
	// Flags: [Final|Native|Public]
	void OnLatentActionCompleted(int32_t LinkID); // Offset: 0x10219f018 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaManager.OnActorDestroyed
	// Flags: [Final|Native|Public]
	void OnActorDestroyed(struct AActor* Actor); // Offset: 0x10219f094 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnLua.UnLuaManager.InputVectorAxis
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void InputVectorAxis(struct FVector& AxisValue); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UnLua.UnLuaManager.InputTouch
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void InputTouch(enum class ETouchIndex FingerIndex, struct FVector& Location); // Offset: 0x1043c773c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnLua.UnLuaManager.InputGesture
	// Flags: [Event|Public|BlueprintEvent]
	void InputGesture(float Value); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaManager.InputAxis
	// Flags: [Event|Public|BlueprintEvent]
	void InputAxis(float AxisValue); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaManager.InputAction
	// Flags: [Event|Public|BlueprintEvent]
	void InputAction(struct FKey Key); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UnLua.UnLuaPerformanceTestProxy
// Size: 0x2c8 // Inherited bytes: 0x268
struct AUnLuaPerformanceTestProxy : AActor {
	// Fields
	char pad_0x268[0x8]; // Offset: 0x268 // Size: 0x08
	int32_t MeshID; // Offset: 0x270 // Size: 0x04
	char pad_0x274[0x4]; // Offset: 0x274 // Size: 0x04
	struct FString MeshName; // Offset: 0x278 // Size: 0x10
	struct FVector COM; // Offset: 0x288 // Size: 0x0c
	char pad_0x294[0x4]; // Offset: 0x294 // Size: 0x04
	struct TArray<int32_t> Indices; // Offset: 0x298 // Size: 0x10
	struct TArray<struct FVector> Positions; // Offset: 0x2a8 // Size: 0x10
	struct TArray<struct FVector> PredictedPositions; // Offset: 0x2b8 // Size: 0x10

	// Functions

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.UpdatePositions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdatePositions(struct TArray<struct FVector>& NewPositions); // Offset: 0x10219f8c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.UpdateMeshName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString UpdateMeshName(struct FString NewName); // Offset: 0x10219fc14 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.UpdateMeshID
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t UpdateMeshID(int32_t NewID); // Offset: 0x10219fce4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.UpdateIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateIndices(struct TArray<int32_t>& NewIndices); // Offset: 0x10219f9f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.Simulate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Simulate(float DeltaTime); // Offset: 0x10219fe68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.Raycast
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool Raycast(struct FVector& Origin, struct FVector& Direction); // Offset: 0x10219fb28 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.NOP
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NOP(); // Offset: 0x10219fee4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetPredictedPositions
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FVector> GetPredictedPositions(); // Offset: 0x10219f840 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetPositions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPositions(struct TArray<struct FVector>& OutPositions); // Offset: 0x10219f960 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetMeshName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetMeshName(); // Offset: 0x10219fdb0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetMeshInfo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool GetMeshInfo(int32_t& OutMeshID, struct FString& OutMeshName, struct FVector& OutCOM, struct TArray<int32_t>& OutIndices, struct TArray<struct FVector>& OutPositions, struct TArray<struct FVector>& OutPredictedPositions); // Offset: 0x10219f5d8 // Return & Params: Num(7) Size(0x59)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetMeshID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMeshID(); // Offset: 0x10219fe34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetIndices(struct TArray<int32_t>& OutIndices); // Offset: 0x10219fa90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetCOM
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetCOM(); // Offset: 0x10219fd70 // Return & Params: Num(1) Size(0xc)
};

