#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass AGameInstance_BP.AGameInstance_BP_C
// Size: 0x408 // Inherited bytes: 0x408
struct UAGameInstance_BP_C : UApexGameInstance {
};

