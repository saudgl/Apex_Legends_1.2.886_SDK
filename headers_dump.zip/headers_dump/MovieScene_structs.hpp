#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct MovieScene.MovieSceneObjectBindingID
// Size: 0x18 // Inherited bytes: 0x00
struct FMovieSceneObjectBindingID {
	// Fields
	int32_t SequenceID; // Offset: 0x00 // Size: 0x04
	enum class EMovieSceneObjectBindingSpace Space; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct FGuid Guid; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvalTemplateBase
// Size: 0x10 // Inherited bytes: 0x00
struct FMovieSceneEvalTemplateBase {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvalTemplate
// Size: 0x18 // Inherited bytes: 0x10
struct FMovieSceneEvalTemplate : FMovieSceneEvalTemplateBase {
	// Fields
	enum class EMovieSceneCompletionMode CompletionMode; // Offset: 0x09 // Size: 0x01
	struct TWeakObjectPtr<struct UMovieSceneSection> SourceSectionPtr; // Offset: 0x0c // Size: 0x08
};

// Object Name: ScriptStruct MovieScene.MovieSceneChannel
// Size: 0x08 // Inherited bytes: 0x00
struct FMovieSceneChannel {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct MovieScene.MovieSceneByteChannel
// Size: 0x98 // Inherited bytes: 0x08
struct FMovieSceneByteChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x08 // Size: 0x10
	char DefaultValue; // Offset: 0x18 // Size: 0x01
	bool bHasDefaultValue; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x6]; // Offset: 0x1a // Size: 0x06
	struct TArray<char> Values; // Offset: 0x20 // Size: 0x10
	struct UEnum* Enum; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x60]; // Offset: 0x38 // Size: 0x60
};

// Object Name: ScriptStruct MovieScene.MovieSceneFloatChannel
// Size: 0xa0 // Inherited bytes: 0x08
struct FMovieSceneFloatChannel : FMovieSceneChannel {
	// Fields
	enum class ERichCurveExtrapolation PreInfinityExtrap; // Offset: 0x08 // Size: 0x01
	enum class ERichCurveExtrapolation PostInfinityExtrap; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	struct TArray<struct FFrameNumber> Times; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FMovieSceneFloatValue> Values; // Offset: 0x20 // Size: 0x10
	float DefaultValue; // Offset: 0x30 // Size: 0x04
	bool bHasDefaultValue; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	struct FMovieSceneKeyHandleMap KeyHandles; // Offset: 0x38 // Size: 0x60
	struct FFrameRate TickResolution; // Offset: 0x98 // Size: 0x08
};

// Object Name: ScriptStruct MovieScene.MovieSceneKeyHandleMap
// Size: 0x60 // Inherited bytes: 0x60
struct FMovieSceneKeyHandleMap : FKeyHandleLookupTable {
};

// Object Name: ScriptStruct MovieScene.MovieSceneFloatValue
// Size: 0x1c // Inherited bytes: 0x00
struct FMovieSceneFloatValue {
	// Fields
	float Value; // Offset: 0x00 // Size: 0x04
	enum class ERichCurveInterpMode InterpMode; // Offset: 0x04 // Size: 0x01
	enum class ERichCurveTangentMode TangentMode; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FMovieSceneTangentData Tangent; // Offset: 0x08 // Size: 0x14
};

// Object Name: ScriptStruct MovieScene.MovieSceneTangentData
// Size: 0x14 // Inherited bytes: 0x00
struct FMovieSceneTangentData {
	// Fields
	float ArriveTangent; // Offset: 0x00 // Size: 0x04
	float LeaveTangent; // Offset: 0x04 // Size: 0x04
	enum class ERichCurveTangentWeightMode TangentWeightMode; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float ArriveTangentWeight; // Offset: 0x0c // Size: 0x04
	float LeaveTangentWeight; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneIntegerChannel
// Size: 0x90 // Inherited bytes: 0x08
struct FMovieSceneIntegerChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x08 // Size: 0x10
	int32_t DefaultValue; // Offset: 0x18 // Size: 0x04
	bool bHasDefaultValue; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	struct TArray<int32_t> Values; // Offset: 0x20 // Size: 0x10
	char pad_0x30[0x60]; // Offset: 0x30 // Size: 0x60
};

// Object Name: ScriptStruct MovieScene.MovieSceneTrackLabels
// Size: 0x10 // Inherited bytes: 0x00
struct FMovieSceneTrackLabels {
	// Fields
	struct TArray<struct FString> Strings; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneEditorData
// Size: 0xe0 // Inherited bytes: 0x00
struct FMovieSceneEditorData {
	// Fields
	struct TMap<struct FString, struct FMovieSceneExpansionState> ExpansionStates; // Offset: 0x00 // Size: 0x50
	double ViewStart; // Offset: 0x50 // Size: 0x08
	double ViewEnd; // Offset: 0x58 // Size: 0x08
	double WorkStart; // Offset: 0x60 // Size: 0x08
	double WorkEnd; // Offset: 0x68 // Size: 0x08
	struct TSet<struct FFrameNumber> MarkedFrames; // Offset: 0x70 // Size: 0x50
	struct FFloatRange WorkingRange; // Offset: 0xc0 // Size: 0x10
	struct FFloatRange ViewRange; // Offset: 0xd0 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneExpansionState
// Size: 0x01 // Inherited bytes: 0x00
struct FMovieSceneExpansionState {
	// Fields
	bool bExpanded; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct MovieScene.MovieSceneMarkedFrame
// Size: 0x18 // Inherited bytes: 0x00
struct FMovieSceneMarkedFrame {
	// Fields
	struct FFrameNumber FrameNumber; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Label; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneTimecodeSource
// Size: 0x18 // Inherited bytes: 0x00
struct FMovieSceneTimecodeSource {
	// Fields
	struct FTimecode Timecode; // Offset: 0x00 // Size: 0x14
	struct FFrameNumber DeltaFrame; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneBinding
// Size: 0x30 // Inherited bytes: 0x00
struct FMovieSceneBinding {
	// Fields
	struct FGuid ObjectGuid; // Offset: 0x00 // Size: 0x10
	struct FString BindingName; // Offset: 0x10 // Size: 0x10
	struct TArray<struct UMovieSceneTrack*> Tracks; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneBindingOverrideData
// Size: 0x24 // Inherited bytes: 0x00
struct FMovieSceneBindingOverrideData {
	// Fields
	struct FMovieSceneObjectBindingID ObjectBindingId; // Offset: 0x00 // Size: 0x18
	struct TWeakObjectPtr<struct UObject> Object; // Offset: 0x18 // Size: 0x08
	bool bOverridesDefault; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
};

// Object Name: ScriptStruct MovieScene.OptionalMovieSceneBlendType
// Size: 0x02 // Inherited bytes: 0x00
struct FOptionalMovieSceneBlendType {
	// Fields
	enum class EMovieSceneBlendType BlendType; // Offset: 0x00 // Size: 0x01
	bool bIsValid; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct MovieScene.MovieSceneBoolChannel
// Size: 0x90 // Inherited bytes: 0x08
struct FMovieSceneBoolChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x08 // Size: 0x10
	bool DefaultValue; // Offset: 0x18 // Size: 0x01
	bool bHasDefaultValue; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x6]; // Offset: 0x1a // Size: 0x06
	struct TArray<bool> Values; // Offset: 0x20 // Size: 0x10
	char pad_0x30[0x60]; // Offset: 0x30 // Size: 0x60
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvalTemplatePtr
// Size: 0x38 // Inherited bytes: 0x00
struct FMovieSceneEvalTemplatePtr {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
};

// Object Name: ScriptStruct MovieScene.MovieSceneEmptyStruct
// Size: 0x01 // Inherited bytes: 0x00
struct FMovieSceneEmptyStruct {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationField
// Size: 0x30 // Inherited bytes: 0x00
struct FMovieSceneEvaluationField {
	// Fields
	struct TArray<struct FMovieSceneFrameRange> Ranges; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FMovieSceneEvaluationGroup> Groups; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FMovieSceneEvaluationMetaData> MetaData; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationMetaData
// Size: 0x70 // Inherited bytes: 0x00
struct FMovieSceneEvaluationMetaData {
	// Fields
	struct TArray<struct FMovieSceneSequenceID> ActiveSequences; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FMovieSceneOrderedEvaluationKey> ActiveEntities; // Offset: 0x10 // Size: 0x10
	struct TMap<struct FMovieSceneSequenceID, uint32_t> SubTemplateSerialNumbers; // Offset: 0x20 // Size: 0x50
};

// Object Name: ScriptStruct MovieScene.MovieSceneSequenceID
// Size: 0x04 // Inherited bytes: 0x00
struct FMovieSceneSequenceID {
	// Fields
	uint32_t Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneOrderedEvaluationKey
// Size: 0x10 // Inherited bytes: 0x00
struct FMovieSceneOrderedEvaluationKey {
	// Fields
	struct FMovieSceneEvaluationKey Key; // Offset: 0x00 // Size: 0x0c
	uint32_t EvaluationIndex; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationKey
// Size: 0x0c // Inherited bytes: 0x00
struct FMovieSceneEvaluationKey {
	// Fields
	struct FMovieSceneSequenceID SequenceID; // Offset: 0x00 // Size: 0x04
	struct FMovieSceneTrackIdentifier TrackIdentifier; // Offset: 0x04 // Size: 0x04
	uint32_t SectionIndex; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneTrackIdentifier
// Size: 0x04 // Inherited bytes: 0x00
struct FMovieSceneTrackIdentifier {
	// Fields
	uint32_t Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationGroup
// Size: 0x20 // Inherited bytes: 0x00
struct FMovieSceneEvaluationGroup {
	// Fields
	struct TArray<struct FMovieSceneEvaluationGroupLUTIndex> LUTIndices; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FMovieSceneEvaluationFieldSegmentPtr> SegmentPtrLUT; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationFieldTrackPtr
// Size: 0x08 // Inherited bytes: 0x00
struct FMovieSceneEvaluationFieldTrackPtr {
	// Fields
	struct FMovieSceneSequenceID SequenceID; // Offset: 0x00 // Size: 0x04
	struct FMovieSceneTrackIdentifier TrackIdentifier; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationFieldSegmentPtr
// Size: 0x0c // Inherited bytes: 0x08
struct FMovieSceneEvaluationFieldSegmentPtr : FMovieSceneEvaluationFieldTrackPtr {
	// Fields
	struct FMovieSceneSegmentIdentifier SegmentID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneSegmentIdentifier
// Size: 0x04 // Inherited bytes: 0x00
struct FMovieSceneSegmentIdentifier {
	// Fields
	int32_t IdentifierIndex; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationGroupLUTIndex
// Size: 0x0c // Inherited bytes: 0x00
struct FMovieSceneEvaluationGroupLUTIndex {
	// Fields
	int32_t LUTOffset; // Offset: 0x00 // Size: 0x04
	int32_t NumInitPtrs; // Offset: 0x04 // Size: 0x04
	int32_t NumEvalPtrs; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneFrameRange
// Size: 0x10 // Inherited bytes: 0x00
struct FMovieSceneFrameRange {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationOperand
// Size: 0x14 // Inherited bytes: 0x00
struct FMovieSceneEvaluationOperand {
	// Fields
	struct FGuid ObjectBindingId; // Offset: 0x00 // Size: 0x10
	struct FMovieSceneSequenceID SequenceID; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationTemplate
// Size: 0x2f0 // Inherited bytes: 0x00
struct FMovieSceneEvaluationTemplate {
	// Fields
	struct TMap<struct FMovieSceneTrackIdentifier, struct FMovieSceneEvaluationTrack> Tracks; // Offset: 0x00 // Size: 0x50
	char pad_0x50[0x50]; // Offset: 0x50 // Size: 0x50
	struct FMovieSceneEvaluationField EvaluationField; // Offset: 0xa0 // Size: 0x30
	struct FMovieSceneSequenceHierarchy Hierarchy; // Offset: 0xd0 // Size: 0xa0
	struct FGuid SequenceSignature; // Offset: 0x170 // Size: 0x10
	struct FMovieSceneEvaluationTemplateSerialNumber TemplateSerialNumber; // Offset: 0x180 // Size: 0x04
	char pad_0x184[0x4]; // Offset: 0x184 // Size: 0x04
	struct FMovieSceneTemplateGenerationLedger TemplateLedger; // Offset: 0x188 // Size: 0xa8
	struct FMovieSceneTrackFieldData TrackFieldData; // Offset: 0x230 // Size: 0x60
	struct FMovieSceneSubSectionFieldData SubSectionFieldData; // Offset: 0x290 // Size: 0x60
};

// Object Name: ScriptStruct MovieScene.MovieSceneSubSectionFieldData
// Size: 0x60 // Inherited bytes: 0x00
struct FMovieSceneSubSectionFieldData {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x00 // Size: 0x60
};

// Object Name: ScriptStruct MovieScene.MovieSceneTrackFieldData
// Size: 0x60 // Inherited bytes: 0x00
struct FMovieSceneTrackFieldData {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x00 // Size: 0x60
};

// Object Name: ScriptStruct MovieScene.MovieSceneTemplateGenerationLedger
// Size: 0xa8 // Inherited bytes: 0x00
struct FMovieSceneTemplateGenerationLedger {
	// Fields
	struct FMovieSceneTrackIdentifier LastTrackIdentifier; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<struct FGuid, struct FMovieSceneTrackIdentifier> TrackSignatureToTrackIdentifier; // Offset: 0x08 // Size: 0x50
	struct TMap<struct FGuid, struct FMovieSceneFrameRange> SubSectionRanges; // Offset: 0x58 // Size: 0x50
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationTemplateSerialNumber
// Size: 0x04 // Inherited bytes: 0x00
struct FMovieSceneEvaluationTemplateSerialNumber {
	// Fields
	uint32_t Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneSequenceHierarchy
// Size: 0xa0 // Inherited bytes: 0x00
struct FMovieSceneSequenceHierarchy {
	// Fields
	struct TMap<struct FMovieSceneSequenceID, struct FMovieSceneSubSequenceData> SubSequences; // Offset: 0x00 // Size: 0x50
	struct TMap<struct FMovieSceneSequenceID, struct FMovieSceneSequenceHierarchyNode> Hierarchy; // Offset: 0x50 // Size: 0x50
};

// Object Name: ScriptStruct MovieScene.MovieSceneSequenceHierarchyNode
// Size: 0x18 // Inherited bytes: 0x00
struct FMovieSceneSequenceHierarchyNode {
	// Fields
	struct FMovieSceneSequenceID ParentID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FMovieSceneSequenceID> Children; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneSubSequenceData
// Size: 0xa8 // Inherited bytes: 0x00
struct FMovieSceneSubSequenceData {
	// Fields
	struct FSoftObjectPath Sequence; // Offset: 0x00 // Size: 0x18
	struct FMovieSceneSequenceTransform RootToSequenceTransform; // Offset: 0x18 // Size: 0x0c
	struct FFrameRate TickResolution; // Offset: 0x24 // Size: 0x08
	struct FMovieSceneSequenceID DeterministicSequenceID; // Offset: 0x2c // Size: 0x04
	struct FMovieSceneFrameRange PlayRange; // Offset: 0x30 // Size: 0x10
	struct FMovieSceneFrameRange PreRollRange; // Offset: 0x40 // Size: 0x10
	struct FMovieSceneFrameRange PostRollRange; // Offset: 0x50 // Size: 0x10
	int32_t HierarchicalBias; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FMovieSceneSequenceInstanceDataPtr InstanceData; // Offset: 0x68 // Size: 0x18
	char pad_0x80[0x8]; // Offset: 0x80 // Size: 0x08
	struct FGuid SubSectionSignature; // Offset: 0x88 // Size: 0x10
	struct FMovieSceneSequenceTransform OuterToInnerTransform; // Offset: 0x98 // Size: 0x0c
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneSequenceTransform
// Size: 0x0c // Inherited bytes: 0x00
struct FMovieSceneSequenceTransform {
	// Fields
	float TimeScale; // Offset: 0x00 // Size: 0x04
	struct FFrameTime Offset; // Offset: 0x04 // Size: 0x08
};

// Object Name: ScriptStruct MovieScene.MovieSceneSequenceInstanceDataPtr
// Size: 0x18 // Inherited bytes: 0x00
struct FMovieSceneSequenceInstanceDataPtr {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationTrack
// Size: 0xf8 // Inherited bytes: 0x00
struct FMovieSceneEvaluationTrack {
	// Fields
	struct FGuid ObjectBindingId; // Offset: 0x00 // Size: 0x10
	uint16_t EvaluationPriority; // Offset: 0x10 // Size: 0x02
	enum class EEvaluationMethod EvaluationMethod; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x5]; // Offset: 0x13 // Size: 0x05
	struct FMovieSceneEvaluationTrackSegments Segments; // Offset: 0x18 // Size: 0x20
	struct UMovieSceneTrack* SourceTrack; // Offset: 0x38 // Size: 0x08
	struct FSectionEvaluationDataTree EvaluationTree; // Offset: 0x40 // Size: 0x60
	struct TArray<struct FMovieSceneEvalTemplatePtr> ChildTemplates; // Offset: 0xa0 // Size: 0x10
	struct FMovieSceneTrackImplementationPtr TrackTemplate; // Offset: 0xb0 // Size: 0x38
	struct FName EvaluationGroup; // Offset: 0xe8 // Size: 0x08
	char bEvaluateInPreroll : 1; // Offset: 0xf0 // Size: 0x01
	char bEvaluateInPostroll : 1; // Offset: 0xf0 // Size: 0x01
	char pad_0xF0_2 : 6; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x7]; // Offset: 0xf1 // Size: 0x07
};

// Object Name: ScriptStruct MovieScene.MovieSceneTrackImplementationPtr
// Size: 0x38 // Inherited bytes: 0x00
struct FMovieSceneTrackImplementationPtr {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
};

// Object Name: ScriptStruct MovieScene.SectionEvaluationDataTree
// Size: 0x60 // Inherited bytes: 0x00
struct FSectionEvaluationDataTree {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x00 // Size: 0x60
};

// Object Name: ScriptStruct MovieScene.MovieSceneEvaluationTrackSegments
// Size: 0x20 // Inherited bytes: 0x00
struct FMovieSceneEvaluationTrackSegments {
	// Fields
	struct TArray<int32_t> SegmentIdentifierToIndex; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FMovieSceneSegment> SortedSegments; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieSceneSegment
// Size: 0x58 // Inherited bytes: 0x00
struct FMovieSceneSegment {
	// Fields
	char pad_0x0[0x58]; // Offset: 0x00 // Size: 0x58
};

// Object Name: ScriptStruct MovieScene.MovieSceneSubSectionData
// Size: 0x1c // Inherited bytes: 0x00
struct FMovieSceneSubSectionData {
	// Fields
	struct TWeakObjectPtr<struct UMovieSceneSubSection> Section; // Offset: 0x00 // Size: 0x08
	struct FGuid ObjectBindingId; // Offset: 0x08 // Size: 0x10
	enum class ESectionEvaluationFlags Flags; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
};

// Object Name: ScriptStruct MovieScene.MovieSceneRootEvaluationTemplateInstance
// Size: 0x300 // Inherited bytes: 0x00
struct FMovieSceneRootEvaluationTemplateInstance {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
	struct TMap<struct FMovieSceneSequenceID, struct UObject*> DirectorInstances; // Offset: 0x18 // Size: 0x50
	char pad_0x68[0x298]; // Offset: 0x68 // Size: 0x298
};

// Object Name: ScriptStruct MovieScene.MovieSceneKeyStruct
// Size: 0x08 // Inherited bytes: 0x00
struct FMovieSceneKeyStruct {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct MovieScene.MovieSceneKeyTimeStruct
// Size: 0x28 // Inherited bytes: 0x08
struct FMovieSceneKeyTimeStruct : FMovieSceneKeyStruct {
	// Fields
	struct FFrameNumber Time; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x1c]; // Offset: 0x0c // Size: 0x1c
};

// Object Name: ScriptStruct MovieScene.GeneratedMovieSceneKeyStruct
// Size: 0x50 // Inherited bytes: 0x00
struct FGeneratedMovieSceneKeyStruct {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct MovieScene.MovieSceneObjectPathChannel
// Size: 0xc0 // Inherited bytes: 0x08
struct FMovieSceneObjectPathChannel : FMovieSceneChannel {
	// Fields
	struct UObject* PropertyClass; // Offset: 0x08 // Size: 0x08
	struct TArray<struct FFrameNumber> Times; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FMovieSceneObjectPathChannelKeyValue> Values; // Offset: 0x20 // Size: 0x10
	struct FMovieSceneObjectPathChannelKeyValue DefaultValue; // Offset: 0x30 // Size: 0x30
	char pad_0x60[0x60]; // Offset: 0x60 // Size: 0x60
};

// Object Name: ScriptStruct MovieScene.MovieSceneObjectPathChannelKeyValue
// Size: 0x30 // Inherited bytes: 0x00
struct FMovieSceneObjectPathChannelKeyValue {
	// Fields
	struct TSoftObjectPtr<UObject> SoftPtr; // Offset: 0x00 // Size: 0x28
	struct UObject* HardPtr; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct MovieScene.MovieScenePossessable
// Size: 0x48 // Inherited bytes: 0x00
struct FMovieScenePossessable {
	// Fields
	struct TArray<struct FName> Tags; // Offset: 0x00 // Size: 0x10
	struct FGuid Guid; // Offset: 0x10 // Size: 0x10
	struct FString Name; // Offset: 0x20 // Size: 0x10
	struct UObject* PossessedObjectClass; // Offset: 0x30 // Size: 0x08
	struct FGuid ParentGuid; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct MovieScene.MovieScenePropertySectionTemplate
// Size: 0x40 // Inherited bytes: 0x18
struct FMovieScenePropertySectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieScenePropertySectionData PropertyData; // Offset: 0x18 // Size: 0x28
};

// Object Name: ScriptStruct MovieScene.MovieScenePropertySectionData
// Size: 0x28 // Inherited bytes: 0x00
struct FMovieScenePropertySectionData {
	// Fields
	struct FName PropertyName; // Offset: 0x00 // Size: 0x08
	struct FString PropertyPath; // Offset: 0x08 // Size: 0x10
	struct FName FunctionName; // Offset: 0x18 // Size: 0x08
	struct FName NotifyFunctionName; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct MovieScene.MovieSceneEasingSettings
// Size: 0x38 // Inherited bytes: 0x00
struct FMovieSceneEasingSettings {
	// Fields
	int32_t AutoEaseInDuration; // Offset: 0x00 // Size: 0x04
	int32_t AutoEaseOutDuration; // Offset: 0x04 // Size: 0x04
	struct TScriptInterface<IMovieSceneEasingFunction> EaseIn; // Offset: 0x08 // Size: 0x10
	bool bManualEaseIn; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int32_t ManualEaseInDuration; // Offset: 0x1c // Size: 0x04
	struct TScriptInterface<IMovieSceneEasingFunction> EaseOut; // Offset: 0x20 // Size: 0x10
	bool bManualEaseOut; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	int32_t ManualEaseOutDuration; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneSectionEvalOptions
// Size: 0x02 // Inherited bytes: 0x00
struct FMovieSceneSectionEvalOptions {
	// Fields
	bool bCanEditCompletionMode; // Offset: 0x00 // Size: 0x01
	enum class EMovieSceneCompletionMode CompletionMode; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct MovieScene.MovieSceneSectionParameters
// Size: 0x18 // Inherited bytes: 0x00
struct FMovieSceneSectionParameters {
	// Fields
	struct FFrameNumber StartFrameOffset; // Offset: 0x00 // Size: 0x04
	float TimeScale; // Offset: 0x04 // Size: 0x04
	int32_t HierarchicalBias; // Offset: 0x08 // Size: 0x04
	float StartOffset; // Offset: 0x0c // Size: 0x04
	float PrerollTime; // Offset: 0x10 // Size: 0x04
	float PostrollTime; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.SectionEvaluationData
// Size: 0x0c // Inherited bytes: 0x00
struct FSectionEvaluationData {
	// Fields
	int32_t ImplIndex; // Offset: 0x00 // Size: 0x04
	struct FFrameNumber ForcedTime; // Offset: 0x04 // Size: 0x04
	enum class ESectionEvaluationFlags Flags; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct MovieScene.MovieSceneSequenceInstanceData
// Size: 0x08 // Inherited bytes: 0x00
struct FMovieSceneSequenceInstanceData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct MovieScene.MovieSceneSequencePlaybackSettings
// Size: 0x24 // Inherited bytes: 0x00
struct FMovieSceneSequencePlaybackSettings {
	// Fields
	char bAutoPlay : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_1 : 7; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FMovieSceneSequenceLoopCount LoopCount; // Offset: 0x04 // Size: 0x04
	float PlayRate; // Offset: 0x08 // Size: 0x04
	float StartTime; // Offset: 0x0c // Size: 0x04
	char bRandomStartTime : 1; // Offset: 0x10 // Size: 0x01
	char bRestoreState : 1; // Offset: 0x10 // Size: 0x01
	char bDisableMovementInput : 1; // Offset: 0x10 // Size: 0x01
	char bDisableLookAtInput : 1; // Offset: 0x10 // Size: 0x01
	char bHidePlayer : 1; // Offset: 0x10 // Size: 0x01
	char bHideHud : 1; // Offset: 0x10 // Size: 0x01
	char bDisableCameraCuts : 1; // Offset: 0x10 // Size: 0x01
	char bPauseAtEnd : 1; // Offset: 0x10 // Size: 0x01
	char bApplyRebase : 1; // Offset: 0x11 // Size: 0x01
	char bApplyOffset : 1; // Offset: 0x11 // Size: 0x01
	char pad_0x11_2 : 6; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	float StartBlendInTime; // Offset: 0x14 // Size: 0x04
	struct FVector Offset; // Offset: 0x18 // Size: 0x0c
};

// Object Name: ScriptStruct MovieScene.MovieSceneSequenceLoopCount
// Size: 0x04 // Inherited bytes: 0x00
struct FMovieSceneSequenceLoopCount {
	// Fields
	int32_t Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneSequenceReplProperties
// Size: 0x10 // Inherited bytes: 0x00
struct FMovieSceneSequenceReplProperties {
	// Fields
	struct FFrameTime LastKnownPosition; // Offset: 0x00 // Size: 0x08
	enum class EMovieScenePlayerStatus LastKnownStatus; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int32_t LastKnownNumLoops; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.MovieSceneSpawnable
// Size: 0x90 // Inherited bytes: 0x00
struct FMovieSceneSpawnable {
	// Fields
	struct FTransform SpawnTransform; // Offset: 0x00 // Size: 0x30
	struct TArray<struct FName> Tags; // Offset: 0x30 // Size: 0x10
	bool bContinuouslyRespawn; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x3]; // Offset: 0x41 // Size: 0x03
	struct FGuid Guid; // Offset: 0x44 // Size: 0x10
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString Name; // Offset: 0x58 // Size: 0x10
	struct UObject* ObjectTemplate; // Offset: 0x68 // Size: 0x08
	struct TArray<struct FGuid> ChildPossessables; // Offset: 0x70 // Size: 0x10
	enum class ESpawnOwnership Ownership; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x3]; // Offset: 0x81 // Size: 0x03
	struct FName LevelName; // Offset: 0x84 // Size: 0x08
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
};

// Object Name: ScriptStruct MovieScene.TestMovieSceneEvalTemplate
// Size: 0x18 // Inherited bytes: 0x18
struct FTestMovieSceneEvalTemplate : FMovieSceneEvalTemplate {
};

// Object Name: ScriptStruct MovieScene.MovieSceneTrackDisplayOptions
// Size: 0x04 // Inherited bytes: 0x00
struct FMovieSceneTrackDisplayOptions {
	// Fields
	char bShowVerticalFrames : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_1 : 7; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
};

// Object Name: ScriptStruct MovieScene.MovieSceneTrackEvalOptions
// Size: 0x04 // Inherited bytes: 0x00
struct FMovieSceneTrackEvalOptions {
	// Fields
	char bCanEvaluateNearestSection : 1; // Offset: 0x00 // Size: 0x01
	char bEvalNearestSection : 1; // Offset: 0x00 // Size: 0x01
	char bEvaluateInPreroll : 1; // Offset: 0x00 // Size: 0x01
	char bEvaluateInPostroll : 1; // Offset: 0x00 // Size: 0x01
	char bEvaluateNearestSection : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_5 : 3; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
};

// Object Name: ScriptStruct MovieScene.MovieSceneTrackImplementation
// Size: 0x10 // Inherited bytes: 0x10
struct FMovieSceneTrackImplementation : FMovieSceneEvalTemplateBase {
};

