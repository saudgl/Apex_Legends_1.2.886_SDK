#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class FSMAsset.FSM
// Size: 0x88 // Inherited bytes: 0x28
struct UFSM : UObject {
	// Fields
	struct UEdGraph* GraphView; // Offset: 0x28 // Size: 0x08
	struct FName EntryState; // Offset: 0x30 // Size: 0x08
	struct FFSMData StateMachine; // Offset: 0x38 // Size: 0x50
};

// Object Name: Class FSMAsset.FSMComponent
// Size: 0x138 // Inherited bytes: 0xf0
struct UFSMComponent : UActorComponent {
	// Fields
	struct TSoftObjectPtr<UFSM> FSMAssetPtr; // Offset: 0xf0 // Size: 0x28
	struct UFSM* FSM; // Offset: 0x118 // Size: 0x08
	struct FName CurrentState; // Offset: 0x120 // Size: 0x08
	struct FMulticastInlineDelegate OnStateChanged; // Offset: 0x128 // Size: 0x10

	// Functions

	// Object Name: Function FSMAsset.FSMComponent.RestartFSM
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RestartFSM(); // Offset: 0x101ca9884 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function FSMAsset.FSMComponent.ReceiveKeyword
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ReceiveKeyword(struct FName& Condition); // Offset: 0x101ca97c4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function FSMAsset.FSMComponent.IsRunning
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsRunning(); // Offset: 0x101ca96f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function FSMAsset.FSMComponent.GotoStateDirectly
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GotoStateDirectly(struct FName& NewState); // Offset: 0x101ca9738 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function FSMAsset.FSMComponent.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetCurrentState(); // Offset: 0x101ca9850 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function FSMAsset.FSMComponent.EndFSM
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndFSM(); // Offset: 0x101ca9724 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function FSMAsset.FSMComponent.ChangeFSM
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChangeFSM(struct UFSM* NewFSM); // Offset: 0x101ca9898 // Return & Params: Num(1) Size(0x8)
};

