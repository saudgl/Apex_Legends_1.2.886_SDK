#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GamePlayBridge.EventFlowElement_DispatcherBase
// Size: 0xb0 // Inherited bytes: 0x90
struct UEventFlowElement_DispatcherBase : UEventFlowElementBase {
	// Fields
	struct UEntityDispatcherBase* DispatcherInstance; // Offset: 0x90 // Size: 0x08
	struct FName FinishTag; // Offset: 0x98 // Size: 0x08
	struct FEventFlowFinishEvent OnDispatchFinished; // Offset: 0xa0 // Size: 0x10

	// Functions

	// Object Name: Function GamePlayBridge.EventFlowElement_DispatcherBase.ForceFinishDispatcherToServer
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer]
	void ForceFinishDispatcherToServer(struct FName Tag); // Offset: 0x101f27918 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GamePlayBridge.EventFlowElement_DispatcherBase.BindOnDispatchFinishedEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void BindOnDispatchFinishedEvent(struct FDelegate& Delegate); // Offset: 0x101f2799c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class GamePlayBridge.EventFlowElement_ActiveDispatcher
// Size: 0xb8 // Inherited bytes: 0xb0
struct UEventFlowElement_ActiveDispatcher : UEventFlowElement_DispatcherBase {
	// Fields
	char bInterruptSequenceWhenAbort : 1; // Offset: 0xb0 // Size: 0x01
	char pad_0xB0_1 : 7; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x7]; // Offset: 0xb1 // Size: 0x07

	// Functions

	// Object Name: Function GamePlayBridge.EventFlowElement_ActiveDispatcher.WhenDispatcherFinished
	// Flags: [Final|Native|Protected|HasOutParms]
	void WhenDispatcherFinished(struct FName& InFinishTag); // Offset: 0x101f27dd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GamePlayBridge.EventFlowElement_ActiveDispatcher.WhenDispatcherAborted
	// Flags: [Final|Native|Protected]
	void WhenDispatcherAborted(); // Offset: 0x101f27dc0 // Return & Params: Num(0) Size(0x0)
};

