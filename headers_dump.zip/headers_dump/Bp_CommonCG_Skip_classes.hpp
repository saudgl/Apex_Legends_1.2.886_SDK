#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Bp_CommonCG_Skip.Bp_CommonCG_Skip_C
// Size: 0x2b0 // Inherited bytes: 0x240
struct UBp_CommonCG_Skip_C : UUserWidget {
	// Fields
	struct UCanvasPanel* AdaptPanel; // Offset: 0x240 // Size: 0x08
	struct UBP_CommonButton_C* BP_CommonButton; // Offset: 0x248 // Size: 0x08
	struct UTextBlock* BP_SkipText; // Offset: 0x250 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_load; // Offset: 0x258 // Size: 0x08
	struct UImage* Image_BGrBottom; // Offset: 0x260 // Size: 0x08
	struct UImage* Image_BGTop; // Offset: 0x268 // Size: 0x08
	struct UTextBlock* MediaExplain_Text; // Offset: 0x270 // Size: 0x08
	struct UCanvasPanel* Panel_Skip; // Offset: 0x278 // Size: 0x08
	struct UButton* Skip_Panel; // Offset: 0x280 // Size: 0x08
	struct UTextBlock* Skip_Text; // Offset: 0x288 // Size: 0x08
	struct UTextBlock* Skip_Text_schedule; // Offset: 0x290 // Size: 0x08
	struct FText Count_Down_SeasonCGSkip; // Offset: 0x298 // Size: 0x18

	// Functions

	// Object Name: Function Bp_CommonCG_Skip.Bp_CommonCG_Skip_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x10)
};

