#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AudioMixer.SynthComponent
// Size: 0x680 // Inherited bytes: 0x260
struct USynthComponent : USceneComponent {
	// Fields
	char bAutoDestroy : 1; // Offset: 0x258 // Size: 0x01
	char bStopWhenOwnerDestroyed : 1; // Offset: 0x258 // Size: 0x01
	char bAllowSpatialization : 1; // Offset: 0x258 // Size: 0x01
	char bOverrideAttenuation : 1; // Offset: 0x258 // Size: 0x01
	char bOutputToBusOnly : 1; // Offset: 0x258 // Size: 0x01
	struct USoundAttenuation* AttenuationSettings; // Offset: 0x260 // Size: 0x08
	struct FSoundAttenuationSettings AttenuationOverrides; // Offset: 0x268 // Size: 0x2e8
	struct USoundConcurrency* ConcurrencySettings; // Offset: 0x550 // Size: 0x08
	struct TSet<struct USoundConcurrency*> ConcurrencySet; // Offset: 0x558 // Size: 0x50
	struct USoundClass* SoundClass; // Offset: 0x5a8 // Size: 0x08
	struct USoundEffectSourcePresetChain* SourceEffectChain; // Offset: 0x5b0 // Size: 0x08
	struct USoundSubmix* SoundSubmix; // Offset: 0x5b8 // Size: 0x08
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // Offset: 0x5c0 // Size: 0x10
	struct TArray<struct FSoundSourceBusSendInfo> BusSends; // Offset: 0x5d0 // Size: 0x10
	struct FSoundModulation Modulation; // Offset: 0x5e0 // Size: 0x10
	struct TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // Offset: 0x5f0 // Size: 0x10
	char bIsUISound : 1; // Offset: 0x600 // Size: 0x01
	char bIsPreviewSound : 1; // Offset: 0x600 // Size: 0x01
	char pad_0x600_7 : 1; // Offset: 0x600 // Size: 0x01
	char pad_0x601[0x3]; // Offset: 0x601 // Size: 0x03
	int32_t EnvelopeFollowerAttackTime; // Offset: 0x604 // Size: 0x04
	int32_t EnvelopeFollowerReleaseTime; // Offset: 0x608 // Size: 0x04
	char pad_0x60C[0x4]; // Offset: 0x60c // Size: 0x04
	struct FMulticastInlineDelegate OnAudioEnvelopeValue; // Offset: 0x610 // Size: 0x10
	char pad_0x620[0x20]; // Offset: 0x620 // Size: 0x20
	struct USynthSound* Synth; // Offset: 0x640 // Size: 0x08
	struct UAudioComponent* AudioComponent; // Offset: 0x648 // Size: 0x08
	char pad_0x650[0x30]; // Offset: 0x650 // Size: 0x30

	// Functions

	// Object Name: Function AudioMixer.SynthComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x1052b84a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AudioMixer.SynthComponent.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Start(); // Offset: 0x1052b84b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AudioMixer.SynthComponent.SetVolumeMultiplier
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVolumeMultiplier(float VolumeMultiplier); // Offset: 0x1052b83f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AudioMixer.SynthComponent.SetSubmixSend
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSubmixSend(struct USoundSubmix* Submix, float SendLevel); // Offset: 0x1052b8330 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AudioMixer.SynthComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlaying(); // Offset: 0x1052b846c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AudioMixer.AudioGenerator
// Size: 0xc0 // Inherited bytes: 0x28
struct UAudioGenerator : UObject {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 // Size: 0x98
};

// Object Name: Class AudioMixer.AudioMixerBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAudioMixerBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct USoundWave* StopRecordingOutput(struct UObject* WorldContextObject, enum class EAudioRecordingExportType ExportType, struct FString Name, struct FString Path, struct USoundSubmix* SubmixToRecord, struct USoundWave* ExistingSoundWaveToOverwrite); // Offset: 0x1052b5b30 // Return & Params: Num(7) Size(0x48)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToStopAnalyzing); // Offset: 0x1052b5750 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartRecordingOutput(struct UObject* WorldContextObject, float ExpectedDuration, struct USoundSubmix* SubmixToRecord); // Offset: 0x1052b5d74 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToAnalyze, enum class EFFTSize FFTSize, enum class EFFTPeakInterpolationMethod InterpolationMethod, enum class EFFTWindowType WindowType, float HopSize); // Offset: 0x1052b5804 // Return & Params: Num(6) Size(0x18)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex, bool bBypassed); // Offset: 0x1052b5130 // Return & Params: Num(4) Size(0x15)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ResumeRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Offset: 0x1052b59c8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex); // Offset: 0x1052b5270 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Offset: 0x1052b5ee4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PauseRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Offset: 0x1052b5a7c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetPhaseForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Phases, struct USoundSubmix* SubmixToAnalyze); // Offset: 0x1052b5458 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain); // Offset: 0x1052b5074 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMagnitudeForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Magnitudes, struct USoundSubmix* SubmixToAnalyze); // Offset: 0x1052b55d4 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearMasterSubmixEffects(struct UObject* WorldContextObject); // Offset: 0x1052b5e70 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry); // Offset: 0x1052b5368 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Offset: 0x1052b5f98 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// Size: 0xd0 // Inherited bytes: 0x40
struct USubmixEffectDynamicsProcessorPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x68]; // Offset: 0x40 // Size: 0x68
	struct FSubmixEffectDynamicsProcessorSettings Settings; // Offset: 0xa8 // Size: 0x28

	// Functions

	// Object Name: Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectDynamicsProcessorSettings& InSettings); // Offset: 0x1052b6944 // Return & Params: Num(1) Size(0x28)
};

// Object Name: Class AudioMixer.SubmixEffectSubmixEQPreset
// Size: 0xa0 // Inherited bytes: 0x40
struct USubmixEffectSubmixEQPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 // Size: 0x50
	struct FSubmixEffectSubmixEQSettings Settings; // Offset: 0x90 // Size: 0x10

	// Functions

	// Object Name: Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings); // Offset: 0x1052b6ed8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AudioMixer.SubmixEffectReverbPreset
// Size: 0xe8 // Inherited bytes: 0x40
struct USubmixEffectReverbPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x74]; // Offset: 0x40 // Size: 0x74
	struct FSubmixEffectReverbSettings Settings; // Offset: 0xb4 // Size: 0x34

	// Functions

	// Object Name: Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // Offset: 0x1052b73c4 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function AudioMixer.SubmixEffectReverbPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectReverbSettings& InSettings); // Offset: 0x1052b74c4 // Return & Params: Num(1) Size(0x34)
};

// Object Name: Class AudioMixer.SubmixEffectReverbFastPreset
// Size: 0xe8 // Inherited bytes: 0x40
struct USubmixEffectReverbFastPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x74]; // Offset: 0x40 // Size: 0x74
	struct FSubmixEffectReverbFastSettings Settings; // Offset: 0xb4 // Size: 0x34

	// Functions

	// Object Name: Function AudioMixer.SubmixEffectReverbFastPreset.SetSettingsWithReverbEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // Offset: 0x1052b7a50 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function AudioMixer.SubmixEffectReverbFastPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectReverbFastSettings& InSettings); // Offset: 0x1052b7b50 // Return & Params: Num(1) Size(0x34)
};

// Object Name: Class AudioMixer.SynthSound
// Size: 0x330 // Inherited bytes: 0x310
struct USynthSound : USoundWaveProcedural {
	// Fields
	struct USynthComponent* OwningSynthComponent; // Offset: 0x310 // Size: 0x08
	char pad_0x318[0x18]; // Offset: 0x318 // Size: 0x18
};

