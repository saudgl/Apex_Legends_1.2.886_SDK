#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct GameAction_Runtime.GameActionTransitionBase
// Size: 0x18 // Inherited bytes: 0x00
struct FGameActionTransitionBase {
	// Fields
	struct FDelegate Condition; // Offset: 0x00 // Size: 0x10
	struct UGameActionSegmentBase* TransitionToSegment; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionEventTransition
// Size: 0x20 // Inherited bytes: 0x18
struct FGameActionEventTransition : FGameActionTransitionBase {
	// Fields
	struct FName EventName; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionTickTransition
// Size: 0x18 // Inherited bytes: 0x18
struct FGameActionTickTransition : FGameActionTransitionBase {
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionAnimationSectionTemplate
// Size: 0x170 // Inherited bytes: 0x18
struct FGameActionAnimationSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FGameActionAnimationSectionTemplateParameters Params; // Offset: 0x18 // Size: 0x158
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionAnimationParams
// Size: 0x150 // Inherited bytes: 0x00
struct FGameActionAnimationParams {
	// Fields
	struct UAnimMontage* Montage; // Offset: 0x00 // Size: 0x08
	struct FFrameNumber FirstLoopStartFrameOffset; // Offset: 0x08 // Size: 0x04
	struct FFrameNumber StartFrameOffset; // Offset: 0x0c // Size: 0x04
	struct FFrameNumber EndFrameOffset; // Offset: 0x10 // Size: 0x04
	float PlayRate; // Offset: 0x14 // Size: 0x04
	struct FMovieSceneFloatChannel Weight; // Offset: 0x18 // Size: 0xa0
	struct FMovieSceneByteChannel TearDownStrategy; // Offset: 0xb8 // Size: 0x98
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionAnimationSectionTemplateParameters
// Size: 0x158 // Inherited bytes: 0x150
struct FGameActionAnimationSectionTemplateParameters : FGameActionAnimationParams {
	// Fields
	struct FFrameNumber SectionStartTime; // Offset: 0x150 // Size: 0x04
	struct FFrameNumber SectionEndTime; // Offset: 0x154 // Size: 0x04
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionSequenceOverride
// Size: 0x01 // Inherited bytes: 0x00
struct FGameActionSequenceOverride {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionSceneActorData
// Size: 0x01 // Inherited bytes: 0x00
struct FGameActionSceneActorData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionSpawnBySpawnerSectionTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FGameActionSpawnBySpawnerSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UGameActionSpawnBySpawnerSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionSpawnByTemplateSectionTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FGameActionSpawnByTemplateSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UGameActionSpawnByTemplateSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionStateEventSectionTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FGameActionStateEventSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UGameActionStateEventSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionStateEventInnerKeyChannel
// Size: 0x88 // Inherited bytes: 0x08
struct FGameActionStateEventInnerKeyChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FGameActionStateEventInnerKeyValue> KeyValues; // Offset: 0x18 // Size: 0x10
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionStateEventInnerKeyValue
// Size: 0x08 // Inherited bytes: 0x00
struct FGameActionStateEventInnerKeyValue {
	// Fields
	struct UGameActionStateInnerKeyEvent* KeyEvent; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionKeyEventSectionTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FGameActionKeyEventSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UGameActionKeyEventSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionKeyEventChannel
// Size: 0x88 // Inherited bytes: 0x08
struct FGameActionKeyEventChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FGameActionKeyEventValue> KeyValues; // Offset: 0x18 // Size: 0x10
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionKeyEventValue
// Size: 0x08 // Inherited bytes: 0x00
struct FGameActionKeyEventValue {
	// Fields
	struct UGameActionKeyEvent* KeyEvent; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionSequenceSubobjectBinding
// Size: 0x18 // Inherited bytes: 0x00
struct FGameActionSequenceSubobjectBinding {
	// Fields
	struct FName OwnerPropertyName; // Offset: 0x00 // Size: 0x08
	struct FString PathToSubobject; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionPossessableActorData
// Size: 0x18 // Inherited bytes: 0x00
struct FGameActionPossessableActorData {
	// Fields
	struct FVector RelativeLocation; // Offset: 0x00 // Size: 0x0c
	struct FRotator RelativeRotation; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionEntry
// Size: 0x10 // Inherited bytes: 0x00
struct FGameActionEntry {
	// Fields
	struct TArray<struct FGameActionEntryTransition> Transitions; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionEntryTransition
// Size: 0x18 // Inherited bytes: 0x18
struct FGameActionEntryTransition : FGameActionTransitionBase {
};

// Object Name: ScriptStruct GameAction_Runtime.GameActionEventEntry
// Size: 0x01 // Inherited bytes: 0x00
struct FGameActionEventEntry {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

