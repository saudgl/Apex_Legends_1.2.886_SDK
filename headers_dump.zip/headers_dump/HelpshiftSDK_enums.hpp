#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum HelpshiftSDK.EHelpshiftConfigParameterValueType
enum class EHelpshiftConfigParameterValueType : uint8 {
	Null = 0,
	Integer = 1,
	Float = 2,
	Bool = 3,
	String = 4,
	Array = 5,
	Map = 6,
	EHelpshiftConfigParameterValueType_MAX = 7
};

// Object Name: Enum HelpshiftSDK.EHelpshiftAuthenticationFailureReason
enum class EHelpshiftAuthenticationFailureReason : uint8 {
	REASON_AUTH_TOKEN_NOT_PROVIDED = 0,
	REASON_INVALID_AUTH_TOKEN = 1,
	UNKNOWN = 2,
	EHelpshiftAuthenticationFailureReason_MAX = 3
};

// Object Name: Enum HelpshiftSDK.EHelpshiftCustomIssueFieldParameterValueType
enum class EHelpshiftCustomIssueFieldParameterValueType : uint8 {
	Null = 0,
	SingleLine = 1,
	MultiLine = 2,
	Number = 3,
	Dropdown = 4,
	Date = 5,
	Checkbox = 6,
	EHelpshiftCustomIssueFieldParameterValueType_MAX = 7
};

