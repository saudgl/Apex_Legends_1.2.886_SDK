#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ActorSequence.ActorSequence
// Size: 0x370 // Inherited bytes: 0x348
struct UActorSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 // Size: 0x08
	struct FActorSequenceObjectReferenceMap ObjectReferences; // Offset: 0x350 // Size: 0x20
};

// Object Name: Class ActorSequence.ActorSequenceComponent
// Size: 0x128 // Inherited bytes: 0xf0
struct UActorSequenceComponent : UActorComponent {
	// Fields
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0xf0 // Size: 0x24
	char pad_0x114[0x4]; // Offset: 0x114 // Size: 0x04
	struct UActorSequence* Sequence; // Offset: 0x118 // Size: 0x08
	struct UActorSequencePlayer* SequencePlayer; // Offset: 0x120 // Size: 0x08
};

// Object Name: Class ActorSequence.ActorSequencePlayer
// Size: 0x828 // Inherited bytes: 0x828
struct UActorSequencePlayer : UMovieSceneSequencePlayer {
};

