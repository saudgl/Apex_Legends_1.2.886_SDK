#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SysErrCodeConfig_Type.BP_STRUCT_SysErrCodeConfig_Type
// Size: 0x28 // Inherited bytes: 0x00
struct FBP_STRUCT_SysErrCodeConfig_Type {
	// Fields
	int32_t Id_26_7C8D14006F94A7C476CACADB046B8334; // Offset: 0x00 // Size: 0x04
	int32_t ErrorCode_27_3B88ED000A07421C580B8D3103A3DDF5; // Offset: 0x04 // Size: 0x04
	struct FText Message_28_27ABDD0029D37A882D3E78E4070052B5; // Offset: 0x08 // Size: 0x18
	int32_t TipType_29_0D8C1F804BB38B6210C84DCA0FCF8525; // Offset: 0x20 // Size: 0x04
	int32_t IsUpload_30_7C8D14006F94A7C476CACADB046B8334; // Offset: 0x24 // Size: 0x04
};

