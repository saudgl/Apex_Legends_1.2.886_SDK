#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum IdeaDecal.EIdeaDecalParentType
enum class EIdeaDecalParentType : uint8 {
	NoParent = 0,
	MovableStaticMesh = 1,
	SkeletalMesh = 2,
	DestroyableStaticMesh = 3,
	EIdeaDecalParentType_MAX = 4
};

