#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum Skill.EUTSkillStopReason
enum class EUTSkillStopReason : uint8 {
	SkillStopReason_UnKown = 0,
	SkillStopReason_Finished = 1,
	SkillStopReason_FailedWithSkillInvalid = 2,
	SkillStopReason_FailedWithPhaseInvalid = 3,
	SkillStopReason_FailedWithConditionInvalid = 4,
	SkillStopReason_UserCanceled = 5,
	SkillStopReason_Interrupted = 6,
	SkillStopReason_Clear = 7,
	SkillStopReason_MainHandNoRecoverInterrupted = 8,
	SkillStopReason_MainHandCanRecoverInterrupted = 9,
	SkillStopReason_ClientPredictFailed = 10,
	SkillStopReason_MAX = 11
};

// Object Name: Enum Skill.EUTSkillEventType
enum class EUTSkillEventType : uint8 {
	SET_KEY_DOWN = 0,
	SET_KEY_UP = 1,
	SET_COLLIDE_TARGET = 2,
	SET_MISS_TARGET = 3,
	SET_HIT_TARGET = 4,
	SET_KILL_TARGET = 5,
	SET_COLLIDE_ACTOR = 6,
	SET_FINDPATH_FINISH = 7,
	SET_PHASE_START = 8,
	SET_PHASE_FINISH = 9,
	SET_PHASE_FINISH_EARLY = 10,
	SET_PHASE_INTERRUPT = 11,
	SET_SKILL_FINISH = 12,
	SET_SKILL_CANCEL = 13,
	SET_NO_TARGET = 14,
	SET_SKILL_INTERRUPT = 15,
	SET_MAX = 16
};

// Object Name: Enum Skill.ESkillAttrOperator
enum class ESkillAttrOperator : uint8 {
	Additive = 0,
	Multiplicitive = 1,
	MultiplicitiveScale = 2,
	Override = 3,
	Max = 4
};

// Object Name: Enum Skill.EDamageSourceType
enum class EDamageSourceType : uint8 {
	NormalDamage = 0,
	TrueDamage = 1,
	Explosion = 2,
	Burns = 3,
	Caustic = 4,
	EDamageSourceType_MAX = 5
};

// Object Name: Enum Skill.ETriggerSkillCondition
enum class ETriggerSkillCondition : uint8 {
	Self = 0,
	Teammates = 1,
	Enemy = 2,
	ETriggerSkillCondition_MAX = 3
};

// Object Name: Enum Skill.ESkillType
enum class ESkillType : uint8 {
	Technical = 0,
	Passive = 1,
	Ultimate = 2,
	ByItem = 3,
	MeleeAttack = 4,
	Others = 5,
	ESkillType_MAX = 6
};

// Object Name: Enum Skill.ESkillCastType
enum class ESkillCastType : uint8 {
	Normal = 1,
	Trigger = 2,
	Passive = 3,
	Max = 4
};

// Object Name: Enum Skill.ECDCompare
enum class ECDCompare : uint8 {
	CDC_Bigger = 0,
	CDC_Equal = 1,
	CDC_Smaller = 2,
	CDC_MAX = 3
};

// Object Name: Enum Skill.ECDType
enum class ECDType : uint8 {
	CDT_Energy = 1,
	CDT_Point = 2,
	CDT_MAX = 3
};

// Object Name: Enum Skill.ESkillCollectResourcesType
enum class ESkillCollectResourcesType : uint8 {
	ESCRT_FPP_Only = 0,
	ESCRT_TPP_Only = 1,
	ESCRT_All = 2,
	ESCRT_MAX = 3
};

// Object Name: Enum Skill.ESkillAddForceDirection
enum class ESkillAddForceDirection : uint8 {
	ESkillDir_SelfToTarget = 0,
	ESkillDir_TargetToSelf = 1,
	ESkillDir_SelfDir = 2,
	ESkillDir_TargetDir = 3,
	ESkillDir_TargetZ = 4,
	ESkillDir_SelfZ = 5,
	ESkillDir_MAX = 6
};

// Object Name: Enum Skill.ECDSpeedUpType
enum class ECDSpeedUpType : uint8 {
	UnUseSpeed = 0,
	TacticalType = 1,
	TacticalType_Bloodhound = 2,
	UltimateType = 3,
	PassiveType = 4,
	None = 5,
	ECDSpeedUpType_MAX = 6
};

// Object Name: Enum Skill.UTPickerTargetType
enum class UTPickerTargetType : uint8 {
	PTT_FRIEND = 0,
	PTT_ENEMY = 1,
	PTT_ALL = 2,
	PTT_Self = 3,
	PTT_MAX = 4
};

// Object Name: Enum Skill.EUTSkillPhaseJumpResult
enum class EUTSkillPhaseJumpResult : uint8 {
	PJR_OK = 0,
	PJR_LIFE_FULL = 1,
	PJR_ARMOR_UNEQUIPPED = 2,
	PJR_ARMOR_FULL = 3,
	PJR_LIFE_AND_ARMOR_FULL = 4,
	PJR_ULTIMATE_SKILL_READY = 5,
	PJR_ITEM_IN_USE = 6,
	PJR_IN_DEATH_PROTECT_STATE = 7,
	PJR_TOTEM_SPACE_LIMITED = 8,
	PJR_MAX = 9
};

// Object Name: Enum Skill.ESkillActionDataNetRole
enum class ESkillActionDataNetRole : uint8 {
	TO_CLIENT = 0,
	TO_SERVER = 1,
	TO_MULTICAST = 2,
	TO_MAX = 3
};

// Object Name: Enum Skill.ESkillEndConditionType
enum class ESkillEndConditionType : uint8 {
	ESECT_MyHP = 0,
	ESECT_MyHPAndSD = 1,
	ESECT_FrinedHP = 2,
	ESECT_ExistsEnemy = 3,
	ESECT_ExistsEnemy2 = 4,
	ESECT_ExistsEnemyAndFriends = 5,
	ESECT_AnyTime = 6,
	ESECT_None = 7,
	ESECT_MAX = 8
};

// Object Name: Enum Skill.ESkillConditionType
enum class ESkillConditionType : uint8 {
	ESCT_MyHP = 0,
	ESCT_MyHPAndSD = 1,
	ESCT_MyHPAndSDNoEmeny = 2,
	ESCT_FrinedHP = 3,
	ESCT_ExistsEnemy = 4,
	ESCT_ExistsEnemy2 = 5,
	ESCT_ExistsEnemyAndFriends = 6,
	ESCT_AnyTime = 7,
	ESCT_None = 8,
	ESCT_MAX = 9
};

// Object Name: Enum Skill.UTSkillPhaseType
enum class UTSkillPhaseType : uint8 {
	SPT_SEQUENCE = 0,
	SPT_WAIT = 1,
	SPT_FINAL = 2,
	SPT_MAX = 3
};

// Object Name: Enum Skill.UTSkillPickerType
enum class UTSkillPickerType : uint8 {
	SPT_SELF = 0,
	SPT_TARGET = 1,
	SPT_VIEWPOINT = 2,
	SPT_VIEWPOINT_STATIC = 3,
	SPT_RECT = 4,
	SPT_CIRCLE = 5,
	SPT_FAN = 6,
	SPT_CROSSHAIR = 7,
	SPT_CUSTOM = 8,
	SPT_DESTINATION = 9,
	SPT_VIEWPOINT_NORMAL = 10,
	SPT_DEFAULT = 11,
	SPT_MAX = 12
};

