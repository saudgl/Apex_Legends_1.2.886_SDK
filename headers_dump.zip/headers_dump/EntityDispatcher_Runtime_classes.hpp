#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class EntityDispatcher_Runtime.BTDecorator_IsInDispatch
// Size: 0xc8 // Inherited bytes: 0xc8
struct UBTDecorator_IsInDispatch : UBTDecorator {
};

// Object Name: Class EntityDispatcher_Runtime.BTTask_AcceptDispatch
// Size: 0x128 // Inherited bytes: 0x128
struct UBTTask_AcceptDispatch : UBTTaskNode {
};

// Object Name: Class EntityDispatcher_Runtime.BTTask_ExecuteDispatcher
// Size: 0x130 // Inherited bytes: 0x128
struct UBTTask_ExecuteDispatcher : UBTTaskNode {
	// Fields
	struct UEntityDispatcherBase* Dispatcher; // Offset: 0x128 // Size: 0x08
};

// Object Name: Class EntityDispatcher_Runtime.DA_NavPathVisualControlMetadata
// Size: 0x28 // Inherited bytes: 0x28
struct UDA_NavPathVisualControlMetadata : USplineMetadata {
};

// Object Name: Class EntityDispatcher_Runtime.DA_NavPathVisualControl
// Size: 0x650 // Inherited bytes: 0x650
struct UDA_NavPathVisualControl : USplineComponent {
};

// Object Name: Class EntityDispatcher_Runtime.DA_NavPathActorBase
// Size: 0x290 // Inherited bytes: 0x268
struct ADA_NavPathActorBase : AActor {
	// Fields
	char bIsClosedLoop : 1; // Offset: 0x268 // Size: 0x01
	char pad_0x268_1 : 7; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x7]; // Offset: 0x269 // Size: 0x07
	struct TArray<struct FDA_NavPathPoint> NavPathPoints; // Offset: 0x270 // Size: 0x10
	struct UNavigationQueryFilter* QueryFilter; // Offset: 0x280 // Size: 0x08
	struct USceneComponent* NavPathRoot; // Offset: 0x288 // Size: 0x08

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DA_NavPathActorBase.GetSlotName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetSlotName(int32_t Index); // Offset: 0x101e7ccb8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function EntityDispatcher_Runtime.DA_NavPathActorBase.GetPointWorldRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetPointWorldRotation(int32_t Index); // Offset: 0x101e7cd44 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function EntityDispatcher_Runtime.DA_NavPathActorBase.GetPointWorldLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetPointWorldLocation(int32_t Index); // Offset: 0x101e7cdd4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function EntityDispatcher_Runtime.DA_NavPathActorBase.GetPathPointCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPathPointCount(); // Offset: 0x101e7ce64 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class EntityDispatcher_Runtime.DA_NavPathActor
// Size: 0x290 // Inherited bytes: 0x290
struct ADA_NavPathActor : ADA_NavPathActorBase {
};

// Object Name: Class EntityDispatcher_Runtime.DA_SequencePositionPreviewHelper
// Size: 0xf0 // Inherited bytes: 0xf0
struct UDA_SequencePositionPreviewHelper : UActorComponent {
};

// Object Name: Class EntityDispatcher_Runtime.DA_SequencePositionPreview
// Size: 0x290 // Inherited bytes: 0x268
struct ADA_SequencePositionPreview : AActor {
	// Fields
	struct TSoftObjectPtr<ULevelSequence> PreviewSequence; // Offset: 0x268 // Size: 0x28
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableActionBase
// Size: 0x50 // Inherited bytes: 0x28
struct UDispatchableActionBase : UObject {
	// Fields
	char bIsCoexistWithOtherActionForever : 1; // Offset: 0x28 // Size: 0x01
	char pad_0x28_1 : 7; // Offset: 0x28 // Size: 0x01
	enum class EDispatchableActionCompatibleType DefaultActionCompatibleType; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x6]; // Offset: 0x2a // Size: 0x06
	struct UDispatchableActionBase* GeneratedByTemplate; // Offset: 0x30 // Size: 0x08
	char bReplicated : 1; // Offset: 0x38 // Size: 0x01
	char pad_0x38_1 : 7; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct ADispatchableActionReplicationActor* ReplicationActor; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x1]; // Offset: 0x48 // Size: 0x01
	char bIsCachedAction : 1; // Offset: 0x49 // Size: 0x01
	char bTickable : 1; // Offset: 0x49 // Size: 0x01
	char pad_0x49_2 : 6; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x6]; // Offset: 0x4a // Size: 0x06

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.SetActionReplicatedTargets
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void SetActionReplicatedTargets(struct AActor* NetOwner, struct TArray<struct AActor*>& RelevantTargets, bool ReplicateDispatcher, float RelevantDistance); // Offset: 0x101e80b80 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveWhenTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenTick(float DeltaSeconds); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveWhenResetAction
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenResetAction(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveWhenBroadcastDeactived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenBroadcastDeactived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveWhenBroadcastActived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenBroadcastActived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveWhenActionReactived
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ReceiveWhenActionReactived(); // Offset: 0x101e80a20 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveWhenActionDeactived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenActionDeactived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveWhenActionConstruct
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenActionConstruct(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveWhenActionActived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenActionActived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveWhenActionAborted
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ReceiveWhenActionAborted(enum class EDispatchableActionAbortState AbortState); // Offset: 0x101e80a3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ReceiveCheckActionDispatchable
	// Flags: [Native|Event|Protected|BlueprintEvent|Const]
	bool ReceiveCheckActionDispatchable(); // Offset: 0x101e809e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.IsLocalControlled
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	bool IsLocalControlled(); // Offset: 0x101e80d2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.IsEvaluateBound
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsEvaluateBound(struct FEvaluateDispatchableActionParameter& Evaluator); // Offset: 0x101e808e4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.HasAuthority
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	bool HasAuthority(); // Offset: 0x101e80cf8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.GetNetOwner
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	struct ADispatchableActionReplicationActor* GetNetOwner(); // Offset: 0x101e80d60 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.FinishAction
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void FinishAction(struct FDispatchableActionFinishEvent& FinishEvent); // Offset: 0x101e80ad4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.FinishAbort
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void FinishAbort(); // Offset: 0x101e80ac0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ExecuteEvaluate
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable|Const]
	bool ExecuteEvaluate(struct FEvaluateDispatchableActionParameter& Evaluator); // Offset: 0x101e807b8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.CreateAssignOrResetActionFromTemplate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|Const]
	void CreateAssignOrResetActionFromTemplate(struct UObject* Outer, struct UDispatchableActionBase*& InstanceRef); // Offset: 0x101e80e54 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.CreateActionFromTemplate
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	struct UDispatchableActionBase* CreateActionFromTemplate(struct UObject* Outer); // Offset: 0x101e80f28 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionBase.ConstructAndActiveAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ConstructAndActiveAction(); // Offset: 0x101e80fb4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableAction_PlaySequenceBase
// Size: 0x100 // Inherited bytes: 0x50
struct UDispatchableAction_PlaySequenceBase : UDispatchableActionBase {
	// Fields
	struct ULevelSequence* LevelSequence; // Offset: 0x50 // Size: 0x08
	struct TSoftObjectPtr<AActor> PlayOrigin; // Offset: 0x58 // Size: 0x28
	struct TArray<struct FPlaySequenceActorData> PlaySequenceActorDatas; // Offset: 0x80 // Size: 0x10
	struct TArray<struct FPlaySequenceMoveToData> PlaySequenceMoveToDatas; // Offset: 0x90 // Size: 0x10
	struct FDispatchableActionFinishEvent WhenPlayCompleted; // Offset: 0xa0 // Size: 0x10
	struct FDispatchableActionFinishEvent WhenCanNotPlay; // Offset: 0xb0 // Size: 0x10
	struct AReplicableLevelSequenceActor* SequenceActor; // Offset: 0xc0 // Size: 0x08
	char pad_0xC8[0x8]; // Offset: 0xc8 // Size: 0x08
	struct FTransform PlayOriginTransform; // Offset: 0xd0 // Size: 0x30

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_PlaySequenceBase.WhenSequencerPlayFinished
	// Flags: [Native|Protected]
	void WhenSequencerPlayFinished(); // Offset: 0x101e7d728 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_PlaySequenceBase.InitBindingDatas
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void InitBindingDatas(struct TArray<struct FPlaySequenceActorData>& InPlaySequenceActorDatas, struct TArray<struct FPlaySequenceMoveToData>& InPlaySequenceMoveToDatas); // Offset: 0x101e7d744 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableAction_PlaySequence
// Size: 0x100 // Inherited bytes: 0x100
struct UDispatchableAction_PlaySequence : UDispatchableAction_PlaySequenceBase {
};

// Object Name: Class EntityDispatcher_Runtime.ispatchableAction_SelectionContext
// Size: 0x28 // Inherited bytes: 0x28
struct UispatchableAction_SelectionContext : UObject {
	// Functions

	// Object Name: Function EntityDispatcher_Runtime.ispatchableAction_SelectionContext.SetEvaluateSelectionValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|Const]
	void SetEvaluateSelectionValue(int32_t& SelectionValue); // Offset: 0x101e7e37c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableAction_SelectionBase
// Size: 0x60 // Inherited bytes: 0x50
struct UDispatchableAction_SelectionBase : UDispatchableActionBase {
	// Fields
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SelectionBase.SelectSelection
	// Flags: [Final|Native|Public|HasOutParms]
	void SelectSelection(struct FDispatchableAction_SelectionEntryBase& Selection); // Offset: 0x101e7e4f4 // Return & Params: Num(1) Size(0x40)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SelectionBase.SelectedToServer
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void SelectedToServer(int32_t SelectedIndex); // Offset: 0x101e7e794 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SelectionBase.EvaluateSelection
	// Flags: [Final|Native|Public|HasOutParms|Const]
	void EvaluateSelection(struct FDispatchableAction_SelectionEntryAbstract& Selection); // Offset: 0x101e7e6d4 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SelectionBase.BP_SelectSelection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void BP_SelectSelection(struct FDispatchableAction_SelectionEntryBase& Selection); // Offset: 0x101e7ea2c // Return & Params: Num(1) Size(0x40)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SelectionBase.BP_EvaluateSelection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|Const]
	void BP_EvaluateSelection(struct FDispatchableAction_SelectionEntryBase& Selection); // Offset: 0x101e7e9c0 // Return & Params: Num(1) Size(0x40)
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableAction_SelectionExample
// Size: 0xa8 // Inherited bytes: 0x60
struct UDispatchableAction_SelectionExample : UDispatchableAction_SelectionBase {
	// Fields
	struct TSoftObjectPtr<APawn> Role; // Offset: 0x60 // Size: 0x28
	struct TArray<struct FDispatchableAction_SelectionEntryExample_2> DispatchableAction_SelectionEntry_1s; // Offset: 0x88 // Size: 0x10
	struct TArray<struct FDispatchableAction_SelectionEntryExample_3> DispatchableAction_SelectionEntry_2s; // Offset: 0x98 // Size: 0x10

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SelectionExample.AddSelectionEntry_DispatchableAction_SelectionEntryExample_3
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddSelectionEntry_DispatchableAction_SelectionEntryExample_3(int32_t SelectionIndex, struct FDelegate& SelectedDelegate); // Offset: 0x101e7eca4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SelectionExample.AddSelectionEntry_DispatchableAction_SelectionEntryExample_2
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddSelectionEntry_DispatchableAction_SelectionEntryExample_2(int32_t SelectionIndex, struct FDelegate& SelectedDelegate); // Offset: 0x101e7ee24 // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableAction_SubDispatcher
// Size: 0x70 // Inherited bytes: 0x50
struct UDispatchableAction_SubDispatcher : UDispatchableActionBase {
	// Fields
	struct UEntityDispatcherBase* SubDispatcher; // Offset: 0x50 // Size: 0x08
	struct FName FinishTag; // Offset: 0x58 // Size: 0x08
	struct FDispatchableActionFinishEvent OnSubDispatcherFinished; // Offset: 0x60 // Size: 0x10

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SubDispatcher.WhenDispatcherFinished
	// Flags: [Final|Native|Private|HasOutParms]
	void WhenDispatcherFinished(struct FName& InFinishTag); // Offset: 0x101e7f440 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SubDispatcher.WhenDispatcherAborted
	// Flags: [Final|Native|Private]
	void WhenDispatcherAborted(); // Offset: 0x101e7f42c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_SubDispatcher.BindOnSubDispatcherFinishedEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void BindOnSubDispatcherFinishedEvent(struct FDelegate& Delegate); // Offset: 0x101e7f4cc // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableAction_Together
// Size: 0x70 // Inherited bytes: 0x50
struct UDispatchableAction_Together : UDispatchableActionBase {
	// Fields
	struct TArray<struct FTogetherData> TogetherDatas; // Offset: 0x50 // Size: 0x10
	struct FDispatchableActionFinishEvent OnTogether; // Offset: 0x60 // Size: 0x10

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_Together.InvokeStartTogetherAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvokeStartTogetherAction(int32_t ActionIdx, bool CacheEntityPosition, struct FDelegate OnStartWaitAction); // Offset: 0x101e7fa78 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableAction_Together.InitTogetherAction
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void InitTogetherAction(int32_t TogetherActionCount, struct FDispatchableActionFinishEvent& OnTogetherEvent); // Offset: 0x101e7fbac // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableActionReplicationActor
// Size: 0x290 // Inherited bytes: 0x268
struct ADispatchableActionReplicationActor : AActor {
	// Fields
	struct TArray<struct AActor*> NetRelevantTargets; // Offset: 0x268 // Size: 0x10
	struct UDispatchableActionBase* RealAction; // Offset: 0x278 // Size: 0x08
	struct UEntityDispatcherBase* EntityDispatcher; // Offset: 0x280 // Size: 0x08
	struct UDispatchableActionBase* RPC_ProxyAction; // Offset: 0x288 // Size: 0x08

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionReplicationActor.OnRep_ProxyAction
	// Flags: [Final|Native|Public]
	void OnRep_ProxyAction(); // Offset: 0x101e801bc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableActionBlueprint
// Size: 0xd0 // Inherited bytes: 0xd0
struct UDispatchableActionBlueprint : UBlueprint {
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableActionGeneratedClass
// Size: 0x410 // Inherited bytes: 0x400
struct UDispatchableActionGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	struct TArray<struct FName> EntityPropertyNames; // Offset: 0x400 // Size: 0x10
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableActionFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UDispatchableActionFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionFunctionLibrary.ToDispatchingActionCollectionRef
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FDispatchingActionCollectionRef ToDispatchingActionCollectionRef(struct FDispatchingActionCollection& Actions); // Offset: 0x101e82298 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableActionFunctionLibrary.MakeDispatchableActionFinishEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FDispatchableActionFinishEvent MakeDispatchableActionFinishEvent(struct FDelegate& Delegate); // Offset: 0x101e8232c // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class EntityDispatcher_Runtime.DispatchableEntityInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UDispatchableEntityInterface : UInterface {
	// Functions

	// Object Name: Function EntityDispatcher_Runtime.DispatchableEntityInterface.GetCurrentDispatchableActions
	// Flags: [Native|Event|Public|BlueprintEvent]
	struct FDispatchingActionCollectionRef GetCurrentDispatchableActions(); // Offset: 0x101e827d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableEntityInterface.EntityHasDispatchableTag
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	bool EntityHasDispatchableTag(struct FGameplayTag& Tag); // Offset: 0x101e826f4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableEntityInterface.EntityAddDispatchableTag
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void EntityAddDispatchableTag(struct FGameplayTag& Tag); // Offset: 0x101e82660 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EntityDispatcher_Runtime.DispatchableEntityInterface.CanExecuteDispatcher
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool CanExecuteDispatcher(); // Offset: 0x101e82798 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class EntityDispatcher_Runtime.EntityDispatcherBase
// Size: 0xe0 // Inherited bytes: 0x28
struct UEntityDispatcherBase : UObject {
	// Fields
	char DummyVariable : 1; // Offset: 0x28 // Size: 0x01
	char pad_0x28_1 : 7; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct TArray<struct UDispatchableActionBase*> ActivedActions; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x18]; // Offset: 0x40 // Size: 0x18
	struct FName CachedFinishTag; // Offset: 0x58 // Size: 0x08
	struct FDelegate OnDispatcherFinishedDelegate; // Offset: 0x60 // Size: 0x10
	char pad_0x70[0x18]; // Offset: 0x70 // Size: 0x18
	struct FDelegate OnDispatcherAbortedDelegate; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x18]; // Offset: 0x98 // Size: 0x18
	struct TArray<struct UDispatchableActionBase*> AbortingActions; // Offset: 0xb0 // Size: 0x10
	struct TArray<struct UDispatchableActionBase*> ReactivableActions; // Offset: 0xc0 // Size: 0x10
	struct TArray<struct UDispatchableActionBase*> InvalidActions; // Offset: 0xd0 // Size: 0x10

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.TriggerActionCheckPass
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TriggerActionCheckPass(struct FName InTriggerEventName); // Offset: 0x101e8329c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.StartByDefaultEntry
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void StartByDefaultEntry(); // Offset: 0x101e83430 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.ReceiveWhenDeactived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenDeactived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.ReceiveWhenActived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenActived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction EntityDispatcher_Runtime.EntityDispatcherBase.OnDispatcherFinishedDelegate__DelegateSignature
	// Flags: [Public|Delegate|HasOutParms]
	void OnDispatcherFinishedDelegate__DelegateSignature(struct FName& Tag); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction EntityDispatcher_Runtime.EntityDispatcherBase.OnDispatcherAbortedDelegate__DelegateSignature
	// Flags: [Public|Delegate]
	void OnDispatcherAbortedDelegate__DelegateSignature(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.IsAnyActionActived
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsAnyActionActived(struct TArray<struct UDispatchableActionBase*>& CheckedByTemplates); // Offset: 0x101e83198 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.GetMainDispatcher
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UEntityDispatcherBase* GetMainDispatcher(); // Offset: 0x101e83240 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.FinishDispatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishDispatch(struct FName InFinishTag); // Offset: 0x101e83328 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.DefaultDispatchStart
	// Flags: [Event|Public|BlueprintEvent]
	void DefaultDispatchStart(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.CanActiveAction_ByTemplate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CanActiveAction_ByTemplate(struct UDispatchableActionBase* CheckedByTemplate); // Offset: 0x101e8310c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.CanActiveAction_ByInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CanActiveAction_ByInstance(struct UDispatchableActionBase* CheckedInstance); // Offset: 0x101e83080 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.BP_AbortDispatcher
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BP_AbortDispatcher(); // Offset: 0x101e83274 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.EntityDispatcherBase.ActiveDispatcherCheckPass
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ActiveDispatcherCheckPass(struct FName EntryPointName); // Offset: 0x101e833a4 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class EntityDispatcher_Runtime.EntityDispatcherBlueprint
// Size: 0xe0 // Inherited bytes: 0xd0
struct UEntityDispatcherBlueprint : UBlueprint {
	// Fields
	struct TArray<struct FName> FinishTags; // Offset: 0xd0 // Size: 0x10
};

// Object Name: Class EntityDispatcher_Runtime.EntityDispatcherBlueprintGeneratedClass
// Size: 0x400 // Inherited bytes: 0x400
struct UEntityDispatcherBlueprintGeneratedClass : UBlueprintGeneratedClass {
};

// Object Name: Class EntityDispatcher_Runtime.EntityDispatcherManager
// Size: 0xa8 // Inherited bytes: 0x30
struct UEntityDispatcherManager : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x78]; // Offset: 0x30 // Size: 0x78
};

// Object Name: Class EntityDispatcher_Runtime.EntityDispatcherRuntimeSettings
// Size: 0x50 // Inherited bytes: 0x30
struct UEntityDispatcherRuntimeSettings : UDataAsset {
	// Fields
	struct FDispatchableActionCompatibleMatrix ActionCompatibleMatrix; // Offset: 0x30 // Size: 0x20
};

// Object Name: Class EntityDispatcher_Runtime.EntityDispatcherSettings
// Size: 0x60 // Inherited bytes: 0x38
struct UEntityDispatcherSettings : UDeveloperSettings {
	// Fields
	struct TSoftObjectPtr<UEntityDispatcherRuntimeSettings> RuntimeSettings; // Offset: 0x38 // Size: 0x28
};

// Object Name: Class EntityDispatcher_Runtime.InitEntityDispatcherOnePawnInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UInitEntityDispatcherOnePawnInterface : UInterface {
	// Functions

	// Object Name: Function EntityDispatcher_Runtime.InitEntityDispatcherOnePawnInterface.InitEntityDispatcherOnePawnInterface
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void InitEntityDispatcherOnePawnInterface(struct APawn* InPawn); // Offset: 0x101e844c4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class EntityDispatcher_Runtime.ReplicableLevelSequenceActor
// Size: 0x368 // Inherited bytes: 0x300
struct AReplicableLevelSequenceActor : ALevelSequenceActor {
	// Fields
	struct TSet<struct FReplicableSequenceBinding> PreBindingDatas; // Offset: 0x300 // Size: 0x50
	struct TArray<struct FReplicableSequenceBinding> BindingDatas; // Offset: 0x350 // Size: 0x10
	struct ULevelSequence* LevelSequenceRef; // Offset: 0x360 // Size: 0x08

	// Functions

	// Object Name: Function EntityDispatcher_Runtime.ReplicableLevelSequenceActor.RemoveReplicableBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveReplicableBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor); // Offset: 0x101e84b68 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EntityDispatcher_Runtime.ReplicableLevelSequenceActor.Play
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void Play(struct ULevelSequence* Sequence, struct FTransform& PlayTransform); // Offset: 0x101e84a4c // Return & Params: Num(2) Size(0x40)

	// Object Name: Function EntityDispatcher_Runtime.ReplicableLevelSequenceActor.OnRep_LevelSequence
	// Flags: [Final|Native|Public]
	void OnRep_LevelSequence(); // Offset: 0x101e84d30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.ReplicableLevelSequenceActor.OnRep_BindingDatas
	// Flags: [Final|Native|Public]
	void OnRep_BindingDatas(); // Offset: 0x101e84d44 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EntityDispatcher_Runtime.ReplicableLevelSequenceActor.AddReplicableBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddReplicableBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor); // Offset: 0x101e84c4c // Return & Params: Num(2) Size(0x20)
};

