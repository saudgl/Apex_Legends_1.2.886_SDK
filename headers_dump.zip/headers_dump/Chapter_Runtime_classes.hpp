#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Chapter_Runtime.ChapterFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UChapterFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Chapter_Runtime.ChapterFunctionLibrary.SetParam_Internal
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetParam_Internal(struct TArray<struct FString>& InWords); // Offset: 0x101e68b20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Chapter_Runtime.ChapterFunctionLibrary.ModifyStringValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ModifyStringValue(struct FChapterParams& Params, struct FString VariableName, struct FString Value); // Offset: 0x101e68228 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Chapter_Runtime.ChapterFunctionLibrary.ModifyFloatValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ModifyFloatValue(struct FChapterParams& Params, struct FString VariableName, float Value); // Offset: 0x101e685d0 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Chapter_Runtime.ChapterFunctionLibrary.GetStringValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString GetStringValue(struct FChapterParams& Params, struct FString VariableName); // Offset: 0x101e68890 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Chapter_Runtime.ChapterFunctionLibrary.GetFloatValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	float GetFloatValue(struct FChapterParams& Params, struct FString VariableName); // Offset: 0x101e689f4 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Chapter_Runtime.ChapterFunctionLibrary.AddStringValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddStringValue(struct FChapterParams& Params, struct FString VariableName, struct FString Value); // Offset: 0x101e683fc // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Chapter_Runtime.ChapterFunctionLibrary.AddFloatValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddFloatValue(struct FChapterParams& Params, struct FString VariableName, float Value); // Offset: 0x101e68730 // Return & Params: Num(3) Size(0x24)
};

// Object Name: Class Chapter_Runtime.ChapterProfile
// Size: 0x48 // Inherited bytes: 0x38
struct UChapterProfile : UDeveloperSettings {
	// Fields
	struct TArray<struct FChapterProfileTemplate> Profiles; // Offset: 0x38 // Size: 0x10
};

