#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UESVON.AITask_SVONMoveTo
// Size: 0x130 // Inherited bytes: 0x68
struct UAITask_SVONMoveTo : UAITask {
	// Fields
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08
	struct FMulticastInlineDelegate OnRequestFailed; // Offset: 0x70 // Size: 0x10
	struct FMulticastInlineDelegate OnMoveFinished; // Offset: 0x80 // Size: 0x10
	struct FAIMoveRequest MoveRequest; // Offset: 0x90 // Size: 0x40
	char pad_0xD0[0x58]; // Offset: 0xd0 // Size: 0x58
	struct USVONNavigationComponent* myNavComponent; // Offset: 0x128 // Size: 0x08

	// Functions

	// Object Name: Function UESVON.AITask_SVONMoveTo.SVONAIMoveTo
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAITask_SVONMoveTo* SVONAIMoveTo(struct AAIController* Controller, struct FVector GoalLocation, bool aUseAsyncPathfinding, struct AActor* GoalActor, float AcceptanceRadius, enum class EAIOptionFlag StopOnOverlap, bool bLockAILogic, bool bUseContinuosGoalTracking); // Offset: 0x101df17c0 // Return & Params: Num(9) Size(0x30)
};

// Object Name: Class UESVON.BTTask_SVONMoveTo
// Size: 0x160 // Inherited bytes: 0x150
struct UBTTask_SVONMoveTo : UBTTask_BlackboardBase {
	// Fields
	float AcceptableRadius; // Offset: 0x150 // Size: 0x04
	float ObservedBlackboardValueTolerance; // Offset: 0x154 // Size: 0x04
	char bObserveBlackboardValue : 1; // Offset: 0x158 // Size: 0x01
	char bTrackMovingGoal : 1; // Offset: 0x158 // Size: 0x01
	char bReachTestIncludesAgentRadius : 1; // Offset: 0x158 // Size: 0x01
	char bReachTestIncludesGoalRadius : 1; // Offset: 0x158 // Size: 0x01
	char pad_0x158_4 : 4; // Offset: 0x158 // Size: 0x01
	bool bUseAsyncPathfinding; // Offset: 0x159 // Size: 0x01
	char pad_0x15A[0x6]; // Offset: 0x15a // Size: 0x06
};

// Object Name: Class UESVON.CustomVisualLoggerExtension
// Size: 0x28 // Inherited bytes: 0x28
struct UCustomVisualLoggerExtension : UObject {
};

// Object Name: Class UESVON.CustomVisualLoggerRenderingComponent
// Size: 0x560 // Inherited bytes: 0x560
struct UCustomVisualLoggerRenderingComponent : UPrimitiveComponent {
};

// Object Name: Class UESVON.SVONNavigationComponent
// Size: 0x160 // Inherited bytes: 0xf0
struct USVONNavigationComponent : UActorComponent {
	// Fields
	bool DebugPrintCurrentPosition; // Offset: 0xf0 // Size: 0x01
	bool DebugPrintMortonCodes; // Offset: 0xf1 // Size: 0x01
	bool DebugDrawOpenNodes; // Offset: 0xf2 // Size: 0x01
	bool UseUnitCost; // Offset: 0xf3 // Size: 0x01
	float UnitCost; // Offset: 0xf4 // Size: 0x04
	float EstimateWeight; // Offset: 0xf8 // Size: 0x04
	float NodeSizeCompensation; // Offset: 0xfc // Size: 0x04
	enum class ESVONPathCostType PathCostType; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x3]; // Offset: 0x101 // Size: 0x03
	int32_t SmoothingIterations; // Offset: 0x104 // Size: 0x04
	char pad_0x108[0x58]; // Offset: 0x108 // Size: 0x58
};

// Object Name: Class UESVON.SVONTestingActorRenderingComponent
// Size: 0x560 // Inherited bytes: 0x560
struct USVONTestingActorRenderingComponent : UPrimitiveComponent {
};

// Object Name: Class UESVON.SVONTestingActor
// Size: 0x2a8 // Inherited bytes: 0x268
struct ASVONTestingActor : AActor {
	// Fields
	struct TWeakObjectPtr<struct ASVONTestingActor> TargetActor; // Offset: 0x268 // Size: 0x08
	struct UCapsuleComponent* CapsuleComponent; // Offset: 0x270 // Size: 0x08
	struct UBillboardComponent* ShowSprite; // Offset: 0x278 // Size: 0x08
	struct USVONTestingActorRenderingComponent* RenderingComponent; // Offset: 0x280 // Size: 0x08
	enum class ESVONPathPostProcess PostProcess; // Offset: 0x288 // Size: 0x01
	enum class ESVONPathCostType PathCostType; // Offset: 0x289 // Size: 0x01
	char pad_0x28A[0x2]; // Offset: 0x28a // Size: 0x02
	int32_t SearchDir; // Offset: 0x28c // Size: 0x04
	char pad_0x290[0x10]; // Offset: 0x290 // Size: 0x10
	struct USVONNavigationComponent* SVONComponent; // Offset: 0x2a0 // Size: 0x08
};

// Object Name: Class UESVON.SVONVolume
// Size: 0x340 // Inherited bytes: 0x2a0
struct ASVONVolume : AVolume {
	// Fields
	bool EnableLodRendering; // Offset: 0x2a0 // Size: 0x01
	char pad_0x2A1[0x3]; // Offset: 0x2a1 // Size: 0x03
	float LodRenderingDistance; // Offset: 0x2a4 // Size: 0x04
	float ExpectLeafWidth; // Offset: 0x2a8 // Size: 0x04
	bool myShowVoxels; // Offset: 0x2ac // Size: 0x01
	bool myShowLeafVoxels; // Offset: 0x2ad // Size: 0x01
	bool myShowNeighbourLinks; // Offset: 0x2ae // Size: 0x01
	bool myShowParentChildLinks; // Offset: 0x2af // Size: 0x01
	struct FString myDebugShow; // Offset: 0x2b0 // Size: 0x10
	int32_t myVoxelPower; // Offset: 0x2c0 // Size: 0x04
	enum class ECollisionChannel myCollisionChannel; // Offset: 0x2c4 // Size: 0x01
	char myNumLayers; // Offset: 0x2c5 // Size: 0x01
	char pad_0x2C6[0x2]; // Offset: 0x2c6 // Size: 0x02
	int32_t myNumBytes; // Offset: 0x2c8 // Size: 0x04
	char pad_0x2CC[0x4]; // Offset: 0x2cc // Size: 0x04
	struct FString VoxelFile; // Offset: 0x2d0 // Size: 0x10
	char pad_0x2E0[0x60]; // Offset: 0x2e0 // Size: 0x60
};

// Object Name: Class UESVON.SVONVolumeRenderingComponent
// Size: 0x560 // Inherited bytes: 0x560
struct USVONVolumeRenderingComponent : UPrimitiveComponent {
};

