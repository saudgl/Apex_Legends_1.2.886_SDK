#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass BP_CommonButton.BP_CommonButton_C
// Size: 0x578 // Inherited bytes: 0x560
struct UBP_CommonButton_C : UCommonButtonWidget {
	// Fields
	struct UWidgetAnimation* Anim_CloseBtn; // Offset: 0x560 // Size: 0x08
	struct UWidgetAnimation* Anim_Press; // Offset: 0x568 // Size: 0x08
	struct UCanvasPanel* ShareGift; // Offset: 0x570 // Size: 0x08
};

