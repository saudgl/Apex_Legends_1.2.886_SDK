#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum ReplicatedLevelInstance.EReplicatedSubLevelInstanceType
enum class EReplicatedSubLevelInstanceType : uint8 {
	Main = 0,
	AlwaysLoaded = 1,
	ScriptLoaded = 2,
	EReplicatedSubLevelInstanceType_MAX = 3
};

