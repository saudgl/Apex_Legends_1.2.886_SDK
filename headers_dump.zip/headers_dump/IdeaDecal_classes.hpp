#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class IdeaDecal.IdeaDecalRenderComponent
// Size: 0x660 // Inherited bytes: 0x5c0
struct UIdeaDecalRenderComponent : URuntimeMeshComponent {
	// Fields
	char pad_0x5C0[0xa0]; // Offset: 0x5c0 // Size: 0xa0
};

// Object Name: Class IdeaDecal.IdeaDecalManager
// Size: 0x600 // Inherited bytes: 0x268
struct AIdeaDecalManager : AActor {
	// Fields
	struct TMap<struct FDecalBlock, struct UMaterialInstanceDynamic*> DecalMaterialsLookupTable; // Offset: 0x268 // Size: 0x50
	struct TArray<struct UIdeaDecalRenderComponent*> DecalComponents; // Offset: 0x2b8 // Size: 0x10
	char pad_0x2C8[0x338]; // Offset: 0x2c8 // Size: 0x338
};

// Object Name: Class IdeaDecal.StaticIdeaDecalActor
// Size: 0x310 // Inherited bytes: 0x268
struct AStaticIdeaDecalActor : AActor {
	// Fields
	struct USceneComponent* Root; // Offset: 0x268 // Size: 0x08
	struct FVector2D UVOffset; // Offset: 0x270 // Size: 0x08
	struct FVector2D UVScale; // Offset: 0x278 // Size: 0x08
	struct UMaterialInterface* DecalMat; // Offset: 0x280 // Size: 0x08
	uint32_t Priority; // Offset: 0x288 // Size: 0x04
	char pad_0x28C[0x84]; // Offset: 0x28c // Size: 0x84

	// Functions

	// Object Name: Function IdeaDecal.StaticIdeaDecalActor.UpdateDecal
	// Flags: [Final|Native|Public]
	void UpdateDecal(); // Offset: 0x101d8cb40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function IdeaDecal.StaticIdeaDecalActor.RemoveDecal
	// Flags: [Final|Native|Public]
	void RemoveDecal(); // Offset: 0x101d8cb2c // Return & Params: Num(0) Size(0x0)
};

