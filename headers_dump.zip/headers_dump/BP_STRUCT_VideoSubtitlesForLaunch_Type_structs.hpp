#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VideoSubtitlesForLaunch_Type.BP_STRUCT_VideoSubtitlesForLaunch_Type
// Size: 0x28 // Inherited bytes: 0x00
struct FBP_STRUCT_VideoSubtitlesForLaunch_Type {
	// Fields
	int32_t Id_2_20A5B48E4F25519ADCC79E911D855448; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FText Text_3_28D094C00438B821256DB68406038E54; // Offset: 0x08 // Size: 0x18
	int32_t StartMilliseconds_4_7E5668801A783A6A4D93434E00B2F543; // Offset: 0x20 // Size: 0x04
	int32_t EndMilliseconds_5_0A29AAC02927DC6F78B4860B0ADA5DD3; // Offset: 0x24 // Size: 0x04
};

