#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct MediaUtils.MediaPlayerOptions
// Size: 0x30 // Inherited bytes: 0x00
struct FMediaPlayerOptions {
	// Fields
	struct FMediaPlayerTrackOptions Tracks; // Offset: 0x00 // Size: 0x1c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FTimespan SeekTime; // Offset: 0x20 // Size: 0x08
	enum class EMediaPlayerOptionBooleanOverride PlayOnOpen; // Offset: 0x28 // Size: 0x01
	enum class EMediaPlayerOptionBooleanOverride Loop; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x6]; // Offset: 0x2a // Size: 0x06
};

// Object Name: ScriptStruct MediaUtils.MediaPlayerTrackOptions
// Size: 0x1c // Inherited bytes: 0x00
struct FMediaPlayerTrackOptions {
	// Fields
	int32_t Audio; // Offset: 0x00 // Size: 0x04
	int32_t Caption; // Offset: 0x04 // Size: 0x04
	int32_t MetaData; // Offset: 0x08 // Size: 0x04
	int32_t Script; // Offset: 0x0c // Size: 0x04
	int32_t Subtitle; // Offset: 0x10 // Size: 0x04
	int32_t Text; // Offset: 0x14 // Size: 0x04
	int32_t Video; // Offset: 0x18 // Size: 0x04
};

