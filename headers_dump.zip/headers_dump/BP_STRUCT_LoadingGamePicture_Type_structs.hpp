#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_LoadingGamePicture_Type.BP_STRUCT_LoadingGamePicture_Type
// Size: 0xb8 // Inherited bytes: 0x00
struct FBP_STRUCT_LoadingGamePicture_Type {
	// Fields
	int32_t ID_517_644413406A521E6B76B3E256099A36D3; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FText MapName_518_2B2DEA402FF864FB585738B80F319F15; // Offset: 0x08 // Size: 0x18
	struct FName MapID_519_686DAD40739D910D5DE92708092F3004; // Offset: 0x20 // Size: 0x08
	int32_t Guide_520_457E9E004B8B70D605DAA11809120B75; // Offset: 0x28 // Size: 0x04
	int32_t Probability_521_35D022C001D463351EBCB4830E8571E9; // Offset: 0x2c // Size: 0x04
	struct FName Path_522_0EAC25C07D1BF3D775900D7F0D90A3E8; // Offset: 0x30 // Size: 0x08
	struct FName BpPath_523_37D2924025143F0D304E7C13015E2538; // Offset: 0x38 // Size: 0x08
	int32_t LoadingType_524_4BE8BA806CB81D205818DEE007636315; // Offset: 0x40 // Size: 0x04
	int32_t ShowType_525_071F13403D3B229F3017849606213035; // Offset: 0x44 // Size: 0x04
	struct FName MinMapBpPath_526_3966E2C00FEBFC615908FE10066016B8; // Offset: 0x48 // Size: 0x08
	struct TArray<int32_t> BgTipsList_527_557FDBC02855C57B13B9246D0DE77754; // Offset: 0x50 // Size: 0x10
	struct TArray<int32_t> LevelRange_528_2CBB3BC012A1F2554B415FC6078AA355; // Offset: 0x60 // Size: 0x10
	int32_t ImageGuideType_529_20309F4055F70E597F88ADF0079ACF95; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct FString ImageGuidePics_530_3680BA8018F312607F8F047A079A6053; // Offset: 0x78 // Size: 0x10
	struct FText ImageGuideTitles_531_5C40B4006CE2F2F25FEBD18C0ABF6553; // Offset: 0x88 // Size: 0x18
	struct FText ImageGuideDescs_532_644413406A521E6B76B3E256099A36D3; // Offset: 0xa0 // Size: 0x18
};

