#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum ZZAnimationLib.EBlendListTransitionType_Component
enum class EBlendListTransitionType_Component : uint8 {
	StandardBlend = 0,
	Inertialization = 1,
	EBlendListTransitionType_MAX = 2
};

// Object Name: Enum ZZAnimationLib.EIKFootRootLocalAxis
enum class EIKFootRootLocalAxis : uint8 {
	NONE = 0,
	X = 1,
	Y = 2,
	Z = 3,
	EIKFootRootLocalAxis_MAX = 4
};

// Object Name: Enum ZZAnimationLib.EColliderType
enum class EColliderType : uint8 {
	Collider_Sphere = 0,
	Collider_Capsule = 1,
	Collider_MAX = 2
};

// Object Name: Enum ZZAnimationLib.EFindTargetFrameResult
enum class EFindTargetFrameResult : uint8 {
	NORMAL = 0,
	CANNOTFIND = 1,
	DIVIDEBYZERO = 2,
	Count = 3,
	EFindTargetFrameResult_MAX = 4
};

// Object Name: Enum ZZAnimationLib.ECharacterLocalDirection
enum class ECharacterLocalDirection : uint8 {
	NORTH = 0,
	EAST = 1,
	SOUTH = 2,
	WEST = 3,
	Count = 4,
	ECharacterLocalDirection_MAX = 5
};

