#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct GeometryCollectionEngine.GeomComponentCacheParameters
// Size: 0x50 // Inherited bytes: 0x00
struct FGeomComponentCacheParameters {
	// Fields
	enum class EGeometryCollectionCacheType CacheMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UGeometryCollectionCache* TargetCache; // Offset: 0x08 // Size: 0x08
	float ReverseCacheBeginTime; // Offset: 0x10 // Size: 0x04
	bool SaveCollisionData; // Offset: 0x14 // Size: 0x01
	bool DoGenerateCollisionData; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
	int32_t CollisionDataSizeMax; // Offset: 0x18 // Size: 0x04
	bool DoCollisionDataSpatialHash; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	float CollisionDataSpatialHashRadius; // Offset: 0x20 // Size: 0x04
	int32_t MaxCollisionPerCell; // Offset: 0x24 // Size: 0x04
	bool SaveBreakingData; // Offset: 0x28 // Size: 0x01
	bool DoGenerateBreakingData; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
	int32_t BreakingDataSizeMax; // Offset: 0x2c // Size: 0x04
	bool DoBreakingDataSpatialHash; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	float BreakingDataSpatialHashRadius; // Offset: 0x34 // Size: 0x04
	int32_t MaxBreakingPerCell; // Offset: 0x38 // Size: 0x04
	bool SaveTrailingData; // Offset: 0x3c // Size: 0x01
	bool DoGenerateTrailingData; // Offset: 0x3d // Size: 0x01
	char pad_0x3E[0x2]; // Offset: 0x3e // Size: 0x02
	int32_t TrailingDataSizeMax; // Offset: 0x40 // Size: 0x04
	float TrailingMinSpeedThreshold; // Offset: 0x44 // Size: 0x04
	float TrailingMinVolumeThreshold; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct GeometryCollectionEngine.ChaosCollisionEventData
// Size: 0x4c // Inherited bytes: 0x00
struct FChaosCollisionEventData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FVector Normal; // Offset: 0x0c // Size: 0x0c
	struct FVector Velocity1; // Offset: 0x18 // Size: 0x0c
	struct FVector Velocity2; // Offset: 0x24 // Size: 0x0c
	float Mass1; // Offset: 0x30 // Size: 0x04
	float Mass2; // Offset: 0x34 // Size: 0x04
	struct FVector Impulse; // Offset: 0x38 // Size: 0x0c
	int32_t ParticleIndex; // Offset: 0x44 // Size: 0x04
	int32_t LevelsetIndex; // Offset: 0x48 // Size: 0x04
};

// Object Name: ScriptStruct GeometryCollectionEngine.ChaosBreakingEventData
// Size: 0x20 // Inherited bytes: 0x00
struct FChaosBreakingEventData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x0c // Size: 0x0c
	float Mass; // Offset: 0x18 // Size: 0x04
	int32_t ParticleIndex; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct GeometryCollectionEngine.ChaosTrailingEventData
// Size: 0x2c // Inherited bytes: 0x00
struct FChaosTrailingEventData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x0c // Size: 0x0c
	struct FVector AngularVelocity; // Offset: 0x18 // Size: 0x0c
	float Mass; // Offset: 0x24 // Size: 0x04
	int32_t ParticleIndex; // Offset: 0x28 // Size: 0x04
};

// Object Name: ScriptStruct GeometryCollectionEngine.ChaosBreakingEventRequestSettings
// Size: 0x18 // Inherited bytes: 0x00
struct FChaosBreakingEventRequestSettings {
	// Fields
	int32_t MaxNumberOfResults; // Offset: 0x00 // Size: 0x04
	float MinRadius; // Offset: 0x04 // Size: 0x04
	float MinSpeed; // Offset: 0x08 // Size: 0x04
	float MinMass; // Offset: 0x0c // Size: 0x04
	float MaxDistance; // Offset: 0x10 // Size: 0x04
	enum class EChaosBreakingSortMethod SortMethod; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct GeometryCollectionEngine.ChaosCollisionEventRequestSettings
// Size: 0x18 // Inherited bytes: 0x00
struct FChaosCollisionEventRequestSettings {
	// Fields
	int32_t MaxNumberResults; // Offset: 0x00 // Size: 0x04
	float MinMass; // Offset: 0x04 // Size: 0x04
	float MinSpeed; // Offset: 0x08 // Size: 0x04
	float MinImpulse; // Offset: 0x0c // Size: 0x04
	float MaxDistance; // Offset: 0x10 // Size: 0x04
	enum class EChaosCollisionSortMethod SortMethod; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct GeometryCollectionEngine.ChaosTrailingEventRequestSettings
// Size: 0x18 // Inherited bytes: 0x00
struct FChaosTrailingEventRequestSettings {
	// Fields
	int32_t MaxNumberOfResults; // Offset: 0x00 // Size: 0x04
	float MinMass; // Offset: 0x04 // Size: 0x04
	float MinSpeed; // Offset: 0x08 // Size: 0x04
	float MinAngularSpeed; // Offset: 0x0c // Size: 0x04
	float MaxDistance; // Offset: 0x10 // Size: 0x04
	enum class EChaosTrailingSortMethod SortMethod; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct GeometryCollectionEngine.GeometryCollectionDebugDrawActorSelectedRigidBody
// Size: 0x18 // Inherited bytes: 0x00
struct FGeometryCollectionDebugDrawActorSelectedRigidBody {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct AChaosSolverActor* Solver; // Offset: 0x08 // Size: 0x08
	struct AGeometryCollectionActor* GeometryCollection; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct GeometryCollectionEngine.GeometryCollectionDebugDrawWarningMessage
// Size: 0x01 // Inherited bytes: 0x00
struct FGeometryCollectionDebugDrawWarningMessage {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct GeometryCollectionEngine.GeometryCollectionSizeSpecificData
// Size: 0x24 // Inherited bytes: 0x00
struct FGeometryCollectionSizeSpecificData {
	// Fields
	float MaxSize; // Offset: 0x00 // Size: 0x04
	enum class ECollisionTypeEnum CollisionType; // Offset: 0x04 // Size: 0x01
	enum class EImplicitTypeEnum ImplicitType; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	int32_t MinLevelSetResolution; // Offset: 0x08 // Size: 0x04
	int32_t MaxLevelSetResolution; // Offset: 0x0c // Size: 0x04
	int32_t MinClusterLevelSetResolution; // Offset: 0x10 // Size: 0x04
	int32_t MaxClusterLevelSetResolution; // Offset: 0x14 // Size: 0x04
	int32_t CollisionObjectReductionPercentage; // Offset: 0x18 // Size: 0x04
	float CollisionParticlesFraction; // Offset: 0x1c // Size: 0x04
	int32_t MaximumCollisionParticles; // Offset: 0x20 // Size: 0x04
};

