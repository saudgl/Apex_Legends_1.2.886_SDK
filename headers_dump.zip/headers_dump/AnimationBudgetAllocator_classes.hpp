#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Offset: 0x101d76260 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
	// Flags: [Final|Native|Static|Private|BlueprintCallable]
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Offset: 0x101d76398 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xc60 // Inherited bytes: 0xc30
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	// Fields
	char pad_0xC30[0x20]; // Offset: 0xc30 // Size: 0x20
	char bAutoRegisterWithBudgetAllocator : 1; // Offset: 0xc50 // Size: 0x01
	char bAutoCalculateSignificance : 1; // Offset: 0xc50 // Size: 0x01
	char bShouldUseActorRenderedFlag : 1; // Offset: 0xc50 // Size: 0x01
	char bTickEvenIfNotRenderedFlag : 1; // Offset: 0xc50 // Size: 0x01
	char pad_0xC50_4 : 4; // Offset: 0xc50 // Size: 0x01
	char pad_0xC51[0xf]; // Offset: 0xc51 // Size: 0x0f

	// Functions

	// Object Name: Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Offset: 0x101d766e8 // Return & Params: Num(1) Size(0x1)
};

