#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AClient.DoorOverlapingActor
// Size: 0x20 // Inherited bytes: 0x00
struct FDoorOverlapingActor {
	// Fields
	struct AActor* TargetActor; // Offset: 0x00 // Size: 0x08
	struct FVector CollisionCenterOffset; // Offset: 0x08 // Size: 0x0c
	float CollisionRadius; // Offset: 0x14 // Size: 0x04
	float CollisionHalfHeight; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.DoorDamageType
// Size: 0x0c // Inherited bytes: 0x00
struct FDoorDamageType {
	// Fields
	enum class EDamageType DamageType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t SkillDamageTypeID; // Offset: 0x04 // Size: 0x04
	float DamageRate; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattleItemUseTipInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FBattleItemUseTipInfo {
	// Fields
	struct ACharacter* User; // Offset: 0x00 // Size: 0x08
	float Duration; // Offset: 0x08 // Size: 0x04
	uint32_t ItemID; // Offset: 0x0c // Size: 0x04
	char EventType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t TeamIdx; // Offset: 0x14 // Size: 0x04
	int32_t HealthHeal; // Offset: 0x18 // Size: 0x04
	int32_t ShieldHeal; // Offset: 0x1c // Size: 0x04
	int32_t SkillID; // Offset: 0x20 // Size: 0x04
	int32_t PlayerKey; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.KillAssistUIInfo
// Size: 0x70 // Inherited bytes: 0x00
struct FKillAssistUIInfo {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
	struct FName IconTexture; // Offset: 0x0c // Size: 0x08
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FName> BgPaths; // Offset: 0x18 // Size: 0x10
	char pad_0x28[0x48]; // Offset: 0x28 // Size: 0x48
};

// Object Name: ScriptStruct AClient.BattlefieldKillKingMessage
// Size: 0x50 // Inherited bytes: 0x00
struct FBattlefieldKillKingMessage {
	// Fields
	enum class EPlayerKillMessageType MessageType; // Offset: 0x00 // Size: 0x01
	enum class EKillKingMessageType KillKingMessageType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FBattlefieldPlayerInfo KillerInfo; // Offset: 0x08 // Size: 0x20
	struct FBattlefieldPlayerInfo VictimInfo; // Offset: 0x28 // Size: 0x20
	int32_t KillCount; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattlefieldPlayerInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FBattlefieldPlayerInfo {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	uint32_t PlayerKey; // Offset: 0x10 // Size: 0x04
	int32_t TeamID; // Offset: 0x14 // Size: 0x04
	int32_t TeamIdx; // Offset: 0x18 // Size: 0x04
	int32_t SegmentLevel; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.VisualSoundInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FVisualSoundInfo {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.TurnTableCallback
// Size: 0xb0 // Inherited bytes: 0x00
struct FTurnTableCallback {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x10
	struct FName EmojiId; // Offset: 0x10 // Size: 0x08
	struct FName IconPath; // Offset: 0x18 // Size: 0x08
	char pad_0x20[0x90]; // Offset: 0x20 // Size: 0x90
};

// Object Name: ScriptStruct AClient.ItemDefineID
// Size: 0x10 // Inherited bytes: 0x00
struct FItemDefineID {
	// Fields
	int32_t Type; // Offset: 0x00 // Size: 0x04
	int32_t TypeSpecificID; // Offset: 0x04 // Size: 0x04
	int64_t InstanceID; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SimpleClientPingInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FSimpleClientPingInfo {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	int32_t ItemID; // Offset: 0x04 // Size: 0x04
	uint64_t ItemUUID; // Offset: 0x08 // Size: 0x08
	struct TWeakObjectPtr<struct AActor> ReferenceActor; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PropsWeaponFadeOutParams
// Size: 0x08 // Inherited bytes: 0x00
struct FPropsWeaponFadeOutParams {
	// Fields
	enum class EPropsWeaponEndReason FadeOutReason; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float FadeOutTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BroadcastMsgData
// Size: 0x01 // Inherited bytes: 0x00
struct FBroadcastMsgData {
	// Fields
	enum class EBroadcastMsgType BroadcastMsgType; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.MPBattleResult
// Size: 0x50 // Inherited bytes: 0x00
struct FMPBattleResult {
	// Fields
	char ExitReason; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	uint64_t MVPPlayerKey; // Offset: 0x08 // Size: 0x08
	struct FString Reason; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FMPResultTeamData> TeamList; // Offset: 0x20 // Size: 0x10
	int32_t TeamID; // Offset: 0x30 // Size: 0x04
	int32_t WinnerID; // Offset: 0x34 // Size: 0x04
	bool IsEscape; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct TArray<struct FWinModeInfo> WinModeInfos; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct AClient.WinModeInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FWinModeInfo {
	// Fields
	uint64_t PlayerKey; // Offset: 0x00 // Size: 0x08
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	int32_t LegendId; // Offset: 0x18 // Size: 0x04
	int32_t LegendSkin; // Offset: 0x1c // Size: 0x04
	struct TArray<int32_t> Emote; // Offset: 0x20 // Size: 0x10
	bool bIsMVP; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
};

// Object Name: ScriptStruct AClient.MPResultTeamData
// Size: 0x20 // Inherited bytes: 0x00
struct FMPResultTeamData {
	// Fields
	char ExitReason; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t TeamScore; // Offset: 0x04 // Size: 0x04
	int32_t TeamScoreKillCount; // Offset: 0x08 // Size: 0x04
	int32_t TeamID; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FBattleResultTeammate> members; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BattleResultTeammate
// Size: 0xe0 // Inherited bytes: 0x00
struct FBattleResultTeammate {
	// Fields
	uint64_t UID; // Offset: 0x00 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString Name; // Offset: 0x10 // Size: 0x10
	int32_t KillNum; // Offset: 0x20 // Size: 0x04
	int32_t DeathNum; // Offset: 0x24 // Size: 0x04
	int32_t AssistNum; // Offset: 0x28 // Size: 0x04
	int32_t RevivalNum; // Offset: 0x2c // Size: 0x04
	int32_t RescueNum; // Offset: 0x30 // Size: 0x04
	int32_t SurviveTime; // Offset: 0x34 // Size: 0x04
	float DamageAmount; // Offset: 0x38 // Size: 0x04
	int32_t Rank; // Offset: 0x3c // Size: 0x04
	int32_t LegendId; // Offset: 0x40 // Size: 0x04
	int32_t LegendSkin; // Offset: 0x44 // Size: 0x04
	int32_t FrameID; // Offset: 0x48 // Size: 0x04
	int32_t PosID; // Offset: 0x4c // Size: 0x04
	int32_t bIsEscape; // Offset: 0x50 // Size: 0x04
	bool bAlive; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
	int32_t Score; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct FBRAreanDetailData ArenaDetail; // Offset: 0x60 // Size: 0x70
	struct TArray<int32_t> Emote; // Offset: 0xd0 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BRAreanDetailData
// Size: 0x70 // Inherited bytes: 0x00
struct FBRAreanDetailData {
	// Fields
	struct FBRAreanBrilliantData Brilliant; // Offset: 0x00 // Size: 0x3c
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct TArray<int64_t> Achievements; // Offset: 0x40 // Size: 0x10
	uint64_t Score; // Offset: 0x50 // Size: 0x08
	float RankRatio; // Offset: 0x58 // Size: 0x04
	struct FBRAreanRadarData Radar; // Offset: 0x5c // Size: 0x14
};

// Object Name: ScriptStruct AClient.BRAreanRadarData
// Size: 0x14 // Inherited bytes: 0x00
struct FBRAreanRadarData {
	// Fields
	float Kill; // Offset: 0x00 // Size: 0x04
	float Rank; // Offset: 0x04 // Size: 0x04
	float Damage; // Offset: 0x08 // Size: 0x04
	float Revive; // Offset: 0x0c // Size: 0x04
	float Survival; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BRAreanBrilliantData
// Size: 0x3c // Inherited bytes: 0x00
struct FBRAreanBrilliantData {
	// Fields
	int32_t ComboKill; // Offset: 0x00 // Size: 0x04
	int32_t ComboKillAvg; // Offset: 0x04 // Size: 0x04
	float HeadShotRate; // Offset: 0x08 // Size: 0x04
	float HeadShotRateAvg; // Offset: 0x0c // Size: 0x04
	float DamageTImeRecoveryHP; // Offset: 0x10 // Size: 0x04
	float DamageTImeRecoveryHPAvg; // Offset: 0x14 // Size: 0x04
	float VerticalDamage; // Offset: 0x18 // Size: 0x04
	float VerticalDamageAvg; // Offset: 0x1c // Size: 0x04
	float BehiindDamage; // Offset: 0x20 // Size: 0x04
	float BehiindDamageAvg; // Offset: 0x24 // Size: 0x04
	int32_t SegmentLevel; // Offset: 0x28 // Size: 0x04
	float KillAvg; // Offset: 0x2c // Size: 0x04
	float AssistAvg; // Offset: 0x30 // Size: 0x04
	float DamageAvg; // Offset: 0x34 // Size: 0x04
	int32_t GameNum; // Offset: 0x38 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SyncUpdatableCoreData
// Size: 0x10 // Inherited bytes: 0x00
struct FSyncUpdatableCoreData {
	// Fields
	struct TArray<struct FSyncUpdatableCoreDataInfo> SyncUpdatableCoreDataList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SyncUpdatableCoreDataInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FSyncUpdatableCoreDataInfo {
	// Fields
	int32_t GroupID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Param1; // Offset: 0x08 // Size: 0x10
	struct FString Param2; // Offset: 0x18 // Size: 0x10
	struct FString Param3; // Offset: 0x28 // Size: 0x10
	struct FString Param4; // Offset: 0x38 // Size: 0x10
	struct FString Param5; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SimpleBattleResultData
// Size: 0x80 // Inherited bytes: 0x00
struct FSimpleBattleResultData {
	// Fields
	char ExitReason; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString ModeType; // Offset: 0x08 // Size: 0x10
	enum class EBattleResultType ResultType; // Offset: 0x18 // Size: 0x01
	bool IsEscape; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x6]; // Offset: 0x1a // Size: 0x06
	struct FString Reason; // Offset: 0x20 // Size: 0x10
	int32_t TotalPlayerCount; // Offset: 0x30 // Size: 0x04
	int32_t TotalTeamCount; // Offset: 0x34 // Size: 0x04
	int32_t TeamID; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FSimpleBattleResultTeamData TeamData; // Offset: 0x40 // Size: 0x18
	struct FRatingScoreResultData RatingData; // Offset: 0x58 // Size: 0x14
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct TArray<struct FWinModeInfo> WinModeInfos; // Offset: 0x70 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RatingScoreResultData
// Size: 0x14 // Inherited bytes: 0x00
struct FRatingScoreResultData {
	// Fields
	int32_t KillAssistScore; // Offset: 0x00 // Size: 0x04
	int32_t MatchPlacementScore; // Offset: 0x04 // Size: 0x04
	int32_t SegmentLevel; // Offset: 0x08 // Size: 0x04
	int32_t Rating; // Offset: 0x0c // Size: 0x04
	int32_t DailyWinTime; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SimpleBattleResultTeamData
// Size: 0x18 // Inherited bytes: 0x00
struct FSimpleBattleResultTeamData {
	// Fields
	int32_t TeamRank; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FBattleResultTeammate> members; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CommonSignData
// Size: 0x40 // Inherited bytes: 0x00
struct FCommonSignData {
	// Fields
	int32_t SignSyncIndex; // Offset: 0x00 // Size: 0x04
	struct FVector WorldPosition; // Offset: 0x04 // Size: 0x0c
	enum class ESignType SignType; // Offset: 0x10 // Size: 0x01
	enum class ESignTypeFor TypeFor; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	uint32_t SourcePlayerID; // Offset: 0x14 // Size: 0x04
	float Duration; // Offset: 0x18 // Size: 0x04
	int32_t TeamID; // Offset: 0x1c // Size: 0x04
	struct TWeakObjectPtr<struct AActor> FollowedActor; // Offset: 0x20 // Size: 0x08
	uint32_t NetworkGUIDValue; // Offset: 0x28 // Size: 0x04
	int32_t SkinType; // Offset: 0x2c // Size: 0x04
	bool bIsClientCreated; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	struct FSignAdditionData SignAdditionData; // Offset: 0x34 // Size: 0x08
	float CreateTime; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.SignAdditionData
// Size: 0x08 // Inherited bytes: 0x00
struct FSignAdditionData {
	// Fields
	int32_t CampID; // Offset: 0x00 // Size: 0x04
	float Duration; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattleItemUseTarget
// Size: 0x20 // Inherited bytes: 0x00
struct FBattleItemUseTarget {
	// Fields
	struct FItemDefineID TargetDefineID; // Offset: 0x00 // Size: 0x10
	struct FName TargetAssociationName; // Offset: 0x10 // Size: 0x08
	enum class EWeaponSaveSlot TargetSlot; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct AClient.ApgameWeaponInstanceId
// Size: 0x02 // Inherited bytes: 0x00
struct FApgameWeaponInstanceId {
	// Fields
	uint16_t Value; // Offset: 0x00 // Size: 0x02
};

// Object Name: ScriptStruct AClient.ScreenOperateModeInfo
// Size: 0x02 // Inherited bytes: 0x00
struct FScreenOperateModeInfo {
	// Fields
	enum class EScreenLeftOperateMode LeftOperateMode; // Offset: 0x00 // Size: 0x01
	enum class EScreenRightOperateMode RightOperateMode; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.CharacterAvatar_WearInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FCharacterAvatar_WearInfo {
	// Fields
	struct TArray<struct FCharacterAvatar_EquipSkinInfo> EquipedSkinList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FCharacterAvatar_PendantInfo> EquipedPendantList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CharacterAvatar_PendantInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FCharacterAvatar_PendantInfo {
	// Fields
	int32_t PendantItemID; // Offset: 0x00 // Size: 0x04
	struct FCharacterAvatar_WearItemMetaInfo AttachedItemMetaInfo; // Offset: 0x04 // Size: 0x14
};

// Object Name: ScriptStruct AClient.CharacterAvatar_WearItemMetaInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FCharacterAvatar_WearItemMetaInfo {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	int32_t ItemType; // Offset: 0x04 // Size: 0x04
	int32_t ItemSubType; // Offset: 0x08 // Size: 0x04
	int32_t ItemLevel; // Offset: 0x0c // Size: 0x04
	bool ValidInfo; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
};

// Object Name: ScriptStruct AClient.CharacterAvatar_EquipSkinInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FCharacterAvatar_EquipSkinInfo {
	// Fields
	int32_t ReplacedItemID; // Offset: 0x00 // Size: 0x04
	struct FCharacterAvatar_WearItemMetaInfo SkinMetaInfo; // Offset: 0x04 // Size: 0x14
};

// Object Name: ScriptStruct AClient.MiniMapStaticItemVisibleInfo
// Size: 0x02 // Inherited bytes: 0x00
struct FMiniMapStaticItemVisibleInfo {
	// Fields
	char Type; // Offset: 0x00 // Size: 0x01
	bool bVisible; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.InGameRecoverItemGuidInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FInGameRecoverItemGuidInfo {
	// Fields
	int32_t GuideID; // Offset: 0x00 // Size: 0x04
	enum class eInGameRecoverItemGuidType eInGameRecoverItemGuidType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	float MinPercentValue; // Offset: 0x08 // Size: 0x04
	float MaxPercentValue; // Offset: 0x0c // Size: 0x04
	float DurationTime; // Offset: 0x10 // Size: 0x04
	int32_t ItemID; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PickupNotifyData
// Size: 0x28 // Inherited bytes: 0x00
struct FPickupNotifyData {
	// Fields
	bool bPickupResult; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t OccupiedCapacity; // Offset: 0x04 // Size: 0x04
	int32_t Capacity; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FItemDefineID DefineID; // Offset: 0x10 // Size: 0x10
	bool bEquipping; // Offset: 0x20 // Size: 0x01
	bool bIsAutoPickUp; // Offset: 0x21 // Size: 0x01
	enum class EBattleItemPickupReason PickupReason; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x5]; // Offset: 0x23 // Size: 0x05
};

// Object Name: ScriptStruct AClient.AttrModifyItem
// Size: 0x60 // Inherited bytes: 0x00
struct FAttrModifyItem {
	// Fields
	float FinalAddValue; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString AttrModifyItemName; // Offset: 0x08 // Size: 0x10
	enum class EApexAttrType AttrType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct FString AttrName; // Offset: 0x20 // Size: 0x10
	enum class EAttrOperator ModifierOp; // Offset: 0x30 // Size: 0x01
	bool bIsResource; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x2]; // Offset: 0x32 // Size: 0x02
	float ModifierValue; // Offset: 0x34 // Size: 0x04
	struct FSoftObjectPath ModifierResValue; // Offset: 0x38 // Size: 0x18
	bool IsEnable; // Offset: 0x50 // Size: 0x01
	bool ClientSimulate; // Offset: 0x51 // Size: 0x01
	bool LinearChanging; // Offset: 0x52 // Size: 0x01
	char pad_0x53[0x1]; // Offset: 0x53 // Size: 0x01
	float ChangingDuration; // Offset: 0x54 // Size: 0x04
	float LinearProgressTime; // Offset: 0x58 // Size: 0x04
	float OriModifierValue; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AttrRegisterItem
// Size: 0x30 // Inherited bytes: 0x00
struct FAttrRegisterItem {
	// Fields
	struct FString AttrName; // Offset: 0x00 // Size: 0x10
	enum class EAttrVariableType AttrVariableType; // Offset: 0x10 // Size: 0x01
	bool HasReplicatedTag; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x6]; // Offset: 0x12 // Size: 0x06
	struct UObject* OriginalRes; // Offset: 0x18 // Size: 0x08
	char pad_0x20[0x10]; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.FormulaProxyAttrModifyItem
// Size: 0x80 // Inherited bytes: 0x60
struct FFormulaProxyAttrModifyItem : FAttrModifyItem {
	// Fields
	bool bEnableModifyLimit; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x3]; // Offset: 0x61 // Size: 0x03
	float MinModifyValue; // Offset: 0x64 // Size: 0x04
	float MaxModifyValue; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x14]; // Offset: 0x6c // Size: 0x14
};

// Object Name: ScriptStruct AClient.ActiveModifyContainer
// Size: 0x2b0 // Inherited bytes: 0x108
struct FActiveModifyContainer : FFastArraySerializer {
	// Fields
	char pad_0x108[0x168]; // Offset: 0x108 // Size: 0x168
	struct TArray<struct FActiveModify> ActiveModifies_Internal; // Offset: 0x270 // Size: 0x10
	struct TArray<struct FActiveModify> ActiveModifies_ForPrediction; // Offset: 0x280 // Size: 0x10
	char pad_0x290[0x20]; // Offset: 0x290 // Size: 0x20
};

// Object Name: ScriptStruct AClient.ActiveModify
// Size: 0x160 // Inherited bytes: 0x0c
struct FActiveModify : FFastArraySerializerItem {
	// Fields
	char pad_0xC[0xc]; // Offset: 0x0c // Size: 0x0c
	struct FAttributeModifierSpec Spec; // Offset: 0x18 // Size: 0x110
	struct FPredictionKey PredictionKey; // Offset: 0x128 // Size: 0x10
	float StartServerWorldTime; // Offset: 0x138 // Size: 0x04
	float CachedStartServerWorldTime; // Offset: 0x13c // Size: 0x04
	float StartWorldTime; // Offset: 0x140 // Size: 0x04
	bool bIsInhibited; // Offset: 0x144 // Size: 0x01
	char pad_0x145[0x1b]; // Offset: 0x145 // Size: 0x1b
};

// Object Name: ScriptStruct AClient.AttributeModifierSpec
// Size: 0x110 // Inherited bytes: 0x00
struct FAttributeModifierSpec {
	// Fields
	struct FName Tip; // Offset: 0x00 // Size: 0x08
	struct UModifyAttributeData* ModifyAttributeData; // Offset: 0x08 // Size: 0x08
	char RemoveMode; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct TWeakObjectPtr<struct AActor> Source; // Offset: 0x14 // Size: 0x08
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FModifierSpec> Modifiers; // Offset: 0x20 // Size: 0x10
	char bCompletedSourceAttributeCapture : 1; // Offset: 0x30 // Size: 0x01
	char bCompletedTargetAttributeCapture : 1; // Offset: 0x30 // Size: 0x01
	char pad_0x30_2 : 6; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct FAttributeCaptureSpecContainer CapturedRelevantAttributes; // Offset: 0x38 // Size: 0x28
	char pad_0x60[0xa0]; // Offset: 0x60 // Size: 0xa0
	float Level; // Offset: 0x100 // Size: 0x04
	bool IsInitLevel; // Offset: 0x104 // Size: 0x01
	char pad_0x105[0x3]; // Offset: 0x105 // Size: 0x03
	struct FName PawnStateKey; // Offset: 0x108 // Size: 0x08
};

// Object Name: ScriptStruct AClient.AttributeCaptureSpecContainer
// Size: 0x28 // Inherited bytes: 0x00
struct FAttributeCaptureSpecContainer {
	// Fields
	struct TArray<struct FAttributeCaptureSpec> SourceAttributes; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FAttributeCaptureSpec> TargetAttributes; // Offset: 0x10 // Size: 0x10
	bool bHasNonSnapshottedAttributes; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct AClient.AttributeCaptureSpec
// Size: 0x50 // Inherited bytes: 0x00
struct FAttributeCaptureSpec {
	// Fields
	struct FAttributeCaptureDefinition BackingDefinition; // Offset: 0x00 // Size: 0x40
	char pad_0x40[0x10]; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AttributeCaptureDefinition
// Size: 0x40 // Inherited bytes: 0x00
struct FAttributeCaptureDefinition {
	// Fields
	struct FGameplayAttribute AttributeToCapture; // Offset: 0x00 // Size: 0x38
	enum class EAttributeCaptureSource AttributeSource; // Offset: 0x38 // Size: 0x01
	bool bSnapshot; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x6]; // Offset: 0x3a // Size: 0x06
};

// Object Name: ScriptStruct AClient.GameplayAttribute
// Size: 0x38 // Inherited bytes: 0x00
struct FGameplayAttribute {
	// Fields
	struct FString AttributeName; // Offset: 0x00 // Size: 0x10
	struct TFieldPath<FProperty> Attribute; // Offset: 0x10 // Size: 0x20
	struct UStruct* AttributeOwner; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ModifierSpec
// Size: 0x04 // Inherited bytes: 0x00
struct FModifierSpec {
	// Fields
	float EvaluatedMagnitude; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AClient.HandStateData
// Size: 0x40 // Inherited bytes: 0x00
struct FHandStateData {
	// Fields
	enum class EOperationType OperationType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString OperationGroup; // Offset: 0x08 // Size: 0x10
	struct FHandStateCustomData CustomData; // Offset: 0x18 // Size: 0x0c
	bool OverrideCustomData; // Offset: 0x24 // Size: 0x01
	enum class eOperationSrcType eOperationSrcType; // Offset: 0x25 // Size: 0x01
	char pad_0x26[0x2]; // Offset: 0x26 // Size: 0x02
	float Timestamp; // Offset: 0x28 // Size: 0x04
	int32_t UniqueID; // Offset: 0x2c // Size: 0x04
	struct FString DetailDesc; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.HandStateCustomData
// Size: 0x0c // Inherited bytes: 0x00
struct FHandStateCustomData {
	// Fields
	int32_t CustomIntData1; // Offset: 0x00 // Size: 0x04
	int32_t CustomIntData2; // Offset: 0x04 // Size: 0x04
	enum class EWeaponDataSlot WeaponSlot; // Offset: 0x08 // Size: 0x01
	bool bNeedWeaponProcess; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
};

// Object Name: ScriptStruct AClient.DynamicItemConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FDynamicItemConfig {
	// Fields
	struct TMap<int32_t, struct FDynamicItemMeshConfig> DynamicStaticData; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.DynamicItemMeshConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FDynamicItemMeshConfig {
	// Fields
	struct TMap<struct FName, struct UMaterialInterface*> DynamicStaticMeshData; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.PickUpItemData
// Size: 0x30 // Inherited bytes: 0x00
struct FPickUpItemData {
	// Fields
	struct FItemDefineID ID; // Offset: 0x00 // Size: 0x10
	int32_t count; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FBattleItemAdditionalData> AdditionalDataList; // Offset: 0x18 // Size: 0x10
	int32_t Index; // Offset: 0x28 // Size: 0x04
	int32_t InsertTime; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattleItemAdditionalData
// Size: 0x20 // Inherited bytes: 0x00
struct FBattleItemAdditionalData {
	// Fields
	enum class EItemAdditionalType DataType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float FloatData; // Offset: 0x04 // Size: 0x04
	int32_t IntData; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<int32_t> IntArray; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PickupLockData
// Size: 0x0c // Inherited bytes: 0x00
struct FPickupLockData {
	// Fields
	enum class EPickupLockedReason Reason; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float LockTime; // Offset: 0x04 // Size: 0x04
	uint32_t LockPlayerKey; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PickUpShowParticleConfig
// Size: 0x80 // Inherited bytes: 0x00
struct FPickUpShowParticleConfig {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> ParticleSystemPrt; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UStaticMesh> EffectMeshPrt; // Offset: 0x28 // Size: 0x28
	struct FTransform Transform; // Offset: 0x50 // Size: 0x30
};

// Object Name: ScriptStruct AClient.ThrowProps
// Size: 0x40 // Inherited bytes: 0x00
struct FThrowProps {
	// Fields
	struct FPickUpItemData MainItem; // Offset: 0x00 // Size: 0x30
	struct TArray<struct FPickUpItemData> AttachItem; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.FireBtnData
// Size: 0x78 // Inherited bytes: 0x00
struct FFireBtnData {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	struct FName IconType; // Offset: 0x04 // Size: 0x08
	struct FName AnimName; // Offset: 0x0c // Size: 0x08
	struct FLinearColor EffectColor; // Offset: 0x14 // Size: 0x10
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct UObject* NormalIcon; // Offset: 0x28 // Size: 0x08
	struct UObject* HoverIcon; // Offset: 0x30 // Size: 0x08
	struct UObject* PressIcon; // Offset: 0x38 // Size: 0x08
	struct UObject* NormalIconLeft; // Offset: 0x40 // Size: 0x08
	struct UObject* PressIconLeft; // Offset: 0x48 // Size: 0x08
	struct UObject* NormalIconWaistShoot; // Offset: 0x50 // Size: 0x08
	struct UObject* PressIconWaistShoot; // Offset: 0x58 // Size: 0x08
	struct UUserWidget* EffectWidgetClass; // Offset: 0x60 // Size: 0x08
	struct FName PressAnimNameRight; // Offset: 0x68 // Size: 0x08
	struct FName NormalAnimNameRight; // Offset: 0x70 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ItemData
// Size: 0x88 // Inherited bytes: 0x00
struct FItemData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FItemDefineID DefineID; // Offset: 0x08 // Size: 0x10
	struct FText Name; // Offset: 0x18 // Size: 0x18
	struct FText Desc; // Offset: 0x30 // Size: 0x18
	struct FString SmallIcon; // Offset: 0x48 // Size: 0x10
	struct FString BigIcon; // Offset: 0x58 // Size: 0x10
	int32_t SubType; // Offset: 0x68 // Size: 0x04
	int32_t MaxCount; // Offset: 0x6c // Size: 0x04
	struct UItemHandleBase* ItemHandle; // Offset: 0x70 // Size: 0x08
	int32_t ProgressBarCount; // Offset: 0x78 // Size: 0x04
	int32_t StackCount; // Offset: 0x7c // Size: 0x04
	int32_t ItemQuality; // Offset: 0x80 // Size: 0x04
	bool bBackpackInclude; // Offset: 0x84 // Size: 0x01
	char pad_0x85[0x3]; // Offset: 0x85 // Size: 0x03
};

// Object Name: ScriptStruct AClient.BattleItemData
// Size: 0xe0 // Inherited bytes: 0x88
struct FBattleItemData : FItemData {
	// Fields
	int32_t count; // Offset: 0x88 // Size: 0x04
	bool bEquipping; // Offset: 0x8c // Size: 0x01
	char pad_0x8D[0x3]; // Offset: 0x8d // Size: 0x03
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // Offset: 0x90 // Size: 0x10
	bool BackpackSlotIndex; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x3]; // Offset: 0xa1 // Size: 0x03
	struct FBattleItemFeatureData FeatureData; // Offset: 0xa4 // Size: 0x20
	bool bCanUsable; // Offset: 0xc4 // Size: 0x01
	char pad_0xC5[0x3]; // Offset: 0xc5 // Size: 0x03
	struct TArray<struct FItemAssociation> Associations; // Offset: 0xc8 // Size: 0x10
	int32_t DeriveID; // Offset: 0xd8 // Size: 0x04
	bool Fixed; // Offset: 0xdc // Size: 0x01
	char pad_0xDD[0x3]; // Offset: 0xdd // Size: 0x03
};

// Object Name: ScriptStruct AClient.ItemAssociation
// Size: 0x20 // Inherited bytes: 0x00
struct FItemAssociation {
	// Fields
	struct FName AssociationName; // Offset: 0x00 // Size: 0x08
	struct FItemDefineID AssociationTargetDefineID; // Offset: 0x08 // Size: 0x10
	struct UItemHandleBase* AssociationTargetHandle; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BattleItemFeatureData
// Size: 0x20 // Inherited bytes: 0x00
struct FBattleItemFeatureData {
	// Fields
	float UnitWeight; // Offset: 0x00 // Size: 0x04
	int32_t MaxCount; // Offset: 0x04 // Size: 0x04
	bool bUnique; // Offset: 0x08 // Size: 0x01
	bool bStackable; // Offset: 0x09 // Size: 0x01
	bool bEquippable; // Offset: 0x0a // Size: 0x01
	bool bConsumable; // Offset: 0x0b // Size: 0x01
	bool bAutoEquipAndDrop; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	int32_t SortingPriority; // Offset: 0x10 // Size: 0x04
	int32_t ItemType; // Offset: 0x14 // Size: 0x04
	int32_t ItemQuality; // Offset: 0x18 // Size: 0x04
	int32_t ToolbarWeight; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.InGameGuideStepInfo
// Size: 0x108 // Inherited bytes: 0x00
struct FInGameGuideStepInfo {
	// Fields
	int32_t GuideID; // Offset: 0x00 // Size: 0x04
	bool IsComplete; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct FName BlueprintName; // Offset: 0x08 // Size: 0x08
	struct FName NodeName; // Offset: 0x10 // Size: 0x08
	struct FName HighLightBlueprintName; // Offset: 0x18 // Size: 0x08
	struct FName HighLightNodeName; // Offset: 0x20 // Size: 0x08
	struct FName JumpBlueprintName; // Offset: 0x28 // Size: 0x08
	struct FName JumpNodeName; // Offset: 0x30 // Size: 0x08
	int32_t JumpGuideID; // Offset: 0x38 // Size: 0x04
	bool IsButton; // Offset: 0x3c // Size: 0x01
	bool IsAllScreenButton; // Offset: 0x3d // Size: 0x01
	bool IsForceGuide; // Offset: 0x3e // Size: 0x01
	char pad_0x3F[0x1]; // Offset: 0x3f // Size: 0x01
	float Duration; // Offset: 0x40 // Size: 0x04
	enum class EInGameGuideType GuideType; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
	struct FText GraphicGuideTitle; // Offset: 0x48 // Size: 0x18
	struct TArray<struct FGraphicGuideInfo> GraphicGuideInfos; // Offset: 0x60 // Size: 0x10
	struct TArray<struct UInGameGuideConditionBase*> ConditionList; // Offset: 0x70 // Size: 0x10
	struct TArray<struct UInGameGuideConditionBase*> EndConditionList; // Offset: 0x80 // Size: 0x10
	bool IsAutoEnterNextStep; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x3]; // Offset: 0x91 // Size: 0x03
	float ResetDurationTime; // Offset: 0x94 // Size: 0x04
	struct FString LuaPath; // Offset: 0x98 // Size: 0x10
	struct TArray<struct FString> LuaArgs; // Offset: 0xa8 // Size: 0x10
	bool IsKeyStep; // Offset: 0xb8 // Size: 0x01
	bool IsContinueCheck; // Offset: 0xb9 // Size: 0x01
	char pad_0xBA[0x6]; // Offset: 0xba // Size: 0x06
	struct FText ShowTips; // Offset: 0xc0 // Size: 0x18
	enum class EInGameGuideDirection ShowTipsDir; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x3]; // Offset: 0xd9 // Size: 0x03
	struct FVector2D ShowTipsOffsetEx; // Offset: 0xdc // Size: 0x08
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
	struct FString ResetShowTips; // Offset: 0xe8 // Size: 0x10
	bool bEnableHandGuide; // Offset: 0xf8 // Size: 0x01
	char pad_0xF9[0x3]; // Offset: 0xf9 // Size: 0x03
	float HandGuideTime; // Offset: 0xfc // Size: 0x04
	enum class EInGameGuideHandGuideType HandGuideType; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07
};

// Object Name: ScriptStruct AClient.GraphicGuideInfo
// Size: 0xb8 // Inherited bytes: 0x00
struct FGraphicGuideInfo {
	// Fields
	struct FSlateBrush ImageIcon; // Offset: 0x00 // Size: 0x88
	struct FText GuideTitle; // Offset: 0x88 // Size: 0x18
	struct FText GuideDesc; // Offset: 0xa0 // Size: 0x18
};

// Object Name: ScriptStruct AClient.SearchedPickUpWrapperResult
// Size: 0x88 // Inherited bytes: 0x00
struct FSearchedPickUpWrapperResult {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	int32_t SearchedPickUpTime; // Offset: 0x08 // Size: 0x04
	bool IsDisable; // Offset: 0x0c // Size: 0x01
	bool IsSick; // Offset: 0x0d // Size: 0x01
	bool IsLowQuality; // Offset: 0x0e // Size: 0x01
	bool IsRecommend; // Offset: 0x0f // Size: 0x01
	int32_t RecommendCount; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FPickUpItemData PickupInfo; // Offset: 0x18 // Size: 0x30
	int32_t ItemSubType; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FItemDefineID BulletDefineID; // Offset: 0x50 // Size: 0x10
	enum class EPickupGroup PickupGroup; // Offset: 0x60 // Size: 0x01
	bool IsGroupColumn; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x2]; // Offset: 0x62 // Size: 0x02
	int32_t Size; // Offset: 0x64 // Size: 0x04
	bool bReserved; // Offset: 0x68 // Size: 0x01
	bool bDropped; // Offset: 0x69 // Size: 0x01
	char pad_0x6A[0x2]; // Offset: 0x6a // Size: 0x02
	int32_t NetGuid; // Offset: 0x6c // Size: 0x04
	bool bDeleted; // Offset: 0x70 // Size: 0x01
	bool IsCanPickupByBin; // Offset: 0x71 // Size: 0x01
	bool IsLobaOwner; // Offset: 0x72 // Size: 0x01
	enum class EItemSpawnReason SpawnReason; // Offset: 0x73 // Size: 0x01
	struct FVector Location; // Offset: 0x74 // Size: 0x0c
	uint32_t RecoverBannerPlayerKey; // Offset: 0x80 // Size: 0x04
	int32_t RecoverBannerLegendId; // Offset: 0x84 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AuraInfo
// Size: 0x90 // Inherited bytes: 0x00
struct FAuraInfo {
	// Fields
	struct FName AuraName; // Offset: 0x00 // Size: 0x08
	struct UAuraShape* AuraShape; // Offset: 0x08 // Size: 0x08
	bool IsEvaluateBlock; // Offset: 0x10 // Size: 0x01
	enum class ECollisionChannel BlockChannel; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x6]; // Offset: 0x12 // Size: 0x06
	struct TSet<struct FName> BuffNameArray; // Offset: 0x18 // Size: 0x50
	enum class EPickerTargetType TargetType; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x3]; // Offset: 0x69 // Size: 0x03
	struct FAuraTargetLimitInfo TargetLimitInfo; // Offset: 0x6c // Size: 0x08
	bool bNeedSimulateOnClient; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03
	struct TArray<struct FName> RejectedByBuffs; // Offset: 0x78 // Size: 0x10
	bool RejectedInVoid; // Offset: 0x88 // Size: 0x01
	bool CleanBuffOnRemoveAura; // Offset: 0x89 // Size: 0x01
	bool IsActive; // Offset: 0x8a // Size: 0x01
	char pad_0x8B[0x1]; // Offset: 0x8b // Size: 0x01
	int32_t LegendId; // Offset: 0x8c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AuraTargetLimitInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FAuraTargetLimitInfo {
	// Fields
	enum class EAuraTargetLimitType LimitType; // Offset: 0x00 // Size: 0x01
	bool IgnoreDecoyNum; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int32_t MaxNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ProxyActorWeaponData
// Size: 0x18 // Inherited bytes: 0x00
struct FProxyActorWeaponData {
	// Fields
	struct FItemDefineID WeaponID; // Offset: 0x00 // Size: 0x10
	enum class EWeaponSaveSlot WeaponSaveSlot; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t WeaponSkinID; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponTransformConfig
// Size: 0x68 // Inherited bytes: 0x00
struct FWeaponTransformConfig {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	float TPPAO; // Offset: 0x04 // Size: 0x04
	struct FVector TPPOffsetHand; // Offset: 0x08 // Size: 0x0c
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TMap<enum class EWeaponAttchSocketPosition, struct FTransform> TPPTransformsMap; // Offset: 0x18 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ApgameWeaponAttributeSetInitialDataHandle
// Size: 0x50 // Inherited bytes: 0x00
struct FApgameWeaponAttributeSetInitialDataHandle {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ApgameWeaponInitializationData
// Size: 0x50 // Inherited bytes: 0x00
struct FApgameWeaponInitializationData {
	// Fields
	uint16_t RepIndex; // Offset: 0x00 // Size: 0x02
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FItemDefineID ItemDefineID; // Offset: 0x08 // Size: 0x10
	struct FSpawnWeaponAdditionalData AdditionalData; // Offset: 0x18 // Size: 0x38
};

// Object Name: ScriptStruct AClient.SpawnWeaponAdditionalData
// Size: 0x38 // Inherited bytes: 0x00
struct FSpawnWeaponAdditionalData {
	// Fields
	bool bUseSpecialBullet; // Offset: 0x00 // Size: 0x01
	bool bFirstPickup; // Offset: 0x01 // Size: 0x01
	int8_t SignatureModelIndex; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	int32_t SkinId; // Offset: 0x04 // Size: 0x04
	int32_t InitBulletNum; // Offset: 0x08 // Size: 0x04
	int32_t DeriveID; // Offset: 0x0c // Size: 0x04
	int32_t ExtraBulletNum; // Offset: 0x10 // Size: 0x04
	int32_t SpecialBulletNum; // Offset: 0x14 // Size: 0x04
	int32_t SkinOwnerKey; // Offset: 0x18 // Size: 0x04
	int32_t CumulativeKill; // Offset: 0x1c // Size: 0x04
	int32_t SignatureId; // Offset: 0x20 // Size: 0x04
	int32_t SignatureLevel; // Offset: 0x24 // Size: 0x04
	struct TArray<int32_t> SignatureFeatureIdList; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameWeaponSlotMap
// Size: 0x01 // Inherited bytes: 0x00
struct FApgameWeaponSlotMap {
	// Fields
	bool bSwapped; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.SwitchWeaponParamter
// Size: 0x05 // Inherited bytes: 0x00
struct FSwitchWeaponParamter {
	// Fields
	enum class EWeaponDataSlot TargetSlot; // Offset: 0x00 // Size: 0x01
	bool bNeedAnimation; // Offset: 0x01 // Size: 0x01
	enum class EWeaponSaveSlot CurrentSlot; // Offset: 0x02 // Size: 0x01
	bool bNeedPop; // Offset: 0x03 // Size: 0x01
	char RepIndex; // Offset: 0x04 // Size: 0x01
};

// Object Name: ScriptStruct AClient.WeaponBallisticInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponBallisticInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.SimuWeaponFollow
// Size: 0x02 // Inherited bytes: 0x00
struct FSimuWeaponFollow {
	// Fields
	bool bWeaponMainFollow; // Offset: 0x00 // Size: 0x01
	bool bWeaponAttachFollow; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.ApgameEvent
// Size: 0x20 // Inherited bytes: 0x00
struct FApgameEvent {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct AClient.DynamicBasedMovementInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FDynamicBasedMovementInfo {
	// Fields
	struct UPrimitiveComponent* MovementBase; // Offset: 0x00 // Size: 0x08
	struct FName BoneName; // Offset: 0x08 // Size: 0x08
	struct FVector_NetQuantize100 Location; // Offset: 0x10 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x1c // Size: 0x0c
	bool bServerHasBaseComponent; // Offset: 0x28 // Size: 0x01
	bool bRelativeRotation; // Offset: 0x29 // Size: 0x01
	bool bServerHasVelocity; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x5]; // Offset: 0x2b // Size: 0x05
};

// Object Name: ScriptStruct AClient.ProjectileLaunchData
// Size: 0x40 // Inherited bytes: 0x00
struct FProjectileLaunchData {
	// Fields
	float InitialSpeed; // Offset: 0x00 // Size: 0x04
	struct FVector Velocity; // Offset: 0x04 // Size: 0x0c
	struct FProjectilePositionData PositionData; // Offset: 0x10 // Size: 0x30
};

// Object Name: ScriptStruct AClient.ProjectilePositionData
// Size: 0x30 // Inherited bytes: 0x00
struct FProjectilePositionData {
	// Fields
	struct FRotator Rotator; // Offset: 0x00 // Size: 0x0c
	struct FVector OwnerOffset; // Offset: 0x0c // Size: 0x0c
	struct UPrimitiveComponent* MovementBase; // Offset: 0x18 // Size: 0x08
	struct FVector BaseOffset; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ImpactResult
// Size: 0xb8 // Inherited bytes: 0x00
struct FImpactResult {
	// Fields
	struct FVector Velocity; // Offset: 0x00 // Size: 0x0c
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FMovementSyncDataWithRotation MovementSyncDataWithRotation; // Offset: 0x10 // Size: 0x20
	struct FHitResult Hit; // Offset: 0x30 // Size: 0x88
};

// Object Name: ScriptStruct AClient.MovementSyncDataWithRotation
// Size: 0x20 // Inherited bytes: 0x00
struct FMovementSyncDataWithRotation {
	// Fields
	struct UPrimitiveComponent* Base; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x18]; // Offset: 0x08 // Size: 0x18
};

// Object Name: ScriptStruct AClient.ProjectilePendingData
// Size: 0x38 // Inherited bytes: 0x00
struct FProjectilePendingData {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
	bool bDiscardBounceWhenStop; // Offset: 0x28 // Size: 0x01
	bool bOneStopSimulating; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
	float PendingBounceDeltaTime; // Offset: 0x2c // Size: 0x04
	float PendingStopDeltaTime; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.HoverTankMovementSetting
// Size: 0x40 // Inherited bytes: 0x00
struct FHoverTankMovementSetting {
	// Fields
	float HoverTankMoveSpeed; // Offset: 0x00 // Size: 0x04
	float HoverTankAccelerated; // Offset: 0x04 // Size: 0x04
	float DecelDistance; // Offset: 0x08 // Size: 0x04
	float MaxPitchAmount; // Offset: 0x0c // Size: 0x04
	float MaxReversePitchAmount; // Offset: 0x10 // Size: 0x04
	float MaxPitchDeltaPerSecond; // Offset: 0x14 // Size: 0x04
	float ReversePitchDistance; // Offset: 0x18 // Size: 0x04
	float ReverseYawDistance; // Offset: 0x1c // Size: 0x04
	float LookAheadDistance; // Offset: 0x20 // Size: 0x04
	float MaxYawDeltaPerSecond; // Offset: 0x24 // Size: 0x04
	float LandingSpeed; // Offset: 0x28 // Size: 0x04
	float LandingYawSpeed; // Offset: 0x2c // Size: 0x04
	struct UCurveFloat* LandingYawCurve; // Offset: 0x30 // Size: 0x08
	float KindaDeltaYaw; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.HoverTankPointData
// Size: 0x30 // Inherited bytes: 0x00
struct FHoverTankPointData {
	// Fields
	enum class EHoverTankPathPointType PointType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t PathPointID; // Offset: 0x04 // Size: 0x04
	struct TArray<int32_t> LinkPathPointIDArray; // Offset: 0x08 // Size: 0x10
	struct FVector Location; // Offset: 0x18 // Size: 0x0c
	struct FRotator Rotate; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.ApgameDeathRecallHistory
// Size: 0x28 // Inherited bytes: 0x00
struct FApgameDeathRecallHistory {
	// Fields
	struct TArray<struct FBannerData> BannerList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FApgameDeathRecallRecord> RecordList; // Offset: 0x10 // Size: 0x10
	int32_t OwnerPlayerKey; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgameDeathRecallRecord
// Size: 0x40 // Inherited bytes: 0x00
struct FApgameDeathRecallRecord {
	// Fields
	char bAttacked : 1; // Offset: 0x00 // Size: 0x01
	char bOtherIsAI : 1; // Offset: 0x00 // Size: 0x01
	char bKilledOrKnockedDown : 1; // Offset: 0x00 // Size: 0x01
	char bFatalDamage : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_4 : 4; // Offset: 0x00 // Size: 0x01
	enum class EApgameDeathRecallDamageSourceType DamageSourceType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int32_t OtherPlayerKey; // Offset: 0x04 // Size: 0x04
	uint64_t OtherPlayerUID; // Offset: 0x08 // Size: 0x08
	struct FString OtherPlayerName; // Offset: 0x10 // Size: 0x10
	int32_t ItemID; // Offset: 0x20 // Size: 0x04
	int32_t SkillID; // Offset: 0x24 // Size: 0x04
	int32_t KillMsgSkinID; // Offset: 0x28 // Size: 0x04
	float DamageValue; // Offset: 0x2c // Size: 0x04
	struct TArray<bool> DamageFlows; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BannerData
// Size: 0x48 // Inherited bytes: 0x00
struct FBannerData {
	// Fields
	int32_t LegendId; // Offset: 0x00 // Size: 0x04
	int32_t SkinId; // Offset: 0x04 // Size: 0x04
	int32_t FrameID; // Offset: 0x08 // Size: 0x04
	int32_t PosID; // Offset: 0x0c // Size: 0x04
	struct FString PlayerName; // Offset: 0x10 // Size: 0x10
	int32_t KillNum; // Offset: 0x20 // Size: 0x04
	int32_t PlayerKey; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FServerBadgeData> BadgeDataArray; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FServerTrackerData> TrackerDataArray; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ServerTrackerData
// Size: 0x08 // Inherited bytes: 0x00
struct FServerTrackerData {
	// Fields
	int32_t TrackerID; // Offset: 0x00 // Size: 0x04
	int32_t Process; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ServerBadgeData
// Size: 0x0c // Inherited bytes: 0x00
struct FServerBadgeData {
	// Fields
	int32_t BadgeID; // Offset: 0x00 // Size: 0x04
	int32_t Process; // Offset: 0x04 // Size: 0x04
	int32_t Status; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgameDamageEventInfo
// Size: 0x01 // Inherited bytes: 0x00
struct FApgameDamageEventInfo {
	// Fields
	bool bWithDisruptorEnergy; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.ControllableAreaSettings
// Size: 0x28 // Inherited bytes: 0x00
struct FControllableAreaSettings {
	// Fields
	float DefaultControlTime; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<float> ControlTimeSettings; // Offset: 0x08 // Size: 0x10
	float NoneTeamReduceTime; // Offset: 0x18 // Size: 0x04
	float ControlReduceTime; // Offset: 0x1c // Size: 0x04
	char bDiffCampNumKeepTime : 1; // Offset: 0x20 // Size: 0x01
	char pad_0x20_1 : 7; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct AClient.GameModeStateChangedParams
// Size: 0x08 // Inherited bytes: 0x00
struct FGameModeStateChangedParams {
	// Fields
	enum class EMGameModeStage GameModeStageType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float GameModeStageDuration; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.TeammateItemData
// Size: 0xb8 // Inherited bytes: 0x00
struct FTeammateItemData {
	// Fields
	bool IsSelf; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Health; // Offset: 0x04 // Size: 0x04
	float MaxHealth; // Offset: 0x08 // Size: 0x04
	float HealthHealing; // Offset: 0x0c // Size: 0x04
	float ShieldHealing; // Offset: 0x10 // Size: 0x04
	int32_t ShieldQuality; // Offset: 0x14 // Size: 0x04
	int32_t HelmetQuality; // Offset: 0x18 // Size: 0x04
	int32_t GradableShieldExpRemain; // Offset: 0x1c // Size: 0x04
	int32_t GradableShieldLevel; // Offset: 0x20 // Size: 0x04
	int32_t BackpackLevel; // Offset: 0x24 // Size: 0x04
	int32_t KnockDownShieldLevel; // Offset: 0x28 // Size: 0x04
	float ShieldValue; // Offset: 0x2c // Size: 0x04
	float MaxShieldValue; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString PlayerName; // Offset: 0x38 // Size: 0x10
	int32_t LegendId; // Offset: 0x48 // Size: 0x04
	int32_t SkinId; // Offset: 0x4c // Size: 0x04
	int32_t ChooseLegendID; // Offset: 0x50 // Size: 0x04
	int32_t ConfirmLegendID; // Offset: 0x54 // Size: 0x04
	uint32_t PlayerKey; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	uint64_t UID; // Offset: 0x60 // Size: 0x08
	uint32_t TeamIdx; // Offset: 0x68 // Size: 0x04
	bool bIsCommander; // Offset: 0x6c // Size: 0x01
	bool bIsNetLost; // Offset: 0x6d // Size: 0x01
	bool bIsShowNextLife; // Offset: 0x6e // Size: 0x01
	bool bIsSingleParachute; // Offset: 0x6f // Size: 0x01
	bool bIsProtectedByTotem; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x3]; // Offset: 0x71 // Size: 0x03
	uint32_t DyingCount; // Offset: 0x74 // Size: 0x04
	char DyingTimeoutSec; // Offset: 0x78 // Size: 0x01
	char RespawningTime; // Offset: 0x79 // Size: 0x01
	char pad_0x7A[0x2]; // Offset: 0x7a // Size: 0x02
	int32_t UseItemID; // Offset: 0x7c // Size: 0x04
	char BatBeState; // Offset: 0x80 // Size: 0x01
	char BannerState; // Offset: 0x81 // Size: 0x01
	char CurrentNextLifeRespawnState; // Offset: 0x82 // Size: 0x01
	char pad_0x83[0x1]; // Offset: 0x83 // Size: 0x01
	uint32_t FirstSlotBulletId; // Offset: 0x84 // Size: 0x04
	uint32_t SecondSlotBulletId; // Offset: 0x88 // Size: 0x04
	uint32_t SyncDyingRealTime; // Offset: 0x8c // Size: 0x04
	uint32_t SyncRespawningRealTime; // Offset: 0x90 // Size: 0x04
	uint32_t SyncShownRespawningRealTime; // Offset: 0x94 // Size: 0x04
	uint32_t AIHostPlayerKey; // Offset: 0x98 // Size: 0x04
	bool bAIHosting; // Offset: 0x9c // Size: 0x01
	char pad_0x9D[0x3]; // Offset: 0x9d // Size: 0x03
	int32_t AIHostFunc1; // Offset: 0xa0 // Size: 0x04
	int32_t AIHostFunc2; // Offset: 0xa4 // Size: 0x04
	int32_t AIHostFunc3; // Offset: 0xa8 // Size: 0x04
	int32_t AIHostFunc4; // Offset: 0xac // Size: 0x04
	int32_t AIHostFunc5; // Offset: 0xb0 // Size: 0x04
	bool bUseSecIcon; // Offset: 0xb4 // Size: 0x01
	char pad_0xB5[0x3]; // Offset: 0xb5 // Size: 0x03
};

// Object Name: ScriptStruct AClient.RoundResultState
// Size: 0x0c // Inherited bytes: 0x00
struct FRoundResultState {
	// Fields
	enum class ERoundResultReason Reason; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t CampID; // Offset: 0x04 // Size: 0x04
	bool bIsRoundEnd; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct AClient.GamepadAxisScaleDetail
// Size: 0x1c // Inherited bytes: 0x00
struct FGamepadAxisScaleDetail {
	// Fields
	enum class EGamepadKeyType GamepadKeyType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FGamepadAxisScale GamepadAxisScale; // Offset: 0x04 // Size: 0x18
};

// Object Name: ScriptStruct AClient.GamepadAxisScale
// Size: 0x18 // Inherited bytes: 0x00
struct FGamepadAxisScale {
	// Fields
	struct FName MinValueConfigName; // Offset: 0x00 // Size: 0x08
	struct FName MaxValueConfigName; // Offset: 0x08 // Size: 0x08
	float MinValue; // Offset: 0x10 // Size: 0x04
	float MaxValue; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GamepadUserDefineActionDetailInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FGamepadUserDefineActionDetailInfo {
	// Fields
	int32_t FakeActionIndex; // Offset: 0x00 // Size: 0x04
	enum class EGamepadUserKeyType UserKeyType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.GamepadIconInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FGamepadIconInfo {
	// Fields
	enum class EGamepadUserKeyType UserKeyType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString PS4IconPath; // Offset: 0x08 // Size: 0x10
	struct FString XBoxIconPath; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AniSequence
// Size: 0x18 // Inherited bytes: 0x00
struct FAniSequence {
	// Fields
	struct TArray<struct FAniItem> Anis; // Offset: 0x00 // Size: 0x10
	float Duration; // Offset: 0x10 // Size: 0x04
	int32_t DataIndex; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AniItem
// Size: 0x30 // Inherited bytes: 0x00
struct FAniItem {
	// Fields
	struct TSoftClassPtr<UObject> WidgetClass; // Offset: 0x00 // Size: 0x28
	enum class EAniType AniType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct AClient.ApexProjectilePosture
// Size: 0xd4 // Inherited bytes: 0x00
struct FApexProjectilePosture {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	struct FVector LaunchVelocity; // Offset: 0x18 // Size: 0x0c
	struct FVector ProjectileMeshLocation; // Offset: 0x24 // Size: 0x0c
	struct FVector ProjectileMeshLaunchVelocity; // Offset: 0x30 // Size: 0x0c
	struct FHitResult TargetHitResult; // Offset: 0x3c // Size: 0x88
	struct FVector TraceEnd; // Offset: 0xc4 // Size: 0x0c
	bool bValid; // Offset: 0xd0 // Size: 0x01
	char pad_0xD1[0x3]; // Offset: 0xd1 // Size: 0x03
};

// Object Name: ScriptStruct AClient.ArcBoltDeployInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FArcBoltDeployInfo {
	// Fields
	struct TWeakObjectPtr<struct AActor> AttachActor; // Offset: 0x00 // Size: 0x08
	struct FVector_NetQuantizeNormal DeployNormal; // Offset: 0x08 // Size: 0x0c
	struct FVector_NetQuantize DeployLocation; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.TrackingVisionInfo
// Size: 0x60 // Inherited bytes: 0x00
struct FTrackingVisionInfo {
	// Fields
	int32_t InfoId; // Offset: 0x00 // Size: 0x04
	enum class ETrackingVisionPOITypes POIType; // Offset: 0x04 // Size: 0x01
	bool bBaseRelativePosition; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct TWeakObjectPtr<struct UPrimitiveComponent> MovementBase; // Offset: 0x08 // Size: 0x08
	struct FVector Location; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FQuat Rotation; // Offset: 0x20 // Size: 0x10
	float StartTime; // Offset: 0x30 // Size: 0x04
	enum class ETrackingPOIPriority Priority; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	int32_t CampID; // Offset: 0x38 // Size: 0x04
	int32_t TeamID; // Offset: 0x3c // Size: 0x04
	int32_t DamageId; // Offset: 0x40 // Size: 0x04
	struct TWeakObjectPtr<struct AActor> OwnerActor; // Offset: 0x44 // Size: 0x08
	char pad_0x4C[0x14]; // Offset: 0x4c // Size: 0x14
};

// Object Name: ScriptStruct AClient.ViewAssistParamInfo
// Size: 0x03 // Inherited bytes: 0x00
struct FViewAssistParamInfo {
	// Fields
	bool OnlyEnemy; // Offset: 0x00 // Size: 0x01
	bool ContainDying; // Offset: 0x01 // Size: 0x01
	bool OnlyVisible; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct AClient.SkillActorDelayShowTime
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillActorDelayShowTime {
	// Fields
	float FPPDelayShowTime; // Offset: 0x00 // Size: 0x04
	float TPPDelayShowTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillActorAttachData
// Size: 0x48 // Inherited bytes: 0x00
struct FSkillActorAttachData {
	// Fields
	bool bIsAttached; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct AActor* AttachedActor; // Offset: 0x08 // Size: 0x08
	struct USceneComponent* AttachedComponent; // Offset: 0x10 // Size: 0x08
	bool bAttachScreenNode; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	struct FName AttachSocketName; // Offset: 0x1c // Size: 0x08
	enum class EAttachmentRule AttachmentRule; // Offset: 0x24 // Size: 0x01
	enum class EAttachmentRule ScaleAttachmentRule; // Offset: 0x25 // Size: 0x01
	char pad_0x26[0x2]; // Offset: 0x26 // Size: 0x02
	struct FVector OffsetLocation; // Offset: 0x28 // Size: 0x0c
	struct FRotator OffsetRotation; // Offset: 0x34 // Size: 0x0c
	bool bIgnoreParentRotation; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct AClient.MonkeyKingCudgelStatus
// Size: 0x01 // Inherited bytes: 0x00
struct FMonkeyKingCudgelStatus {
	// Fields
	bool IsInteractiveWithOwner; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.MovementSyncData
// Size: 0x18 // Inherited bytes: 0x00
struct FMovementSyncData {
	// Fields
	struct UPrimitiveComponent* Base; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApexDamageInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FApexDamageInfo {
	// Fields
	char pad_0x0[0x48]; // Offset: 0x00 // Size: 0x48
};

// Object Name: ScriptStruct AClient.TrainingExtractionZoneConfigDataStruct
// Size: 0x14 // Inherited bytes: 0x00
struct FTrainingExtractionZoneConfigDataStruct {
	// Fields
	bool bOverLapCharacter; // Offset: 0x00 // Size: 0x01
	bool bOverLapProjectile; // Offset: 0x01 // Size: 0x01
	bool bIsDetectUnique; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	int32_t DetectID; // Offset: 0x04 // Size: 0x04
	bool bIsDetectOnce; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int32_t DetectCount; // Offset: 0x0c // Size: 0x04
	bool bIsNeedReset; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
};

// Object Name: ScriptStruct AClient.HighLightWidgetBackgroundData
// Size: 0x0c // Inherited bytes: 0x00
struct FHighLightWidgetBackgroundData {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.HighLightCommonSettings
// Size: 0x80 // Inherited bytes: 0x00
struct FHighLightCommonSettings {
	// Fields
	struct UHighLightWidgetTooltipBase* TooltipType; // Offset: 0x00 // Size: 0x08
	struct FText ToolTipText; // Offset: 0x08 // Size: 0x18
	struct FVector2D Alignment; // Offset: 0x20 // Size: 0x08
	struct FVector2D Anchors; // Offset: 0x28 // Size: 0x08
	struct FVector2D Offset; // Offset: 0x30 // Size: 0x08
	struct TSoftClassPtr<UObject> BackgroundType; // Offset: 0x38 // Size: 0x28
	struct FName OutlineWidgetName; // Offset: 0x60 // Size: 0x08
	struct FName AdditionalOutlineWidgetName; // Offset: 0x68 // Size: 0x08
	struct FString StepName; // Offset: 0x70 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MiniMapSkillItemInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FMiniMapSkillItemInfo {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	char Type; // Offset: 0x04 // Size: 0x01
	char State; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	float Yaw; // Offset: 0x14 // Size: 0x04
	float Radius; // Offset: 0x18 // Size: 0x04
	char ScaleType; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	float Length; // Offset: 0x20 // Size: 0x04
	float Timespan; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MiniMapStaticItemInfo
// Size: 0x2c // Inherited bytes: 0x00
struct FMiniMapStaticItemInfo {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	char Type; // Offset: 0x04 // Size: 0x01
	char State; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	float Yaw; // Offset: 0x14 // Size: 0x04
	float Radius; // Offset: 0x18 // Size: 0x04
	char ScaleType; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	float Length; // Offset: 0x20 // Size: 0x04
	int32_t Level; // Offset: 0x24 // Size: 0x04
	int32_t TrainCoachIndex; // Offset: 0x28 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RepMiniMapPlayerInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FRepMiniMapPlayerInfo {
	// Fields
	int32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	enum class EMiniMapPlayerType Type; // Offset: 0x04 // Size: 0x01
	enum class EMiniMapPlayerState State; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	float Yaw; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RatingScoreInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FRatingScoreInfo {
	// Fields
	struct TArray<struct FRankScoreData> RankScoreInfo; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RankScoreData
// Size: 0x08 // Inherited bytes: 0x00
struct FRankScoreData {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t RankScore; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.InGameTipsUIParam
// Size: 0x48 // Inherited bytes: 0x00
struct FInGameTipsUIParam {
	// Fields
	int32_t TipsUIType; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FText TipsText; // Offset: 0x08 // Size: 0x18
	struct FText AppendTipsText; // Offset: 0x20 // Size: 0x18
	int32_t TipsSwitcherIndex; // Offset: 0x38 // Size: 0x04
	float TipsTime; // Offset: 0x3c // Size: 0x04
	int32_t PlayerKey; // Offset: 0x40 // Size: 0x04
	int32_t Level; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ChangeWeaponEventData
// Size: 0x14 // Inherited bytes: 0x00
struct FChangeWeaponEventData {
	// Fields
	enum class EWeaponSaveSlot Slot; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t TypeDefineID; // Offset: 0x04 // Size: 0x04
	bool bAutonomous; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int32_t WeaponBulletID; // Offset: 0x0c // Size: 0x04
	int32_t TypeSpecificID; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WholeWeaponData
// Size: 0x50 // Inherited bytes: 0x00
struct FWholeWeaponData {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t WeaponID; // Offset: 0x04 // Size: 0x04
	int32_t Color; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<int32_t> AttachList; // Offset: 0x10 // Size: 0x10
	struct TArray<int32_t> AttachCanEquip; // Offset: 0x20 // Size: 0x10
	struct TArray<int32_t> AttachCanShow; // Offset: 0x30 // Size: 0x10
	int32_t SpecialBullet; // Offset: 0x40 // Size: 0x04
	struct FName BulletIcon; // Offset: 0x44 // Size: 0x08
	int32_t QualityRule; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponAttachmentUIData
// Size: 0x1c // Inherited bytes: 0x00
struct FWeaponAttachmentUIData {
	// Fields
	enum class EAttachSocketType Slot; // Offset: 0x00 // Size: 0x01
	bool bEquipped; // Offset: 0x01 // Size: 0x01
	bool bShow; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	int32_t ItemID; // Offset: 0x04 // Size: 0x04
	int32_t Quality; // Offset: 0x08 // Size: 0x04
	struct FName IconPath; // Offset: 0x0c // Size: 0x08
	struct FName LastIconPath; // Offset: 0x14 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameEventHandle
// Size: 0x0c // Inherited bytes: 0x00
struct FApgameEventHandle {
	// Fields
	struct FGameplayTag EventTag; // Offset: 0x00 // Size: 0x08
	uint16_t DelegateId; // Offset: 0x08 // Size: 0x02
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
};

// Object Name: ScriptStruct AClient.ApgameEventListenParameters
// Size: 0x0c // Inherited bytes: 0x00
struct FApgameEventListenParameters {
	// Fields
	bool bUnique; // Offset: 0x00 // Size: 0x01
	bool bFirst; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	struct FName PriorityName; // Offset: 0x04 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SecurityLogHitTargetInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FSecurityLogHitTargetInfo {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.WeaponReportData
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponReportData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.BulletHitInfoUploadData
// Size: 0xc0 // Inherited bytes: 0x00
struct FBulletHitInfoUploadData {
	// Fields
	char pad_0x0[0x2c]; // Offset: 0x00 // Size: 0x2c
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x2c // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x34 // Size: 0x08
	char pad_0x3C[0x14]; // Offset: 0x3c // Size: 0x14
	struct FMovementSyncData ShootStart; // Offset: 0x50 // Size: 0x18
	struct FMovementSyncData ShootEnd; // Offset: 0x68 // Size: 0x18
	char pad_0x80[0x40]; // Offset: 0x80 // Size: 0x40
};

// Object Name: ScriptStruct AClient.BulletHitInfoTLogData
// Size: 0x24 // Inherited bytes: 0x00
struct FBulletHitInfoTLogData {
	// Fields
	uint32_t ShootID; // Offset: 0x00 // Size: 0x04
	uint32_t DocuType; // Offset: 0x04 // Size: 0x04
	char PelletID; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FVector_NetQuantize ShootWeaponPos; // Offset: 0x0c // Size: 0x0c
	struct FVector2D ShootMomentRecoil; // Offset: 0x18 // Size: 0x08
	char ShootMomentSightType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
};

// Object Name: ScriptStruct AClient.AccessoriesAnimInstanceProxy
// Size: 0x7c0 // Inherited bytes: 0x7b0
struct FAccessoriesAnimInstanceProxy : FAnimInstanceProxy {
	// Fields
	struct ABasePropsWeapon* C_OwnerWeapon; // Offset: 0x7a8 // Size: 0x08
	bool C_FPP; // Offset: 0x7b0 // Size: 0x01
	char pad_0x7B9[0x7]; // Offset: 0x7b9 // Size: 0x07
};

// Object Name: ScriptStruct AClient.ActionFilterInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FActionFilterInfo {
	// Fields
	struct TSet<enum class EPawnState> DisablePawnStates; // Offset: 0x00 // Size: 0x50
	uint64_t FinalPawnActionFilterResult; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SyncActionFilterInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FSyncActionFilterInfo {
	// Fields
	struct TArray<enum class EPawnState> DisablePawnStateList; // Offset: 0x00 // Size: 0x10
	uint64_t FinalPawnActionFilterResult; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PawnActionFilterTableItem
// Size: 0xb0 // Inherited bytes: 0x00
struct FPawnActionFilterTableItem {
	// Fields
	struct FString Des; // Offset: 0x00 // Size: 0x10
	struct TSet<enum class EPawnState> DisablePawnStates; // Offset: 0x10 // Size: 0x50
	struct TSet<enum class EPawnActionFilterType> PawnActionFilters; // Offset: 0x60 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ActiveModifyHandle
// Size: 0x08 // Inherited bytes: 0x00
struct FActiveModifyHandle {
	// Fields
	int32_t Handle; // Offset: 0x00 // Size: 0x04
	bool bPassedFiltersAndWasExecuted; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.WeaponClimbingAdvanceRecorder
// Size: 0x0c // Inherited bytes: 0x00
struct FWeaponClimbingAdvanceRecorder {
	// Fields
	float SequenceStartTime; // Offset: 0x00 // Size: 0x04
	int32_t HitNum; // Offset: 0x04 // Size: 0x04
	int32_t ShootNum; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.DoorAdvanceRecorder
// Size: 0x18 // Inherited bytes: 0x00
struct FDoorAdvanceRecorder {
	// Fields
	float SequenceStartTime; // Offset: 0x00 // Size: 0x04
	int32_t ZiplineUsedNum; // Offset: 0x04 // Size: 0x04
	int32_t PlayerKilledByAINum; // Offset: 0x08 // Size: 0x04
	int32_t DoorBrokenByProjectileNum; // Offset: 0x0c // Size: 0x04
	int32_t DoorBrokenByMeleeNum; // Offset: 0x10 // Size: 0x04
	int32_t PlayerSuicideNum; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.TracePointData
// Size: 0x10 // Inherited bytes: 0x00
struct FTracePointData {
	// Fields
	struct TArray<struct FTraceData> Datas; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.TraceData
// Size: 0x20 // Inherited bytes: 0x00
struct FTraceData {
	// Fields
	uint32_t ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FVector> TracePoints; // Offset: 0x08 // Size: 0x10
	bool Result; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct AClient.ItemTypeArray
// Size: 0x10 // Inherited bytes: 0x00
struct FItemTypeArray {
	// Fields
	struct TArray<int32_t> Items; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ShadowMirageTutorialConfig
// Size: 0x1c // Inherited bytes: 0x00
struct FShadowMirageTutorialConfig {
	// Fields
	enum class EShadowMirageTutorialType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float TriggerDistance; // Offset: 0x04 // Size: 0x04
	float TriggerAngleInRadian; // Offset: 0x08 // Size: 0x04
	int32_t MaxCount; // Offset: 0x0c // Size: 0x04
	float CD; // Offset: 0x10 // Size: 0x04
	int32_t LoopTime; // Offset: 0x14 // Size: 0x04
	float TriggerInterval; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AIFakebroadConfig
// Size: 0x128 // Inherited bytes: 0x00
struct FAIFakebroadConfig {
	// Fields
	float StartTime; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<uint32_t, uint32_t> WeaponKillConfig; // Offset: 0x08 // Size: 0x50
	struct TMap<enum class EDamageType, uint32_t> TargetSpecialKillConfig; // Offset: 0x58 // Size: 0x50
	float SpecialKillRatio; // Offset: 0xa8 // Size: 0x04
	float KillRatio; // Offset: 0xac // Size: 0x04
	struct TMap<enum class EDamageType, uint32_t> SpecialKillConfig; // Offset: 0xb0 // Size: 0x50
	struct FVector2D DyingToDieInterval; // Offset: 0x100 // Size: 0x08
	struct FVector2D KillInterval; // Offset: 0x108 // Size: 0x08
	struct FVector2D PoisonKillInterval; // Offset: 0x110 // Size: 0x08
	struct TArray<struct FVector> FakebroadTargetRatio; // Offset: 0x118 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GMAIConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FGMAIConfig {
	// Fields
	int32_t AITeam; // Offset: 0x00 // Size: 0x04
	int32_t AICamp; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BaseSpawnAIRules
// Size: 0x40 // Inherited bytes: 0x00
struct FBaseSpawnAIRules {
	// Fields
	bool IsWarm; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t BucketID; // Offset: 0x04 // Size: 0x04
	int32_t AILevel; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x14]; // Offset: 0x0c // Size: 0x14
	int32_t DynamicAILevelMax; // Offset: 0x20 // Size: 0x04
	int32_t DynamicAILevelMin; // Offset: 0x24 // Size: 0x04
	float HKDEAR; // Offset: 0x28 // Size: 0x04
	float LKDEAR; // Offset: 0x2c // Size: 0x04
	int32_t AILevelAMP; // Offset: 0x30 // Size: 0x04
	int32_t KDERContainsPlayer; // Offset: 0x34 // Size: 0x04
	int32_t KDERChangeOnKilled; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BRSpawnAIParams
// Size: 0xa0 // Inherited bytes: 0x00
struct FBRSpawnAIParams {
	// Fields
	int32_t MaxAIInGame; // Offset: 0x00 // Size: 0x04
	int32_t JumpAINum; // Offset: 0x04 // Size: 0x04
	int32_t DeliverTargetNum; // Offset: 0x08 // Size: 0x04
	int32_t DeliverAINum; // Offset: 0x0c // Size: 0x04
	struct TMap<uint32_t, uint32_t> DeliverTimes; // Offset: 0x10 // Size: 0x50
	int32_t SpawnMode; // Offset: 0x60 // Size: 0x04
	int32_t FirstFakeBroadNum; // Offset: 0x64 // Size: 0x04
	int32_t FirstFakeBroadCD; // Offset: 0x68 // Size: 0x04
	int32_t FirstFakeBroadTime; // Offset: 0x6c // Size: 0x04
	int32_t SecondFakeBroadEndTimeMin; // Offset: 0x70 // Size: 0x04
	int32_t SecondFakeBroadEndTimeMax; // Offset: 0x74 // Size: 0x04
	int32_t TimeToCollect; // Offset: 0x78 // Size: 0x04
	int32_t DeliverSec; // Offset: 0x7c // Size: 0x04
	int32_t DeliverCD; // Offset: 0x80 // Size: 0x04
	int32_t SingleDeliverLimit; // Offset: 0x84 // Size: 0x04
	int32_t DeliverLimitAtSameTime; // Offset: 0x88 // Size: 0x04
	int32_t FakeBroadTime; // Offset: 0x8c // Size: 0x04
	int32_t PoisonKillTime; // Offset: 0x90 // Size: 0x04
	int32_t PoisonKillCD; // Offset: 0x94 // Size: 0x04
	int32_t AILevelValve; // Offset: 0x98 // Size: 0x04
	int32_t IsMLAIDropOpen; // Offset: 0x9c // Size: 0x04
};

// Object Name: ScriptStruct AClient.CcsDamageInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FCcsDamageInfo {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DynamicDmgCurve
// Size: 0x558 // Inherited bytes: 0x00
struct FDynamicDmgCurve {
	// Fields
	bool EnableAILevelAI2AI; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FRuntimeFloatCurve AILevelDamage; // Offset: 0x08 // Size: 0x88
	struct FRuntimeFloatCurve AILevelHit; // Offset: 0x90 // Size: 0x88
	struct FRuntimeFloatCurve AI2PlayerDamage; // Offset: 0x118 // Size: 0x88
	struct FRuntimeFloatCurve AI2PlayerHit; // Offset: 0x1a0 // Size: 0x88
	struct FRuntimeFloatCurve AI2AIDamage; // Offset: 0x228 // Size: 0x88
	struct FRuntimeFloatCurve AI2AIHit; // Offset: 0x2b0 // Size: 0x88
	struct FRuntimeFloatCurve AIVelocityFixHit; // Offset: 0x338 // Size: 0x88
	struct FRuntimeFloatCurve AIDistanceFixHit; // Offset: 0x3c0 // Size: 0x88
	struct FRuntimeFloatCurve AI2TeammateAIHit; // Offset: 0x448 // Size: 0x88
	struct FRuntimeFloatCurve AI2TeammateAIDamage; // Offset: 0x4d0 // Size: 0x88
};

// Object Name: ScriptStruct AClient.EnemyInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FEnemyInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.BTTaskStartFireMemory
// Size: 0x10 // Inherited bytes: 0x00
struct FBTTaskStartFireMemory {
	// Fields
	float SustainTime; // Offset: 0x00 // Size: 0x04
	float TakeRestTime; // Offset: 0x04 // Size: 0x04
	float StartFireTimer; // Offset: 0x08 // Size: 0x04
	bool bFire; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct AClient.WeaponRangeType
// Size: 0x0c // Inherited bytes: 0x00
struct FWeaponRangeType {
	// Fields
	enum class EWeaponItemType WeaponType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float RangeRadius; // Offset: 0x04 // Size: 0x04
	float RangeAngle; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.DynamicHitRate
// Size: 0x10 // Inherited bytes: 0x00
struct FDynamicHitRate {
	// Fields
	struct FVector2D HealthPercent; // Offset: 0x00 // Size: 0x08
	float HitRate; // Offset: 0x08 // Size: 0x04
	float DamageScale; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.HitRateSettingLevel
// Size: 0x10 // Inherited bytes: 0x00
struct FHitRateSettingLevel {
	// Fields
	struct FVector2D ELORange; // Offset: 0x00 // Size: 0x08
	float HitRate; // Offset: 0x08 // Size: 0x04
	float DamageScale; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.HostUIData
// Size: 0x58 // Inherited bytes: 0x00
struct FHostUIData {
	// Fields
	struct UButton* Btn_Func; // Offset: 0x00 // Size: 0x08
	struct UWidgetSwitcher* WS_Func; // Offset: 0x08 // Size: 0x08
	struct UTextBlock* Text_Func_2; // Offset: 0x10 // Size: 0x08
	struct UTextBlock* Text_Func_3; // Offset: 0x18 // Size: 0x08
	struct FString ImagePath; // Offset: 0x20 // Size: 0x10
	struct FString ImageActivePath; // Offset: 0x30 // Size: 0x10
	struct UImage* Image_Func_2; // Offset: 0x40 // Size: 0x08
	struct UImage* Image_Func_3; // Offset: 0x48 // Size: 0x08
	bool bOriginalShow; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
};

// Object Name: ScriptStruct AClient.AirdropWorkbenchHitGroundEffect
// Size: 0x04 // Inherited bytes: 0x00
struct FAirdropWorkbenchHitGroundEffect {
	// Fields
	int32_t Round; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponLootReplacement
// Size: 0xa8 // Inherited bytes: 0x00
struct FWeaponLootReplacement {
	// Fields
	float CanReplacedChance; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TSet<int32_t> BeReplacedWeaponList; // Offset: 0x08 // Size: 0x50
	struct TSet<int32_t> TargetWeaponList; // Offset: 0x58 // Size: 0x50
};

// Object Name: ScriptStruct AClient.EnemyLockLootInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FEnemyLockLootInfo {
	// Fields
	float Step; // Offset: 0x00 // Size: 0x04
	float VirtualDistance; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WayPointLink
// Size: 0x08 // Inherited bytes: 0x00
struct FWayPointLink {
	// Fields
	int32_t NextPointID; // Offset: 0x00 // Size: 0x04
	int32_t Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AkSpawnAmbientData
// Size: 0x30 // Inherited bytes: 0x00
struct FAkSpawnAmbientData {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct AAkAmbientSound* AkAmbientSoundClass; // Offset: 0x10 // Size: 0x08
	struct FVector RelativeLoc; // Offset: 0x18 // Size: 0x0c
	struct FRotator RelativeRot; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.TurnMontageSet
// Size: 0x140 // Inherited bytes: 0x00
struct FTurnMontageSet {
	// Fields
	struct TSoftObjectPtr<UAnimMontage> TurnLeft45_Montage; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> TurnLeft90_Montage; // Offset: 0x28 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> TurnLeft135_Montage; // Offset: 0x50 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> TurnLeft180_Montage; // Offset: 0x78 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> TurnRight45_Montage; // Offset: 0xa0 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> TurnRight90_Montage; // Offset: 0xc8 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> TurnRight135_Montage; // Offset: 0xf0 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> TurnRight180_Montage; // Offset: 0x118 // Size: 0x28
};

// Object Name: ScriptStruct AClient.ApexNpcSettings
// Size: 0x1a8 // Inherited bytes: 0x00
struct FApexNpcSettings {
	// Fields
	struct TMap<struct FName, float> AttrSettings; // Offset: 0x00 // Size: 0x50
	struct FPlayerLoadoutConfig LoadoutConfig; // Offset: 0x50 // Size: 0xd8
	struct TMap<int32_t, int32_t> TombBoxItems; // Offset: 0x128 // Size: 0x50
	struct FText Name; // Offset: 0x178 // Size: 0x18
	struct FLinearColor Color; // Offset: 0x190 // Size: 0x10
	int32_t TeamID; // Offset: 0x1a0 // Size: 0x04
	char pad_0x1A4[0x4]; // Offset: 0x1a4 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PlayerLoadoutConfig
// Size: 0xd8 // Inherited bytes: 0x00
struct FPlayerLoadoutConfig {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
	int32_t LoadoutID; // Offset: 0x0c // Size: 0x04
	struct FPlayerLoadoutWeapon MainWeapon; // Offset: 0x10 // Size: 0x38
	struct FPlayerLoadoutWeapon SubWeapon; // Offset: 0x48 // Size: 0x38
	struct TArray<struct FPlayerLoadoutItem> Drug; // Offset: 0x80 // Size: 0x10
	struct TArray<struct FPlayerLoadoutItem> Shield; // Offset: 0x90 // Size: 0x10
	struct FPlayerLoadoutItem FallingShield; // Offset: 0xa0 // Size: 0x08
	struct FPlayerLoadoutItem Helmet; // Offset: 0xa8 // Size: 0x08
	struct FPlayerLoadoutItem Armor; // Offset: 0xb0 // Size: 0x08
	struct FPlayerLoadoutItem Backpack; // Offset: 0xb8 // Size: 0x08
	struct TArray<struct FPlayerLoadoutItem> Grenade; // Offset: 0xc0 // Size: 0x10
	bool bForceLoadout; // Offset: 0xd0 // Size: 0x01
	char pad_0xD1[0x7]; // Offset: 0xd1 // Size: 0x07
};

// Object Name: ScriptStruct AClient.PlayerLoadoutItem
// Size: 0x08 // Inherited bytes: 0x00
struct FPlayerLoadoutItem {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	int32_t ItemCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PlayerLoadoutWeapon
// Size: 0x38 // Inherited bytes: 0x00
struct FPlayerLoadoutWeapon {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t Set; // Offset: 0x04 // Size: 0x04
	int32_t Level; // Offset: 0x08 // Size: 0x04
	bool SpecialWeapon; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	int32_t WeaponID; // Offset: 0x10 // Size: 0x04
	int32_t BulletID; // Offset: 0x14 // Size: 0x04
	int32_t BulletNum; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FPlayerLoadoutItem> WeaponFittings; // Offset: 0x20 // Size: 0x10
	bool bIsWholeWeapon; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
};

// Object Name: ScriptStruct AClient.AIBehaviorRules
// Size: 0x18 // Inherited bytes: 0x00
struct FAIBehaviorRules {
	// Fields
	struct UBehaviorTree* Default; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FAIBehaviorLevel> LevelRules; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AIBehaviorLevel
// Size: 0x20 // Inherited bytes: 0x00
struct FAIBehaviorLevel {
	// Fields
	struct FString LevelRange; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FAIBehavior> List; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AIBehavior
// Size: 0x10 // Inherited bytes: 0x00
struct FAIBehavior {
	// Fields
	float Weight; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UBehaviorTree* Tree; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.HitPositionConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FHitPositionConfig {
	// Fields
	enum class EHitDamagePositionAI Position; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AIHearingEventConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FAIHearingEventConfig {
	// Fields
	enum class EAIHearingType HearingType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Range; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AnimParamList
// Size: 0x74 // Inherited bytes: 0x00
struct FAnimParamList {
	// Fields
	float ClimbOverStartRate; // Offset: 0x00 // Size: 0x04
	bool IsDeath; // Offset: 0x04 // Size: 0x01
	bool ScopeOn; // Offset: 0x05 // Size: 0x01
	bool ScopeOff; // Offset: 0x06 // Size: 0x01
	bool IsLanded; // Offset: 0x07 // Size: 0x01
	bool IsLandingLight; // Offset: 0x08 // Size: 0x01
	bool IsLandingHard; // Offset: 0x09 // Size: 0x01
	bool IsSlidingToAir; // Offset: 0x0a // Size: 0x01
	bool IsAirToSliding; // Offset: 0x0b // Size: 0x01
	float ParachuteTurnInput; // Offset: 0x0c // Size: 0x04
	float ParachuteForwardInput; // Offset: 0x10 // Size: 0x04
	struct FVector LastLocation; // Offset: 0x14 // Size: 0x0c
	bool IsHurting; // Offset: 0x20 // Size: 0x01
	bool IsNearDeathStatus; // Offset: 0x21 // Size: 0x01
	bool ImmediatelyKnockdownPose; // Offset: 0x22 // Size: 0x01
	char SkillAnimHandType; // Offset: 0x23 // Size: 0x01
	bool SkillAnimHandPingPong; // Offset: 0x24 // Size: 0x01
	enum class ECharAnimDeadType DeadAnimType; // Offset: 0x25 // Size: 0x01
	enum class ECharAnimRescueType AnimRescueType; // Offset: 0x26 // Size: 0x01
	char pad_0x27[0x1]; // Offset: 0x27 // Size: 0x01
	float RescueAnimPlayRate; // Offset: 0x28 // Size: 0x04
	struct FBackpackSwitchGunAnimData BackpackSwitchGunAnimData; // Offset: 0x2c // Size: 0x0c
	enum class ECharAnimClimbOverType ClimbOverAnimType; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	float ClimbAnimVelocity; // Offset: 0x3c // Size: 0x04
	struct FVector HangingPosition; // Offset: 0x40 // Size: 0x0c
	bool bIsBeFinisherStatus; // Offset: 0x4c // Size: 0x01
	bool bInArmedAnimation; // Offset: 0x4d // Size: 0x01
	bool bSlideAlongSurface; // Offset: 0x4e // Size: 0x01
	bool bOnSwitchThrowMode; // Offset: 0x4f // Size: 0x01
	bool bDefuseBombSuccess; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x3]; // Offset: 0x51 // Size: 0x03
	struct FVector GrapplingAimDirection; // Offset: 0x54 // Size: 0x0c
	float Significance; // Offset: 0x60 // Size: 0x04
	enum class ECharacterJumpType JumpType; // Offset: 0x64 // Size: 0x01
	bool IsTurning; // Offset: 0x65 // Size: 0x01
	bool StateEnterFire; // Offset: 0x66 // Size: 0x01
	char pad_0x67[0xd]; // Offset: 0x67 // Size: 0x0d
};

// Object Name: ScriptStruct AClient.BackpackSwitchGunAnimData
// Size: 0x0c // Inherited bytes: 0x00
struct FBackpackSwitchGunAnimData {
	// Fields
	float Duration; // Offset: 0x00 // Size: 0x04
	float Alpha; // Offset: 0x04 // Size: 0x04
	bool bPingPong; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct AClient.WeaponAnimationIntKey
// Size: 0x03 // Inherited bytes: 0x00
struct FWeaponAnimationIntKey {
	// Fields
	enum class ECharaAnimListType ListType; // Offset: 0x00 // Size: 0x01
	enum class EWeaponAnimationType AnimType; // Offset: 0x01 // Size: 0x01
	enum class ECharacterPoseType PoseType; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct AClient.CharacterAnimationIntKey
// Size: 0x03 // Inherited bytes: 0x00
struct FCharacterAnimationIntKey {
	// Fields
	enum class ECharaAnimListType ListType; // Offset: 0x00 // Size: 0x01
	enum class ECharacterAnimType AnimType; // Offset: 0x01 // Size: 0x01
	enum class ECharacterPoseType PoseType; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct AClient.AnimBPLodConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FAnimBPLodConfig {
	// Fields
	enum class ELODDeviceGrade Grade; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FAnimSignificanceInfo> AnimSignificanceDataArray; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AnimSignificanceInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FAnimSignificanceInfo {
	// Fields
	enum class EAnimSignificanceType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Significance; // Offset: 0x04 // Size: 0x04
	bool bEnableFootIK; // Offset: 0x08 // Size: 0x01
	bool bEnableNearWall; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
};

// Object Name: ScriptStruct AClient.FinalKey
// Size: 0x04 // Inherited bytes: 0x00
struct FFinalKey {
	// Fields
	int32_t Key; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AClient.APEXAnimInstanceProxy
// Size: 0x860 // Inherited bytes: 0x7b0
struct FAPEXAnimInstanceProxy : FAnimInstanceProxy {
	// Fields
	struct AApexCharacterBase* OwnerPawn; // Offset: 0x7b0 // Size: 0x08
	struct UAPEXAnimInstance* ParentAnimInst; // Offset: 0x7b8 // Size: 0x08
	bool LastMoveDirIsBack; // Offset: 0x7c0 // Size: 0x01
	bool LastMoveDirIsLeft; // Offset: 0x7c1 // Size: 0x01
	char pad_0x7C2[0x6]; // Offset: 0x7c2 // Size: 0x06
	struct FOrientationWarpingAngleConfig OrientationWarpingAngle; // Offset: 0x7c8 // Size: 0x10
	int32_t CurrentOrientationWarpingDirectionIndex; // Offset: 0x7d8 // Size: 0x04
	int32_t PreviousOrientationWarpingDirectionIndex; // Offset: 0x7dc // Size: 0x04
	float CurrentPlayRate; // Offset: 0x7e0 // Size: 0x04
	float CurrentDirectionValue; // Offset: 0x7e4 // Size: 0x04
	float CurrentGearValue; // Offset: 0x7e8 // Size: 0x04
	int32_t CurrentGearIndex; // Offset: 0x7ec // Size: 0x04
	int32_t PreviousGearIndex; // Offset: 0x7f0 // Size: 0x04
	bool CacheBlendToggleStandCrouch; // Offset: 0x7f4 // Size: 0x01
	char pad_0x7F5[0x33]; // Offset: 0x7f5 // Size: 0x33
	struct FName IKHandRName; // Offset: 0x828 // Size: 0x08
	struct FName IKHandLName; // Offset: 0x830 // Size: 0x08
	struct FName HeadSocketName; // Offset: 0x838 // Size: 0x08
	float RandomIdleTime; // Offset: 0x840 // Size: 0x04
	float FireDelayTime; // Offset: 0x844 // Size: 0x04
	char pad_0x848[0x4]; // Offset: 0x848 // Size: 0x04
	float ForceInFallingRealtime; // Offset: 0x84c // Size: 0x04
	bool DelayClimbOneFrame; // Offset: 0x850 // Size: 0x01
	bool UpdateSkillStateLogic; // Offset: 0x851 // Size: 0x01
	char pad_0x852[0xe]; // Offset: 0x852 // Size: 0x0e
};

// Object Name: ScriptStruct AClient.FootprintsSettings
// Size: 0x10 // Inherited bytes: 0x00
struct FFootprintsSettings {
	// Fields
	struct FName SocketName; // Offset: 0x00 // Size: 0x08
	struct UParticleSystem* PSTemplate; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.CharacterSoundPair
// Size: 0x50 // Inherited bytes: 0x00
struct FCharacterSoundPair {
	// Fields
	struct TMap<enum class ELegendType, struct UAkAudioEvent*> LegendSoundSetting; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.WeaponSoundPair
// Size: 0x10 // Inherited bytes: 0x00
struct FWeaponSoundPair {
	// Fields
	struct UAkAudioEvent* AudioEvent; // Offset: 0x00 // Size: 0x08
	struct UApexSoundCallbackConfig* CallBackConfig; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.CharacterVOAudioData
// Size: 0x50 // Inherited bytes: 0x00
struct FCharacterVOAudioData {
	// Fields
	struct TMap<enum class EAnimNotifySoundGroupType, struct FVOAudioData> CharacterVO; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.VOAudioData
// Size: 0x20 // Inherited bytes: 0x00
struct FVOAudioData {
	// Fields
	struct FString AudioEvent; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVOData> VOData; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.VOData
// Size: 0x10 // Inherited bytes: 0x00
struct FVOData {
	// Fields
	struct FString ExternalSrc; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PreviewAudioParam
// Size: 0x04 // Inherited bytes: 0x00
struct FPreviewAudioParam {
	// Fields
	enum class EAnimNotifySoundPlayType SoundPlayType; // Offset: 0x00 // Size: 0x01
	enum class ELegendType LegendType; // Offset: 0x01 // Size: 0x01
	enum class EWeaponSpecificType WeaponType; // Offset: 0x02 // Size: 0x01
	enum class EPawnState PawnState; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AClient.AudioData
// Size: 0x28 // Inherited bytes: 0x00
struct FAudioData {
	// Fields
	struct UAkAudioEvent* AudioEvent; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x20]; // Offset: 0x08 // Size: 0x20
};

// Object Name: ScriptStruct AClient.AssetsPrelaodConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FAssetsPrelaodConfig {
	// Fields
	struct FName AssetPath; // Offset: 0x00 // Size: 0x08
	int32_t QualityLevel; // Offset: 0x08 // Size: 0x04
	int32_t Catagory; // Offset: 0x0c // Size: 0x04
	int32_t LoadFrequency; // Offset: 0x10 // Size: 0x04
	int32_t FirstLoadTime; // Offset: 0x14 // Size: 0x04
	int32_t ManualLevel; // Offset: 0x18 // Size: 0x04
	int32_t AssetSize; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AudioAmbientZoneData
// Size: 0x20 // Inherited bytes: 0x00
struct FAudioAmbientZoneData {
	// Fields
	enum class EAudioAmbientZoneAction Action; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString RtpcName; // Offset: 0x08 // Size: 0x10
	float RtpcValue; // Offset: 0x18 // Size: 0x04
	int32_t InterpolationTime; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ValidityTimeModifyData
// Size: 0x30 // Inherited bytes: 0x00
struct FValidityTimeModifyData {
	// Fields
	enum class EValidityTimeScaleChangeType ValidityTimeScaleChangeType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UCurveFloat* Curve; // Offset: 0x08 // Size: 0x08
	struct FGameplayTag RequireTargetGameplayTag; // Offset: 0x10 // Size: 0x08
	struct FGameplayTag RejectTargetGameplayTag; // Offset: 0x18 // Size: 0x08
	struct FGameplayTag RequireSourceGameplayTag; // Offset: 0x20 // Size: 0x08
	struct FGameplayTag RejectSourceGameplayTag; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BuffInstanceStruct
// Size: 0x01 // Inherited bytes: 0x00
struct FBuffInstanceStruct {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.BuffEventActionItem
// Size: 0x10 // Inherited bytes: 0x00
struct FBuffEventActionItem {
	// Fields
	struct UApexBuffEventType* EventType; // Offset: 0x00 // Size: 0x08
	struct UApexBuffAction* BuffEventAction; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BuffActionItem
// Size: 0x08 // Inherited bytes: 0x00
struct FBuffActionItem {
	// Fields
	struct UApexBuffAction* BuffAction; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.StatusChange
// Size: 0x08 // Inherited bytes: 0x00
struct FStatusChange {
	// Fields
	struct UApexBuffStatusType* StatusName; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BeamTargetPointInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FBeamTargetPointInfo {
	// Fields
	int32_t EmitterIndex; // Offset: 0x00 // Size: 0x04
	int32_t TargetIndex; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CausticPoisonDotTargetData
// Size: 0x0c // Inherited bytes: 0x00
struct FCausticPoisonDotTargetData {
	// Fields
	struct TWeakObjectPtr<struct AActor> TargetActor; // Offset: 0x00 // Size: 0x08
	float InCausticPoisonTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.FormulaProxyAttrModifyItemData
// Size: 0x98 // Inherited bytes: 0x00
struct FFormulaProxyAttrModifyItemData {
	// Fields
	enum class EFormulaType FormulaType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float X; // Offset: 0x04 // Size: 0x04
	float Y; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct UCurveFloat* Curve; // Offset: 0x10 // Size: 0x08
	struct FFormulaProxyAttrModifyItem FormulaProxyAttrModifyItem; // Offset: 0x18 // Size: 0x80
};

// Object Name: ScriptStruct AClient.TowardTargetSkillActorData
// Size: 0x20 // Inherited bytes: 0x00
struct FTowardTargetSkillActorData {
	// Fields
	struct UObject* TargetUClass; // Offset: 0x00 // Size: 0x08
	float TargetDistance; // Offset: 0x08 // Size: 0x04
	float TargetMovingTowardHalfAngle; // Offset: 0x0c // Size: 0x04
	struct TArray<enum class EPawnState> InvalidPawnStateArray; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BuffHeroAudioConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FBuffHeroAudioConfig {
	// Fields
	enum class ELegendType LegendType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAkAudioEvent* AkEvent_1P; // Offset: 0x08 // Size: 0x08
	struct UAkAudioEvent* AkEvent_3P; // Offset: 0x10 // Size: 0x08
	struct UAkAudioEvent* undoPAkEvent; // Offset: 0x18 // Size: 0x08
	struct UAkAudioEvent* undoPAkEvent_3P; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct AClient.UIEffect
// Size: 0x28 // Inherited bytes: 0x00
struct FUIEffect {
	// Fields
	struct FName EffectAnimName; // Offset: 0x00 // Size: 0x08
	float PlaySpeed; // Offset: 0x08 // Size: 0x04
	int32_t PlayPriority; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FUIEffectParams> CustomParams; // Offset: 0x10 // Size: 0x10
	bool bNotPlayEffectForLowGrade; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct AClient.UIEffectParams
// Size: 0x30 // Inherited bytes: 0x00
struct FUIEffectParams {
	// Fields
	struct FName TargetName; // Offset: 0x00 // Size: 0x08
	struct FName ParamsName; // Offset: 0x08 // Size: 0x08
	enum class EPlayUIEffectParamsType ParamsType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float ScalarValue; // Offset: 0x14 // Size: 0x04
	struct FLinearColor VectorValue; // Offset: 0x18 // Size: 0x10
	struct UTexture* TextureValue; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct AClient.CheckInteractiveData
// Size: 0x28 // Inherited bytes: 0x00
struct FCheckInteractiveData {
	// Fields
	struct UObject* BaseClass; // Offset: 0x00 // Size: 0x08
	struct FName InvalidBaseTag; // Offset: 0x08 // Size: 0x08
	struct TArray<enum class EPawnState> InvalidPawnStateArray; // Offset: 0x10 // Size: 0x10
	float Distance2D; // Offset: 0x20 // Size: 0x04
	float ZDistance; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MoveTowardTargetSkillActorData
// Size: 0x20 // Inherited bytes: 0x00
struct FMoveTowardTargetSkillActorData {
	// Fields
	struct UObject* TargetUClass; // Offset: 0x00 // Size: 0x08
	float TargetDistance; // Offset: 0x08 // Size: 0x04
	float TargetMovingTowardHalfAngle; // Offset: 0x0c // Size: 0x04
	struct TArray<enum class EPawnState> InvalidPawnStateArray; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BuffTemplateInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FBuffTemplateInfo {
	// Fields
	int32_t HeroID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TSoftClassPtr<UObject> BuffClass; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct AClient.BuffStructure
// Size: 0x10 // Inherited bytes: 0x00
struct FBuffStructure {
	// Fields
	struct TArray<struct FBuffLayer> InfoList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BuffLayer
// Size: 0x20 // Inherited bytes: 0x00
struct FBuffLayer {
	// Fields
	double ModifyTime; // Offset: 0x00 // Size: 0x08
	struct FName BuffName; // Offset: 0x08 // Size: 0x08
	struct TArray<struct FBuffInnerInfo> InfoList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BuffInnerInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FBuffInnerInfo {
	// Fields
	struct TWeakObjectPtr<struct AController> BuffCauser; // Offset: 0x00 // Size: 0x08
	struct TWeakObjectPtr<struct AActor> CauserActor; // Offset: 0x08 // Size: 0x08
	int32_t TeamID; // Offset: 0x10 // Size: 0x04
	int32_t CampID; // Offset: 0x14 // Size: 0x04
	float ValidityTimeScale; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FPredictionKey PredictionKey; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ReplicateInputInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FReplicateInputInfo {
	// Fields
	float ForwardInput; // Offset: 0x00 // Size: 0x04
	float RightInput; // Offset: 0x04 // Size: 0x04
	bool AimToggle; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct AClient.ApgameSkinMemMgrSkinResources
// Size: 0x08 // Inherited bytes: 0x00
struct FApgameSkinMemMgrSkinResources {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgamePlayerSkinResources
// Size: 0x210 // Inherited bytes: 0x08
struct FApgamePlayerSkinResources : FApgameSkinMemMgrSkinResources {
	// Fields
	bool bInGameCharacter; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FName SkinKey; // Offset: 0x0c // Size: 0x08
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FPlayerSkinAssets SkinAssets; // Offset: 0x18 // Size: 0x1f8
};

// Object Name: ScriptStruct AClient.PlayerSkinAssets
// Size: 0x1f8 // Inherited bytes: 0x08
struct FPlayerSkinAssets : FTableRowBase {
	// Fields
	struct TSoftObjectPtr<USkeletalMesh> TPPSKMesh; // Offset: 0x08 // Size: 0x28
	struct TSoftClassPtr<UObject> TPPSKMeshAnimIns; // Offset: 0x30 // Size: 0x28
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> TPPMeshMatsOverride; // Offset: 0x58 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> TPPMeshMatsLodOverride; // Offset: 0x68 // Size: 0x10
	struct TSoftObjectPtr<USkeletalMesh> FPPSKMesh; // Offset: 0x78 // Size: 0x28
	struct TSoftClassPtr<UObject> FPPSKMeshAnimIns; // Offset: 0xa0 // Size: 0x28
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> FPPMeshMatsOverride; // Offset: 0xc8 // Size: 0x10
	struct TSoftObjectPtr<UObject> HatMesh; // Offset: 0xd8 // Size: 0x28
	struct TSoftObjectPtr<UObject> FaceMesh; // Offset: 0x100 // Size: 0x28
	struct TSoftObjectPtr<UObject> NeckMesh; // Offset: 0x128 // Size: 0x28
	struct TSoftObjectPtr<UObject> ArmMesh; // Offset: 0x150 // Size: 0x28
	struct TSoftObjectPtr<UObject> BreastMesh; // Offset: 0x178 // Size: 0x28
	struct TSoftObjectPtr<UObject> WaistMesh; // Offset: 0x1a0 // Size: 0x28
	struct TSoftObjectPtr<UObject> FeetMesh; // Offset: 0x1c8 // Size: 0x28
	bool bNeedCheckFppMesh; // Offset: 0x1f0 // Size: 0x01
	char pad_0x1F1[0x7]; // Offset: 0x1f1 // Size: 0x07
};

// Object Name: ScriptStruct AClient.SimViewData
// Size: 0x06 // Inherited bytes: 0x00
struct FSimViewData {
	// Fields
	char ViewPitch; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x1]; // Offset: 0x01 // Size: 0x01
	uint16_t ViewYaw; // Offset: 0x02 // Size: 0x02
	char ViewRoll; // Offset: 0x04 // Size: 0x01
	bool FreeCamera; // Offset: 0x05 // Size: 0x01
};

// Object Name: ScriptStruct AClient.QueryPlayerInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FQueryPlayerInfo {
	// Fields
	struct FString GameModeID; // Offset: 0x00 // Size: 0x10
	float PlayTime; // Offset: 0x10 // Size: 0x04
	struct FVector Position; // Offset: 0x14 // Size: 0x0c
	int32_t LegendId; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString CurrSkillIdsStr; // Offset: 0x28 // Size: 0x10
	struct FString CurrPawnStatesStr; // Offset: 0x38 // Size: 0x10
	struct FString CurrBuffIdsStr; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ActorListInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FActorListInfo {
	// Fields
	struct TArray<struct AActor*> ActorList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RepBloodHoundOnDetected
// Size: 0x20 // Inherited bytes: 0x00
struct FRepBloodHoundOnDetected {
	// Fields
	int32_t ReplicationCounter; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct AActor*> TheRevealedArray; // Offset: 0x08 // Size: 0x10
	float RevealDuration; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.RepBloodHoundBeDetected
// Size: 0x18 // Inherited bytes: 0x00
struct FRepBloodHoundBeDetected {
	// Fields
	int32_t ReplicationCounter; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct AApexCharacter* BeenRevealedByWho; // Offset: 0x08 // Size: 0x08
	float RevealDuration; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CharacterComponentCreateData
// Size: 0x10 // Inherited bytes: 0x00
struct FCharacterComponentCreateData {
	// Fields
	char bCreateOnDS : 1; // Offset: 0x00 // Size: 0x01
	char bTickOnDS : 1; // Offset: 0x00 // Size: 0x01
	char bCreateOnAutonomous : 1; // Offset: 0x00 // Size: 0x01
	char bTickOnAutonomous : 1; // Offset: 0x00 // Size: 0x01
	char bCreateOnSimulated : 1; // Offset: 0x00 // Size: 0x01
	char bTickOnSimulated : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_6 : 2; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UActorComponent* ComponentClass; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.RepDeathTotemRangeTest
// Size: 0x08 // Inherited bytes: 0x00
struct FRepDeathTotemRangeTest {
	// Fields
	char IsOutOfValidRange : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_1 : 7; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float OutOfRangeTestEndTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RepDeathTotemProtection
// Size: 0x14 // Inherited bytes: 0x00
struct FRepDeathTotemProtection {
	// Fields
	char HasProtectionOfDeathTotem : 1; // Offset: 0x00 // Size: 0x01
	char LeaveByConsumption : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_2 : 6; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float TotemProtectionLeftSeconds; // Offset: 0x04 // Size: 0x04
	struct FVector DeathTotemPosition; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.RepRevenantSilence
// Size: 0x08 // Inherited bytes: 0x00
struct FRepRevenantSilence {
	// Fields
	float RevenantSilenceEffectEndTime; // Offset: 0x00 // Size: 0x04
	float RevenantSilenceLastDuration; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AnimSeqList
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimSeqList {
	// Fields
	struct TArray<struct FAnimSeqData> AnimSoundSeqList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AnimSeqData
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimSeqData {
	// Fields
	int32_t SoundSeq; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UApexAnimNotifySoundSetting* SoundSetting; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SkinSubSkeletalMeshComponentData
// Size: 0x28 // Inherited bytes: 0x00
struct FSkinSubSkeletalMeshComponentData {
	// Fields
	struct TArray<struct TWeakObjectPtr<struct USkeletalMeshComponent>> FppSkeletalMeshComponentArray; // Offset: 0x00 // Size: 0x10
	struct TArray<struct TWeakObjectPtr<struct USkeletalMeshComponent>> TppSkeletalMeshComponentArray; // Offset: 0x10 // Size: 0x10
	bool FppIsLobby; // Offset: 0x20 // Size: 0x01
	bool TppIsLobby; // Offset: 0x21 // Size: 0x01
	char pad_0x22[0x6]; // Offset: 0x22 // Size: 0x06
};

// Object Name: ScriptStruct AClient.PlayerSocketNames
// Size: 0x38 // Inherited bytes: 0x00
struct FPlayerSocketNames {
	// Fields
	struct FName HatSocketName; // Offset: 0x00 // Size: 0x08
	struct FName FaceSocketName; // Offset: 0x08 // Size: 0x08
	struct FName NeckSocketName; // Offset: 0x10 // Size: 0x08
	struct FName ArmSocketName; // Offset: 0x18 // Size: 0x08
	struct FName BreastSocketName; // Offset: 0x20 // Size: 0x08
	struct FName WaistSocketName; // Offset: 0x28 // Size: 0x08
	struct FName FeetSocketName; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SubObjectsReplicationConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FSubObjectsReplicationConfig {
	// Fields
	float MinDistance; // Offset: 0x00 // Size: 0x04
	float MaxDistance; // Offset: 0x04 // Size: 0x04
	float MinProbability; // Offset: 0x08 // Size: 0x04
	float MaxProbability; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.PickupTipInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FPickupTipInfo {
	// Fields
	char UniqueID; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t ItemID; // Offset: 0x04 // Size: 0x04
	int32_t DriverID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SpringArmLengthLerpInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FSpringArmLengthLerpInfo {
	// Fields
	float LerpStartTime; // Offset: 0x00 // Size: 0x04
	float Duration; // Offset: 0x04 // Size: 0x04
	float FromLen; // Offset: 0x08 // Size: 0x04
	float ToLen; // Offset: 0x0c // Size: 0x04
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
	struct FTimerHandle SpringArmLengthLerpTimer; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.CameraLerpBaseInfo
// Size: 0xe8 // Inherited bytes: 0x00
struct FCameraLerpBaseInfo {
	// Fields
	struct FVector TargetFPPValue; // Offset: 0x00 // Size: 0x0c
	struct FVector TargetTPPValue; // Offset: 0x0c // Size: 0x0c
	struct FVector TargetFPPOverrideValue; // Offset: 0x18 // Size: 0x0c
	struct FVector TargetTPPOverrideValue; // Offset: 0x24 // Size: 0x0c
	float StartTime; // Offset: 0x30 // Size: 0x04
	float EndTime; // Offset: 0x34 // Size: 0x04
	struct UCurveVector* LerpCurve; // Offset: 0x38 // Size: 0x08
	struct FVector CurveScale; // Offset: 0x40 // Size: 0x0c
	struct FVector FPPCurveScale; // Offset: 0x4c // Size: 0x0c
	enum class EApexCameraModifyType ValueType; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
	struct UCurveFloat* TPPFadeCurve; // Offset: 0x60 // Size: 0x08
	struct UCurveFloat* FPPFadeCurve; // Offset: 0x68 // Size: 0x08
	char pad_0x70[0x78]; // Offset: 0x70 // Size: 0x78
};

// Object Name: ScriptStruct AClient.StateLerpArrayInfos
// Size: 0x50 // Inherited bytes: 0x00
struct FStateLerpArrayInfos {
	// Fields
	struct TMap<enum class EApexCameraLerpType, struct FStateLerpInfo> Infos; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.StateLerpInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FStateLerpInfo {
	// Fields
	char Priority; // Offset: 0x00 // Size: 0x01
	enum class EApexCameraModifyType ModifyType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float DelayTime; // Offset: 0x04 // Size: 0x04
	bool UseCurve; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FVector FPPTargetValue; // Offset: 0x0c // Size: 0x0c
	struct FVector TPPTargetValue; // Offset: 0x18 // Size: 0x0c
	float LerpTime; // Offset: 0x24 // Size: 0x04
	struct UCurveVector* LerpCurve; // Offset: 0x28 // Size: 0x08
	struct FVector CurveScale; // Offset: 0x30 // Size: 0x0c
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.FingerLocationData
// Size: 0x10 // Inherited bytes: 0x00
struct FFingerLocationData {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SensibilityConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FSensibilityConfig {
	// Fields
	struct FSensibilityMode NormalMode; // Offset: 0x00 // Size: 0x24
	struct FSensibilityMode FireMode; // Offset: 0x24 // Size: 0x24
	float GlobalSensibility; // Offset: 0x48 // Size: 0x04
	float VerticalSensitivityScale; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct AClient.SensibilityMode
// Size: 0x24 // Inherited bytes: 0x00
struct FSensibilityMode {
	// Fields
	float NoAim; // Offset: 0x00 // Size: 0x04
	float Sight1X; // Offset: 0x04 // Size: 0x04
	float Sight2X; // Offset: 0x08 // Size: 0x04
	float Sight3X; // Offset: 0x0c // Size: 0x04
	float Sight4X; // Offset: 0x10 // Size: 0x04
	float Sight6X; // Offset: 0x14 // Size: 0x04
	float Sight8X; // Offset: 0x18 // Size: 0x04
	float Sight10X; // Offset: 0x1c // Size: 0x04
	float FPPNoAim; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct AClient.FOVChangeTimeByScope
// Size: 0x20 // Inherited bytes: 0x00
struct FFOVChangeTimeByScope {
	// Fields
	float NoAim; // Offset: 0x00 // Size: 0x04
	float Sight1X; // Offset: 0x04 // Size: 0x04
	float Sight2X; // Offset: 0x08 // Size: 0x04
	float Sight3X; // Offset: 0x0c // Size: 0x04
	float Sight4X; // Offset: 0x10 // Size: 0x04
	float Sight6X; // Offset: 0x14 // Size: 0x04
	float Sight8X; // Offset: 0x18 // Size: 0x04
	float Sight10X; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.TouchInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FTouchInfo {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
	struct FVector StartLocation; // Offset: 0x04 // Size: 0x0c
	struct FVector DistanceCalcStartLocation; // Offset: 0x10 // Size: 0x0c
	struct FVector Location; // Offset: 0x1c // Size: 0x0c
	enum class ECharacterViewSide ViewSide; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FTouchTakeOverInfo TakeOverInfo; // Offset: 0x30 // Size: 0x20
};

// Object Name: ScriptStruct AClient.TouchTakeOverInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FTouchTakeOverInfo {
	// Fields
	struct FTouchTakeOverConfig TakeOverCofing; // Offset: 0x00 // Size: 0x03
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	struct FVector2D ButtonPosition; // Offset: 0x04 // Size: 0x08
	struct FVector2D ButtonSize; // Offset: 0x0c // Size: 0x08
	int32_t Priority; // Offset: 0x14 // Size: 0x04
	struct FName WeakWidgetName; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.TouchTakeOverConfig
// Size: 0x03 // Inherited bytes: 0x00
struct FTouchTakeOverConfig {
	// Fields
	enum class ETouchTakeOverType TakeOverType; // Offset: 0x00 // Size: 0x01
	enum class EButtonPassType PassType; // Offset: 0x01 // Size: 0x01
	enum class ETouchTakeOverType OriTakeOverType; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct AClient.TouchTakeOverInfoFingerIndex
// Size: 0x10 // Inherited bytes: 0x00
struct FTouchTakeOverInfoFingerIndex {
	// Fields
	int32_t FingerIndex; // Offset: 0x00 // Size: 0x04
	struct FTouchTakeOverConfig TakeOverConfig; // Offset: 0x04 // Size: 0x03
	char pad_0x7[0x1]; // Offset: 0x07 // Size: 0x01
	struct FName WeakWidgetName; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.VisualSoundPawnStates
// Size: 0x10 // Inherited bytes: 0x00
struct FVisualSoundPawnStates {
	// Fields
	struct TArray<enum class EPawnState> States; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.VisualSoundTexture
// Size: 0x18 // Inherited bytes: 0x00
struct FVisualSoundTexture {
	// Fields
	struct UObject* UpperTex; // Offset: 0x00 // Size: 0x08
	struct UObject* HorizonTex; // Offset: 0x08 // Size: 0x08
	struct UObject* LowerTex; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PawnStateMask
// Size: 0x08 // Inherited bytes: 0x00
struct FPawnStateMask {
	// Fields
	int64_t PawnStateMask; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.MonsterStateTranfromEBehavior
// Size: 0x02 // Inherited bytes: 0x00
struct FMonsterStateTranfromEBehavior {
	// Fields
	enum class EPawnState PawnState; // Offset: 0x00 // Size: 0x01
	enum class EBehavior ToState; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.MonsterStateTranfromEPendant
// Size: 0x02 // Inherited bytes: 0x00
struct FMonsterStateTranfromEPendant {
	// Fields
	enum class EPawnState PawnState; // Offset: 0x00 // Size: 0x01
	enum class EPendant ToState; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.MonsterStateTranfromEPose
// Size: 0x02 // Inherited bytes: 0x00
struct FMonsterStateTranfromEPose {
	// Fields
	enum class EPawnState PawnState; // Offset: 0x00 // Size: 0x01
	enum class EPose ToState; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.ReconnectSyncData
// Size: 0x10 // Inherited bytes: 0x00
struct FReconnectSyncData {
	// Fields
	bool bNeedWaitLevelStreaming; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector_NetQuantize100 ServerLineTraceLocation; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.AIPhySimuPoint
// Size: 0x10 // Inherited bytes: 0x00
struct FAIPhySimuPoint {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApexCharacterReviveInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FApexCharacterReviveInfo {
	// Fields
	struct AApexCharacter* RevivePlayer; // Offset: 0x00 // Size: 0x08
	struct ADeathTotem* DeathTotem; // Offset: 0x08 // Size: 0x08
	char ReviveInfoValid : 1; // Offset: 0x10 // Size: 0x01
	char RecordedIsCrouching : 1; // Offset: 0x10 // Size: 0x01
	char pad_0x10_2 : 6; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float ReviveInfoValidEndTime; // Offset: 0x14 // Size: 0x04
	float RecordedHealth; // Offset: 0x18 // Size: 0x04
	float RecordedSpeed; // Offset: 0x1c // Size: 0x04
	struct FVector ReviveLocation; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FQuat ReviveQuatRotation; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GuidePanelSettings
// Size: 0x28 // Inherited bytes: 0x00
struct FGuidePanelSettings {
	// Fields
	struct FText Title; // Offset: 0x00 // Size: 0x18
	struct TArray<struct FGuidePanelSettingsItem> Items; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GuidePanelSettingsItem
// Size: 0x20 // Inherited bytes: 0x00
struct FGuidePanelSettingsItem {
	// Fields
	struct FText Desc; // Offset: 0x00 // Size: 0x18
	struct UTexture2D* Image; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SkillActorBaseList
// Size: 0x10 // Inherited bytes: 0x00
struct FSkillActorBaseList {
	// Fields
	struct TArray<struct TWeakObjectPtr<struct ASkillActorBase>> ActorList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CharacterMontageMap
// Size: 0x50 // Inherited bytes: 0x00
struct FCharacterMontageMap {
	// Fields
	struct TMap<enum class EDisplayCharStateMode, struct FWeaponMontageMap> CharacterMontageMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.WeaponMontageMap
// Size: 0x50 // Inherited bytes: 0x00
struct FWeaponMontageMap {
	// Fields
	struct TMap<enum class EWeaponSpecificType, struct TSoftObjectPtr<UAnimMontage>> WeaponMontageMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.LegendOffset
// Size: 0x20 // Inherited bytes: 0x08
struct FLegendOffset : FTableRowBase {
	// Fields
	struct FVector BaseOffset; // Offset: 0x08 // Size: 0x0c
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct UCurveVector* AspOffset; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.DisplayWeaponSkinCfg
// Size: 0x18 // Inherited bytes: 0x00
struct FDisplayWeaponSkinCfg {
	// Fields
	struct FSoftObjectPath WeaponFrameEffect; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.WeaponAudioMapData
// Size: 0x50 // Inherited bytes: 0x00
struct FWeaponAudioMapData {
	// Fields
	struct TMap<enum class EDisplayWeaponStateMode, struct UAkAudioEvent*> ActionAudioMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.WeaponAnimAssetMap
// Size: 0x50 // Inherited bytes: 0x00
struct FWeaponAnimAssetMap {
	// Fields
	struct TMap<enum class EWeaponSpecificType, struct TSoftObjectPtr<UAnimationAsset>> WeaponAnimAssetMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.WeaponBulletChangeNum
// Size: 0x08 // Inherited bytes: 0x00
struct FWeaponBulletChangeNum {
	// Fields
	char ColorNum1; // Offset: 0x00 // Size: 0x01
	char ColorNum2; // Offset: 0x01 // Size: 0x01
	char ColorNum3; // Offset: 0x02 // Size: 0x01
	char FlashNum; // Offset: 0x03 // Size: 0x01
	int32_t MaxNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApexEmojiRuntimeInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FApexEmojiRuntimeInfo {
	// Fields
	struct TMap<enum class EEmojiType, struct FName> EmojiType2ID; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.GameCreditScoreRatingInfo
// Size: 0x78 // Inherited bytes: 0x00
struct FGameCreditScoreRatingInfo {
	// Fields
	char pad_0x0[0x78]; // Offset: 0x00 // Size: 0x78
};

// Object Name: ScriptStruct AClient.GameflowCommonData
// Size: 0x20 // Inherited bytes: 0x00
struct FGameflowCommonData {
	// Fields
	struct FString RegisterCountry; // Offset: 0x00 // Size: 0x10
	struct FString IPCountry; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GameflowStage_ActionConfigPair
// Size: 0x20 // Inherited bytes: 0x00
struct FGameflowStage_ActionConfigPair {
	// Fields
	struct TArray<struct FGameflowStage_ActionConfig> ParallelActionConfigs; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FGameflowStage_ActionConfig> SequentialActionConfigs; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GameflowStage_ActionConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FGameflowStage_ActionConfig {
	// Fields
	struct UBaseInGameStageAction* ActionClass; // Offset: 0x00 // Size: 0x08
	float Timeout; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.GameFlowWorldInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FGameFlowWorldInfo {
	// Fields
	struct FString GameModeID; // Offset: 0x00 // Size: 0x10
	struct FString MapURL; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.HeadNamePool
// Size: 0x10 // Inherited bytes: 0x00
struct FHeadNamePool {
	// Fields
	float DistanceSq; // Offset: 0x00 // Size: 0x04
	bool bEnemy; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct TWeakObjectPtr<struct UUserWidget> TargetWidget; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SWidgetTextDrawInfo
// Size: 0x90 // Inherited bytes: 0x00
struct FSWidgetTextDrawInfo {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
	struct UFont* Font; // Offset: 0x20 // Size: 0x08
	struct FSlateFontInfo SlateFontInfo; // Offset: 0x28 // Size: 0x50
	char pad_0x78[0x18]; // Offset: 0x78 // Size: 0x18
};

// Object Name: ScriptStruct AClient.SWidgetTextureDrawInfo
// Size: 0xb0 // Inherited bytes: 0x00
struct FSWidgetTextureDrawInfo {
	// Fields
	struct FSlateBrush BrushInfo; // Offset: 0x00 // Size: 0x88
	char pad_0x88[0x28]; // Offset: 0x88 // Size: 0x28
};

// Object Name: ScriptStruct AClient.EditorPlayerLoginInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FEditorPlayerLoginInfo {
	// Fields
	struct FString PlayerNameOption; // Offset: 0x00 // Size: 0x10
	uint32_t PlayerKeyOption; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString NameOption; // Offset: 0x18 // Size: 0x10
	int32_t PlayerIndex; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApexGameSettings
// Size: 0x48 // Inherited bytes: 0x00
struct FApexGameSettings {
	// Fields
	bool IsFPP; // Offset: 0x00 // Size: 0x01
	bool IsSkipNearDeath; // Offset: 0x01 // Size: 0x01
	bool KnockdownShield4NoSkipDying; // Offset: 0x02 // Size: 0x01
	bool IsSkipRespawn; // Offset: 0x03 // Size: 0x01
	bool IsNeedSpawnTombBox; // Offset: 0x04 // Size: 0x01
	bool KeepBackpackWhenNoTome; // Offset: 0x05 // Size: 0x01
	bool ClearBackpackWhenChangeLegend; // Offset: 0x06 // Size: 0x01
	bool ResetHealthWhenChangeLegend; // Offset: 0x07 // Size: 0x01
	struct FName PlayerLoadoutTable; // Offset: 0x08 // Size: 0x08
	struct FName LoadoutWeaponTable; // Offset: 0x10 // Size: 0x08
	bool WithLoadout; // Offset: 0x18 // Size: 0x01
	bool bForceLoadout; // Offset: 0x19 // Size: 0x01
	bool AutoAction; // Offset: 0x1a // Size: 0x01
	char pad_0x1B[0x1]; // Offset: 0x1b // Size: 0x01
	struct FName ModeItemJsonPath; // Offset: 0x1c // Size: 0x08
	struct FName ModeDynamicItemPath; // Offset: 0x24 // Size: 0x08
	bool bIsAutoCreateLegend; // Offset: 0x2c // Size: 0x01
	bool GameModeBanOB; // Offset: 0x2d // Size: 0x01
	bool EnableOBAI; // Offset: 0x2e // Size: 0x01
	char pad_0x2F[0x1]; // Offset: 0x2f // Size: 0x01
	struct FString GameModeSkillConfigID; // Offset: 0x30 // Size: 0x10
	int32_t SecurityModeID; // Offset: 0x40 // Size: 0x04
	int32_t BattlefieldPositiveFeedbackActiveID; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RTPCParamInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FRTPCParamInfo {
	// Fields
	struct FString RTPCKey; // Offset: 0x00 // Size: 0x10
	float Value; // Offset: 0x10 // Size: 0x04
	int32_t InterpolationTimeMs; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.TravelFailureInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FTravelFailureInfo {
	// Fields
	struct UWorld* World; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct FString ErrorMessage; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.NetworkFailureInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FNetworkFailureInfo {
	// Fields
	struct UWorld* World; // Offset: 0x00 // Size: 0x08
	struct UNetDriver* NetDriver; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
	struct FString ErrorMessage; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CommonCoinInfo
// Size: 0x18 // Inherited bytes: 0x08
struct FCommonCoinInfo : FTableRowBase {
	// Fields
	struct TArray<struct FCommonCoinSingleInfo> Coins; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CommonCoinSingleInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FCommonCoinSingleInfo {
	// Fields
	int32_t CoinID; // Offset: 0x00 // Size: 0x04
	bool bShowAddBtn; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.ApexTranslationItemData
// Size: 0x80 // Inherited bytes: 0x00
struct FApexTranslationItemData {
	// Fields
	struct FString SourceKey; // Offset: 0x00 // Size: 0x10
	struct FString Namespace; // Offset: 0x10 // Size: 0x10
	struct FString Key; // Offset: 0x20 // Size: 0x10
	struct TMap<struct FString, struct FString> Culture2LocalizeString; // Offset: 0x30 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ActorLockLootInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FActorLockLootInfo {
	// Fields
	float LockTime; // Offset: 0x00 // Size: 0x04
	float LockRadius; // Offset: 0x04 // Size: 0x04
	float VirtualDistance; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ForbidSwitchCameraState
// Size: 0x18 // Inherited bytes: 0x00
struct FForbidSwitchCameraState {
	// Fields
	struct TArray<enum class EPawnState> ForbidStates; // Offset: 0x00 // Size: 0x10
	uint64_t ForbidStatesMask; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.DoubleClickPosition
// Size: 0x14 // Inherited bytes: 0x00
struct FDoubleClickPosition {
	// Fields
	struct FVector WorldPosition; // Offset: 0x00 // Size: 0x0c
	struct FVector2D ScreenPosition; // Offset: 0x0c // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApexPlayerStartPriority
// Size: 0x18 // Inherited bytes: 0x00
struct FApexPlayerStartPriority {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
	struct AApexPlayerStart* PlayerStart; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApexPlayerStartPriorityInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FApexPlayerStartPriorityInfo {
	// Fields
	struct AApexPlayerState* Player; // Offset: 0x00 // Size: 0x08
	struct TArray<struct AApexPlayerState*> Ally; // Offset: 0x08 // Size: 0x10
	struct TArray<struct AApexPlayerState*> Enemy; // Offset: 0x18 // Size: 0x10
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApexPostProcessCfgItem
// Size: 0x18 // Inherited bytes: 0x00
struct FApexPostProcessCfgItem {
	// Fields
	enum class EApexPostProcessType PPT; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct AActor* PostProcessClass; // Offset: 0x08 // Size: 0x08
	float Duation; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApexProjectileMovementRuntimeData
// Size: 0x08 // Inherited bytes: 0x00
struct FApexProjectileMovementRuntimeData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.RailPointArr
// Size: 0x10 // Inherited bytes: 0x00
struct FRailPointArr {
	// Fields
	struct TArray<struct FRailPoint> Data; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RailPoint
// Size: 0x48 // Inherited bytes: 0x00
struct FRailPoint {
	// Fields
	struct TArray<float> Location; // Offset: 0x00 // Size: 0x10
	bool IsCircle; // Offset: 0x10 // Size: 0x01
	bool IsStation; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x6]; // Offset: 0x12 // Size: 0x06
	struct FString Station; // Offset: 0x18 // Size: 0x10
	struct TArray<int32_t> Link; // Offset: 0x28 // Size: 0x10
	struct TArray<int32_t> PreLink; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RepRotatingDoor
// Size: 0x08 // Inherited bytes: 0x00
struct FRepRotatingDoor {
	// Fields
	float Sequence; // Offset: 0x00 // Size: 0x04
	float Yaw; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApexSceneManagerTickFunction
// Size: 0x58 // Inherited bytes: 0x50
struct FApexSceneManagerTickFunction : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.DistanceActorInfos
// Size: 0x10 // Inherited bytes: 0x00
struct FDistanceActorInfos {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DistanceActorInfo
// Size: 0x68 // Inherited bytes: 0x00
struct FDistanceActorInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	float DistanceSqu; // Offset: 0x08 // Size: 0x04
	float Distance2ReticleSqu; // Offset: 0x0c // Size: 0x04
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
	struct TMap<enum class EPawnState, float> PawnState2EndTime; // Offset: 0x18 // Size: 0x50
};

// Object Name: ScriptStruct AClient.DebugDrawData
// Size: 0x48 // Inherited bytes: 0x00
struct FDebugDrawData {
	// Fields
	struct TArray<struct FDebugLine> ServerLineArray; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FDebugLine> LocalLineArray; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FDebugSphere> ServerSphereArray; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FDebugSphere> LocalSphereArray; // Offset: 0x30 // Size: 0x10
	float DistanceLimit; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AClient.DebugSphere
// Size: 0x1c // Inherited bytes: 0x00
struct FDebugSphere {
	// Fields
	struct FVector CenterPos; // Offset: 0x00 // Size: 0x0c
	float Radius; // Offset: 0x0c // Size: 0x04
	int32_t Segments; // Offset: 0x10 // Size: 0x04
	struct FColor Color; // Offset: 0x14 // Size: 0x04
	bool IsServer; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
};

// Object Name: ScriptStruct AClient.DebugLine
// Size: 0x20 // Inherited bytes: 0x00
struct FDebugLine {
	// Fields
	struct FVector StartPos; // Offset: 0x00 // Size: 0x0c
	struct FVector EndPos; // Offset: 0x0c // Size: 0x0c
	struct FColor Color; // Offset: 0x18 // Size: 0x04
	bool IsServer; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct AClient.ApexSkillAssist
// Size: 0x28 // Inherited bytes: 0x00
struct FApexSkillAssist {
	// Fields
	int32_t SkillIndex; // Offset: 0x00 // Size: 0x04
	int32_t SkillConfigId; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FApexSkillReplace> SkillsEnableAssist; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FApexSkillReplace> SkillsDisableAssist; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApexSkillReplace
// Size: 0x30 // Inherited bytes: 0x00
struct FApexSkillReplace {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	int32_t ConfigId; // Offset: 0x04 // Size: 0x04
	struct TSoftClassPtr<UObject> SkillToReplace; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct AClient.TriggerEventBuffPoolItem
// Size: 0x10 // Inherited bytes: 0x00
struct FTriggerEventBuffPoolItem {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct USkillEventParam* SkillEventParam; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.HeroSkillInfos
// Size: 0x18 // Inherited bytes: 0x08
struct FHeroSkillInfos : FTableRowBase {
	// Fields
	struct TArray<struct TSoftClassPtr<UObject>> SkillBps; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SkillAimSight
// Size: 0x30 // Inherited bytes: 0x00
struct FSkillAimSight {
	// Fields
	struct TArray<struct UTexture*> AimSightTextureArray; // Offset: 0x00 // Size: 0x10
	struct FVector2D AimSightSize; // Offset: 0x10 // Size: 0x08
	bool Disabled; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct TArray<struct FSkillAimSightDisplayData> DisplayArray; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SkillAimSightDisplayData
// Size: 0x48 // Inherited bytes: 0x00
struct FSkillAimSightDisplayData {
	// Fields
	char pad_0x0[0x48]; // Offset: 0x00 // Size: 0x48
};

// Object Name: ScriptStruct AClient.ApexSkillShapeGenerator
// Size: 0x10 // Inherited bytes: 0x00
struct FApexSkillShapeGenerator {
	// Fields
	enum class ESkillShapeType ShapeType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ShapeParamA; // Offset: 0x04 // Size: 0x04
	float ShapeParamB; // Offset: 0x08 // Size: 0x04
	float ShapeParamC; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApexSkillRoleCheckRuleData
// Size: 0x05 // Inherited bytes: 0x00
struct FApexSkillRoleCheckRuleData {
	// Fields
	bool bAuthority; // Offset: 0x00 // Size: 0x01
	bool bAutonomousProxy; // Offset: 0x01 // Size: 0x01
	bool bSimulatedProxy; // Offset: 0x02 // Size: 0x01
	bool bObEnabled; // Offset: 0x03 // Size: 0x01
	bool bObOnlyEnabled; // Offset: 0x04 // Size: 0x01
};

// Object Name: ScriptStruct AClient.ApexSkillEventPostPathRuleData
// Size: 0x0c // Inherited bytes: 0x00
struct FApexSkillEventPostPathRuleData {
	// Fields
	bool bSendToChildren; // Offset: 0x00 // Size: 0x01
	bool bSendToChildrenBroadcast; // Offset: 0x01 // Size: 0x01
	bool bSendToParent; // Offset: 0x02 // Size: 0x01
	bool bSendToParentBroadcast; // Offset: 0x03 // Size: 0x01
	bool bSendToSelf; // Offset: 0x04 // Size: 0x01
	bool bSendToSelfBroadcast; // Offset: 0x05 // Size: 0x01
	bool bSendToOwnerApexSkillActor; // Offset: 0x06 // Size: 0x01
	char pad_0x7[0x1]; // Offset: 0x07 // Size: 0x01
	int32_t SkillID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ParabolaAirFrictionMove
// Size: 0x18 // Inherited bytes: 0x00
struct FParabolaAirFrictionMove {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.ParabolaAirFrictionData
// Size: 0x0c // Inherited bytes: 0x00
struct FParabolaAirFrictionData {
	// Fields
	float GravityScale; // Offset: 0x00 // Size: 0x04
	float AirFriction; // Offset: 0x04 // Size: 0x04
	float TimeDuration; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApexSkillTargetActorArray
// Size: 0x18 // Inherited bytes: 0x00
struct FApexSkillTargetActorArray {
	// Fields
	enum class EPickerTargetType PickerTargetType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct AActor*> ActorList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SkillPredictionLineConfigData
// Size: 0x238 // Inherited bytes: 0x00
struct FSkillPredictionLineConfigData {
	// Fields
	struct UObject* PredictionLineCls; // Offset: 0x00 // Size: 0x08
	enum class ESplineMeshAxis PredictLineForwardAxis; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float PredictionLineRoll; // Offset: 0x0c // Size: 0x04
	float PredictionLineRollTPP; // Offset: 0x10 // Size: 0x04
	bool IsFaceCamera; // Offset: 0x14 // Size: 0x01
	enum class EAPRenderPass RenderPass; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
	struct FVector2D PredictionLineScale; // Offset: 0x18 // Size: 0x08
	struct FVector2D PredictionLineScaleTPP; // Offset: 0x20 // Size: 0x08
	struct FLinearColor PredictionLineColor; // Offset: 0x28 // Size: 0x10
	struct FLinearColor PredictionLineColor_PDCC; // Offset: 0x38 // Size: 0x10
	struct FLinearColor PredictionLineTargetColor; // Offset: 0x48 // Size: 0x10
	struct FLinearColor PredictionLineTargetColor_PDCC; // Offset: 0x58 // Size: 0x10
	struct FLinearColor PredictionLineTargetColorSecond; // Offset: 0x68 // Size: 0x10
	struct FLinearColor PredictionLineTargetColorSecond_PDCC; // Offset: 0x78 // Size: 0x10
	struct TSoftObjectPtr<UStaticMesh> PredictionLineMeshClass; // Offset: 0x88 // Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> PredictionLineTargetParticleClass; // Offset: 0xb0 // Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> PredictionLineTargetAreaParticleClass; // Offset: 0xd8 // Size: 0x28
	struct TSoftObjectPtr<UMaterialInstance> PredictionLineMaterialStart; // Offset: 0x100 // Size: 0x28
	struct TSoftObjectPtr<UMaterialInstance> PredictionLineMaterialEnd; // Offset: 0x128 // Size: 0x28
	struct TSoftObjectPtr<UMaterialInstance> PredictionLineMaterialStartTPP; // Offset: 0x150 // Size: 0x28
	struct TSoftObjectPtr<UMaterialInstance> PredictionLineMaterialEndTPP; // Offset: 0x178 // Size: 0x28
	struct TSoftObjectPtr<UMaterialInstance> PredictionLineTargetMaterial; // Offset: 0x1a0 // Size: 0x28
	struct TSoftObjectPtr<UMaterialInstance> PredictionLineTargetMaterialTPP; // Offset: 0x1c8 // Size: 0x28
	struct UStaticMesh* PredictionLineMesh; // Offset: 0x1f0 // Size: 0x08
	struct UParticleSystem* PredictionLineTargetParticle; // Offset: 0x1f8 // Size: 0x08
	struct UParticleSystem* PredictionLineTargetAreaParticle; // Offset: 0x200 // Size: 0x08
	struct UMaterialInstanceDynamic* PredictionLineMaterialStartInst; // Offset: 0x208 // Size: 0x08
	struct UMaterialInstanceDynamic* PredictionLineMaterialEndInst; // Offset: 0x210 // Size: 0x08
	struct UMaterialInstanceDynamic* PredictionLineMaterialStartInstTPP; // Offset: 0x218 // Size: 0x08
	struct UMaterialInstanceDynamic* PredictionLineMaterialEndInstTPP; // Offset: 0x220 // Size: 0x08
	struct UMaterialInstanceDynamic* PredictionTargetMaterialInst; // Offset: 0x228 // Size: 0x08
	struct UMaterialInstanceDynamic* PredictionTargetMaterialInstTPP; // Offset: 0x230 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SkillActorCompInstPool
// Size: 0x38 // Inherited bytes: 0x00
struct FSkillActorCompInstPool {
	// Fields
	int32_t ActorCompInstPoolSize; // Offset: 0x00 // Size: 0x04
	int32_t MaxActorCompInstPoolSize; // Offset: 0x04 // Size: 0x04
	double MaxMillisecondForTick; // Offset: 0x08 // Size: 0x08
	struct UObject* ClassToInstance; // Offset: 0x10 // Size: 0x08
	struct TArray<struct UActorComponent*> ActorCompInstArray; // Offset: 0x18 // Size: 0x10
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SkillSingleMatchData
// Size: 0x18 // Inherited bytes: 0x00
struct FSkillSingleMatchData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct TArray<struct UStatisticDataItemBase*> StatisticDataArray; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.TrainInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FTrainInfo {
	// Fields
	float BodyLength; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct AActor* BodyClass; // Offset: 0x08 // Size: 0x08
	float Padding; // Offset: 0x10 // Size: 0x04
	bool bAllowIgnoreMove; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	float DistanceTOLocomotive; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct ATrainCoach* Coach; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PenetrateCharacterRecord
// Size: 0x40 // Inherited bytes: 0x00
struct FPenetrateCharacterRecord {
	// Fields
	struct ACharacter* Character; // Offset: 0x00 // Size: 0x08
	struct UPrimitiveComponent* Base; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x30]; // Offset: 0x10 // Size: 0x30
};

// Object Name: ScriptStruct AClient.HideWidgetEntry
// Size: 0x18 // Inherited bytes: 0x00
struct FHideWidgetEntry {
	// Fields
	struct UUserWidget* TargetUI; // Offset: 0x00 // Size: 0x08
	struct FWidgetNames WidgetNames; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.WidgetNames
// Size: 0x10 // Inherited bytes: 0x00
struct FWidgetNames {
	// Fields
	struct TArray<struct FName> WidgetNames; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApexViewInfo
// Size: 0xa0 // Inherited bytes: 0x00
struct FApexViewInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct UCameraComponent* CurrentCamera; // Offset: 0x08 // Size: 0x08
	struct USpringArmComponent* CurrentSpringArm; // Offset: 0x10 // Size: 0x08
	char pad_0x18[0x88]; // Offset: 0x18 // Size: 0x88
};

// Object Name: ScriptStruct AClient.ReplicationGraphSettings
// Size: 0x2c // Inherited bytes: 0x00
struct FReplicationGraphSettings {
	// Fields
	bool bEnableReplicationGraph; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float DefaultGridCellSize; // Offset: 0x04 // Size: 0x04
	struct FBox DefaultGridBounds; // Offset: 0x08 // Size: 0x1c
	float PickUpActorGridCellSizeOverride; // Offset: 0x24 // Size: 0x04
	float CharacterGridCellSizeOverride; // Offset: 0x28 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillContainer
// Size: 0x30 // Inherited bytes: 0x00
struct FSkillContainer {
	// Fields
	struct TArray<struct TSoftClassPtr<UObject>> TacticalSkills; // Offset: 0x00 // Size: 0x10
	struct TArray<struct TSoftClassPtr<UObject>> UltimateSkills; // Offset: 0x10 // Size: 0x10
	struct TArray<struct TSoftClassPtr<UObject>> PassiveSkills; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameWeaponAttributeSetInitialData
// Size: 0x08 // Inherited bytes: 0x00
struct FApgameWeaponAttributeSetInitialData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameCommonWeaponASID
// Size: 0x58 // Inherited bytes: 0x08
struct FApgameCommonWeaponASID : FApgameWeaponAttributeSetInitialData {
	// Fields
	char pad_0x8[0x50]; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ApgameWeaponMeshInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FApgameWeaponMeshInfo {
	// Fields
	struct FApgameWeaponMeshCompViews CompViews; // Offset: 0x00 // Size: 0x10
	struct FApgameWeaponMeshCompViews CharmViews; // Offset: 0x10 // Size: 0x10
	struct UWeaponFrameEffectData* EffectDataAsset; // Offset: 0x20 // Size: 0x08
	struct USkeletalMesh* NormalFppModelCache; // Offset: 0x28 // Size: 0x08
	struct USkeletalMesh* HighFppModelCache; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameWeaponMeshCompViews
// Size: 0x10 // Inherited bytes: 0x00
struct FApgameWeaponMeshCompViews {
	// Fields
	struct USkeletalMeshComponent* Fpp; // Offset: 0x00 // Size: 0x08
	struct USkeletalMeshComponent* Tpp; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameDisruptorWeaponASID
// Size: 0x10 // Inherited bytes: 0x08
struct FApgameDisruptorWeaponASID : FApgameWeaponAttributeSetInitialData {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameEventDataHandle
// Size: 0x10 // Inherited bytes: 0x00
struct FApgameEventDataHandle {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameEventData
// Size: 0x08 // Inherited bytes: 0x00
struct FApgameEventData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgamePickupFloatingResult
// Size: 0x08 // Inherited bytes: 0x00
struct FApgamePickupFloatingResult {
	// Fields
	float Height; // Offset: 0x00 // Size: 0x04
	float Angle; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgameBackpackSnapshot
// Size: 0x20 // Inherited bytes: 0x00
struct FApgameBackpackSnapshot {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FApgameBackpackItemSnapshot> Items; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameBackpackItemSnapshot
// Size: 0x38 // Inherited bytes: 0x00
struct FApgameBackpackItemSnapshot {
	// Fields
	struct FItemDefineID ItemID; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FBattleItemAdditionalData> AdditionalDataList; // Offset: 0x10 // Size: 0x10
	char pad_0x20[0x8]; // Offset: 0x20 // Size: 0x08
	struct TArray<int32_t> Associations; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameClientPlayerState
// Size: 0x28 // Inherited bytes: 0x00
struct FApgameClientPlayerState {
	// Fields
	enum class EGameViewType ViewType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector PlayerLocation; // Offset: 0x04 // Size: 0x0c
	struct FVector CameraLocation; // Offset: 0x10 // Size: 0x0c
	struct FRotator CameraRotation; // Offset: 0x1c // Size: 0x0c
};

// Object Name: ScriptStruct AClient.ApgamePlayerStateCondensedSnapshot
// Size: 0x30 // Inherited bytes: 0x00
struct FApgamePlayerStateCondensedSnapshot {
	// Fields
	struct FDateTime Time; // Offset: 0x00 // Size: 0x08
	struct FVector PlayerLocation; // Offset: 0x08 // Size: 0x0c
	struct FVector CameraLocation; // Offset: 0x14 // Size: 0x0c
	struct FRotator CameraRotation; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgamePlayerStateSnapshot
// Size: 0x88 // Inherited bytes: 0x00
struct FApgamePlayerStateSnapshot {
	// Fields
	enum class EGameViewType ViewType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FDateTime Time; // Offset: 0x08 // Size: 0x08
	struct FApgamePlayerMovementSnapshot Movement; // Offset: 0x10 // Size: 0x28
	struct FVector CameraLocation; // Offset: 0x38 // Size: 0x0c
	struct FRotator CameraRotation; // Offset: 0x44 // Size: 0x0c
	float Health; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FApgameBackpackSnapshot BackpackAndEquipment; // Offset: 0x58 // Size: 0x20
	struct TArray<struct FApgameSkillSnapshot> Skills; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameSkillSnapshot
// Size: 0x20 // Inherited bytes: 0x00
struct FApgameSkillSnapshot {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Name; // Offset: 0x08 // Size: 0x10
	float Energy; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgamePlayerMovementSnapshot
// Size: 0x28 // Inherited bytes: 0x00
struct FApgamePlayerMovementSnapshot {
	// Fields
	bool bRelativeToMovementBase; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct TWeakObjectPtr<struct UPrimitiveComponent> MovementBase; // Offset: 0x04 // Size: 0x08
	struct FVector RelativeLocation; // Offset: 0x0c // Size: 0x0c
	struct FVector WorldLocation; // Offset: 0x18 // Size: 0x0c
	float Yaw; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgamePreFireWeaponASID
// Size: 0x10 // Inherited bytes: 0x08
struct FApgamePreFireWeaponASID : FApgameWeaponAttributeSetInitialData {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameShootWeaponASID
// Size: 0x50 // Inherited bytes: 0x08
struct FApgameShootWeaponASID : FApgameWeaponAttributeSetInitialData {
	// Fields
	char pad_0x8[0x48]; // Offset: 0x08 // Size: 0x48
};

// Object Name: ScriptStruct AClient.ApgameSkinMemMgrSkinCustomKey
// Size: 0x08 // Inherited bytes: 0x00
struct FApgameSkinMemMgrSkinCustomKey {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameSignatureWeaponSkinCustomKey
// Size: 0x18 // Inherited bytes: 0x08
struct FApgameSignatureWeaponSkinCustomKey : FApgameSkinMemMgrSkinCustomKey {
	// Fields
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameSignatureWeaponSkinResources
// Size: 0xa88 // Inherited bytes: 0x08
struct FApgameSignatureWeaponSkinResources : FApgameSkinMemMgrSkinResources {
	// Fields
	char pad_0x8[0xa80]; // Offset: 0x08 // Size: 0xa80
};

// Object Name: ScriptStruct AClient.SkillCacheRes
// Size: 0x70 // Inherited bytes: 0x00
struct FSkillCacheRes {
	// Fields
	struct TArray<struct UObject*> ObjectList; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x60]; // Offset: 0x10 // Size: 0x60
};

// Object Name: ScriptStruct AClient.ApgameSkinMemMgrSkinTypeSettings
// Size: 0x30 // Inherited bytes: 0x00
struct FApgameSkinMemMgrSkinTypeSettings {
	// Fields
	enum class EApgameSkinMemMgrSkinType SkinType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FApgameSkinMemMgrSkinTypeParams Params; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct AClient.ApgameSkinMemMgrSkinTypeParams
// Size: 0x28 // Inherited bytes: 0x00
struct FApgameSkinMemMgrSkinTypeParams {
	// Fields
	int32_t MaxSkinNumOnScreen; // Offset: 0x00 // Size: 0x04
	float RenderedTimeForCulling; // Offset: 0x04 // Size: 0x04
	struct TArray<float> LowLodDistanceList; // Offset: 0x08 // Size: 0x10
	int32_t MaxSkinUserNumOnScreen; // Offset: 0x18 // Size: 0x04
	float SkinUserDistanceGrid; // Offset: 0x1c // Size: 0x04
	float SkinUserViewAngleGrid; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgameSkinMemMgrSkinInfo
// Size: 0xa0 // Inherited bytes: 0x00
struct FApgameSkinMemMgrSkinInfo {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x00 // Size: 0x40
	struct TArray<struct UObject*> ResourceObjects; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x50]; // Offset: 0x50 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ApgameWeaponCommonAnimInstanceProxy
// Size: 0x7b0 // Inherited bytes: 0x7b0
struct FApgameWeaponCommonAnimInstanceProxy : FAnimInstanceProxy {
};

// Object Name: ScriptStruct AClient.ApgameWeaponOwnedAttributeSetInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FApgameWeaponOwnedAttributeSetInfo {
	// Fields
	struct UApgameWeaponAttributeSet* AttributeSet; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameWeaponLogicInstance
// Size: 0x30 // Inherited bytes: 0x00
struct FApgameWeaponLogicInstance {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct TScriptInterface<IApgameWeaponLogicInterface> UObjectPtr; // Offset: 0x08 // Size: 0x10
	char pad_0x18[0x18]; // Offset: 0x18 // Size: 0x18
};

// Object Name: ScriptStruct AClient.ApgameSignatureWeaponTestInitialData
// Size: 0x20 // Inherited bytes: 0x00
struct FApgameSignatureWeaponTestInitialData {
	// Fields
	int32_t LegendId; // Offset: 0x00 // Size: 0x04
	int32_t SignatureId; // Offset: 0x04 // Size: 0x04
	int32_t Level; // Offset: 0x08 // Size: 0x04
	int32_t ModelIndex; // Offset: 0x0c // Size: 0x04
	struct TArray<int32_t> FeatureIdList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameWeaponInstanceUniqueId
// Size: 0x0c // Inherited bytes: 0x00
struct FApgameWeaponInstanceUniqueId {
	// Fields
	struct FApgameWeaponInstanceId InstanceID; // Offset: 0x00 // Size: 0x02
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	struct TWeakObjectPtr<struct UApgameWeaponCoreComponent> CoreCompPtr; // Offset: 0x04 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameWeaponLogicInstanceDefinition
// Size: 0x10 // Inherited bytes: 0x00
struct FApgameWeaponLogicInstanceDefinition {
	// Fields
	struct FName InstanceName; // Offset: 0x00 // Size: 0x08
	struct FGameplayTag RegisterTag; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameWeaponLogicInstanceConfig
// Size: 0x01 // Inherited bytes: 0x00
struct FApgameWeaponLogicInstanceConfig {
	// Fields
	char bCanEverLogicTick : 1; // Offset: 0x00 // Size: 0x01
	char bStartWithLogicTickEnabled : 1; // Offset: 0x00 // Size: 0x01
	char bAllowLogicTickOnDS : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_3 : 5; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.ApgameWeaponAttachmentCosmeticData
// Size: 0xb0 // Inherited bytes: 0x00
struct FApgameWeaponAttachmentCosmeticData {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
	struct UMeshComponent* FppMesh; // Offset: 0x10 // Size: 0x08
	struct UMeshComponent* TppMesh; // Offset: 0x18 // Size: 0x08
	char pad_0x20[0x90]; // Offset: 0x20 // Size: 0x90
};

// Object Name: ScriptStruct AClient.ApgameWeaponAnimNotifyEvent_MagazineStart
// Size: 0x10 // Inherited bytes: 0x08
struct FApgameWeaponAnimNotifyEvent_MagazineStart : FApgameEventData {
	// Fields
	float LifeSpan; // Offset: 0x08 // Size: 0x04
	enum class ECommDiscardMagSkeletalMeshType MeshType; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct AClient.AttrModifyItemMem
// Size: 0x60 // Inherited bytes: 0x00
struct FAttrModifyItemMem {
	// Fields
	struct FAttrModifyItem AttrModifyItem; // Offset: 0x00 // Size: 0x60
};

// Object Name: ScriptStruct AClient.PerkAPEventArrayParams
// Size: 0x10 // Inherited bytes: 0x00
struct FPerkAPEventArrayParams {
	// Fields
	struct TArray<int32_t> PerkIDs; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BackpackItemInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FBackpackItemInfo {
	// Fields
	int32_t AmmoID; // Offset: 0x00 // Size: 0x04
	int32_t count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillCDInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FSkillCDInfo {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x00 // Size: 0x14
};

// Object Name: ScriptStruct AClient.PlayerStatePartInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FPlayerStatePartInfo {
	// Fields
	uint16_t DyingCount; // Offset: 0x00 // Size: 0x02
	uint16_t DyingTimeoutSec; // Offset: 0x02 // Size: 0x02
	uint16_t DyingRealtimeSec; // Offset: 0x04 // Size: 0x02
	uint16_t RespawningTimeoutSec; // Offset: 0x06 // Size: 0x02
	uint16_t RespawningRealtimeSec; // Offset: 0x08 // Size: 0x02
	uint16_t ShownRespawningTimeoutSec; // Offset: 0x0a // Size: 0x02
	uint16_t ShownRespawningRealtimeSec; // Offset: 0x0c // Size: 0x02
	uint16_t RespawnTeammateEndSign; // Offset: 0x0e // Size: 0x02
	uint16_t RescuingEndSign; // Offset: 0x10 // Size: 0x02
	enum class EPlayerBattleBehState CurrentBattleBehState; // Offset: 0x12 // Size: 0x01
	enum class EPlayerBattleBehState PreviousBattleBehState; // Offset: 0x13 // Size: 0x01
	enum class EPlayerBannerState CurrentBannerState; // Offset: 0x14 // Size: 0x01
	enum class EPlayerNextLifeRespawnState CurrentNextLifeRespawnState; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
	struct FVector ServerLocation; // Offset: 0x18 // Size: 0x0c
	float RescueTimeSec; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.TeammateItemDataList
// Size: 0x10 // Inherited bytes: 0x00
struct FTeammateItemDataList {
	// Fields
	struct TArray<struct FTeammateItemData> DataList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AddTombBoxSyncData
// Size: 0x18 // Inherited bytes: 0x00
struct FAddTombBoxSyncData {
	// Fields
	struct APlayerTombBox* TombBox; // Offset: 0x00 // Size: 0x08
	struct AApexPlayerState* PlayerState; // Offset: 0x08 // Size: 0x08
	enum class ELastKillerFrom From; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct AClient.OpenTombBoxSyncData
// Size: 0x18 // Inherited bytes: 0x00
struct FOpenTombBoxSyncData {
	// Fields
	struct APlayerTombBox* TombBox; // Offset: 0x00 // Size: 0x08
	struct TArray<int32_t> OpenPlayerKeyList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PhaseBreachTargetInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FPhaseBreachTargetInfo {
	// Fields
	struct TArray<struct FVector> PosList; // Offset: 0x00 // Size: 0x10
	struct FVector StartPos; // Offset: 0x10 // Size: 0x0c
	struct FVector EndPos; // Offset: 0x1c // Size: 0x0c
	struct FVector PathDir; // Offset: 0x28 // Size: 0x0c
	float PathDistance; // Offset: 0x34 // Size: 0x04
	bool bSuccess; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

// Object Name: ScriptStruct AClient.AttributeBasedFloat
// Size: 0xb8 // Inherited bytes: 0x00
struct FAttributeBasedFloat {
	// Fields
	struct FScalableFloat Coefficient; // Offset: 0x00 // Size: 0x20
	struct FScalableFloat PreMultiplyAdditiveValue; // Offset: 0x20 // Size: 0x20
	struct FScalableFloat PostMultiplyAdditiveValue; // Offset: 0x40 // Size: 0x20
	struct FAttributeCaptureDefinition BackingAttribute; // Offset: 0x60 // Size: 0x40
	struct FCurveTableRowHandle AttributeCurve; // Offset: 0xa0 // Size: 0x10
	enum class EAttributeBasedFloatCalculationType AttributeCalculationType; // Offset: 0xb0 // Size: 0x01
	enum class EModifyEvaluationChannel FinalChannel; // Offset: 0xb1 // Size: 0x01
	char pad_0xB2[0x6]; // Offset: 0xb2 // Size: 0x06
};

// Object Name: ScriptStruct AClient.ScalableFloat
// Size: 0x20 // Inherited bytes: 0x00
struct FScalableFloat {
	// Fields
	float Value; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FCurveTableRowHandle Curve; // Offset: 0x08 // Size: 0x10
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.AttributeModifierInfo
// Size: 0x1d0 // Inherited bytes: 0x00
struct FAttributeModifierInfo {
	// Fields
	struct FGameplayAttribute Attribute; // Offset: 0x00 // Size: 0x38
	enum class EAttributeModifyOperator ModifierOp; // Offset: 0x38 // Size: 0x01
	enum class EAttributeSumOperator SumOp; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x6]; // Offset: 0x3a // Size: 0x06
	struct FDynamicSumOp DynamicSumOp; // Offset: 0x40 // Size: 0x20
	struct FAttributeModifierMagnitude ModifierMagnitude; // Offset: 0x60 // Size: 0x168
	struct FModifyEvaluationChannelSettings EvaluationChannelSettings; // Offset: 0x1c8 // Size: 0x01
	char pad_0x1C9[0x7]; // Offset: 0x1c9 // Size: 0x07
};

// Object Name: ScriptStruct AClient.ModifyEvaluationChannelSettings
// Size: 0x01 // Inherited bytes: 0x00
struct FModifyEvaluationChannelSettings {
	// Fields
	enum class EModifyEvaluationChannel Channel; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.AttributeModifierMagnitude
// Size: 0x168 // Inherited bytes: 0x00
struct FAttributeModifierMagnitude {
	// Fields
	enum class EAttributeModifyMagnitudeCalculation MagnitudeCalculationType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FScalableFloat ScalableFloatMagnitude; // Offset: 0x08 // Size: 0x20
	struct FAttributeBasedFloat AttributeBasedMagnitude; // Offset: 0x28 // Size: 0xb8
	struct FCustomCalculationBasedFloat CustomMagnitude; // Offset: 0xe0 // Size: 0x78
	struct FSetByCallerFloat SetByCallerMagnitude; // Offset: 0x158 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SetByCallerFloat
// Size: 0x10 // Inherited bytes: 0x00
struct FSetByCallerFloat {
	// Fields
	struct FName DataName; // Offset: 0x00 // Size: 0x08
	struct FGameplayTag DataTag; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.CustomCalculationBasedFloat
// Size: 0x78 // Inherited bytes: 0x00
struct FCustomCalculationBasedFloat {
	// Fields
	struct UModifyMagnitudeCalculation* CalculationClassMagnitude; // Offset: 0x00 // Size: 0x08
	struct FScalableFloat Coefficient; // Offset: 0x08 // Size: 0x20
	struct FScalableFloat PreMultiplyAdditiveValue; // Offset: 0x28 // Size: 0x20
	struct FScalableFloat PostMultiplyAdditiveValue; // Offset: 0x48 // Size: 0x20
	struct FCurveTableRowHandle FinalLookupCurve; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DynamicSumOp
// Size: 0x20 // Inherited bytes: 0x00
struct FDynamicSumOp {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FCurveTableRowHandle Curve; // Offset: 0x08 // Size: 0x10
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.AttributeMetaData
// Size: 0x30 // Inherited bytes: 0x08
struct FAttributeMetaData : FTableRowBase {
	// Fields
	float BaseValue; // Offset: 0x08 // Size: 0x04
	float MinValue; // Offset: 0x0c // Size: 0x04
	float MaxValue; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString DerivedAttributeInfo; // Offset: 0x18 // Size: 0x10
	bool bCanStack; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct AClient.GameplayAttributeData
// Size: 0x10 // Inherited bytes: 0x00
struct FGameplayAttributeData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	float BaseValue; // Offset: 0x08 // Size: 0x04
	float CurrentValue; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ResBatchItem
// Size: 0x30 // Inherited bytes: 0x00
struct FResBatchItem {
	// Fields
	struct TWeakObjectPtr<struct UAttrModifyComponent> AttrModifyComp; // Offset: 0x00 // Size: 0x08
	struct FString AttrName; // Offset: 0x08 // Size: 0x10
	struct FSoftObjectPath ResPath; // Offset: 0x18 // Size: 0x18
};

// Object Name: ScriptStruct AClient.IncreasingAttrModifyItem
// Size: 0x70 // Inherited bytes: 0x60
struct FIncreasingAttrModifyItem : FAttrModifyItem {
	// Fields
	float IncreaseSpeed; // Offset: 0x60 // Size: 0x04
	bool IsPlusOperator; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
	float TotalIncreasedValue; // Offset: 0x68 // Size: 0x04
	bool bCompleted; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0x3]; // Offset: 0x6d // Size: 0x03
};

// Object Name: ScriptStruct AClient.WeaponOverrideAttrs
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponOverrideAttrs {
	// Fields
	float GameModeOverride_DeviationMoveModifier; // Offset: 0x00 // Size: 0x04
	float GameModeOverride_DeviationStanceJumpModifier; // Offset: 0x04 // Size: 0x04
	float GameModeOverride_MeleeDamageAmountModifier; // Offset: 0x08 // Size: 0x04
	float GameModeOverride_GrenadeDamageRadiusModifier; // Offset: 0x0c // Size: 0x04
	float GameModeOverride_GrenadeDamageAmountModifier; // Offset: 0x10 // Size: 0x04
	float GameModeOverride_GunsDamageAmountModifier; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LegendWeaponAttrModifyConfigList
// Size: 0x50 // Inherited bytes: 0x00
struct FLegendWeaponAttrModifyConfigList {
	// Fields
	struct TMap<struct FString, struct FWeaponAttrModifyConfig> WeaponAttrModifyConfigList; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.WeaponAttrModifyConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FWeaponAttrModifyConfig {
	// Fields
	struct TArray<struct FWeaponAttrModifyData> WeaponAttrModifiers; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.WeaponAttrModifyData
// Size: 0x20 // Inherited bytes: 0x00
struct FWeaponAttrModifyData {
	// Fields
	enum class EApexAttrType AttrType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString ModifyAttr; // Offset: 0x08 // Size: 0x10
	enum class EAttrOperator Op; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float ModifyValue; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AttributeModifierEvaluatedData
// Size: 0x50 // Inherited bytes: 0x00
struct FAttributeModifierEvaluatedData {
	// Fields
	struct FGameplayAttribute Attribute; // Offset: 0x00 // Size: 0x38
	enum class EAttributeModifyOperator ModifierOp; // Offset: 0x38 // Size: 0x01
	enum class EAttributeSumOperator SumOp; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x2]; // Offset: 0x3a // Size: 0x02
	float Magnitude; // Offset: 0x3c // Size: 0x04
	struct FActiveModifyHandle Handle; // Offset: 0x40 // Size: 0x08
	bool IsValid; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
};

// Object Name: ScriptStruct AClient.RemovePredictionKeyMap
// Size: 0x10 // Inherited bytes: 0x00
struct FRemovePredictionKeyMap {
	// Fields
	struct TArray<struct FRemovePredictionKey> RemovePredictionKeys; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RemovePredictionKey
// Size: 0x18 // Inherited bytes: 0x00
struct FRemovePredictionKey {
	// Fields
	struct FPredictionKey PredictionKey; // Offset: 0x00 // Size: 0x10
	int8_t RemoveModeMask; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct AClient.AudioRegionDat
// Size: 0x48 // Inherited bytes: 0x00
struct FAudioRegionDat {
	// Fields
	struct FString LevelName; // Offset: 0x00 // Size: 0x10
	struct FString DatFile; // Offset: 0x10 // Size: 0x10
	struct TSoftObjectPtr<UDataTable> DataTable; // Offset: 0x20 // Size: 0x28
};

// Object Name: ScriptStruct AClient.RiverAmbientWwiseData
// Size: 0x40 // Inherited bytes: 0x00
struct FRiverAmbientWwiseData {
	// Fields
	struct UAkAudioEvent* RiverEvent; // Offset: 0x00 // Size: 0x08
	struct UAkAudioBank* RiverBank; // Offset: 0x08 // Size: 0x08
	struct FString RiverRtpc; // Offset: 0x10 // Size: 0x10
	struct UAkAudioEvent* MagmaEvent; // Offset: 0x20 // Size: 0x08
	struct UAkAudioBank* MagmaBank; // Offset: 0x28 // Size: 0x08
	struct FString MagmaRtpc; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AudioRegionData
// Size: 0x30 // Inherited bytes: 0x08
struct FAudioRegionData : FTableRowBase {
	// Fields
	int32_t RegionID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FAudioRegionWwiseData> WwiseData; // Offset: 0x10 // Size: 0x10
	struct TArray<struct UAkAudioEvent*> WwiseEvent; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AudioRegionWwiseData
// Size: 0x48 // Inherited bytes: 0x00
struct FAudioRegionWwiseData {
	// Fields
	bool bThirdPerson; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString SwitchGroup; // Offset: 0x08 // Size: 0x10
	struct FString SwitchState; // Offset: 0x18 // Size: 0x10
	struct FString StateGroup; // Offset: 0x28 // Size: 0x10
	struct FString StateName; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BulletImpactAutoTestData
// Size: 0x28 // Inherited bytes: 0x00
struct FBulletImpactAutoTestData {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.AutoTraceContext
// Size: 0x10 // Inherited bytes: 0x00
struct FAutoTraceContext {
	// Fields
	struct FString TraceFileName; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AutoTestLevelTreeConfig
// Size: 0x40 // Inherited bytes: 0x00
struct FAutoTestLevelTreeConfig {
	// Fields
	struct FSoftObjectPath FightTree; // Offset: 0x00 // Size: 0x18
	bool bLoop; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct FSoftObjectPath LevelPosDatas; // Offset: 0x20 // Size: 0x18
	int32_t RunNumber; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AutoChooseModeInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FAutoChooseModeInfo {
	// Fields
	int32_t BigMode; // Offset: 0x00 // Size: 0x04
	int32_t Type; // Offset: 0x04 // Size: 0x04
	int32_t ConcreteMode; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MeshSynData
// Size: 0x38 // Inherited bytes: 0x00
struct FMeshSynData {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x10
	int32_t gender; // Offset: 0x10 // Size: 0x04
	enum class ESyncOperation OperationType; // Offset: 0x14 // Size: 0x01
	enum class EAttachSocketType SlotType; // Offset: 0x15 // Size: 0x01
	enum class EOpticalSocketType SubSlotType; // Offset: 0x16 // Size: 0x01
	char pad_0x17[0x1]; // Offset: 0x17 // Size: 0x01
	int32_t HideState; // Offset: 0x18 // Size: 0x04
	int32_t ReplaceState; // Offset: 0x1c // Size: 0x04
	struct FItemDefineID AdditionDefineID; // Offset: 0x20 // Size: 0x10
	bool bPatch; // Offset: 0x30 // Size: 0x01
	bool bDefaultAttach; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
};

// Object Name: ScriptStruct AClient.MeshData
// Size: 0x88 // Inherited bytes: 0x00
struct FMeshData {
	// Fields
	struct UStaticMesh* stMesh; // Offset: 0x00 // Size: 0x08
	struct USkeletalMesh* skMesh; // Offset: 0x08 // Size: 0x08
	struct UMaterialInstance* matIns; // Offset: 0x10 // Size: 0x08
	struct TArray<struct UMaterialInstance*> additionalMats; // Offset: 0x18 // Size: 0x10
	enum class EMeshTypes MeshType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct TArray<int32_t> hiddenSlots; // Offset: 0x30 // Size: 0x10
	struct TArray<int32_t> doHiddenSlots; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FReplacedSlotInfo> replacedSlots; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FHideBoneData> hideBoneSlots; // Offset: 0x60 // Size: 0x10
	struct FItemDefineID definedID; // Offset: 0x70 // Size: 0x10
	enum class EAvatarSubSlot subSlot; // Offset: 0x80 // Size: 0x01
	bool functionValid; // Offset: 0x81 // Size: 0x01
	char pad_0x82[0x6]; // Offset: 0x82 // Size: 0x06
};

// Object Name: ScriptStruct AClient.HideBoneData
// Size: 0x0c // Inherited bytes: 0x00
struct FHideBoneData {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.ReplacedSlotInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FReplacedSlotInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ItemRule
// Size: 0x0c // Inherited bytes: 0x00
struct FItemRule {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	int32_t MaxCount; // Offset: 0x04 // Size: 0x04
	int32_t ProgressBarCount; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CharacterParticleRes
// Size: 0x20 // Inherited bytes: 0x00
struct FCharacterParticleRes {
	// Fields
	struct UParticleSystem* ParticleRes; // Offset: 0x00 // Size: 0x08
	struct FName AttachSocket; // Offset: 0x08 // Size: 0x08
	struct FVector Offset; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AvatarPendantConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FAvatarPendantConfig {
	// Fields
	struct FTransform SocketRelativeTransform; // Offset: 0x00 // Size: 0x30
	struct FVector AngularLimitsMin; // Offset: 0x30 // Size: 0x0c
	struct FVector AngularLimitsMax; // Offset: 0x3c // Size: 0x0c
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BodyAttachmentConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FBodyAttachmentConfig {
	// Fields
	struct FText AttachmentID; // Offset: 0x00 // Size: 0x18
	struct TArray<struct FBodyAttachmentAttrModify> BodyAttachmentAttrModifiers; // Offset: 0x18 // Size: 0x10
	struct UModifyAttributeData* ModifyAttributeDataClass; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BodyAttachmentAttrModify
// Size: 0x18 // Inherited bytes: 0x00
struct FBodyAttachmentAttrModify {
	// Fields
	struct FString ModifyAttr; // Offset: 0x00 // Size: 0x10
	enum class EAttrOperator Op; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float ModifyValue; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AvatarItemData
// Size: 0x100 // Inherited bytes: 0xe0
struct FAvatarItemData : FBattleItemData {
	// Fields
	struct USkeletalMesh* SkeletalMesh; // Offset: 0xe0 // Size: 0x08
	struct UStaticMesh* StaticMesh; // Offset: 0xe8 // Size: 0x08
	struct UMaterialInstance* matInst; // Offset: 0xf0 // Size: 0x08
	int32_t MeshType; // Offset: 0xf8 // Size: 0x04
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
};

// Object Name: ScriptStruct AClient.MaterialSet
// Size: 0x30 // Inherited bytes: 0x00
struct FMaterialSet {
	// Fields
	struct TSoftObjectPtr<UMaterialInterface> targetMat; // Offset: 0x00 // Size: 0x28
	enum class EAvatarSlotType TargetSlot; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct AClient.IncNetArray
// Size: 0x20 // Inherited bytes: 0x00
struct FIncNetArray {
	// Fields
	struct TArray<struct FNetArrayUnit> incArray; // Offset: 0x00 // Size: 0x10
	struct TArray<int32_t> unusePool; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.NetArrayUnit
// Size: 0x50 // Inherited bytes: 0x00
struct FNetArrayUnit {
	// Fields
	struct FBattleItemNet Unit; // Offset: 0x00 // Size: 0x48
	bool markDelete; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
};

// Object Name: ScriptStruct AClient.BattleItemNet
// Size: 0x48 // Inherited bytes: 0x00
struct FBattleItemNet {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x10
	int32_t count; // Offset: 0x10 // Size: 0x04
	bool bEquipping; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FItemAssociation> Associations; // Offset: 0x28 // Size: 0x10
	bool bCanUsable; // Offset: 0x38 // Size: 0x01
	bool bBackpackInclude; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x2]; // Offset: 0x3a // Size: 0x02
	int32_t DeriveID; // Offset: 0x3c // Size: 0x04
	bool Fixed; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct AClient.ItemOperationData
// Size: 0x20 // Inherited bytes: 0x00
struct FItemOperationData {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x10
	enum class EBattleItemOperationType OperationType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t Reason; // Offset: 0x14 // Size: 0x04
	int32_t count; // Offset: 0x18 // Size: 0x04
	enum class EBattleItemOperationFailedReason OperationFailedReason; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct AClient.UTSkillOnItemStruct
// Size: 0x30 // Inherited bytes: 0x00
struct FUTSkillOnItemStruct {
	// Fields
	struct TSoftClassPtr<UObject> SkillTemplate; // Offset: 0x00 // Size: 0x28
	int32_t SkillHandle; // Offset: 0x28 // Size: 0x04
	bool NeedTips; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: ScriptStruct AClient.WeaponAttachmentDefaultResPath
// Size: 0x50 // Inherited bytes: 0x00
struct FWeaponAttachmentDefaultResPath {
	// Fields
	struct TMap<enum class EAttachSocketType, struct FString> ResMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.WeaponAttachmentConfig
// Size: 0xa0 // Inherited bytes: 0x00
struct FWeaponAttachmentConfig {
	// Fields
	enum class EAttachSocketType AttachmentSocketType; // Offset: 0x00 // Size: 0x01
	enum class EOpticalSocketType subSlot; // Offset: 0x01 // Size: 0x01
	bool bCanZoom; // Offset: 0x02 // Size: 0x01
	enum class EOpticalSocketType ZoomSlot; // Offset: 0x03 // Size: 0x01
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FWeaponMeshCfg MeshPackage; // Offset: 0x08 // Size: 0x90
	struct UAkAudioEvent* UseAudioEvent; // Offset: 0x98 // Size: 0x08
};

// Object Name: ScriptStruct AClient.WeaponMeshCfg
// Size: 0x90 // Inherited bytes: 0x00
struct FWeaponMeshCfg {
	// Fields
	struct TSoftObjectPtr<USkeletalMesh> skMesh; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<USkeletalMesh> skMeshLod; // Offset: 0x28 // Size: 0x28
	struct TSoftClassPtr<UObject> Weapon3DUI; // Offset: 0x50 // Size: 0x28
	struct TArray<struct FWeapon3DUIActorIdPair> SpecialWeapon3DUI; // Offset: 0x78 // Size: 0x10
	struct FName SocketName; // Offset: 0x88 // Size: 0x08
};

// Object Name: ScriptStruct AClient.Weapon3DUIActorIdPair
// Size: 0x30 // Inherited bytes: 0x00
struct FWeapon3DUIActorIdPair {
	// Fields
	int32_t WeaponID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TSoftClassPtr<UObject> Special3DUI; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct AClient.UIWidgetRes
// Size: 0x50 // Inherited bytes: 0x00
struct FUIWidgetRes {
	// Fields
	struct UUserWidget* UserWidget; // Offset: 0x00 // Size: 0x08
	struct FName AttachSocket; // Offset: 0x08 // Size: 0x08
	struct FTransform Trans; // Offset: 0x10 // Size: 0x30
	struct FVector2D DrawSize; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ParticleRes
// Size: 0x10 // Inherited bytes: 0x00
struct FParticleRes {
	// Fields
	struct UParticleSystem* ParticleRes; // Offset: 0x00 // Size: 0x08
	struct FName AttachSocket; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.WeaponPartInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FWeaponPartInfo {
	// Fields
	struct UBackpackItemUserWidget* WidgetInstance; // Offset: 0x00 // Size: 0x08
	struct FString DefaultIconName; // Offset: 0x08 // Size: 0x10
	int32_t SocketType; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattleBannerInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FBattleBannerInfo {
	// Fields
	int32_t SeqIndex; // Offset: 0x00 // Size: 0x04
	enum class EScreenState StateType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.BattlefieldPlayerKillMessage
// Size: 0x70 // Inherited bytes: 0x00
struct FBattlefieldPlayerKillMessage {
	// Fields
	struct FBattlefieldPlayerInfo KillerInfo; // Offset: 0x00 // Size: 0x20
	struct TArray<uint32_t> AssisterPlayerKeys; // Offset: 0x20 // Size: 0x10
	struct FBattlefieldPlayerInfo VictimInfo; // Offset: 0x30 // Size: 0x20
	int32_t DamageType; // Offset: 0x50 // Size: 0x04
	int32_t WeaponID; // Offset: 0x54 // Size: 0x04
	int32_t WeaponSkinID; // Offset: 0x58 // Size: 0x04
	int32_t KillMsgSkinID; // Offset: 0x5c // Size: 0x04
	bool bHeadShot; // Offset: 0x60 // Size: 0x01
	bool bBlindSnipe; // Offset: 0x61 // Size: 0x01
	bool bShootThroughSmoke; // Offset: 0x62 // Size: 0x01
	char pad_0x63[0x1]; // Offset: 0x63 // Size: 0x01
	int32_t ComboKill; // Offset: 0x64 // Size: 0x04
	bool bKillLeader; // Offset: 0x68 // Size: 0x01
	bool IsRevenge; // Offset: 0x69 // Size: 0x01
	enum class EPlayerKillMessageType MessageType; // Offset: 0x6a // Size: 0x01
	enum class EKillKingMessageType KillKingMessageType; // Offset: 0x6b // Size: 0x01
	int32_t KillCount; // Offset: 0x6c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattlefieldDelegateStruct
// Size: 0x10 // Inherited bytes: 0x00
struct FBattlefieldDelegateStruct {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BattlefieldMsgActiveWidgets
// Size: 0x10 // Inherited bytes: 0x00
struct FBattlefieldMsgActiveWidgets {
	// Fields
	struct UBattlefieldMsgItem_PlayerKill* MainUI; // Offset: 0x00 // Size: 0x08
	struct UUserWidget* AnimUI; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BattlefieldMsgWidgetCache
// Size: 0x18 // Inherited bytes: 0x00
struct FBattlefieldMsgWidgetCache {
	// Fields
	struct TArray<struct UUserWidget*> CacheList; // Offset: 0x00 // Size: 0x10
	bool bNotClean; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct AClient.WeaponAttachTableData
// Size: 0x2c // Inherited bytes: 0x00
struct FWeaponAttachTableData {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	struct FName MuzzleIconForWeaponUI; // Offset: 0x04 // Size: 0x08
	struct FName MagIconForWeaponUI; // Offset: 0x0c // Size: 0x08
	struct FName OpticalIconForWeaponUI; // Offset: 0x14 // Size: 0x08
	struct FName StockIconForWeaponUI; // Offset: 0x1c // Size: 0x08
	struct FName HopUpIconForWeaponUI; // Offset: 0x24 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PickupProposeData
// Size: 0x1b0 // Inherited bytes: 0x00
struct FPickupProposeData {
	// Fields
	struct TArray<struct FPickupFirstCount> pickFirst; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FPickupFirstList> pickFistList; // Offset: 0x10 // Size: 0x10
	int32_t closeSubType; // Offset: 0x20 // Size: 0x04
	int32_t crossbowSubType; // Offset: 0x24 // Size: 0x04
	int32_t pistolSubType; // Offset: 0x28 // Size: 0x04
	int32_t gunType; // Offset: 0x2c // Size: 0x04
	struct TArray<int32_t> specialTypeList; // Offset: 0x30 // Size: 0x10
	int32_t lens2ID; // Offset: 0x40 // Size: 0x04
	int32_t lens3ID; // Offset: 0x44 // Size: 0x04
	int32_t lens4ID; // Offset: 0x48 // Size: 0x04
	int32_t lens6ID; // Offset: 0x4c // Size: 0x04
	int32_t lens8ID; // Offset: 0x50 // Size: 0x04
	int32_t ScopeSubType; // Offset: 0x54 // Size: 0x04
	int32_t ID2Type; // Offset: 0x58 // Size: 0x04
	int32_t pistolClipSubType; // Offset: 0x5c // Size: 0x04
	int32_t SubMachineGunClipSubType; // Offset: 0x60 // Size: 0x04
	int32_t SniperClipSubType; // Offset: 0x64 // Size: 0x04
	int32_t RifleClipSubType; // Offset: 0x68 // Size: 0x04
	int32_t gasSubID; // Offset: 0x6c // Size: 0x04
	int32_t backSubType; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct TArray<int32_t> back3IDList; // Offset: 0x78 // Size: 0x10
	struct TArray<int32_t> BandageIDList; // Offset: 0x88 // Size: 0x10
	struct TArray<int32_t> EnergyDrinksIDList; // Offset: 0x98 // Size: 0x10
	struct TArray<int32_t> AdrenalineIDList; // Offset: 0xa8 // Size: 0x10
	struct TArray<int32_t> AnodyneIDList; // Offset: 0xb8 // Size: 0x10
	struct TArray<int32_t> Medical1IDList; // Offset: 0xc8 // Size: 0x10
	struct TArray<int32_t> Medical2IDList; // Offset: 0xd8 // Size: 0x10
	struct TArray<int32_t> ZhenBaoDanList; // Offset: 0xe8 // Size: 0x10
	struct TArray<int32_t> YanWuDanList; // Offset: 0xf8 // Size: 0x10
	struct TArray<int32_t> RanShaoPingList; // Offset: 0x108 // Size: 0x10
	struct TArray<int32_t> ShouLeiList; // Offset: 0x118 // Size: 0x10
	struct TArray<int32_t> BrickList; // Offset: 0x128 // Size: 0x10
	struct TArray<int32_t> IconList; // Offset: 0x138 // Size: 0x10
	struct TArray<int32_t> ElectronicList; // Offset: 0x148 // Size: 0x10
	int32_t DefaultMedicineNum; // Offset: 0x158 // Size: 0x04
	int32_t LightBullet; // Offset: 0x15c // Size: 0x04
	int32_t HeavyBullet; // Offset: 0x160 // Size: 0x04
	int32_t EnergyBullet; // Offset: 0x164 // Size: 0x04
	int32_t ShotgunBullet; // Offset: 0x168 // Size: 0x04
	int32_t koujing12ID; // Offset: 0x16c // Size: 0x04
	int32_t magenandanyao300ID; // Offset: 0x170 // Size: 0x04
	int32_t boltID; // Offset: 0x174 // Size: 0x04
	int32_t DefaultBulletNum; // Offset: 0x178 // Size: 0x04
	int32_t helmetSubType; // Offset: 0x17c // Size: 0x04
	int32_t armorSubType; // Offset: 0x180 // Size: 0x04
	int32_t shieldSubType; // Offset: 0x184 // Size: 0x04
	int32_t ScoreItemSubType; // Offset: 0x188 // Size: 0x04
	char pad_0x18C[0x4]; // Offset: 0x18c // Size: 0x04
	struct TArray<int32_t> notDropItemIDList; // Offset: 0x190 // Size: 0x10
	int32_t CapacityThreshold; // Offset: 0x1a0 // Size: 0x04
	int32_t virtualitemid; // Offset: 0x1a4 // Size: 0x04
	int32_t revivalCardID; // Offset: 0x1a8 // Size: 0x04
	float revivalCardValidTime; // Offset: 0x1ac // Size: 0x04
};

// Object Name: ScriptStruct AClient.PickupFirstList
// Size: 0x10 // Inherited bytes: 0x00
struct FPickupFirstList {
	// Fields
	struct TArray<int32_t> pickFirstItem; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PickupFirstCount
// Size: 0x08 // Inherited bytes: 0x00
struct FPickupFirstCount {
	// Fields
	int32_t pickID; // Offset: 0x00 // Size: 0x04
	int32_t count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ItemRecordData
// Size: 0xe8 // Inherited bytes: 0x00
struct FItemRecordData {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	int32_t ItemType; // Offset: 0x04 // Size: 0x04
	int32_t ItemSubType; // Offset: 0x08 // Size: 0x04
	int32_t BPID; // Offset: 0x0c // Size: 0x04
	int32_t MaxCount; // Offset: 0x10 // Size: 0x04
	bool AutoEquipandDrop; // Offset: 0x14 // Size: 0x01
	bool Consumable; // Offset: 0x15 // Size: 0x01
	bool Equipable; // Offset: 0x16 // Size: 0x01
	char pad_0x17[0x1]; // Offset: 0x17 // Size: 0x01
	struct FText ItemName; // Offset: 0x18 // Size: 0x18
	struct FText ItemSimpleName; // Offset: 0x30 // Size: 0x18
	struct FString ItemBigIcon; // Offset: 0x48 // Size: 0x10
	struct FText ItemDesc; // Offset: 0x58 // Size: 0x18
	struct FString ItemSmallIcon; // Offset: 0x70 // Size: 0x10
	int32_t AssociationID; // Offset: 0x80 // Size: 0x04
	int32_t ItemQuality; // Offset: 0x84 // Size: 0x04
	int32_t SortingPriority; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct TArray<int32_t> Attach; // Offset: 0x90 // Size: 0x10
	struct TArray<struct FString> AttachTypeList; // Offset: 0xa0 // Size: 0x10
	int32_t BulletID; // Offset: 0xb0 // Size: 0x04
	int32_t ProposeBulletNum; // Offset: 0xb4 // Size: 0x04
	int32_t Durability; // Offset: 0xb8 // Size: 0x04
	int32_t AIFullVaule; // Offset: 0xbc // Size: 0x04
	float Weight; // Offset: 0xc0 // Size: 0x04
	int32_t ProgressBarCount; // Offset: 0xc4 // Size: 0x04
	int32_t ToolbarWeight; // Offset: 0xc8 // Size: 0x04
	bool IsAutoMark; // Offset: 0xcc // Size: 0x01
	char pad_0xCD[0x3]; // Offset: 0xcd // Size: 0x03
	struct FText ShotItemDesc; // Offset: 0xd0 // Size: 0x18
};

// Object Name: ScriptStruct AClient.BattleItemPickupInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FBattleItemPickupInfo {
	// Fields
	struct UObject* Source; // Offset: 0x00 // Size: 0x08
	int32_t count; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // Offset: 0x10 // Size: 0x10
	bool bAutoEquip; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct FBattleItemUseTarget AutoEquipTarget; // Offset: 0x28 // Size: 0x20
};

// Object Name: ScriptStruct AClient.BattleKillMessageItemResourcesFromTable
// Size: 0x18 // Inherited bytes: 0x00
struct FBattleKillMessageItemResourcesFromTable {
	// Fields
	struct FSoftObjectPath BgImage; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.BattleKillMessageContext
// Size: 0x28 // Inherited bytes: 0x00
struct FBattleKillMessageContext {
	// Fields
	enum class EBattleKillMessageType MsgType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	uint32_t PlayerKey; // Offset: 0x04 // Size: 0x04
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	int32_t WeaponSkinID; // Offset: 0x18 // Size: 0x04
	int32_t KillMsgSkinID; // Offset: 0x1c // Size: 0x04
	float Damage; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattleKillMessagePlayerInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FBattleKillMessagePlayerInfo {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BattleResultSkillTrackerData
// Size: 0x0c // Inherited bytes: 0x00
struct FBattleResultSkillTrackerData {
	// Fields
	int32_t SkillID; // Offset: 0x00 // Size: 0x04
	float SkillData; // Offset: 0x04 // Size: 0x04
	int32_t LegendId; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattleResultSkillUseRecord
// Size: 0x08 // Inherited bytes: 0x00
struct FBattleResultSkillUseRecord {
	// Fields
	int32_t SkillKey; // Offset: 0x00 // Size: 0x04
	int32_t SkillUseTimes; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattleResultLootItemsRecord
// Size: 0x0c // Inherited bytes: 0x00
struct FBattleResultLootItemsRecord {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t Quality; // Offset: 0x04 // Size: 0x04
	int32_t Num; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BattleAccountingInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FBattleAccountingInfo {
	// Fields
	struct FSoftClassPath ClassPath; // Offset: 0x00 // Size: 0x18
	struct FBattleStateInfo BattleStateInfo; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BattleStateInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FBattleStateInfo {
	// Fields
	struct TArray<struct UAkAudioEvent*> StateBGMs; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LegendLimitTips
// Size: 0x18 // Inherited bytes: 0x00
struct FLegendLimitTips {
	// Fields
	struct UUserWidget* Widget; // Offset: 0x00 // Size: 0x08
	struct TArray<int32_t> LegendIDs; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BinTickInterval
// Size: 0x08 // Inherited bytes: 0x00
struct FBinTickInterval {
	// Fields
	float Distance; // Offset: 0x00 // Size: 0x04
	float Interval; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BinDetectedBox
// Size: 0x18 // Inherited bytes: 0x00
struct FBinDetectedBox {
	// Fields
	struct FVector RelativeLocation; // Offset: 0x00 // Size: 0x0c
	struct FVector BoxExtent; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct AClient.SpatialBinConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FSpatialBinConfig {
	// Fields
	struct FName Name; // Offset: 0x00 // Size: 0x08
	int32_t Num; // Offset: 0x08 // Size: 0x04
	float GroupRate; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BlueBinGroupSet
// Size: 0x08 // Inherited bytes: 0x00
struct FBlueBinGroupSet {
	// Fields
	int32_t GroupID; // Offset: 0x00 // Size: 0x04
	float GroupRate; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BirdPoint
// Size: 0x18 // Inherited bytes: 0x00
struct FBirdPoint {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.WaypointClusterInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FWaypointClusterInfo {
	// Fields
	struct FVector ClusterPos; // Offset: 0x00 // Size: 0x0c
	int32_t NumPointsNear; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BirdClusterInfo
// Size: 0x01 // Inherited bytes: 0x00
struct FBirdClusterInfo {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.BirdCluster
// Size: 0x1c // Inherited bytes: 0x00
struct FBirdCluster {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x00 // Size: 0x1c
};

// Object Name: ScriptStruct AClient.RequstData
// Size: 0x14 // Inherited bytes: 0x00
struct FRequstData {
	// Fields
	int32_t RequstID; // Offset: 0x00 // Size: 0x04
	int32_t PlayerKey; // Offset: 0x04 // Size: 0x04
	int32_t WeaponID; // Offset: 0x08 // Size: 0x04
	float RequstTimeOut; // Offset: 0x0c // Size: 0x04
	bool bBuyRequstDone; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
};

// Object Name: ScriptStruct AClient.ActorArray
// Size: 0x10 // Inherited bytes: 0x00
struct FActorArray {
	// Fields
	struct TArray<struct TWeakObjectPtr<struct AActor>> ActorArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PropsWeaponPreloadBP
// Size: 0x10 // Inherited bytes: 0x00
struct FPropsWeaponPreloadBP {
	// Fields
	struct UObject* PropsWeaponBP; // Offset: 0x00 // Size: 0x08
	struct UObject* MissileWeaponBP; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.MLAIDropRsp
// Size: 0x28 // Inherited bytes: 0x00
struct FMLAIDropRsp {
	// Fields
	int32_t NextTickSec; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FMachineLearningAIDrop> Datas; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FMLAILevelRsp> Levels; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MLAILevelRsp
// Size: 0x10 // Inherited bytes: 0x00
struct FMLAILevelRsp {
	// Fields
	uint64_t UID; // Offset: 0x00 // Size: 0x08
	int32_t AILevel; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.MachineLearningAIDrop
// Size: 0x10 // Inherited bytes: 0x00
struct FMachineLearningAIDrop {
	// Fields
	uint64_t UID; // Offset: 0x00 // Size: 0x08
	int32_t DropSec; // Offset: 0x08 // Size: 0x04
	int32_t AILevel; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.MachineLearningPlayerDatas
// Size: 0x10 // Inherited bytes: 0x00
struct FMachineLearningPlayerDatas {
	// Fields
	struct TArray<struct FMachineLearningPlayerInfo> Datas; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MachineLearningPlayerInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FMachineLearningPlayerInfo {
	// Fields
	uint64_t UID; // Offset: 0x00 // Size: 0x08
	int32_t KillPlayerNum; // Offset: 0x08 // Size: 0x04
	int32_t KillAINum; // Offset: 0x0c // Size: 0x04
	int32_t Dmg; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<int32_t> EquipList; // Offset: 0x18 // Size: 0x10
	int32_t PosX; // Offset: 0x28 // Size: 0x04
	int32_t PosY; // Offset: 0x2c // Size: 0x04
	int32_t PosZ; // Offset: 0x30 // Size: 0x04
	int32_t TeamID; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ProbCondition
// Size: 0x48 // Inherited bytes: 0x00
struct FProbCondition {
	// Fields
	float Probability; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FBlackboardKeySelector LeftValue; // Offset: 0x08 // Size: 0x28
	enum class EValueComparer Comparer; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct FString RightValue; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AClient.HearEventScore
// Size: 0x10 // Inherited bytes: 0x00
struct FHearEventScore {
	// Fields
	enum class EAIHearingType HearingType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float MaxScore; // Offset: 0x04 // Size: 0x04
	float DistPerMeterDeviation; // Offset: 0x08 // Size: 0x04
	float AgeScore; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AIHearingConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FAIHearingConfig {
	// Fields
	enum class EAIHearingType HearingType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Score; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GuardTargetInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FGuardTargetInfo {
	// Fields
	struct FBlackboardKeySelector GuardTarget; // Offset: 0x00 // Size: 0x28
	struct TArray<struct FGuardTargetScore> TargetScoreVec; // Offset: 0x28 // Size: 0x10
	float EffectiveDistance; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.GuardTargetScore
// Size: 0x40 // Inherited bytes: 0x00
struct FGuardTargetScore {
	// Fields
	struct FSoftClassPath TargetTypeClass; // Offset: 0x00 // Size: 0x18
	float MemoryTime; // Offset: 0x18 // Size: 0x04
	float MaxScore; // Offset: 0x1c // Size: 0x04
	float NotInSightDeviation; // Offset: 0x20 // Size: 0x04
	float KnockDownDeviation; // Offset: 0x24 // Size: 0x04
	float DistPerMeterDeviation; // Offset: 0x28 // Size: 0x04
	struct FVector2D AttackScoreDeviation; // Offset: 0x2c // Size: 0x08
	struct FVector2D DamegeScoreDeviation; // Offset: 0x34 // Size: 0x08
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.TargetScore
// Size: 0x50 // Inherited bytes: 0x00
struct FTargetScore {
	// Fields
	struct FSoftClassPath TargetTypeClass; // Offset: 0x00 // Size: 0x18
	struct FVector MemoryTime; // Offset: 0x18 // Size: 0x0c
	float MaxScore; // Offset: 0x24 // Size: 0x04
	float NotInSightDeviation; // Offset: 0x28 // Size: 0x04
	float KnockDownDeviation; // Offset: 0x2c // Size: 0x04
	float DistPerMeterDeviation; // Offset: 0x30 // Size: 0x04
	struct FVector ScoreProtectTime; // Offset: 0x34 // Size: 0x0c
	struct FVector2D AttackScoreDeviation; // Offset: 0x40 // Size: 0x08
	struct FVector2D DamegeScoreDeviation; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SkillTrigerData
// Size: 0x0c // Inherited bytes: 0x00
struct FSkillTrigerData {
	// Fields
	int32_t SkillID; // Offset: 0x00 // Size: 0x04
	enum class EUTSkillEventType SkillEventType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	float Waiting; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CustomSpeed
// Size: 0x50 // Inherited bytes: 0x00
struct FCustomSpeed {
	// Fields
	float Probability; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UModifyAttributeData* Modifier; // Offset: 0x08 // Size: 0x08
	struct FGameplayAttribute Attribute; // Offset: 0x10 // Size: 0x38
	enum class EAttributeModifyOperator ModifierOp; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float float; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct AClient.HackNodeInstanceAction
// Size: 0x28 // Inherited bytes: 0x00
struct FHackNodeInstanceAction {
	// Fields
	struct FString NodeName; // Offset: 0x00 // Size: 0x10
	struct FName NodeProperty; // Offset: 0x10 // Size: 0x08
	struct FString NewValue; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CPPlayerControllers
// Size: 0x10 // Inherited bytes: 0x00
struct FCPPlayerControllers {
	// Fields
	struct TArray<struct ACapturePointPlayerController*> CPMembers; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CarePackageTickTriggerData
// Size: 0x10 // Inherited bytes: 0x00
struct FCarePackageTickTriggerData {
	// Fields
	float TriggerTime; // Offset: 0x00 // Size: 0x04
	int32_t TriggerIndex; // Offset: 0x04 // Size: 0x04
	struct FName TriggerName; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.LifelineCarePackage_PickupInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FLifelineCarePackage_PickupInfo {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	float ItemPercent; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CarePackageLootPerSide
// Size: 0x10 // Inherited bytes: 0x00
struct FCarePackageLootPerSide {
	// Fields
	struct TArray<struct FCarePackageLootTypeInfo> LootItemsPerSide; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CarePackageLootTypeInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FCarePackageLootTypeInfo {
	// Fields
	int32_t RandomCount; // Offset: 0x00 // Size: 0x04
	float ChosenProbability; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FLootZoneTypeInfo> LootItems; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LootZoneTypeInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FLootZoneTypeInfo {
	// Fields
	enum class FLootZoneType LootZoneType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString CustomZoneType; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CarePackage_PickupInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FCarePackage_PickupInfo {
	// Fields
	float Weight; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString SocketName; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CarePackageItemIDGroupData
// Size: 0x10 // Inherited bytes: 0x00
struct FCarePackageItemIDGroupData {
	// Fields
	struct TArray<int32_t> ItemIDGroup; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CarePackageCustomDoor
// Size: 0x48 // Inherited bytes: 0x00
struct FCarePackageCustomDoor {
	// Fields
	enum class ECarePackageDoorType DoorType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString TargetTableName; // Offset: 0x08 // Size: 0x10
	struct FString BackUpTableName; // Offset: 0x18 // Size: 0x10
	struct FString OtherTableName0; // Offset: 0x28 // Size: 0x10
	struct FString OtherTableName1; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CarePackageSocketData
// Size: 0xf8 // Inherited bytes: 0x00
struct FCarePackageSocketData {
	// Fields
	struct FName DefaultSocket; // Offset: 0x00 // Size: 0x08
	struct TMap<int32_t, struct FCarePackageIndexToSocketName> ItemTypeToSocketData; // Offset: 0x08 // Size: 0x50
	struct TMap<int32_t, struct FCarePackageIndexToSocketName> ItemSubTypeToSocketData; // Offset: 0x58 // Size: 0x50
	struct TMap<int32_t, struct FCarePackageIndexToSocketName> ItemIDToSocketData; // Offset: 0xa8 // Size: 0x50
};

// Object Name: ScriptStruct AClient.CarePackageIndexToSocketName
// Size: 0x10 // Inherited bytes: 0x00
struct FCarePackageIndexToSocketName {
	// Fields
	struct TArray<struct FName> IndexToSocketName; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CausticDirtyBombStatus
// Size: 0xb8 // Inherited bytes: 0x00
struct FCausticDirtyBombStatus {
	// Fields
	char pad_0x0[0xb8]; // Offset: 0x00 // Size: 0xb8
};

// Object Name: ScriptStruct AClient.DirtyBombReportData
// Size: 0x18 // Inherited bytes: 0x00
struct FDirtyBombReportData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.GasGrenadeReportData
// Size: 0x18 // Inherited bytes: 0x00
struct FGasGrenadeReportData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.Stage_ChapterLink
// Size: 0x18 // Inherited bytes: 0x00
struct FStage_ChapterLink {
	// Fields
	enum class EMGameModeStage GameStage; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FChapterBindItem> ChapterArr; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ChapterBindItem
// Size: 0xb0 // Inherited bytes: 0x00
struct FChapterBindItem {
	// Fields
	struct UChapterBase* ChapterClass; // Offset: 0x00 // Size: 0x08
	struct TMap<struct FString, struct FChapterType_Tracks> TrackBinds; // Offset: 0x08 // Size: 0x50
	struct UChapterEndCheck* EndCondition; // Offset: 0x58 // Size: 0x08
	struct TMap<struct FName, float> FloatArgs; // Offset: 0x60 // Size: 0x50
};

// Object Name: ScriptStruct AClient.AnimLoadHandle
// Size: 0x28 // Inherited bytes: 0x00
struct FAnimLoadHandle {
	// Fields
	uint32_t LoadId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FSoftObjectPath> RequestArray; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FAnimSoftObject> AnimAssets; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AnimSoftObject
// Size: 0x30 // Inherited bytes: 0x00
struct FAnimSoftObject {
	// Fields
	struct TSoftObjectPtr<UAnimationAsset> AnimSoftObjectPtr; // Offset: 0x00 // Size: 0x28
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct AClient.HeroAnimationDataSet
// Size: 0x28 // Inherited bytes: 0x00
struct FHeroAnimationDataSet {
	// Fields
	struct TSoftObjectPtr<UCharacterAnimDataAsset> AnimationData; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.WeaponAnimationData
// Size: 0x28 // Inherited bytes: 0x00
struct FWeaponAnimationData {
	// Fields
	enum class EWeaponAnimationType WeaponAnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString WeaponAnimName; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FWeaponPoseAnimation> PoseAnimList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.WeaponPoseAnimation
// Size: 0x40 // Inherited bytes: 0x00
struct FWeaponPoseAnimation {
	// Fields
	enum class ECharacterPoseType PoseType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString PoseName; // Offset: 0x08 // Size: 0x10
	struct TSoftObjectPtr<UAnimationAsset> PoseAnimSoftPtr; // Offset: 0x18 // Size: 0x28
};

// Object Name: ScriptStruct AClient.CharacterParachuteAnimData
// Size: 0x40 // Inherited bytes: 0x00
struct FCharacterParachuteAnimData {
	// Fields
	enum class ECharParachuteAnimType ParachuteType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString ParachuteAnimName; // Offset: 0x08 // Size: 0x10
	struct TSoftObjectPtr<UAnimationAsset> ParachuteAnimSoftPtr; // Offset: 0x18 // Size: 0x28
};

// Object Name: ScriptStruct AClient.CharacterJumpAnimData
// Size: 0x28 // Inherited bytes: 0x00
struct FCharacterJumpAnimData {
	// Fields
	enum class ECharacterJumpType JumpType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString JumpTypeName; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FChararacterJumpPhaseData> JumpPhaseList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ChararacterJumpPhaseData
// Size: 0x40 // Inherited bytes: 0x00
struct FChararacterJumpPhaseData {
	// Fields
	enum class ECharacterJumpPhase JumpPhase; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString JumpPhaseName; // Offset: 0x08 // Size: 0x10
	struct TSoftObjectPtr<UAnimationAsset> PhaseAnimSoftPtr; // Offset: 0x18 // Size: 0x28
};

// Object Name: ScriptStruct AClient.CharacterMovementAnimData
// Size: 0x28 // Inherited bytes: 0x00
struct FCharacterMovementAnimData {
	// Fields
	enum class ECharacterAnimType AnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString AnimTypeName; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FChararacterPoseAnimData> PoseAnimList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ChararacterPoseAnimData
// Size: 0x40 // Inherited bytes: 0x00
struct FChararacterPoseAnimData {
	// Fields
	enum class ECharacterPoseType PoseType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString PoseName; // Offset: 0x08 // Size: 0x10
	struct TSoftObjectPtr<UAnimationAsset> PoseAnimSoftPtr; // Offset: 0x18 // Size: 0x28
};

// Object Name: ScriptStruct AClient.WeightAnimLayer
// Size: 0x08 // Inherited bytes: 0x00
struct FWeightAnimLayer {
	// Fields
	int32_t LayerType; // Offset: 0x00 // Size: 0x04
	int32_t Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.InstancedBuffItem
// Size: 0x18 // Inherited bytes: 0x00
struct FInstancedBuffItem {
	// Fields
	int32_t BuffID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<float> BuffAddTimes; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BuffConfigItem
// Size: 0x28 // Inherited bytes: 0x00
struct FBuffConfigItem {
	// Fields
	float Duration; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int32_t> EffectViewIDs; // Offset: 0x08 // Size: 0x10
	enum class EMBuffOverlapType BuffOverlapType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	struct FName BuffName; // Offset: 0x1c // Size: 0x08
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RescueCameraParams
// Size: 0x1c // Inherited bytes: 0x00
struct FRescueCameraParams {
	// Fields
	float LerpTime; // Offset: 0x00 // Size: 0x04
	struct FVector FPPTargetValue; // Offset: 0x04 // Size: 0x0c
	struct FVector TPPTargetValue; // Offset: 0x10 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.AnimationBudgetParameters
// Size: 0x14 // Inherited bytes: 0x00
struct FAnimationBudgetParameters {
	// Fields
	float BudgetInMs; // Offset: 0x00 // Size: 0x04
	float MinQuality; // Offset: 0x04 // Size: 0x04
	int32_t MaxTickRate; // Offset: 0x08 // Size: 0x04
	int32_t InterpolationMaxRate; // Offset: 0x0c // Size: 0x04
	int32_t MaxTickedOffsreenComponents; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.DeathRagDollParams
// Size: 0x18 // Inherited bytes: 0x00
struct FDeathRagDollParams {
	// Fields
	float MassInKg; // Offset: 0x00 // Size: 0x04
	float LinearSpeed; // Offset: 0x04 // Size: 0x04
	float MaxLinearSpeed; // Offset: 0x08 // Size: 0x04
	float AngularSpeed; // Offset: 0x0c // Size: 0x04
	float MaxAngularSpeed; // Offset: 0x10 // Size: 0x04
	float GravityAlpha; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CharacterHiddenInVoid
// Size: 0x28 // Inherited bytes: 0x00
struct FCharacterHiddenInVoid {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.CharacterVoidParams
// Size: 0x04 // Inherited bytes: 0x00
struct FCharacterVoidParams {
	// Fields
	bool bCanSeeOtherInVoid; // Offset: 0x00 // Size: 0x01
	bool bCanSeeOtherVoidInVoid; // Offset: 0x01 // Size: 0x01
	bool bAutoSetCollision; // Offset: 0x02 // Size: 0x01
	bool bClearComponentOverlaps; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AClient.ServerPoint
// Size: 0x10 // Inherited bytes: 0x00
struct FServerPoint {
	// Fields
	bool bIsRayCastFloor; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector Location; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.ReplicatedMoveState
// Size: 0x2c // Inherited bytes: 0x00
struct FReplicatedMoveState {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	struct FVector WorldVelocity; // Offset: 0x18 // Size: 0x0c
	float SpeedLength; // Offset: 0x24 // Size: 0x04
	float SimulateServerTimeStamp; // Offset: 0x28 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ParachuteInputInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FParachuteInputInfo {
	// Fields
	float ThrottleInput; // Offset: 0x00 // Size: 0x04
	float SteerInput; // Offset: 0x04 // Size: 0x04
	char ParachuteState; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct AClient.StateAudioMap
// Size: 0x10 // Inherited bytes: 0x00
struct FStateAudioMap {
	// Fields
	struct FName SoundName; // Offset: 0x00 // Size: 0x08
	struct UApexAnimNotifySound* AnimNotifyClass; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.DramaCircleCfg
// Size: 0x10 // Inherited bytes: 0x00
struct FDramaCircleCfg {
	// Fields
	struct TArray<struct FDramaCircleWaveCfg> FDramaCircleWaveCfg; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DramaCircleWaveCfg
// Size: 0x20 // Inherited bytes: 0x00
struct FDramaCircleWaveCfg {
	// Fields
	struct FVector2D WhiteCircle; // Offset: 0x00 // Size: 0x08
	bool IsHaveAirdrop; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float AirdropWaitTime; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FDramaAirDropCfg> AirdropConfig; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DramaAirDropCfg
// Size: 0x40 // Inherited bytes: 0x00
struct FDramaAirDropCfg {
	// Fields
	struct FVector AirdropSpawnPoint; // Offset: 0x00 // Size: 0x0c
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<int32_t> ItemList1; // Offset: 0x10 // Size: 0x10
	struct TArray<int32_t> ItemList2; // Offset: 0x20 // Size: 0x10
	struct TArray<int32_t> ItemList3; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.FirstCircleCfg
// Size: 0x18 // Inherited bytes: 0x00
struct FFirstCircleCfg {
	// Fields
	bool bUseCustomWhiteCenter; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector2D WhiteCircleCenter; // Offset: 0x04 // Size: 0x08
	bool bPreInitBlueCircle; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float BluerCircleRadius; // Offset: 0x10 // Size: 0x04
	bool bConcentricCircles; // Offset: 0x14 // Size: 0x01
	bool IsPreInitCircleShowOnMiniMap; // Offset: 0x15 // Size: 0x01
	bool IsWhiteCircleNotBan; // Offset: 0x16 // Size: 0x01
	char pad_0x17[0x1]; // Offset: 0x17 // Size: 0x01
};

// Object Name: ScriptStruct AClient.CircleCfg
// Size: 0x58 // Inherited bytes: 0x00
struct FCircleCfg {
	// Fields
	float DelayTime; // Offset: 0x00 // Size: 0x04
	struct FCircleSoundStart WhiteCircleSoundStart; // Offset: 0x04 // Size: 0x10
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FCircleSoundDelay> BlueCircleCountDownSound; // Offset: 0x18 // Size: 0x10
	float BlueCircleStartLessenTime; // Offset: 0x28 // Size: 0x04
	struct FCircleSoundStart BlueCircleSoundStart; // Offset: 0x2c // Size: 0x10
	bool WhiteCircleNotBan; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	float LessenDuration; // Offset: 0x40 // Size: 0x04
	float WhiteCircleRadius; // Offset: 0x44 // Size: 0x04
	float WhiteOffset; // Offset: 0x48 // Size: 0x04
	float RadianPainValue; // Offset: 0x4c // Size: 0x04
	float RadianPainIntervalTime; // Offset: 0x50 // Size: 0x04
	enum class UCircleType CircleType; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
};

// Object Name: ScriptStruct AClient.CircleSoundStart
// Size: 0x10 // Inherited bytes: 0x00
struct FCircleSoundStart {
	// Fields
	float SoundDelayTime; // Offset: 0x00 // Size: 0x04
	int32_t SoundID1; // Offset: 0x04 // Size: 0x04
	int32_t SoundID2; // Offset: 0x08 // Size: 0x04
	int32_t SoundID3; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.CircleSoundDelay
// Size: 0x10 // Inherited bytes: 0x00
struct FCircleSoundDelay {
	// Fields
	int32_t SoundIDFar; // Offset: 0x00 // Size: 0x04
	int32_t SoundIDClose; // Offset: 0x04 // Size: 0x04
	float SoundDelayTime; // Offset: 0x08 // Size: 0x04
	float Distance; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ColosseumInvincibleActorData
// Size: 0x0c // Inherited bytes: 0x00
struct FColosseumInvincibleActorData {
	// Fields
	int32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	enum class ColosseumInvincibleStage Stage; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x7]; // Offset: 0x05 // Size: 0x07
};

// Object Name: ScriptStruct AClient.GenerateObjectData
// Size: 0x40 // Inherited bytes: 0x00
struct FGenerateObjectData {
	// Fields
	enum class EGenerateObjectType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector BoxLocation; // Offset: 0x04 // Size: 0x0c
	struct FRotator BoxRotation; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FLootZoneTypeInfo LootZoneTypeInfo; // Offset: 0x20 // Size: 0x18
	int32_t ItemNum; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.GenerateItemData
// Size: 0x30 // Inherited bytes: 0x00
struct FGenerateItemData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FLootZoneTypeInfo LootZoneTypeInfo; // Offset: 0x10 // Size: 0x18
	float Radius; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.CommonSignCacheInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FCommonSignCacheInfo {
	// Fields
	int32_t LegendId; // Offset: 0x00 // Size: 0x04
	int32_t CacheNum; // Offset: 0x04 // Size: 0x04
	struct FSoftClassPath SoftPath; // Offset: 0x08 // Size: 0x18
};

// Object Name: ScriptStruct AClient.CommonSignWidgetData
// Size: 0x10 // Inherited bytes: 0x00
struct FCommonSignWidgetData {
	// Fields
	struct TArray<struct TWeakObjectPtr<struct UCommonSignBaseItemWidget>> ItemArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.KillInfoRecordData
// Size: 0x38 // Inherited bytes: 0x00
struct FKillInfoRecordData {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
};

// Object Name: ScriptStruct AClient.ConditionalReplaceAnimData
// Size: 0x10 // Inherited bytes: 0x00
struct FConditionalReplaceAnimData {
	// Fields
	struct TArray<struct FConditionalSkillReplaceCharAnimData> ConditionalAnimDataList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ConditionalSkillReplaceCharAnimData
// Size: 0x30 // Inherited bytes: 0x00
struct FConditionalSkillReplaceCharAnimData {
	// Fields
	struct TArray<struct FCompositionCondition> Conditions; // Offset: 0x00 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimationAsset>> PoseAnimList; // Offset: 0x10 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimationAsset>> FPPPoseAnimList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CompositionCondition
// Size: 0x02 // Inherited bytes: 0x00
struct FCompositionCondition {
	// Fields
	enum class EConditionPoseType ConditionPose; // Offset: 0x00 // Size: 0x01
	enum class EConditionCharAnimOp Op; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.ConvenientKey
// Size: 0x10 // Inherited bytes: 0x00
struct FConvenientKey {
	// Fields
	uint64_t Key; // Offset: 0x00 // Size: 0x08
	int32_t Type; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.PrintLogStruct
// Size: 0x38 // Inherited bytes: 0x00
struct FPrintLogStruct {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
};

// Object Name: ScriptStruct AClient.ConveyCampGroup
// Size: 0x0c // Inherited bytes: 0x00
struct FConveyCampGroup {
	// Fields
	int32_t BoxNum; // Offset: 0x00 // Size: 0x04
	int32_t BoxSpawnInterval; // Offset: 0x04 // Size: 0x04
	int32_t NextGroupInterval; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AKAudioEventArgs
// Size: 0x10 // Inherited bytes: 0x00
struct FAKAudioEventArgs {
	// Fields
	struct UAkAudioEvent* Audio; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.AreaCostConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FAreaCostConfig {
	// Fields
	float EnteringCost; // Offset: 0x00 // Size: 0x04
	float Cost; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BuffVolumeArea
// Size: 0x10 // Inherited bytes: 0x00
struct FBuffVolumeArea {
	// Fields
	int32_t BuffID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UNavArea* AreaClass; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.CustomCollisionInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FCustomCollisionInfo {
	// Fields
	enum class ECustomCollisionType CollisionType; // Offset: 0x00 // Size: 0x01
	bool bGeneratorListenEvent; // Offset: 0x01 // Size: 0x01
	bool bGeneratorOverlapBrush; // Offset: 0x02 // Size: 0x01
	bool bTraceUseObjectType; // Offset: 0x03 // Size: 0x01
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<enum class EObjectTypeQuery> TraceObjectTypes; // Offset: 0x08 // Size: 0x10
	bool bOneFrameBeginEndOverlapSplit; // Offset: 0x18 // Size: 0x01
	bool bCheckInServer; // Offset: 0x19 // Size: 0x01
	bool bCheckInAutonomous; // Offset: 0x1a // Size: 0x01
	bool bCheckInSimulate; // Offset: 0x1b // Size: 0x01
	float CheckInterval; // Offset: 0x1c // Size: 0x04
	char pad_0x20[0x10]; // Offset: 0x20 // Size: 0x10
	struct TArray<struct UPrimitiveComponent*> OverlappedComps; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x18]; // Offset: 0x40 // Size: 0x18
};

// Object Name: ScriptStruct AClient.CheckTimer
// Size: 0x08 // Inherited bytes: 0x00
struct FCheckTimer {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.TextureData
// Size: 0x2c // Inherited bytes: 0x00
struct FTextureData {
	// Fields
	char pad_0x0[0x2c]; // Offset: 0x00 // Size: 0x2c
};

// Object Name: ScriptStruct AClient.DamageNumSimulateData
// Size: 0x0c // Inherited bytes: 0x00
struct FDamageNumSimulateData {
	// Fields
	int32_t Damage; // Offset: 0x00 // Size: 0x04
	bool bHeadShot; // Offset: 0x04 // Size: 0x01
	bool IsShieldDamage; // Offset: 0x05 // Size: 0x01
	bool IsShieldBroken; // Offset: 0x06 // Size: 0x01
	char pad_0x7[0x1]; // Offset: 0x07 // Size: 0x01
	int32_t ShieldLevel; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.DamageNumInfo
// Size: 0x98 // Inherited bytes: 0x00
struct FDamageNumInfo {
	// Fields
	char pad_0x0[0x98]; // Offset: 0x00 // Size: 0x98
};

// Object Name: ScriptStruct AClient.BreakShieldSpirits
// Size: 0x10 // Inherited bytes: 0x00
struct FBreakShieldSpirits {
	// Fields
	struct TArray<struct UTexture2D*> AnimSpirits; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DamageNumColor
// Size: 0xc0 // Inherited bytes: 0x00
struct FDamageNumColor {
	// Fields
	struct FLinearColor BodyDamageColor; // Offset: 0x00 // Size: 0x10
	struct FLinearColor BodyDamageOutLineColor; // Offset: 0x10 // Size: 0x10
	struct FLinearColor HeadDamageColor; // Offset: 0x20 // Size: 0x10
	struct FLinearColor HeadDamageOutLineColor; // Offset: 0x30 // Size: 0x10
	struct FLinearColor ShieldDamageColor; // Offset: 0x40 // Size: 0x10
	struct FLinearColor SkillActorDamageColor; // Offset: 0x50 // Size: 0x10
	struct FLinearColor SkillActorDamageOutLineColor; // Offset: 0x60 // Size: 0x10
	struct TMap<enum class EApexCharacterShieldLevel, struct FLinearColor> ShieldColorMap; // Offset: 0x70 // Size: 0x50
};

// Object Name: ScriptStruct AClient.CommonReportDataKeyInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FCommonReportDataKeyInfo {
	// Fields
	struct TArray<struct FString> CommonReportDataKeys; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CommonReportDataInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FCommonReportDataInfo {
	// Fields
	enum class EDataStatisticsType DataType; // Offset: 0x00 // Size: 0x01
	enum class EReportMode ReportMode; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct TMap<struct FString, float> DataMap; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct AClient.CommonReportData
// Size: 0x18 // Inherited bytes: 0x00
struct FCommonReportData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.PlayerDoorData
// Size: 0x30 // Inherited bytes: 0x00
struct FPlayerDoorData {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
};

// Object Name: ScriptStruct AClient.SwitchCameraData
// Size: 0x0c // Inherited bytes: 0x00
struct FSwitchCameraData {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.SecBasic
// Size: 0x40 // Inherited bytes: 0x00
struct FSecBasic {
	// Fields
	struct FString dtEventTime; // Offset: 0x00 // Size: 0x10
	struct FString SecReportData; // Offset: 0x10 // Size: 0x10
	struct FString RoleID; // Offset: 0x20 // Size: 0x10
	struct FString ClientStartTime; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.OBCacheData
// Size: 0x58 // Inherited bytes: 0x40
struct FOBCacheData : FSecBasic {
	// Fields
	struct FString WatchRoleID; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.DeathBoxFlyerData
// Size: 0x20 // Inherited bytes: 0x00
struct FDeathBoxFlyerData {
	// Fields
	struct FName CreepQuality; // Offset: 0x00 // Size: 0x08
	int32_t LootSpawnCount; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FName> LootTableNames; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RepDeathFlyerEscape
// Size: 0x10 // Inherited bytes: 0x00
struct FRepDeathFlyerEscape {
	// Fields
	float Sequence; // Offset: 0x00 // Size: 0x04
	struct FVector Loc; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.DispatchableAction_SkillOrder
// Size: 0x08 // Inherited bytes: 0x00
struct FDispatchableAction_SkillOrder {
	// Fields
	enum class EUTSkillEventType EventType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float NextOrderTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MatConfig
// Size: 0x40 // Inherited bytes: 0x00
struct FMatConfig {
	// Fields
	struct TArray<struct UMaterialInstanceDynamic*> DynamicMatList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> DynamicMatParams; // Offset: 0x10 // Size: 0x10
	bool bOnlyAimShow; // Offset: 0x20 // Size: 0x01
	bool bOnlyNotEquipShow; // Offset: 0x21 // Size: 0x01
	char pad_0x22[0x6]; // Offset: 0x22 // Size: 0x06
	struct UMeshComponent* MeshComponent; // Offset: 0x28 // Size: 0x08
	struct UTextRenderComponent* TextRenderComponent; // Offset: 0x30 // Size: 0x08
	struct UWidgetComponent* WidgetComponent; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct AClient.RepDoorActionCurve
// Size: 0x1c // Inherited bytes: 0x00
struct FRepDoorActionCurve {
	// Fields
	int32_t Sequence; // Offset: 0x00 // Size: 0x04
	float Time; // Offset: 0x04 // Size: 0x04
	float NextTime; // Offset: 0x08 // Size: 0x04
	struct FVector Location; // Offset: 0x0c // Size: 0x0c
	bool IsHit; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
};

// Object Name: ScriptStruct AClient.RepDoorRot
// Size: 0x14 // Inherited bytes: 0x00
struct FRepDoorRot {
	// Fields
	int32_t Sequence; // Offset: 0x00 // Size: 0x04
	float Time; // Offset: 0x04 // Size: 0x04
	float Yaw; // Offset: 0x08 // Size: 0x04
	float ImpusleStrength; // Offset: 0x0c // Size: 0x04
	bool IsClosed; // Offset: 0x10 // Size: 0x01
	bool IsTotalOpen; // Offset: 0x11 // Size: 0x01
	bool IsBlock; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x1]; // Offset: 0x13 // Size: 0x01
};

// Object Name: ScriptStruct AClient.DrugRecommendDefine
// Size: 0x18 // Inherited bytes: 0x00
struct FDrugRecommendDefine {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	float HealthRateMin; // Offset: 0x04 // Size: 0x04
	float HealthRateMax; // Offset: 0x08 // Size: 0x04
	float ShieldRateMin; // Offset: 0x0c // Size: 0x04
	float ShieldRateMax; // Offset: 0x10 // Size: 0x04
	bool EquipShieldLevel4; // Offset: 0x14 // Size: 0x01
	enum class EDrugRecommendType DrugRecommendType; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
};

// Object Name: ScriptStruct AClient.DynamicItemSpawnConfig
// Size: 0x40 // Inherited bytes: 0x00
struct FDynamicItemSpawnConfig {
	// Fields
	enum class EDynamicItemType ItemType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct AActor* DynamicItemClass; // Offset: 0x08 // Size: 0x08
	struct AActor* EditorDynamicItemClass; // Offset: 0x10 // Size: 0x08
	enum class EDynamicItemSpawnType DynamicItemSpawnType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct TArray<struct UDynamicItemSpawnFilterBase*> SpawnFilterArray; // Offset: 0x20 // Size: 0x10
	struct TArray<struct UDynamicItemSpawnerAbstract*> DynamicItemObjDataArray; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DynamicItemData
// Size: 0x70 // Inherited bytes: 0x00
struct FDynamicItemData {
	// Fields
	enum class EDynamicItemType ItemType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector Pos; // Offset: 0x04 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x10 // Size: 0x0c
	int32_t Index; // Offset: 0x1c // Size: 0x04
	struct FTransform Offset; // Offset: 0x20 // Size: 0x30
	struct FLootZoneTypeInfo LootZoneTypeInfo; // Offset: 0x50 // Size: 0x18
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SingleDirLightInfos
// Size: 0x90 // Inherited bytes: 0x08
struct FSingleDirLightInfos : FTableRowBase {
	// Fields
	struct FApexLightInfo DirLightInfo; // Offset: 0x08 // Size: 0x88
};

// Object Name: ScriptStruct AClient.ApexLightInfo
// Size: 0x88 // Inherited bytes: 0x00
struct FApexLightInfo {
	// Fields
	enum class EApexLightType LightType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Intensity; // Offset: 0x04 // Size: 0x04
	struct FColor LightColor; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct UTextureCube* Cubemap; // Offset: 0x10 // Size: 0x08
	struct FVector LightLocation; // Offset: 0x18 // Size: 0x0c
	struct FRotator LightRotation; // Offset: 0x24 // Size: 0x0c
	float AttenuationRadius; // Offset: 0x30 // Size: 0x04
	float InnerConeAngle; // Offset: 0x34 // Size: 0x04
	float OuterConeAngle; // Offset: 0x38 // Size: 0x04
	float DynamicShadowDistanceMovableLight; // Offset: 0x3c // Size: 0x04
	float DynamicShadowDistanceStationaryLight; // Offset: 0x40 // Size: 0x04
	int32_t DynamicShadowCascades; // Offset: 0x44 // Size: 0x04
	float ShadowDistanceFadeoutFraction; // Offset: 0x48 // Size: 0x04
	float CascadeDistributionExponent; // Offset: 0x4c // Size: 0x04
	float CascadeTransitionFraction; // Offset: 0x50 // Size: 0x04
	bool EnableOverrideCSM; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
	float OverrideCSMNear; // Offset: 0x58 // Size: 0x04
	float OverrideCSMFar; // Offset: 0x5c // Size: 0x04
	bool CastDynamicShadows; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x3]; // Offset: 0x61 // Size: 0x03
	float SpecularScale; // Offset: 0x64 // Size: 0x04
	float ShadowResolutionScale; // Offset: 0x68 // Size: 0x04
	float ShadowBias; // Offset: 0x6c // Size: 0x04
	float ShadowSlopeBias; // Offset: 0x70 // Size: 0x04
	bool bUseCustomShadowBound; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03
	float ShadowCasterBoundRadius; // Offset: 0x78 // Size: 0x04
	struct FVector ShadowBoundLocation; // Offset: 0x7c // Size: 0x0c
};

// Object Name: ScriptStruct AClient.LightInfos
// Size: 0x2c8 // Inherited bytes: 0x08
struct FLightInfos : FTableRowBase {
	// Fields
	bool bNewLobbyScene; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct FApexLightInfo DirLightInfo; // Offset: 0x10 // Size: 0x88
	struct FApexLightInfo Spot01LightInfo; // Offset: 0x98 // Size: 0x88
	struct FApexLightInfo Spot02LightInfo; // Offset: 0x120 // Size: 0x88
	struct FApexLightInfo Spot03LightInfo; // Offset: 0x1a8 // Size: 0x88
	struct FApexLightInfo Spot04LightInfo; // Offset: 0x230 // Size: 0x88
	struct TArray<struct FString> AdditionCmd; // Offset: 0x2b8 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DynamicMovementData
// Size: 0x50 // Inherited bytes: 0x00
struct FDynamicMovementData {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
	struct TArray<struct AActor*> IgnoreActors; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ScopeLocationAndRotationRecover
// Size: 0x28 // Inherited bytes: 0x00
struct FScopeLocationAndRotationRecover {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.DynamicMovementComponent_PathMove_LocationData
// Size: 0x08 // Inherited bytes: 0x00
struct FDynamicMovementComponent_PathMove_LocationData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.InstancedEffectViewItemList
// Size: 0x10 // Inherited bytes: 0x00
struct FInstancedEffectViewItemList {
	// Fields
	struct TArray<int32_t> InstancedIDs; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.EncomyExchangeRecord
// Size: 0x0c // Inherited bytes: 0x00
struct FEncomyExchangeRecord {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t Num; // Offset: 0x04 // Size: 0x04
	int32_t Price; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.EncomyExchangeReward
// Size: 0x18 // Inherited bytes: 0x00
struct FEncomyExchangeReward {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t Type; // Offset: 0x04 // Size: 0x04
	int32_t InitNum; // Offset: 0x08 // Size: 0x04
	int32_t AddNum; // Offset: 0x0c // Size: 0x04
	int32_t LimitNum; // Offset: 0x10 // Size: 0x04
	int32_t Price; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SyncEnmityInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FSyncEnmityInfo {
	// Fields
	int64_t ID; // Offset: 0x00 // Size: 0x08
	struct TWeakObjectPtr<struct AActor> Target; // Offset: 0x08 // Size: 0x08
	float EnmityValue; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.EnmityRealTimeInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FEnmityRealTimeInfo {
	// Fields
	struct FEnmityInfo EnmityInfo; // Offset: 0x00 // Size: 0x20
	struct FEnmityTableInfo EnmityTableInfo; // Offset: 0x20 // Size: 0x20
	float EnmityValue; // Offset: 0x40 // Size: 0x04
	float ElpaseTime; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AClient.EnmityTableInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FEnmityTableInfo {
	// Fields
	int64_t ID; // Offset: 0x00 // Size: 0x08
	int32_t EEnmityType; // Offset: 0x08 // Size: 0x04
	int32_t SubID; // Offset: 0x0c // Size: 0x04
	bool Initiative; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float SrourceCoefficient; // Offset: 0x14 // Size: 0x04
	float ClosePickupList_Time; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.EnmityInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FEnmityInfo {
	// Fields
	int32_t EEnmityType; // Offset: 0x00 // Size: 0x04
	int32_t SubID; // Offset: 0x04 // Size: 0x04
	bool Initiative; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct TWeakObjectPtr<struct AActor> Target; // Offset: 0x0c // Size: 0x08
	float Distance; // Offset: 0x14 // Size: 0x04
	float DamageNumber; // Offset: 0x18 // Size: 0x04
	bool bShootNone; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct AClient.ItemIdOrType
// Size: 0x0c // Inherited bytes: 0x00
struct FItemIdOrType {
	// Fields
	char bJudgeById : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_1 : 7; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t ItemID; // Offset: 0x04 // Size: 0x04
	int32_t ItemType; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.FireRangeBannerInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FFireRangeBannerInfo {
	// Fields
	int32_t SeqIndex; // Offset: 0x00 // Size: 0x04
	enum class EScreenState StateType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.TargetGroup
// Size: 0x10 // Inherited bytes: 0x00
struct FTargetGroup {
	// Fields
	struct TArray<struct AActor*> TargetArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.FireRangeShootGamePlayerSettings
// Size: 0x20 // Inherited bytes: 0x00
struct FFireRangeShootGamePlayerSettings {
	// Fields
	bool bIsCharacter; // Offset: 0x00 // Size: 0x01
	enum class EFireRangeTargetType TargetType; // Offset: 0x01 // Size: 0x01
	enum class EFireRangeTargetGaitType GaitType; // Offset: 0x02 // Size: 0x01
	enum class EFireRangeTargetPostureType PostureType; // Offset: 0x03 // Size: 0x01
	enum class EFireRangeTargetHealthType HealthType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int32_t ShieldLevel; // Offset: 0x08 // Size: 0x04
	enum class EFireRangeTargetAttackFrequency TargetAttackFrequency; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float DurationTime; // Offset: 0x10 // Size: 0x04
	int32_t EndConditionMask; // Offset: 0x14 // Size: 0x04
	int32_t ScoreThreshold; // Offset: 0x18 // Size: 0x04
	int32_t TargetThreshold; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.FhoItemData
// Size: 0x08 // Inherited bytes: 0x00
struct FFhoItemData {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	int32_t ItemNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GamblingMachineRandomItem
// Size: 0x14 // Inherited bytes: 0x00
struct FGamblingMachineRandomItem {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x00 // Size: 0x14
};

// Object Name: ScriptStruct AClient.GamblingMachinePlayerOutPut
// Size: 0x50 // Inherited bytes: 0x00
struct FGamblingMachinePlayerOutPut {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.BroadcastItemCfg
// Size: 0x30 // Inherited bytes: 0x00
struct FBroadcastItemCfg {
	// Fields
	struct FString SpeakerNameKey; // Offset: 0x00 // Size: 0x10
	struct FString ContentKey; // Offset: 0x10 // Size: 0x10
	struct TArray<struct UAkAudioEvent*> AudioEvents; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GameFlowHUDItemTickFunction
// Size: 0x58 // Inherited bytes: 0x50
struct FGameFlowHUDItemTickFunction : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.GameFlowProcessorContainer
// Size: 0x50 // Inherited bytes: 0x00
struct FGameFlowProcessorContainer {
	// Fields
	struct TSet<struct UApexGameFlowProcessorBase*> m_ProcessorSet; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.AirDropAreaSpawnInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FAirDropAreaSpawnInfo {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	int32_t Level; // Offset: 0x04 // Size: 0x04
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	float Radius; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AirDropAreaRandomCache
// Size: 0x1c // Inherited bytes: 0x00
struct FAirDropAreaRandomCache {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x00 // Size: 0x1c
};

// Object Name: ScriptStruct AClient.AirDropAreaTypeToRoundData
// Size: 0x50 // Inherited bytes: 0x00
struct FAirDropAreaTypeToRoundData {
	// Fields
	struct TMap<enum class EAirDropAreaType, struct FAirDropAreaRoundData> AirDropTypeToRoundData; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.AirDropAreaRoundData
// Size: 0x70 // Inherited bytes: 0x00
struct FAirDropAreaRoundData {
	// Fields
	int32_t Round; // Offset: 0x00 // Size: 0x04
	float AirDropAreaCount; // Offset: 0x04 // Size: 0x04
	int32_t AirDropLevel; // Offset: 0x08 // Size: 0x04
	int32_t AirDropAreaRadius; // Offset: 0x0c // Size: 0x04
	float WaitTime; // Offset: 0x10 // Size: 0x04
	float BroadcastSpeakerTime; // Offset: 0x14 // Size: 0x04
	float DropTime; // Offset: 0x18 // Size: 0x04
	struct FVector CircleCenter; // Offset: 0x1c // Size: 0x0c
	float CircleRadius; // Offset: 0x28 // Size: 0x04
	float BaseAngle; // Offset: 0x2c // Size: 0x04
	int32_t LeftCalAirDropAreaCount; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<struct FVector> AirDropAreaCenters; // Offset: 0x38 // Size: 0x10
	bool bIsSpawnAirDropAreas; // Offset: 0x48 // Size: 0x01
	bool bIsBroadcastSpeaker; // Offset: 0x49 // Size: 0x01
	bool bIsSpawnAirDrops; // Offset: 0x4a // Size: 0x01
	bool bIsSpawnFirstAirDrops; // Offset: 0x4b // Size: 0x01
	float ShowPointTime; // Offset: 0x4c // Size: 0x04
	struct TArray<struct FAirDropPointSpawnInfo> FirstAirDropPoints; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FAirDropCircleData> AirDropsData; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AirDropCircleData
// Size: 0x58 // Inherited bytes: 0x00
struct FAirDropCircleData {
	// Fields
	float WaitSpawnTime; // Offset: 0x00 // Size: 0x04
	float SpawnInterval; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FString> LootZoneTypeInfoArray; // Offset: 0x08 // Size: 0x10
	int32_t AirDropCount; // Offset: 0x18 // Size: 0x04
	int32_t AirDropLevel; // Offset: 0x1c // Size: 0x04
	struct FVector CircleCenter; // Offset: 0x20 // Size: 0x0c
	float CircleRadius; // Offset: 0x2c // Size: 0x04
	float BaseAngle; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<struct FAirDropPointData> AirDropLocations; // Offset: 0x38 // Size: 0x10
	int32_t LeftCalAirDropCount; // Offset: 0x48 // Size: 0x04
	int32_t LeftSpawnAirDropCount; // Offset: 0x4c // Size: 0x04
	bool bIsSpawnFirstAirDrops; // Offset: 0x50 // Size: 0x01
	bool bIsSpawnAirDrops; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0x6]; // Offset: 0x52 // Size: 0x06
};

// Object Name: ScriptStruct AClient.AirDropPointData
// Size: 0x14 // Inherited bytes: 0x00
struct FAirDropPointData {
	// Fields
	float DropTime; // Offset: 0x00 // Size: 0x04
	struct FVector DropPoint; // Offset: 0x04 // Size: 0x0c
	bool bIsSpawnAirDrops; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
};

// Object Name: ScriptStruct AClient.AirDropPointSpawnInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FAirDropPointSpawnInfo {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t Level; // Offset: 0x04 // Size: 0x04
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.AirDropAreaConfigData
// Size: 0x40 // Inherited bytes: 0x00
struct FAirDropAreaConfigData {
	// Fields
	int32_t Round; // Offset: 0x00 // Size: 0x04
	enum class EAirDropAreaType AirDropType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int32_t AirDropAreaCount; // Offset: 0x08 // Size: 0x04
	float AirDropAreaRadius; // Offset: 0x0c // Size: 0x04
	int32_t AirDropLevel; // Offset: 0x10 // Size: 0x04
	int32_t AirDropCount; // Offset: 0x14 // Size: 0x04
	float WaitTime; // Offset: 0x18 // Size: 0x04
	float BroadcastSpeakerTime; // Offset: 0x1c // Size: 0x04
	float WaitSpawnTime; // Offset: 0x20 // Size: 0x04
	float SpawnInterval; // Offset: 0x24 // Size: 0x04
	float ShowPointTime; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FString> LootZoneTypeInfoArray; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AirDropSpawnInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FAirDropSpawnInfo {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	struct FVector Location; // Offset: 0x04 // Size: 0x0c
	char Type; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
};

// Object Name: ScriptStruct AClient.AirDropRandomCache
// Size: 0x1c // Inherited bytes: 0x00
struct FAirDropRandomCache {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x00 // Size: 0x1c
};

// Object Name: ScriptStruct AClient.AirDropTypeToRoundData
// Size: 0x50 // Inherited bytes: 0x00
struct FAirDropTypeToRoundData {
	// Fields
	struct TMap<enum class EAirDropType, struct FAirDropRoundData> AirDropTypeToRoundData; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.AirDropRoundData
// Size: 0x50 // Inherited bytes: 0x00
struct FAirDropRoundData {
	// Fields
	int32_t Round; // Offset: 0x00 // Size: 0x04
	float WaitTime; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FLootZoneTypeInfo> LootZoneTypeInfoArray; // Offset: 0x08 // Size: 0x10
	float DropTime; // Offset: 0x18 // Size: 0x04
	int32_t AirDropCount; // Offset: 0x1c // Size: 0x04
	struct FVector CircleCenter; // Offset: 0x20 // Size: 0x0c
	float CircleRadius; // Offset: 0x2c // Size: 0x04
	float BaseAngle; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<struct FVector> AirDropLocations; // Offset: 0x38 // Size: 0x10
	int32_t LeftCalAirDropCount; // Offset: 0x48 // Size: 0x04
	bool bIsSpawnAirDrops; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
};

// Object Name: ScriptStruct AClient.AirDropConfigData
// Size: 0x20 // Inherited bytes: 0x00
struct FAirDropConfigData {
	// Fields
	int32_t Round; // Offset: 0x00 // Size: 0x04
	enum class EAirDropType AirDropType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int32_t AirDropCount; // Offset: 0x08 // Size: 0x04
	float WaitTime; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FLootZoneTypeInfo> LootZoneTypeInfoArray; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BattleResultMpLegendData
// Size: 0x04 // Inherited bytes: 0x00
struct FBattleResultMpLegendData {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BombActorSettings
// Size: 0x60 // Inherited bytes: 0x00
struct FBombActorSettings {
	// Fields
	int32_t MaxBombActorCount; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UBombDefusalAttackerComponent* AttackerClassConfig; // Offset: 0x08 // Size: 0x08
	struct ABombActor* BombClassConfig; // Offset: 0x10 // Size: 0x08
	struct ABombCorona* BombCoronaClassConfig; // Offset: 0x18 // Size: 0x08
	struct ABombDefuseTool* DefuseToolConfig; // Offset: 0x20 // Size: 0x08
	struct FName BurdenedSocketName; // Offset: 0x28 // Size: 0x08
	struct FName PlantingSocketName; // Offset: 0x30 // Size: 0x08
	struct FName DefusingSocketName; // Offset: 0x38 // Size: 0x08
	float PlantTime; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct UBombDefusalDefenderComponent* DefenderClassConfig; // Offset: 0x48 // Size: 0x08
	struct TArray<float> DefuseTime; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LootBinCreepsInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FLootBinCreepsInfo {
	// Fields
	struct FVector Pos; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct AClient.TDMLootBinCreepsLevelInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FTDMLootBinCreepsLevelInfo {
	// Fields
	float Time; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<float> LootBinCreepsSpawnRate; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.TDMLootBinCreepsInfo
// Size: 0x1c // Inherited bytes: 0x00
struct FTDMLootBinCreepsInfo {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	struct FVector Pos; // Offset: 0x04 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x10 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.GameModeCommonInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FGameModeCommonInfo {
	// Fields
	struct FVector MapCenter; // Offset: 0x00 // Size: 0x0c
	float ParachuteFreeFall2SlowDownDetectLength; // Offset: 0x0c // Size: 0x04
	float ParachuteBack2FreeFallDetectOffset; // Offset: 0x10 // Size: 0x04
	float ParachuteForceLandingHeight; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CCSAISvrInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FCCSAISvrInfo {
	// Fields
	struct FString SvrGameId; // Offset: 0x00 // Size: 0x10
	bool bSyncAIState; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct AClient.SafetyAreaConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FSafetyAreaConfig {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.ProtoPacketInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FProtoPacketInfo {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct AClient.GameModeKilledParam
// Size: 0x20 // Inherited bytes: 0x00
struct FGameModeKilledParam {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
	struct AController* RealKiller; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.DsFunctionConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FDsFunctionConfig {
	// Fields
	int32_t IsClose; // Offset: 0x00 // Size: 0x04
	int32_t FunctionId; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.HUDPlayerState
// Size: 0x01 // Inherited bytes: 0x00
struct FHUDPlayerState {
	// Fields
	bool bAIHosting; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.PinGameStartData
// Size: 0x08 // Inherited bytes: 0x00
struct FPinGameStartData {
	// Fields
	uint64_t DefenderID; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PlayerNetStats
// Size: 0x80 // Inherited bytes: 0x00
struct FPlayerNetStats {
	// Fields
	struct FString ClientAddr; // Offset: 0x00 // Size: 0x10
	struct FString LocalAddr; // Offset: 0x10 // Size: 0x10
	float AvgPing; // Offset: 0x20 // Size: 0x04
	float MaxPing; // Offset: 0x24 // Size: 0x04
	float HighPingPercent; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x3c]; // Offset: 0x2c // Size: 0x3c
	float InBytesPerSecond; // Offset: 0x68 // Size: 0x04
	float OutBytesPerSecond; // Offset: 0x6c // Size: 0x04
	float InPacketLostRate; // Offset: 0x70 // Size: 0x04
	float OutPacketLostRate; // Offset: 0x74 // Size: 0x04
	float OutSaturationRate; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct AClient.DSPlayerStatusChangedParams
// Size: 0x28 // Inherited bytes: 0x00
struct FDSPlayerStatusChangedParams {
	// Fields
	struct FPlayerID PlayerID; // Offset: 0x00 // Size: 0x0c
	struct FName PlayerStatus; // Offset: 0x0c // Size: 0x08
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Reason; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PlayerID
// Size: 0x0c // Inherited bytes: 0x00
struct FPlayerID {
	// Fields
	struct FName PlayerType; // Offset: 0x00 // Size: 0x08
	int32_t PlayerKey; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GameModePlayerParams
// Size: 0x538 // Inherited bytes: 0x00
struct FGameModePlayerParams {
	// Fields
	uint64_t UID; // Offset: 0x00 // Size: 0x08
	struct FName PlayerType; // Offset: 0x08 // Size: 0x08
	struct FString PlayerName; // Offset: 0x10 // Size: 0x10
	int32_t PlayerKey; // Offset: 0x20 // Size: 0x04
	struct FName PlayerStatus; // Offset: 0x24 // Size: 0x08
	int32_t TeamID; // Offset: 0x2c // Size: 0x04
	int32_t CampID; // Offset: 0x30 // Size: 0x04
	uint32_t TeamNumber; // Offset: 0x34 // Size: 0x04
	bool bIsCommander; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct TArray<int32_t> ValidLegendArray; // Offset: 0x40 // Size: 0x10
	struct TArray<int32_t> LimitValidLegendArray; // Offset: 0x50 // Size: 0x10
	struct TArray<int32_t> ActivityTaskIDArray; // Offset: 0x60 // Size: 0x10
	struct TArray<int32_t> MinGuaranteeLegends; // Offset: 0x70 // Size: 0x10
	struct TArray<struct FBannerData> LegendBannerDataArray; // Offset: 0x80 // Size: 0x10
	struct FBannerData CurrentBannerData; // Offset: 0x90 // Size: 0x48
	struct FString EndReason; // Offset: 0xd8 // Size: 0x10
	uint32_t LegendId; // Offset: 0xe8 // Size: 0x04
	int32_t LegendSkin; // Offset: 0xec // Size: 0x04
	bool bIsRobot; // Offset: 0xf0 // Size: 0x01
	bool IsFromDS; // Offset: 0xf1 // Size: 0x01
	bool HasVIPTicket; // Offset: 0xf2 // Size: 0x01
	char pad_0xF3[0x1]; // Offset: 0xf3 // Size: 0x01
	int32_t DefaultEquipIndex; // Offset: 0xf4 // Size: 0x04
	uint32_t RoomPlayerCount; // Offset: 0xf8 // Size: 0x04
	struct FGameModePlayerBattleInfoGroup BattleInfoGroup; // Offset: 0xfc // Size: 0x14
	struct TMap<int32_t, int32_t> DefaultLegendSkinMap; // Offset: 0x110 // Size: 0x50
	struct TArray<struct FPlayerEquipSkinInfo> EquipSkinArray; // Offset: 0x160 // Size: 0x10
	struct TMap<int32_t, struct FLegendEmotePaintingInfo> EmotePaintData; // Offset: 0x170 // Size: 0x50
	int32_t GameNum; // Offset: 0x1c0 // Size: 0x04
	int32_t BRGameNum; // Offset: 0x1c4 // Size: 0x04
	int32_t sub_mode_group_game_num; // Offset: 0x1c8 // Size: 0x04
	bool IsPureSpectator; // Offset: 0x1cc // Size: 0x01
	char pad_0x1CD[0x3]; // Offset: 0x1cd // Size: 0x03
	int64_t BanOBEndTime; // Offset: 0x1d0 // Size: 0x08
	struct FString BanOBReasonText; // Offset: 0x1d8 // Size: 0x10
	int64_t BanChatEndTime; // Offset: 0x1e8 // Size: 0x08
	int64_t BanChatNoPerceptionEndTime; // Offset: 0x1f0 // Size: 0x08
	int32_t SavePoint; // Offset: 0x1f8 // Size: 0x04
	int32_t SegmentLevel; // Offset: 0x1fc // Size: 0x04
	int32_t Rating; // Offset: 0x200 // Size: 0x04
	int32_t DailyWinTime; // Offset: 0x204 // Size: 0x04
	struct TMap<int32_t, int32_t> FinisherIDs; // Offset: 0x208 // Size: 0x50
	int32_t WarmScore; // Offset: 0x258 // Size: 0x04
	int32_t MatchScore; // Offset: 0x25c // Size: 0x04
	struct TArray<struct FSimpleTrackerData> TrackerDetailArray; // Offset: 0x260 // Size: 0x10
	struct FMpWeaponInfo MpWeaponInfo; // Offset: 0x270 // Size: 0x30
	struct FBrilliantInfo BrilliantInfo; // Offset: 0x2a0 // Size: 0x24
	bool bSubJoin; // Offset: 0x2c4 // Size: 0x01
	char pad_0x2C5[0x3]; // Offset: 0x2c5 // Size: 0x03
	int32_t ReplaceUID; // Offset: 0x2c8 // Size: 0x04
	char pad_0x2CC[0x4]; // Offset: 0x2cc // Size: 0x04
	struct TMap<int32_t, int32_t> JumpTailID; // Offset: 0x2d0 // Size: 0x50
	struct TMap<int32_t, int32_t> ActivitySingleLimitItems; // Offset: 0x320 // Size: 0x50
	struct TMap<int32_t, struct FJumpActionDataServer> JumpActionData; // Offset: 0x370 // Size: 0x50
	int32_t KDERAverage; // Offset: 0x3c0 // Size: 0x04
	int32_t KDERNum; // Offset: 0x3c4 // Size: 0x04
	int32_t AILevel; // Offset: 0x3c8 // Size: 0x04
	char pad_0x3CC[0x4]; // Offset: 0x3cc // Size: 0x04
	struct FGameCreditScore CreditScore; // Offset: 0x3d0 // Size: 0x10
	struct FString OpenId; // Offset: 0x3e0 // Size: 0x10
	int64_t OriginalGameID; // Offset: 0x3f0 // Size: 0x08
	struct TArray<struct FInGameActivityPlayerData> InGameActivityPlayerDataArray; // Offset: 0x3f8 // Size: 0x10
	struct TArray<struct FSkillAssistData> SkillAssistArray; // Offset: 0x408 // Size: 0x10
	struct TArray<struct FLegendAssistData> LegendAssistArray; // Offset: 0x418 // Size: 0x10
	struct FString CorpsName; // Offset: 0x428 // Size: 0x10
	struct FString CorpsNickName; // Offset: 0x438 // Size: 0x10
	int32_t Corps_Select_ID; // Offset: 0x448 // Size: 0x04
	char pad_0x44C[0x4]; // Offset: 0x44c // Size: 0x04
	struct TMap<int32_t, struct FLegendCustomPerksPlan> LegendCustomPerksMap; // Offset: 0x450 // Size: 0x50
	struct TMap<int32_t, int32_t> PutOnPerksIndexMap; // Offset: 0x4a0 // Size: 0x50
	bool bIsPerkOpen; // Offset: 0x4f0 // Size: 0x01
	char pad_0x4F1[0x7]; // Offset: 0x4f1 // Size: 0x07
	struct FString IPCountry; // Offset: 0x4f8 // Size: 0x10
	char pad_0x508[0x10]; // Offset: 0x508 // Size: 0x10
	struct TArray<struct FDSPlayerGunAmuletInfo> GunAmuletArray; // Offset: 0x518 // Size: 0x10
	struct TArray<struct FDSPlayerSignatureWeapon> SignatureWeaponArray; // Offset: 0x528 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DSPlayerSignatureWeapon
// Size: 0x20 // Inherited bytes: 0x00
struct FDSPlayerSignatureWeapon {
	// Fields
	int32_t LegendId; // Offset: 0x00 // Size: 0x04
	int32_t WeaponID; // Offset: 0x04 // Size: 0x04
	int32_t Level; // Offset: 0x08 // Size: 0x04
	int32_t ModelIndex; // Offset: 0x0c // Size: 0x04
	struct TArray<int32_t> FeatureIdList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DSPlayerGunAmuletInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FDSPlayerGunAmuletInfo {
	// Fields
	int32_t GunItemID; // Offset: 0x00 // Size: 0x04
	int32_t AmuletID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LegendCustomPerksPlan
// Size: 0x10 // Inherited bytes: 0x00
struct FLegendCustomPerksPlan {
	// Fields
	struct TArray<struct FLegendCustomPerksInfo> Plan; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LegendCustomPerksInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FLegendCustomPerksInfo {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct TArray<int32_t> PerksID; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LegendAssistData
// Size: 0x08 // Inherited bytes: 0x00
struct FLegendAssistData {
	// Fields
	int32_t LegendId; // Offset: 0x00 // Size: 0x04
	bool EnableAssist; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.SkillAssistData
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillAssistData {
	// Fields
	int32_t SkillID; // Offset: 0x00 // Size: 0x04
	bool EnableAssist; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.InGameActivityPlayerData
// Size: 0x38 // Inherited bytes: 0x00
struct FInGameActivityPlayerData {
	// Fields
	struct TArray<int32_t> ItemIDList; // Offset: 0x00 // Size: 0x10
	int32_t MaxCount; // Offset: 0x10 // Size: 0x04
	int32_t CurCount; // Offset: 0x14 // Size: 0x04
	int64_t LastPickTime; // Offset: 0x18 // Size: 0x08
	enum class EPickupActivityItemResult PickupResult; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	int64_t NextPickupTime; // Offset: 0x28 // Size: 0x08
	int32_t TipsID; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GameCreditScore
// Size: 0x10 // Inherited bytes: 0x00
struct FGameCreditScore {
	// Fields
	struct TArray<float> CreditScores; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.JumpActionDataServer
// Size: 0x10 // Inherited bytes: 0x00
struct FJumpActionDataServer {
	// Fields
	struct TArray<int32_t> List; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BrilliantInfo
// Size: 0x24 // Inherited bytes: 0x00
struct FBrilliantInfo {
	// Fields
	float ComboKillAvg; // Offset: 0x00 // Size: 0x04
	float HeadShotRateAvg; // Offset: 0x04 // Size: 0x04
	float DamageTImeRecoveryHPAvg; // Offset: 0x08 // Size: 0x04
	float VerticalDamageAvg; // Offset: 0x0c // Size: 0x04
	float BehiindDamageAvg; // Offset: 0x10 // Size: 0x04
	float KillAvg; // Offset: 0x14 // Size: 0x04
	float AssistAvg; // Offset: 0x18 // Size: 0x04
	float DamageAvg; // Offset: 0x1c // Size: 0x04
	int32_t GameNum; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MpWeaponInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FMpWeaponInfo {
	// Fields
	struct TArray<struct FMpWeaponUseTimeData> WeaponUseTimeMap; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FMpWeaponFittingData> FittingDataArray; // Offset: 0x10 // Size: 0x10
	struct TArray<int32_t> LastWeaponArray; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MpWeaponFittingData
// Size: 0x08 // Inherited bytes: 0x00
struct FMpWeaponFittingData {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t WeaponFittingItemID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MpWeaponUseTimeData
// Size: 0x08 // Inherited bytes: 0x00
struct FMpWeaponUseTimeData {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t UseTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SimpleTrackerData
// Size: 0x0c // Inherited bytes: 0x00
struct FSimpleTrackerData {
	// Fields
	float Value; // Offset: 0x00 // Size: 0x04
	int32_t TrackerID; // Offset: 0x04 // Size: 0x04
	int32_t LegendId; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LegendEmotePaintingInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FLegendEmotePaintingInfo {
	// Fields
	struct TArray<int32_t> EmotePaintingID; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PlayerEquipSkinInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FPlayerEquipSkinInfo {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	int32_t SkinId; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GameModePlayerBattleInfoGroup
// Size: 0x14 // Inherited bytes: 0x00
struct FGameModePlayerBattleInfoGroup {
	// Fields
	struct FGameModePlayerLastBattleInfo LastBattleInfo; // Offset: 0x00 // Size: 0x14
};

// Object Name: ScriptStruct AClient.GameModePlayerLastBattleInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FGameModePlayerLastBattleInfo {
	// Fields
	int32_t Rank; // Offset: 0x00 // Size: 0x04
	int32_t TeamRank; // Offset: 0x04 // Size: 0x04
	int32_t KillNum; // Offset: 0x08 // Size: 0x04
	int32_t DamageAmount; // Offset: 0x0c // Size: 0x04
	int32_t SurviveTime; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PlayerRatingKillScore
// Size: 0x08 // Inherited bytes: 0x00
struct FPlayerRatingKillScore {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t KillScore; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ServerRatingGameModeConfig
// Size: 0x38 // Inherited bytes: 0x00
struct FServerRatingGameModeConfig {
	// Fields
	int32_t Segment; // Offset: 0x00 // Size: 0x04
	float RankWink; // Offset: 0x04 // Size: 0x04
	float RankFailK; // Offset: 0x08 // Size: 0x04
	float KillK; // Offset: 0x0c // Size: 0x04
	float RankWinParam; // Offset: 0x10 // Size: 0x04
	float RankFailParam; // Offset: 0x14 // Size: 0x04
	float KillParam; // Offset: 0x18 // Size: 0x04
	float KillAIParam; // Offset: 0x1c // Size: 0x04
	int32_t KillMaxScore; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<int32_t> RankExtraScore; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AClient.JumpActionData
// Size: 0x20 // Inherited bytes: 0x00
struct FJumpActionData {
	// Fields
	struct TArray<int32_t> Key; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FJumpActionDataList> List; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.JumpActionDataList
// Size: 0x10 // Inherited bytes: 0x00
struct FJumpActionDataList {
	// Fields
	struct TArray<int32_t> List; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.JumpTailID
// Size: 0x20 // Inherited bytes: 0x00
struct FJumpTailID {
	// Fields
	struct TArray<int32_t> Key; // Offset: 0x00 // Size: 0x10
	struct TArray<int32_t> List; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LegendPutOnPerksInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FLegendPutOnPerksInfo {
	// Fields
	struct TArray<int32_t> PerksID; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GameModePlayerDetailData
// Size: 0xa8 // Inherited bytes: 0x00
struct FGameModePlayerDetailData {
	// Fields
	int32_t CurrentLegendSkin; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0xa4]; // Offset: 0x04 // Size: 0xa4
};

// Object Name: ScriptStruct AClient.PerchedDeathBoxFlyerSpawnInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FPerchedDeathBoxFlyerSpawnInfo {
	// Fields
	struct FTransform Transform; // Offset: 0x00 // Size: 0x30
	int32_t Quality; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0xc]; // Offset: 0x34 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.CirclingDeathBoxFlyerSpawnInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FCirclingDeathBoxFlyerSpawnInfo {
	// Fields
	struct TSoftClassPtr<UObject> PathActorClass; // Offset: 0x00 // Size: 0x28
	int32_t Quality; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.HoverTankConfigData
// Size: 0x10 // Inherited bytes: 0x00
struct FHoverTankConfigData {
	// Fields
	float Rate; // Offset: 0x00 // Size: 0x04
	bool bIsCreateInBeginPlay; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int32_t Round; // Offset: 0x08 // Size: 0x04
	enum class EHoverTankAreaType AreaType; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct AClient.HoverTankStationData
// Size: 0x90 // Inherited bytes: 0x00
struct FHoverTankStationData {
	// Fields
	struct FTransform DefaultTrans; // Offset: 0x00 // Size: 0x30
	struct TArray<struct TSoftObjectPtr<ASmoothPathConfigActor>> SmoothPathConfigArray; // Offset: 0x30 // Size: 0x10
	struct TMap<int32_t, struct TWeakObjectPtr<struct ASmoothSplinePathActor>> CacheSmoothSplinePaths; // Offset: 0x40 // Size: 0x50
};

// Object Name: ScriptStruct AClient.UseActivityConfigData
// Size: 0x08 // Inherited bytes: 0x00
struct FUseActivityConfigData {
	// Fields
	struct UInGameActivityDataBase* ActivityDataClass; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.InGameActivityDropData
// Size: 0x18 // Inherited bytes: 0x00
struct FInGameActivityDropData {
	// Fields
	struct FItemDefineID ItemDefineID; // Offset: 0x00 // Size: 0x10
	enum class EActivityItemPikcupReason SourceReason; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t count; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ServerActivityConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FServerActivityConfig {
	// Fields
	int32_t ActivityType; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	int64_t StartTime; // Offset: 0x08 // Size: 0x08
	int64_t EndTime; // Offset: 0x10 // Size: 0x08
	struct TArray<struct FString> ActivityParams; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.InGameActivityDropReportData
// Size: 0x18 // Inherited bytes: 0x00
struct FInGameActivityDropReportData {
	// Fields
	struct FItemDefineID ItemDefineID; // Offset: 0x00 // Size: 0x10
	enum class EActivityItemDropReason DropReason; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t count; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.InGameActivityPickupReportData
// Size: 0x18 // Inherited bytes: 0x00
struct FInGameActivityPickupReportData {
	// Fields
	struct FItemDefineID ItemDefineID; // Offset: 0x00 // Size: 0x10
	enum class EActivityItemPikcupReason SourceReason; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t count; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.InGameActivityPickupData
// Size: 0x20 // Inherited bytes: 0x00
struct FInGameActivityPickupData {
	// Fields
	struct FItemDefineID ItemDefineID; // Offset: 0x00 // Size: 0x10
	int32_t count; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	int64_t PickTime; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.NewbieScriptReportData
// Size: 0x68 // Inherited bytes: 0x00
struct FNewbieScriptReportData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
	struct TMap<enum class ENewbieScriptReportType, struct FNewbieScriptReportDesc> ReportTypeToDesc; // Offset: 0x18 // Size: 0x50
};

// Object Name: ScriptStruct AClient.NewbieScriptReportDesc
// Size: 0xa8 // Inherited bytes: 0x00
struct FNewbieScriptReportDesc {
	// Fields
	char pad_0x0[0xa8]; // Offset: 0x00 // Size: 0xa8
};

// Object Name: ScriptStruct AClient.NewbieScriptTargetVolumeData
// Size: 0x10 // Inherited bytes: 0x00
struct FNewbieScriptTargetVolumeData {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t EnterCount; // Offset: 0x04 // Size: 0x04
	float EnterTimeSecond; // Offset: 0x08 // Size: 0x04
	float LeaveTimeSecond; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.NewbieScriptBinConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FNewbieScriptBinConfig {
	// Fields
	struct TArray<int32_t> ItemIDArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ParachutePointGroup
// Size: 0x10 // Inherited bytes: 0x00
struct FParachutePointGroup {
	// Fields
	struct TArray<struct UParachutePointComp*> ParachutePointComps; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PlaneData
// Size: 0x60 // Inherited bytes: 0x00
struct FPlaneData {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x00 // Size: 0x40
	struct AActor* ThePlane; // Offset: 0x40 // Size: 0x08
	struct TArray<struct AApexCharacterBase*> InPlaneCharacterBases; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x8]; // Offset: 0x58 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PlaneFlowConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FPlaneFlowConfig {
	// Fields
	float Radius0; // Offset: 0x00 // Size: 0x04
	float PlaneStartRadius; // Offset: 0x04 // Size: 0x04
	float PlaneEndRadius; // Offset: 0x08 // Size: 0x04
	bool bUseCircleCenter; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float PlaneRouteEndConcentration; // Offset: 0x10 // Size: 0x04
	bool bUsingPolygon; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	float PlaneCanJumpRadius; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FVector2D> PolygonPoints; // Offset: 0x20 // Size: 0x10
	float PlaneSpeed; // Offset: 0x30 // Size: 0x04
	float CanJumpFromPlaneCountDown; // Offset: 0x34 // Size: 0x04
	float PlaneHeight; // Offset: 0x38 // Size: 0x04
	struct FVector PathCollision; // Offset: 0x3c // Size: 0x0c
	float CountDownTimeOffset; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct AClient.RecoverPropReportDelegateInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FRecoverPropReportDelegateInfo {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t ItemID; // Offset: 0x04 // Size: 0x04
	struct FString PropertyName; // Offset: 0x08 // Size: 0x10
	float PreValue; // Offset: 0x18 // Size: 0x04
	float AddValue; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.GameModeStageInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FGameModeStageInfo {
	// Fields
	enum class EMGameModeStage StageType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float EnterStageTime; // Offset: 0x04 // Size: 0x04
	float StageDuration; // Offset: 0x08 // Size: 0x04
	int32_t EnterStageTimes; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.TeamRecoverBanner
// Size: 0x10 // Inherited bytes: 0x00
struct FTeamRecoverBanner {
	// Fields
	struct TArray<uint32_t> RecoverBannerPlayerKeys; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GamepadSettableSetting
// Size: 0x01 // Inherited bytes: 0x00
struct FGamepadSettableSetting {
	// Fields
	enum class EGamepadActionType eActionType; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.KeyboardGamepadAxisInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FKeyboardGamepadAxisInfo {
	// Fields
	struct FKey Keyboard; // Offset: 0x00 // Size: 0x18
	enum class EInputEvent eInputEventType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float AxisValue; // Offset: 0x1c // Size: 0x04
	enum class EGamepadKeyType EGamepadKeyType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct AClient.KeyboardGamepadKeyInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FKeyboardGamepadKeyInfo {
	// Fields
	struct FKey Keyboard; // Offset: 0x00 // Size: 0x18
	enum class EInputEvent eInputEventType; // Offset: 0x18 // Size: 0x01
	enum class EGamepadKeyType EGamepadKeyType; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x6]; // Offset: 0x1a // Size: 0x06
};

// Object Name: ScriptStruct AClient.GamepadUserDefineActionInfo
// Size: 0x100 // Inherited bytes: 0x00
struct FGamepadUserDefineActionInfo {
	// Fields
	enum class EGamepadUserKeyType UserKeyType; // Offset: 0x00 // Size: 0x01
	enum class EGamepadKeyType PressKeyType; // Offset: 0x01 // Size: 0x01
	enum class EGamepadKeyType ReleaseKeyType; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	struct FName KeyboardPropertyName; // Offset: 0x04 // Size: 0x08
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TSet<enum class EGamepadKeyType> InterceptKeyList; // Offset: 0x10 // Size: 0x50
	struct TSet<enum class EGamepadActionType> PressActionList; // Offset: 0x60 // Size: 0x50
	struct TSet<enum class EGamepadActionType> ReleaseActionList; // Offset: 0xb0 // Size: 0x50
};

// Object Name: ScriptStruct AClient.GamepadShakeInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FGamepadShakeInfo {
	// Fields
	struct FName ShakeSourceName; // Offset: 0x00 // Size: 0x08
	float Duration; // Offset: 0x08 // Size: 0x04
	int32_t Priority; // Offset: 0x0c // Size: 0x04
	float Strength; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GamepadUINodeListInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FGamepadUINodeListInfo {
	// Fields
	enum class EGamepadType CurrentFillImgType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FGamepadImgNodeInfo> CanvasPanelList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GamepadImgNodeInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FGamepadImgNodeInfo {
	// Fields
	enum class EGamepadActionType EGamepadActionType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UCanvasPanel* CanvasPanel; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.GamepadKeyboardMapInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FGamepadKeyboardMapInfo {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.GamepadAxisMap2KeyByDesigner
// Size: 0x10 // Inherited bytes: 0x00
struct FGamepadAxisMap2KeyByDesigner {
	// Fields
	enum class EGamepadKeyType PressKeyType; // Offset: 0x00 // Size: 0x01
	enum class EGamepadKeyType ReleaseKeyType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	struct FName PropertyKey; // Offset: 0x04 // Size: 0x08
	float Threshold; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.GamepadKeypadPairMsg
// Size: 0x02 // Inherited bytes: 0x00
struct FGamepadKeypadPairMsg {
	// Fields
	enum class EGamepadKeyType PressKeyType; // Offset: 0x00 // Size: 0x01
	enum class EGamepadKeyType ReleaseKeyType; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.GamepadAxisInfoMappedByKeypad
// Size: 0x08 // Inherited bytes: 0x00
struct FGamepadAxisInfoMappedByKeypad {
	// Fields
	enum class EGamepadKeyType GamepadKeyType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float AxisValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GamepadRejectKeyListInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FGamepadRejectKeyListInfo {
	// Fields
	float RejectTime; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<enum class EGamepadKeyType> KeyList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GamepadProcessorStackItem
// Size: 0x10 // Inherited bytes: 0x00
struct FGamepadProcessorStackItem {
	// Fields
	enum class EGamepadMouseVisibility eMouseVisibility; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UGamepadProcessorBase* Processor; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.GamepadWidgetSpecialConfig
// Size: 0x68 // Inherited bytes: 0x00
struct FGamepadWidgetSpecialConfig {
	// Fields
	enum class EGamepadMouseVisibility eMouseVisibility; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FGamepadButtonEventMap GamepadButtonEventMap; // Offset: 0x08 // Size: 0x50
	struct TArray<struct FGamepadUIAction> UIEventList; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GamepadUIAction
// Size: 0x14 // Inherited bytes: 0x00
struct FGamepadUIAction {
	// Fields
	enum class EGamepadActionType ActionType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FName UIName; // Offset: 0x04 // Size: 0x08
	struct FName FunctionName; // Offset: 0x0c // Size: 0x08
};

// Object Name: ScriptStruct AClient.GamepadButtonEventMap
// Size: 0x50 // Inherited bytes: 0x00
struct FGamepadButtonEventMap {
	// Fields
	struct TMap<enum class EGamepadActionType, struct FGamepadButtonEvent> GamepadButtonEventMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.GamepadButtonEvent
// Size: 0x18 // Inherited bytes: 0x00
struct FGamepadButtonEvent {
	// Fields
	enum class EGamepadActionType eAction; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FGamepadButtonActionInfo> GamepadButtonActionList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GamepadButtonActionInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FGamepadButtonActionInfo {
	// Fields
	struct FName UIName; // Offset: 0x00 // Size: 0x08
	enum class EGamepadButtonEventType eButtonEventType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int32_t MaxDepth; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.GamepadWidgetRuleList
// Size: 0x20 // Inherited bytes: 0x00
struct FGamepadWidgetRuleList {
	// Fields
	struct TArray<struct FGamepadWidgetRules> WidgetRuleList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FGamepadActionPair> GuaranteeExecuteActionList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GamepadActionPair
// Size: 0x02 // Inherited bytes: 0x00
struct FGamepadActionPair {
	// Fields
	enum class EGamepadActionType StartAction; // Offset: 0x00 // Size: 0x01
	enum class EGamepadActionType EndAction; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.GamepadWidgetRules
// Size: 0x20 // Inherited bytes: 0x00
struct FGamepadWidgetRules {
	// Fields
	struct TArray<struct FName> WidgetNames; // Offset: 0x00 // Size: 0x10
	struct FName RuleName; // Offset: 0x10 // Size: 0x08
	int32_t Priority; // Offset: 0x18 // Size: 0x04
	enum class EGamepadProcessorType EGamepadProcessorType; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct AClient.GamepadActionRules
// Size: 0x100 // Inherited bytes: 0x00
struct FGamepadActionRules {
	// Fields
	struct FName RuleName; // Offset: 0x00 // Size: 0x08
	struct FName BaseRuleName; // Offset: 0x08 // Size: 0x08
	struct TMap<struct FGamepadCombineKey, enum class EGamepadActionType> CombineKey2Action; // Offset: 0x10 // Size: 0x50
	struct TMap<struct FGamepadCombineKey, struct FGamepadDynamicActionList> DynamicCombineKey2ActionList; // Offset: 0x60 // Size: 0x50
	struct TSet<struct FGamepadCombineKey> ExcludeCombineKey; // Offset: 0xb0 // Size: 0x50
};

// Object Name: ScriptStruct AClient.GamepadCombineKey
// Size: 0x10 // Inherited bytes: 0x00
struct FGamepadCombineKey {
	// Fields
	struct TArray<enum class EGamepadKeyType> CombineKey; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GamepadDynamicActionList
// Size: 0x10 // Inherited bytes: 0x00
struct FGamepadDynamicActionList {
	// Fields
	struct TArray<struct FGamepadDynamicActionInfo> GamepadDynamicActionList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GamepadDynamicActionInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FGamepadDynamicActionInfo {
	// Fields
	enum class EGamepadActionType GamepadActionType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AirDropAudioConfigData
// Size: 0x0c // Inherited bytes: 0x00
struct FAirDropAudioConfigData {
	// Fields
	int32_t EventID; // Offset: 0x00 // Size: 0x04
	float DropAirDropTeamAudioDelta; // Offset: 0x04 // Size: 0x04
	int32_t DropAirDropTeamAudioID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ArmsRaceCampMaxScorePlayer
// Size: 0x10 // Inherited bytes: 0x00
struct FArmsRaceCampMaxScorePlayer {
	// Fields
	int32_t CampID; // Offset: 0x00 // Size: 0x04
	int32_t PlayerKey; // Offset: 0x04 // Size: 0x04
	int32_t ArmsLevel; // Offset: 0x08 // Size: 0x04
	int32_t KillCount; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ArmsRaceLevelHistoryData
// Size: 0x08 // Inherited bytes: 0x00
struct FArmsRaceLevelHistoryData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ArmsRacePlayerWeaponData
// Size: 0x0c // Inherited bytes: 0x00
struct FArmsRacePlayerWeaponData {
	// Fields
	int32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t UsingIndex; // Offset: 0x04 // Size: 0x04
	int32_t CurKillCount; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ArmsRaceWeaponIconConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FArmsRaceWeaponIconConfig {
	// Fields
	int32_t ArmsLevel; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString IconPath; // Offset: 0x08 // Size: 0x10
	bool bIsShowText; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct FString TextColor; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ArmsRaceWeaponQueueConfig
// Size: 0x48 // Inherited bytes: 0x00
struct FArmsRaceWeaponQueueConfig {
	// Fields
	int32_t ArmsLevel; // Offset: 0x00 // Size: 0x04
	int32_t LoadoutWeaponID; // Offset: 0x04 // Size: 0x04
	int32_t TargetCount; // Offset: 0x08 // Size: 0x04
	int32_t LoadoutID; // Offset: 0x0c // Size: 0x04
	bool IsBerserk; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString IconPath; // Offset: 0x18 // Size: 0x10
	bool bIsShowText; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FString TextColor; // Offset: 0x30 // Size: 0x10
	bool bIsPromotion; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct AClient.InGameRegionData
// Size: 0x100 // Inherited bytes: 0x00
struct FInGameRegionData {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
	struct TMap<struct FInGameRegionID, struct FInGameRegionObjectList> RegionIDToObjectList_Static; // Offset: 0x10 // Size: 0x50
	struct TMap<struct FInGameRegionID, struct FInGameRegionObjectList> RegionIDToObjectList_Dynamic; // Offset: 0x60 // Size: 0x50
	struct TMap<struct FInGameRegionObject, struct FInGameRegionID> DynamicRegionObjectToRegionID; // Offset: 0xb0 // Size: 0x50
};

// Object Name: ScriptStruct AClient.InGameRegionObject
// Size: 0x08 // Inherited bytes: 0x00
struct FInGameRegionObject {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.InGameRegionID
// Size: 0x0c // Inherited bytes: 0x00
struct FInGameRegionID {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.InGameRegionObjectList
// Size: 0x10 // Inherited bytes: 0x00
struct FInGameRegionObjectList {
	// Fields
	struct TArray<struct FInGameRegionObject> InGameRegionObjectDataArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.InGameRegionConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FInGameRegionConfig {
	// Fields
	enum class InGameRegionType RegionType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t ClientRegionSize; // Offset: 0x04 // Size: 0x04
	int32_t ServerRegionSize; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.InGameTipsParam
// Size: 0x10 // Inherited bytes: 0x00
struct FInGameTipsParam {
	// Fields
	int32_t MostScoreCamp; // Offset: 0x00 // Size: 0x04
	bool bNeedAppendTips; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int32_t PlayerKey; // Offset: 0x08 // Size: 0x04
	int32_t Level; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.PlayerDeadSignData
// Size: 0x0c // Inherited bytes: 0x00
struct FPlayerDeadSignData {
	// Fields
	int32_t SignIndex; // Offset: 0x00 // Size: 0x04
	float CreateTime; // Offset: 0x04 // Size: 0x04
	int32_t CampID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RepDaliyWeeklyData
// Size: 0x10 // Inherited bytes: 0x00
struct FRepDaliyWeeklyData {
	// Fields
	struct FName DaliyRowName; // Offset: 0x00 // Size: 0x08
	struct FName WeeklyRowName; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ReplicateOperate
// Size: 0x20 // Inherited bytes: 0x00
struct FReplicateOperate {
	// Fields
	enum class EReplicateType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FReplicateOperateData Data; // Offset: 0x08 // Size: 0x18
};

// Object Name: ScriptStruct AClient.ReplicateOperateData
// Size: 0x18 // Inherited bytes: 0x00
struct FReplicateOperateData {
	// Fields
	struct TArray<int32_t> ItemIDs; // Offset: 0x00 // Size: 0x10
	int32_t Cost; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SelectStageConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FSelectStageConfig {
	// Fields
	enum class ESelectLegendStage Stage; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Duration; // Offset: 0x04 // Size: 0x04
	struct FSelecStateInfo Info; // Offset: 0x08 // Size: 0x20
};

// Object Name: ScriptStruct AClient.SelecStateInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FSelecStateInfo {
	// Fields
	struct TArray<struct UAkAudioEvent*> StateBGMs; // Offset: 0x00 // Size: 0x10
	struct TArray<float> SubDevision; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.TDMWeaponItemData
// Size: 0x48 // Inherited bytes: 0x00
struct FTDMWeaponItemData {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t GroupID; // Offset: 0x04 // Size: 0x04
	int32_t IsValid; // Offset: 0x08 // Size: 0x04
	int32_t WholeWeaponID; // Offset: 0x0c // Size: 0x04
	int32_t EmptyFittingID; // Offset: 0x10 // Size: 0x04
	int32_t DefaultFittingID; // Offset: 0x14 // Size: 0x04
	struct TArray<int32_t> UsableFittingIDArray; // Offset: 0x18 // Size: 0x10
	int32_t Quality; // Offset: 0x28 // Size: 0x04
	int32_t WeaponID; // Offset: 0x2c // Size: 0x04
	int32_t BulletCount; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<int32_t> WeaponAttachment; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AClient.TDMSelectWeaponHistory
// Size: 0x20 // Inherited bytes: 0x00
struct FTDMSelectWeaponHistory {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct AClient.TDMSelectWeaponHistoryData
// Size: 0x08 // Inherited bytes: 0x00
struct FTDMSelectWeaponHistoryData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SettlementData
// Size: 0x10 // Inherited bytes: 0x00
struct FSettlementData {
	// Fields
	int32_t Level; // Offset: 0x00 // Size: 0x04
	int32_t KillNum; // Offset: 0x04 // Size: 0x04
	int32_t RewardLoot; // Offset: 0x08 // Size: 0x04
	int32_t RewardEffectLV; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ColosseumStageActiveData
// Size: 0x0c // Inherited bytes: 0x00
struct FColosseumStageActiveData {
	// Fields
	enum class TTOColosseumStage Stage; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float StartServerTime; // Offset: 0x04 // Size: 0x04
	int32_t CurStageTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ColosseumStageTimeData
// Size: 0x08 // Inherited bytes: 0x00
struct FColosseumStageTimeData {
	// Fields
	enum class TTOColosseumStage Stage; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t StageTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.TTOColosseumAudioConfigData
// Size: 0x30 // Inherited bytes: 0x00
struct FTTOColosseumAudioConfigData {
	// Fields
	struct FString Tips; // Offset: 0x00 // Size: 0x10
	enum class TTOColosseumStage AudioStage; // Offset: 0x10 // Size: 0x01
	bool bInStagePlay; // Offset: 0x11 // Size: 0x01
	enum class EColosseumTipsAreaType TipsAreaType; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x1]; // Offset: 0x13 // Size: 0x01
	float EventAudioDelta; // Offset: 0x14 // Size: 0x04
	int32_t EventID; // Offset: 0x18 // Size: 0x04
	int32_t UITipsID; // Offset: 0x1c // Size: 0x04
	float UITipsDuration; // Offset: 0x20 // Size: 0x04
	enum class ColosseumTipsType UITipsType; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	float TeamAudioDelta; // Offset: 0x28 // Size: 0x04
	int32_t TeamAudioID; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.WinterExpressCampState
// Size: 0x0c // Inherited bytes: 0x00
struct FWinterExpressCampState {
	// Fields
	int32_t CampID; // Offset: 0x00 // Size: 0x04
	bool bIsCampDead; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int32_t CampScore; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WinterWarfareSnowEffectConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FWinterWarfareSnowEffectConfig {
	// Fields
	struct TArray<enum class EPawnState> PawnStateArray; // Offset: 0x00 // Size: 0x10
	int32_t Priority; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FWinterWarfareSnowEffectParam> Params; // Offset: 0x18 // Size: 0x10
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct AClient.WinterWarfareSnowEffectParam
// Size: 0x1c // Inherited bytes: 0x00
struct FWinterWarfareSnowEffectParam {
	// Fields
	struct FName ParamName; // Offset: 0x00 // Size: 0x08
	bool bIsFloatParam; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float ParamFloat; // Offset: 0x0c // Size: 0x04
	struct FVector ParamVector; // Offset: 0x10 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.WinterWarfareSortData
// Size: 0x18 // Inherited bytes: 0x00
struct FWinterWarfareSortData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.WinterWarfareRoundData
// Size: 0x10 // Inherited bytes: 0x00
struct FWinterWarfareRoundData {
	// Fields
	int32_t RoundIndex; // Offset: 0x00 // Size: 0x04
	float DelayTime; // Offset: 0x04 // Size: 0x04
	float ActivateTime; // Offset: 0x08 // Size: 0x04
	int32_t ActiveBinCount; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.GameStatisticsVOSetting
// Size: 0x28 // Inherited bytes: 0x00
struct FGameStatisticsVOSetting {
	// Fields
	float MegaKillTime; // Offset: 0x00 // Size: 0x04
	int32_t MegaKillNum; // Offset: 0x04 // Size: 0x04
	struct TArray<float> KnockDownCamboTime; // Offset: 0x08 // Size: 0x10
	float FarEngagementMinDist; // Offset: 0x18 // Size: 0x04
	float SquadEngagementCalloutDebounce; // Offset: 0x1c // Size: 0x04
	float SameEventDebounce; // Offset: 0x20 // Size: 0x04
	float ChanceForCharacterComment; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CampScoringRecord
// Size: 0x10 // Inherited bytes: 0x00
struct FCampScoringRecord {
	// Fields
	int32_t CampID; // Offset: 0x00 // Size: 0x04
	int32_t CampRole; // Offset: 0x04 // Size: 0x04
	int32_t Score; // Offset: 0x08 // Size: 0x04
	enum class EScoringReason Reason; // Offset: 0x0c // Size: 0x01
	bool FinishGame; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
};

// Object Name: ScriptStruct AClient.GameStatisticsPlayerExitStatistics
// Size: 0x50 // Inherited bytes: 0x00
struct FGameStatisticsPlayerExitStatistics {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.GameStatisticsSetting
// Size: 0x28 // Inherited bytes: 0x00
struct FGameStatisticsSetting {
	// Fields
	float AssistAccountableDuration; // Offset: 0x00 // Size: 0x04
	float KnockDownCauserTime; // Offset: 0x04 // Size: 0x04
	struct UCurveFloat* ComboTime; // Offset: 0x08 // Size: 0x08
	float ComboKnockDownTime; // Offset: 0x10 // Size: 0x04
	float VerticalDamageHeight; // Offset: 0x14 // Size: 0x04
	float BehindDamageAngle; // Offset: 0x18 // Size: 0x04
	float DamageRecoveryHPTime; // Offset: 0x1c // Size: 0x04
	float RespawnKillTime; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GameBasicStatistics
// Size: 0x818 // Inherited bytes: 0x00
struct FGameBasicStatistics {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
	uint32_t Observers; // Offset: 0x0c // Size: 0x04
	char pad_0x10[0x808]; // Offset: 0x10 // Size: 0x808
};

// Object Name: ScriptStruct AClient.GamePlayerStatistics
// Size: 0xea0 // Inherited bytes: 0x00
struct FGamePlayerStatistics {
	// Fields
	struct FPlayerInfo PlayerInfo; // Offset: 0x00 // Size: 0x108
	char pad_0x108[0x4c]; // Offset: 0x108 // Size: 0x4c
	int32_t Score; // Offset: 0x154 // Size: 0x04
	char pad_0x158[0xc]; // Offset: 0x158 // Size: 0x0c
	float Damage; // Offset: 0x164 // Size: 0x04
	char pad_0x168[0x1b8]; // Offset: 0x168 // Size: 0x1b8
	struct TMap<struct UZiplineComponent*, int32_t> ZipLineMap; // Offset: 0x320 // Size: 0x50
	char pad_0x370[0x2b8]; // Offset: 0x370 // Size: 0x2b8
	struct TArray<struct FPlayerInfo> Observers; // Offset: 0x628 // Size: 0x10
	char pad_0x638[0x10]; // Offset: 0x638 // Size: 0x10
	int32_t AssistNum; // Offset: 0x648 // Size: 0x04
	char pad_0x64C[0x24]; // Offset: 0x64c // Size: 0x24
	int32_t KillNum; // Offset: 0x670 // Size: 0x04
	char pad_0x674[0x464]; // Offset: 0x674 // Size: 0x464
	int32_t RatingScore; // Offset: 0xad8 // Size: 0x04
	char pad_0xADC[0x35c]; // Offset: 0xadc // Size: 0x35c
	bool bReSpawn; // Offset: 0xe38 // Size: 0x01
	char pad_0xE39[0x67]; // Offset: 0xe39 // Size: 0x67
};

// Object Name: ScriptStruct AClient.PlayerInfo
// Size: 0x108 // Inherited bytes: 0x00
struct FPlayerInfo {
	// Fields
	uint64_t UID; // Offset: 0x00 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x08 // Size: 0x04
	int32_t TeamID; // Offset: 0x0c // Size: 0x04
	int32_t CampID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString PlayerName; // Offset: 0x18 // Size: 0x10
	int32_t Corps_Select_ID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0xc]; // Offset: 0x2c // Size: 0x0c
	struct TArray<int32_t> CurrentEmotePaintingData; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x10]; // Offset: 0x48 // Size: 0x10
	int32_t Rating; // Offset: 0x58 // Size: 0x04
	int32_t DailyWinTime; // Offset: 0x5c // Size: 0x04
	char pad_0x60[0x90]; // Offset: 0x60 // Size: 0x90
	bool bAI; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x7]; // Offset: 0xf1 // Size: 0x07
	struct TArray<int32_t> Emote; // Offset: 0xf8 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AssistDataList
// Size: 0x18 // Inherited bytes: 0x00
struct FAssistDataList {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.CauserKillData
// Size: 0x14 // Inherited bytes: 0x00
struct FCauserKillData {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x00 // Size: 0x14
};

// Object Name: ScriptStruct AClient.PositiveFeedback_GrenadeMultiHit
// Size: 0x0c // Inherited bytes: 0x00
struct FPositiveFeedback_GrenadeMultiHit {
	// Fields
	uint32_t GrenadeID; // Offset: 0x00 // Size: 0x04
	uint32_t KnockDownCount; // Offset: 0x04 // Size: 0x04
	uint32_t KillCount; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PositiveFeedback_Kill
// Size: 0x08 // Inherited bytes: 0x00
struct FPositiveFeedback_Kill {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PositiveFeedback_KnockDown
// Size: 0x10 // Inherited bytes: 0x00
struct FPositiveFeedback_KnockDown {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PlayerInfoToClient
// Size: 0x118 // Inherited bytes: 0x00
struct FPlayerInfoToClient {
	// Fields
	struct FPlayerInfo PlayerInfo; // Offset: 0x00 // Size: 0x108
	struct TArray<struct FSimpleTrackerData> TrackerData; // Offset: 0x108 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LegendPlayInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FLegendPlayInfo {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.StageFiveSecondCheckInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FStageFiveSecondCheckInfo {
	// Fields
	struct FString Timespan; // Offset: 0x00 // Size: 0x10
	int32_t PlayerNum; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.StageSwichRepInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FStageSwichRepInfo {
	// Fields
	struct FString Timespan; // Offset: 0x00 // Size: 0x10
	struct FString RoleID; // Offset: 0x10 // Size: 0x10
	int32_t RoundIdx; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RespawnNextLifeFlowData
// Size: 0x20 // Inherited bytes: 0x00
struct FRespawnNextLifeFlowData {
	// Fields
	int32_t RespawnStartTime; // Offset: 0x00 // Size: 0x04
	int32_t RespawnDistance; // Offset: 0x04 // Size: 0x04
	int32_t RespawnEndTime; // Offset: 0x08 // Size: 0x04
	int32_t RespawnSurvivalTime; // Offset: 0x0c // Size: 0x04
	struct FString RoleID; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.VIPFlowData
// Size: 0x04 // Inherited bytes: 0x00
struct FVIPFlowData {
	// Fields
	int32_t SeasonCoinNum; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AClient.UpgradeArmorFlowData
// Size: 0x60 // Inherited bytes: 0x00
struct FUpgradeArmorFlowData {
	// Fields
	struct FString RoleID; // Offset: 0x00 // Size: 0x10
	struct FString OpenId; // Offset: 0x10 // Size: 0x10
	struct FString dtEventTime; // Offset: 0x20 // Size: 0x10
	int32_t OldLevel; // Offset: 0x30 // Size: 0x04
	int32_t OldExp; // Offset: 0x34 // Size: 0x04
	int32_t NewLevel; // Offset: 0x38 // Size: 0x04
	int32_t NewExp; // Offset: 0x3c // Size: 0x04
	int32_t ChangeType; // Offset: 0x40 // Size: 0x04
	int32_t DamageType; // Offset: 0x44 // Size: 0x04
	int32_t ExpFromTrueRole; // Offset: 0x48 // Size: 0x04
	int32_t ExpFromAI; // Offset: 0x4c // Size: 0x04
	int32_t ExpFromNPC; // Offset: 0x50 // Size: 0x04
	int32_t ExpFromPerk; // Offset: 0x54 // Size: 0x04
	int32_t CircleCount; // Offset: 0x58 // Size: 0x04
	int32_t TeamNum; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct AClient.RowdyFlowData
// Size: 0x14 // Inherited bytes: 0x00
struct FRowdyFlowData {
	// Fields
	float PositionX; // Offset: 0x00 // Size: 0x04
	float PositionY; // Offset: 0x04 // Size: 0x04
	float PositionZ; // Offset: 0x08 // Size: 0x04
	int32_t PlayNum; // Offset: 0x0c // Size: 0x04
	int32_t SpawnNum; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BinFlowData
// Size: 0x48 // Inherited bytes: 0x00
struct FBinFlowData {
	// Fields
	float PositionX; // Offset: 0x00 // Size: 0x04
	float PositionY; // Offset: 0x04 // Size: 0x04
	float PositionZ; // Offset: 0x08 // Size: 0x04
	int32_t Type; // Offset: 0x0c // Size: 0x04
	bool IsOpen; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t OpenWaveIndex; // Offset: 0x14 // Size: 0x04
	struct FString OpenRoleID; // Offset: 0x18 // Size: 0x10
	int32_t IceBinActiveWaveIndex; // Offset: 0x28 // Size: 0x04
	int32_t IceNum; // Offset: 0x2c // Size: 0x04
	struct FString OpenTime; // Offset: 0x30 // Size: 0x10
	bool IsOpenBinBottom; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct AClient.HarvesterFlowData
// Size: 0x10 // Inherited bytes: 0x00
struct FHarvesterFlowData {
	// Fields
	float PositionX; // Offset: 0x00 // Size: 0x04
	float PositionY; // Offset: 0x04 // Size: 0x04
	float PositionZ; // Offset: 0x08 // Size: 0x04
	int32_t ExtractNum; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ReplicatorFlowData
// Size: 0x1c // Inherited bytes: 0x00
struct FReplicatorFlowData {
	// Fields
	float PositionX; // Offset: 0x00 // Size: 0x04
	float PositionY; // Offset: 0x04 // Size: 0x04
	float PositionZ; // Offset: 0x08 // Size: 0x04
	int32_t Type; // Offset: 0x0c // Size: 0x04
	int32_t UseCount; // Offset: 0x10 // Size: 0x04
	int32_t UseSuccessCount; // Offset: 0x14 // Size: 0x04
	int32_t CostMaterialNum; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LootBinCreepFlowData
// Size: 0x90 // Inherited bytes: 0x00
struct FLootBinCreepFlowData {
	// Fields
	float PositionX; // Offset: 0x00 // Size: 0x04
	float PositionY; // Offset: 0x04 // Size: 0x04
	float PositionZ; // Offset: 0x08 // Size: 0x04
	bool bIsDestroy; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	int32_t Quality; // Offset: 0x10 // Size: 0x04
	int32_t SpatialType; // Offset: 0x14 // Size: 0x04
	int32_t Region; // Offset: 0x18 // Size: 0x04
	int32_t Round; // Offset: 0x1c // Size: 0x04
	struct FString KilledTimeSpan; // Offset: 0x20 // Size: 0x10
	struct FString KillerRoleID; // Offset: 0x30 // Size: 0x10
	struct TMap<int32_t, int32_t> ItemsData; // Offset: 0x40 // Size: 0x50
};

// Object Name: ScriptStruct AClient.DoorFlowData
// Size: 0x14 // Inherited bytes: 0x00
struct FDoorFlowData {
	// Fields
	float PositionX; // Offset: 0x00 // Size: 0x04
	float PositionY; // Offset: 0x04 // Size: 0x04
	float PositionZ; // Offset: 0x08 // Size: 0x04
	int32_t OpenCount; // Offset: 0x0c // Size: 0x04
	int32_t CloseCount; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RespawnFlowData
// Size: 0x20 // Inherited bytes: 0x00
struct FRespawnFlowData {
	// Fields
	uint32_t Rescuer; // Offset: 0x00 // Size: 0x04
	char ReviveFrom; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct FString SecReportData; // Offset: 0x08 // Size: 0x10
	int64_t ClientStartTime; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.GameBasicStatistics_BR
// Size: 0x860 // Inherited bytes: 0x818
struct FGameBasicStatistics_BR : FGameBasicStatistics {
	// Fields
	char pad_0x818[0x4]; // Offset: 0x818 // Size: 0x04
	char SurvivePlayer; // Offset: 0x81c // Size: 0x01
	char SurviveTeam; // Offset: 0x81d // Size: 0x01
	char pad_0x81E[0x1]; // Offset: 0x81e // Size: 0x01
	char KillKingMaxKill; // Offset: 0x81f // Size: 0x01
	uint32_t KillKingPlayerKey; // Offset: 0x820 // Size: 0x04
	char pad_0x824[0xc]; // Offset: 0x824 // Size: 0x0c
	struct TArray<struct FGamePlayerStatistics_BR> GamePlayerStatistics; // Offset: 0x830 // Size: 0x10
	char pad_0x840[0x10]; // Offset: 0x840 // Size: 0x10
	struct FRatingScoreInfo RatingScoreInfo; // Offset: 0x850 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GamePlayerStatistics_BR
// Size: 0xed8 // Inherited bytes: 0xea0
struct FGamePlayerStatistics_BR : FGamePlayerStatistics {
	// Fields
	char pad_0xEA0[0x38]; // Offset: 0xea0 // Size: 0x38
};

// Object Name: ScriptStruct AClient.GameStatisticsPlayerExitStatistics_MP
// Size: 0xa0 // Inherited bytes: 0x50
struct FGameStatisticsPlayerExitStatistics_MP : FGameStatisticsPlayerExitStatistics {
	// Fields
	char pad_0x50[0x50]; // Offset: 0x50 // Size: 0x50
};

// Object Name: ScriptStruct AClient.GameBasicStatistics_MP
// Size: 0x8d0 // Inherited bytes: 0x818
struct FGameBasicStatistics_MP : FGameBasicStatistics {
	// Fields
	struct TArray<struct FGamePlayerStatistics_MP> GamePlayerStatistics; // Offset: 0x818 // Size: 0x10
	struct TArray<struct FGameCampStatistics_MP> GameCampStatistics; // Offset: 0x828 // Size: 0x10
	struct TArray<struct FCampScoringRecord> CampScoringRecords; // Offset: 0x838 // Size: 0x10
	bool bRoundData; // Offset: 0x848 // Size: 0x01
	char pad_0x849[0x3]; // Offset: 0x849 // Size: 0x03
	int32_t TiedTimes; // Offset: 0x84c // Size: 0x04
	char pad_0x850[0x70]; // Offset: 0x850 // Size: 0x70
	struct TArray<struct FGameBombDefusalPlayerData> BombDefusalPlayerDataList; // Offset: 0x8c0 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GameBombDefusalPlayerData
// Size: 0x0c // Inherited bytes: 0x00
struct FGameBombDefusalPlayerData {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t PlantSuccessTime; // Offset: 0x04 // Size: 0x04
	int32_t DefuseSuccessTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GameCampStatistics_MP
// Size: 0x38 // Inherited bytes: 0x00
struct FGameCampStatistics_MP {
	// Fields
	int32_t CampID; // Offset: 0x00 // Size: 0x04
	int32_t Rank; // Offset: 0x04 // Size: 0x04
	struct FString Result; // Offset: 0x08 // Size: 0x10
	struct TArray<uint32_t> CampMembers; // Offset: 0x18 // Size: 0x10
	uint16_t Kills; // Offset: 0x28 // Size: 0x02
	uint16_t Died; // Offset: 0x2a // Size: 0x02
	int32_t Score; // Offset: 0x2c // Size: 0x04
	int32_t ScoreKillCount; // Offset: 0x30 // Size: 0x04
	float Damage; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GamePlayerStatistics_MP
// Size: 0xee0 // Inherited bytes: 0xea0
struct FGamePlayerStatistics_MP : FGamePlayerStatistics {
	// Fields
	char pad_0xEA0[0x4]; // Offset: 0xea0 // Size: 0x04
	int32_t Deaths; // Offset: 0xea4 // Size: 0x04
	int32_t ContinuousKills; // Offset: 0xea8 // Size: 0x04
	int32_t Rank; // Offset: 0xeac // Size: 0x04
	int32_t OpenMaterialNum; // Offset: 0xeb0 // Size: 0x04
	int32_t OpenBinNum; // Offset: 0xeb4 // Size: 0x04
	int32_t OpenAirDropNum; // Offset: 0xeb8 // Size: 0x04
	int32_t PlayerIndex; // Offset: 0xebc // Size: 0x04
	float OpenShopTime; // Offset: 0xec0 // Size: 0x04
	int32_t WinLastPlayer; // Offset: 0xec4 // Size: 0x04
	struct FMPFlowData FlowData; // Offset: 0xec8 // Size: 0x14
	char pad_0xEDC[0x4]; // Offset: 0xedc // Size: 0x04
};

// Object Name: ScriptStruct AClient.MPFlowData
// Size: 0x14 // Inherited bytes: 0x00
struct FMPFlowData {
	// Fields
	float OpenShopTime; // Offset: 0x00 // Size: 0x04
	int32_t OpenSocreTime; // Offset: 0x04 // Size: 0x04
	int32_t SlidingWeaponListTime; // Offset: 0x08 // Size: 0x04
	int32_t ClickSellTime; // Offset: 0x0c // Size: 0x04
	int32_t ClickChangeFittingTime; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.VictimData_MPBase
// Size: 0x08 // Inherited bytes: 0x00
struct FVictimData_MPBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.CharacterSyncSetting
// Size: 0x78 // Inherited bytes: 0x00
struct FCharacterSyncSetting {
	// Fields
	bool bInit; // Offset: 0x00 // Size: 0x01
	bool bOpenWeaponEncryption; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FCharacterMovementSyncSetting MovementSyncSetting; // Offset: 0x08 // Size: 0x70
};

// Object Name: ScriptStruct AClient.CharacterMovementSyncSetting
// Size: 0x70 // Inherited bytes: 0x00
struct FCharacterMovementSyncSetting {
	// Fields
	float JumpHeight; // Offset: 0x00 // Size: 0x04
	float MaxJumpHeight; // Offset: 0x04 // Size: 0x04
	float MaxSpeed; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FCharacterMovementSyncSetting_LegendClimbData> LegendClimbData; // Offset: 0x10 // Size: 0x10
	char pad_0x20[0x50]; // Offset: 0x20 // Size: 0x50
};

// Object Name: ScriptStruct AClient.CharacterMovementSyncSetting_LegendClimbData
// Size: 0x0c // Inherited bytes: 0x00
struct FCharacterMovementSyncSetting_LegendClimbData {
	// Fields
	enum class ELegendType LegendType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ClimbLimitHeight; // Offset: 0x04 // Size: 0x04
	float FinalJumpHeight; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WholeWeaponColorConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FWholeWeaponColorConfig {
	// Fields
	struct FLinearColor FrameColor; // Offset: 0x00 // Size: 0x10
	struct FLinearColor ShineColor; // Offset: 0x10 // Size: 0x10
	struct FLinearColor StarColor; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.WeaponColorConfig
// Size: 0x38 // Inherited bytes: 0x00
struct FWeaponColorConfig {
	// Fields
	struct FLinearColor FrameColor; // Offset: 0x00 // Size: 0x10
	struct FSlateColor NumColor; // Offset: 0x10 // Size: 0x28
};

// Object Name: ScriptStruct AClient.BombPosList
// Size: 0x10 // Inherited bytes: 0x00
struct FBombPosList {
	// Fields
	struct TArray<struct FVector> PosList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GrappleHookRuntimeData
// Size: 0xa8 // Inherited bytes: 0x00
struct FGrappleHookRuntimeData {
	// Fields
	char pad_0x0[0xa8]; // Offset: 0x00 // Size: 0xa8
};

// Object Name: ScriptStruct AClient.PathfinderCheckSweepConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FPathfinderCheckSweepConfig {
	// Fields
	float StartLocationPercentage; // Offset: 0x00 // Size: 0x04
	float SphereRadius; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GrapplingHookStatusData
// Size: 0xe0 // Inherited bytes: 0x00
struct FGrapplingHookStatusData {
	// Fields
	char pad_0x0[0xe0]; // Offset: 0x00 // Size: 0xe0
};

// Object Name: ScriptStruct AClient.RopeAnimationParam
// Size: 0x18 // Inherited bytes: 0x00
struct FRopeAnimationParam {
	// Fields
	float QuarterCycleNumUp; // Offset: 0x00 // Size: 0x04
	float QuarterCycleNumRight; // Offset: 0x04 // Size: 0x04
	float OffsetQuarterCycleFactorUp; // Offset: 0x08 // Size: 0x04
	float OffsetQuarterCycleFactorRight; // Offset: 0x0c // Size: 0x04
	float OffsetQuarterCycleUp; // Offset: 0x10 // Size: 0x04
	float OffsetQuarterCycleRight; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RopeAnimationParamRespawn
// Size: 0x08 // Inherited bytes: 0x00
struct FRopeAnimationParamRespawn {
	// Fields
	float Angle; // Offset: 0x00 // Size: 0x04
	float Offset; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GrenadePredictResult
// Size: 0x30 // Inherited bytes: 0x00
struct FGrenadePredictResult {
	// Fields
	struct TArray<struct FVector> SplinePoints; // Offset: 0x00 // Size: 0x10
	bool IsHitActor; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FVector HitActorLocation; // Offset: 0x14 // Size: 0x0c
	struct FRotator HitActorRotation; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.PredictLineRuntimeEffectConfig
// Size: 0x58 // Inherited bytes: 0x00
struct FPredictLineRuntimeEffectConfig {
	// Fields
	enum class ESplineMeshAxis PredictLineForwardAxis; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UStaticMesh* PredictionLineMesh; // Offset: 0x08 // Size: 0x08
	struct UParticleSystem* PredictionLineTargetParticle; // Offset: 0x10 // Size: 0x08
	struct UParticleSystem* PredictionLineTargetAreaParticle; // Offset: 0x18 // Size: 0x08
	struct FName PredictionLineMaterialSlotName; // Offset: 0x20 // Size: 0x08
	struct UMaterialInstanceDynamic* PredictionLineMaterialStartInst; // Offset: 0x28 // Size: 0x08
	struct UMaterialInstanceDynamic* PredictionLineMaterialEndInst; // Offset: 0x30 // Size: 0x08
	int32_t PredictionTargetMaterialSlotIndex; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct UMaterialInstanceDynamic* PredictionTargetMaterialInst; // Offset: 0x40 // Size: 0x08
	struct FVector2D PredictionLineScale; // Offset: 0x48 // Size: 0x08
	float PredictionLineRoll; // Offset: 0x50 // Size: 0x04
	bool IsFaceCamera; // Offset: 0x54 // Size: 0x01
	enum class EAPRenderPass RenderPass; // Offset: 0x55 // Size: 0x01
	char pad_0x56[0x2]; // Offset: 0x56 // Size: 0x02
};

// Object Name: ScriptStruct AClient.GuideSimpleBaseInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FGuideSimpleBaseInfo {
	// Fields
	int32_t GuideID; // Offset: 0x00 // Size: 0x04
	float Duration; // Offset: 0x04 // Size: 0x04
	float DelayHideTime; // Offset: 0x08 // Size: 0x04
	bool bNormal; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	int32_t XLineOffset; // Offset: 0x10 // Size: 0x04
	int32_t XLineLengthOffset; // Offset: 0x14 // Size: 0x04
	int32_t YLineOffset; // Offset: 0x18 // Size: 0x04
	int32_t YLinLengthOffset; // Offset: 0x1c // Size: 0x04
	struct FText ShowTips; // Offset: 0x20 // Size: 0x18
	struct FVector2D ShowTipsPosition; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct AClient.GFReadyStru
// Size: 0x08 // Inherited bytes: 0x00
struct FGFReadyStru {
	// Fields
	int32_t CurSuitID; // Offset: 0x00 // Size: 0x04
	bool bOpenReadyUI; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.GunFightSkillSet_TabRes
// Size: 0x18 // Inherited bytes: 0x00
struct FGunFightSkillSet_TabRes {
	// Fields
	int32_t SkillID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int32_t> RoundNum; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GunFightDataSet_TabRes
// Size: 0x48 // Inherited bytes: 0x00
struct FGunFightDataSet_TabRes {
	// Fields
	int32_t SuitID; // Offset: 0x00 // Size: 0x04
	int32_t SuitGroupID; // Offset: 0x04 // Size: 0x04
	struct TArray<int32_t> ItemIDs; // Offset: 0x08 // Size: 0x10
	struct TArray<int32_t> ItemNum; // Offset: 0x18 // Size: 0x10
	struct TArray<int32_t> ForceItems; // Offset: 0x28 // Size: 0x10
	struct TArray<int32_t> ShowRound; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AClient.HeadRescueTimeInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FHeadRescueTimeInfo {
	// Fields
	struct FTimerHandle TimerID; // Offset: 0x00 // Size: 0x08
	float TotalTime; // Offset: 0x08 // Size: 0x04
	float StartTime; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.HitEffectConfig
// Size: 0x140 // Inherited bytes: 0x08
struct FHitEffectConfig : FTableRowBase {
	// Fields
	struct TMap<enum class EApexCharacterShieldLevel, struct FLinearColor> HurtShieldColor; // Offset: 0x08 // Size: 0x50
	struct FLinearColor BreakShieldColor; // Offset: 0x58 // Size: 0x10
	int32_t AutonomousHitEffectCacheLimit; // Offset: 0x68 // Size: 0x04
	int32_t SimulatedHitEffectCacheLimit; // Offset: 0x6c // Size: 0x04
	int32_t BulletHitAudioDistance; // Offset: 0x70 // Size: 0x04
	int32_t BulletFlyAudioDistance; // Offset: 0x74 // Size: 0x04
	float EffectMaxDistance; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	struct TMap<enum class EDamageType, struct FName> DamageType2Tag; // Offset: 0x80 // Size: 0x50
	struct TMap<struct FName, struct UHitEffectDataAsset*> ExtraEffect; // Offset: 0xd0 // Size: 0x50
	struct UHitEffectDataAsset* DefaultHitEffect; // Offset: 0x120 // Size: 0x08
	struct FRotator FxRotation; // Offset: 0x128 // Size: 0x0c
	float FxDeviation; // Offset: 0x134 // Size: 0x04
	float DecalReverseDistance; // Offset: 0x138 // Size: 0x04
	char pad_0x13C[0x4]; // Offset: 0x13c // Size: 0x04
};

// Object Name: ScriptStruct AClient.HitEffectCachedDataList
// Size: 0x10 // Inherited bytes: 0x00
struct FHitEffectCachedDataList {
	// Fields
	struct TArray<struct FHitEffectCachedData> DataArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.HitEffectCachedData
// Size: 0x28 // Inherited bytes: 0x00
struct FHitEffectCachedData {
	// Fields
	struct UDecalComponent* HitDecalComp; // Offset: 0x00 // Size: 0x08
	struct UParticleSystemComponent* HitParticleComp; // Offset: 0x08 // Size: 0x08
	struct UAkComponent* AKComp; // Offset: 0x10 // Size: 0x08
	struct UAkComponent* BulletFlyAkComp; // Offset: 0x18 // Size: 0x08
	char pad_0x20[0x8]; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct AClient.HitEffectInstanceData
// Size: 0xf0 // Inherited bytes: 0x00
struct FHitEffectInstanceData {
	// Fields
	bool bHitCharacter; // Offset: 0x00 // Size: 0x01
	bool bIsTeamMate; // Offset: 0x01 // Size: 0x01
	bool bShooterIsTeamMate; // Offset: 0x02 // Size: 0x01
	bool bHitKnockdownShield; // Offset: 0x03 // Size: 0x01
	bool bHitShield; // Offset: 0x04 // Size: 0x01
	bool bBreakShield; // Offset: 0x05 // Size: 0x01
	bool bFatalHealth; // Offset: 0x06 // Size: 0x01
	enum class EApexCharacterShieldLevel CurShieldLevel; // Offset: 0x07 // Size: 0x01
	int32_t DamageType; // Offset: 0x08 // Size: 0x04
	bool bIsUnderWater; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	struct FTransform InstanceTransform; // Offset: 0x10 // Size: 0x30
	struct FBulletHitInfoReplicateData SurfaceHit; // Offset: 0x40 // Size: 0x78
	bool bAudioOnly; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x3]; // Offset: 0xb9 // Size: 0x03
	struct FVector DecalScale; // Offset: 0xbc // Size: 0x0c
	struct TWeakObjectPtr<struct USceneComponent> TargetImpactComp; // Offset: 0xc8 // Size: 0x08
	bool bFXOnly; // Offset: 0xd0 // Size: 0x01
	bool bAttackerIsAutonomousClient; // Offset: 0xd1 // Size: 0x01
	bool bVictimIsAutonomousClient; // Offset: 0xd2 // Size: 0x01
	char pad_0xD3[0x1]; // Offset: 0xd3 // Size: 0x01
	int32_t KnockDownShieldLevel; // Offset: 0xd4 // Size: 0x04
	struct AActor* Attacker; // Offset: 0xd8 // Size: 0x08
	bool bUseEffectOptimize; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0xf]; // Offset: 0xe1 // Size: 0x0f
};

// Object Name: ScriptStruct AClient.BulletHitInfoReplicateData
// Size: 0x78 // Inherited bytes: 0x00
struct FBulletHitInfoReplicateData {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x20 // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x28 // Size: 0x08
	struct FMovementSyncData ShootStart; // Offset: 0x30 // Size: 0x18
	struct FMovementSyncData ShootEnd; // Offset: 0x48 // Size: 0x18
	char pad_0x60[0x18]; // Offset: 0x60 // Size: 0x18
};

// Object Name: ScriptStruct AClient.DecalData
// Size: 0x28 // Inherited bytes: 0x00
struct FDecalData {
	// Fields
	float DecalSize; // Offset: 0x00 // Size: 0x04
	float LifeSpan; // Offset: 0x04 // Size: 0x04
	struct UMaterial* DecalMaterial; // Offset: 0x08 // Size: 0x08
	float ImpactEffectStartScaleDistance; // Offset: 0x10 // Size: 0x04
	float ImpactEffectEndScaleDistance; // Offset: 0x14 // Size: 0x04
	float ImpactEffectStartScaleValue; // Offset: 0x18 // Size: 0x04
	float ImpactEffectEndScaleValue; // Offset: 0x1c // Size: 0x04
	float DecalFadeScreenSize; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.HoverTankSpecialStopPointConfig
// Size: 0x40 // Inherited bytes: 0x00
struct FHoverTankSpecialStopPointConfig {
	// Fields
	int32_t StopPointID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct AActor* SpawnClass; // Offset: 0x08 // Size: 0x08
	struct FTransform Transform; // Offset: 0x10 // Size: 0x30
};

// Object Name: ScriptStruct AClient.HoverTankZiplineRepData
// Size: 0x10 // Inherited bytes: 0x00
struct FHoverTankZiplineRepData {
	// Fields
	enum class EHoverTankZiplineType ZiplineType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector EndOffset; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.HoverTankZiplineComponentConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FHoverTankZiplineComponentConfig {
	// Fields
	enum class EHoverTankZiplineType ZiplineType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UZiplineComponent* ZiplineComponent; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.HoverTankLinkMap
// Size: 0x50 // Inherited bytes: 0x00
struct FHoverTankLinkMap {
	// Fields
	struct TMap<int32_t, struct FHoverTankLinkData> LinkToMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.HoverTankLinkData
// Size: 0x0c // Inherited bytes: 0x00
struct FHoverTankLinkData {
	// Fields
	int32_t FromID; // Offset: 0x00 // Size: 0x04
	int32_t ToID; // Offset: 0x04 // Size: 0x04
	float Distance; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.HUDRenderObject
// Size: 0x38 // Inherited bytes: 0x00
struct FHUDRenderObject {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	bool bHidden; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float RenderPriority; // Offset: 0x0c // Size: 0x04
	struct FVector2D Position; // Offset: 0x10 // Size: 0x08
	struct FVector2D Size; // Offset: 0x18 // Size: 0x08
	struct FLinearColor RenderColor; // Offset: 0x20 // Size: 0x10
	float RenderOpacity; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.HUDRenderObject_Text
// Size: 0xa0 // Inherited bytes: 0x38
struct FHUDRenderObject_Text : FHUDRenderObject {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10
	struct FText Text; // Offset: 0x48 // Size: 0x18
	struct UFont* Font; // Offset: 0x60 // Size: 0x08
	float TextScale; // Offset: 0x68 // Size: 0x04
	bool bDrawShadow; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0x3]; // Offset: 0x6d // Size: 0x03
	struct FVector2D ShadowDirection; // Offset: 0x70 // Size: 0x08
	struct FLinearColor ShadowColor; // Offset: 0x78 // Size: 0x10
	bool bDrawOutline; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x3]; // Offset: 0x89 // Size: 0x03
	struct FLinearColor OutlineColor; // Offset: 0x8c // Size: 0x10
	enum class ETextHorzPos HorzPosition; // Offset: 0x9c // Size: 0x01
	enum class ETextVertPos VertPosition; // Offset: 0x9d // Size: 0x01
	char pad_0x9E[0x2]; // Offset: 0x9e // Size: 0x02
};

// Object Name: ScriptStruct AClient.HUDRenderObject_Texture
// Size: 0x80 // Inherited bytes: 0x38
struct FHUDRenderObject_Texture : FHUDRenderObject {
	// Fields
	struct UTexture* Atlas; // Offset: 0x38 // Size: 0x08
	struct FTextureUVs UVs; // Offset: 0x40 // Size: 0x10
	bool bUseTeamColors; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
	struct TArray<struct FLinearColor> TeamColorOverrides; // Offset: 0x58 // Size: 0x10
	bool bIsBorderElement; // Offset: 0x68 // Size: 0x01
	bool bIsSlateElement; // Offset: 0x69 // Size: 0x01
	char pad_0x6A[0x2]; // Offset: 0x6a // Size: 0x02
	struct FVector2D RenderOffset; // Offset: 0x6c // Size: 0x08
	float Rotation; // Offset: 0x74 // Size: 0x04
	struct FVector2D RotPivot; // Offset: 0x78 // Size: 0x08
};

// Object Name: ScriptStruct AClient.TextureUVs
// Size: 0x10 // Inherited bytes: 0x00
struct FTextureUVs {
	// Fields
	float U; // Offset: 0x00 // Size: 0x04
	float V; // Offset: 0x04 // Size: 0x04
	float UL; // Offset: 0x08 // Size: 0x04
	float VL; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.IndiviAnimItem
// Size: 0x40 // Inherited bytes: 0x00
struct FIndiviAnimItem {
	// Fields
	enum class ELegendType LegendType; // Offset: 0x00 // Size: 0x01
	char IndiviType; // Offset: 0x01 // Size: 0x01
	bool bFPP; // Offset: 0x02 // Size: 0x01
	enum class ECharacterAnimType AnimType; // Offset: 0x03 // Size: 0x01
	enum class ECharacterPoseType PoseType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct TSoftObjectPtr<UAnimationAsset> IndiviAnimSoftPtr; // Offset: 0x08 // Size: 0x28
	struct UObject* ExtendObject; // Offset: 0x30 // Size: 0x08
	enum class EAnimLayerType AnimLayer; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

// Object Name: ScriptStruct AClient.InGameChatReportData
// Size: 0x28 // Inherited bytes: 0x00
struct FInGameChatReportData {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.InGameChatInfo
// Size: 0xe8 // Inherited bytes: 0x00
struct FInGameChatInfo {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	uint64_t UID; // Offset: 0x08 // Size: 0x08
	uint32_t PostPlayerKey; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString PostPlayerName; // Offset: 0x18 // Size: 0x10
	struct FString ContentStr; // Offset: 0x28 // Size: 0x10
	struct FString ContentStr2; // Offset: 0x38 // Size: 0x10
	int32_t TeamIdx; // Offset: 0x48 // Size: 0x04
	int32_t TeamID; // Offset: 0x4c // Size: 0x04
	int32_t CampID; // Offset: 0x50 // Size: 0x04
	float CreateTime; // Offset: 0x54 // Size: 0x04
	struct FString SelfName; // Offset: 0x58 // Size: 0x10
	int32_t SendType; // Offset: 0x68 // Size: 0x04
	int32_t FromType; // Offset: 0x6c // Size: 0x04
	struct FString GenerateStr; // Offset: 0x70 // Size: 0x10
	struct FInGameChatPingInfo PingInfo; // Offset: 0x80 // Size: 0x38
	int32_t QuickMsgID; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct TArray<struct FString> ChatParams; // Offset: 0xc0 // Size: 0x10
	struct FInGameChatRequireInfo RequireInfo; // Offset: 0xd0 // Size: 0x18
};

// Object Name: ScriptStruct AClient.InGameChatRequireInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FInGameChatRequireInfo {
	// Fields
	struct FString LocalizeKey; // Offset: 0x00 // Size: 0x10
	int32_t ParamNum1; // Offset: 0x10 // Size: 0x04
	int32_t ParamNum2; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.InGameChatPingInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FInGameChatPingInfo {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	uint64_t ItemUUID; // Offset: 0x08 // Size: 0x08
	struct FVector SourcePosition; // Offset: 0x10 // Size: 0x0c
	int32_t PingType; // Offset: 0x1c // Size: 0x04
	int32_t DingType; // Offset: 0x20 // Size: 0x04
	int32_t PingIndex; // Offset: 0x24 // Size: 0x04
	int32_t ReservePlayerKey; // Offset: 0x28 // Size: 0x04
	bool IsExpired; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
	int32_t ItemDeriveID; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.InGameGuideEffectInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FInGameGuideEffectInfo {
	// Fields
	struct TWeakObjectPtr<struct AActor> GuideCircle; // Offset: 0x00 // Size: 0x08
	struct TWeakObjectPtr<struct AActor> GuideHighLight; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.InGameGuideBaseInfo
// Size: 0x3c // Inherited bytes: 0x00
struct FInGameGuideBaseInfo {
	// Fields
	int32_t GuideID; // Offset: 0x00 // Size: 0x04
	int32_t GuidePriority; // Offset: 0x04 // Size: 0x04
	int32_t SameGuideArgs; // Offset: 0x08 // Size: 0x04
	int32_t GuideWeight; // Offset: 0x0c // Size: 0x04
	bool NeedReback; // Offset: 0x10 // Size: 0x01
	bool IsForSpecial; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	int32_t MaxNum; // Offset: 0x14 // Size: 0x04
	int32_t MaxGameNum; // Offset: 0x18 // Size: 0x04
	int32_t EachGameCountLimit; // Offset: 0x1c // Size: 0x04
	int32_t PlayerLevelLimit; // Offset: 0x20 // Size: 0x04
	int32_t GuideStartGameNum; // Offset: 0x24 // Size: 0x04
	int32_t GuideEndGameNum; // Offset: 0x28 // Size: 0x04
	bool bIsClearWhenCharacterEndPlay; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
	float GuideCD; // Offset: 0x30 // Size: 0x04
	enum class EUILayerType HUDLayer; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	int32_t ForceNextGuideID; // Offset: 0x38 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CurrentGuideInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FCurrentGuideInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.GuideProgressInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FGuideProgressInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.GuideRecordTimer
// Size: 0x08 // Inherited bytes: 0x00
struct FGuideRecordTimer {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.InGameGuideReportData
// Size: 0x20 // Inherited bytes: 0x00
struct FInGameGuideReportData {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct AClient.InGameHandleActionConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FInGameHandleActionConfig {
	// Fields
	struct TArray<struct UInGameHandleActionBase*> ActionArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.InGameHandleAsyncConfig
// Size: 0x58 // Inherited bytes: 0x00
struct FInGameHandleAsyncConfig {
	// Fields
	struct FName AssetName; // Offset: 0x00 // Size: 0x08
	struct TSoftObjectPtr<UObject> LoadAsset; // Offset: 0x08 // Size: 0x28
	struct TSoftClassPtr<UObject> LoadClass; // Offset: 0x30 // Size: 0x28
};

// Object Name: ScriptStruct AClient.InGameLodSkeletalMesh
// Size: 0x50 // Inherited bytes: 0x00
struct FInGameLodSkeletalMesh {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FName ComponentTag; // Offset: 0x08 // Size: 0x08
	bool bReInitPose; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct TArray<struct TSoftObjectPtr<USkeletalMesh>> LodMeshSoftPtrList; // Offset: 0x18 // Size: 0x10
	struct TSoftObjectPtr<USkeletalMesh> OutOfDistanceMeshSoftPtr; // Offset: 0x28 // Size: 0x28
};

// Object Name: ScriptStruct AClient.InGameLodStaticMesh
// Size: 0x48 // Inherited bytes: 0x00
struct FInGameLodStaticMesh {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FName ComponentTag; // Offset: 0x08 // Size: 0x08
	struct TArray<struct TSoftObjectPtr<UStaticMesh>> LodStaticMeshSoftPtrList; // Offset: 0x10 // Size: 0x10
	struct TSoftObjectPtr<UStaticMesh> OutOfDistanceMeshSoftPtr; // Offset: 0x20 // Size: 0x28
};

// Object Name: ScriptStruct AClient.InGameTeamMate
// Size: 0x98 // Inherited bytes: 0x00
struct FInGameTeamMate {
	// Fields
	bool bValid; // Offset: 0x00 // Size: 0x01
	bool IsSelf; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	uint32_t TeamIdx; // Offset: 0x04 // Size: 0x04
	uint64_t UID; // Offset: 0x08 // Size: 0x08
	int32_t PlayerKey; // Offset: 0x10 // Size: 0x04
	int32_t LegendId; // Offset: 0x14 // Size: 0x04
	int32_t ShieldQuality; // Offset: 0x18 // Size: 0x04
	int32_t HelmetQuality; // Offset: 0x1c // Size: 0x04
	int32_t GradableShieldExpRemain; // Offset: 0x20 // Size: 0x04
	int32_t GradableShieldLevel; // Offset: 0x24 // Size: 0x04
	int32_t BackpackLevel; // Offset: 0x28 // Size: 0x04
	bool bNetLost; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
	int32_t KnockDownShieldLevel; // Offset: 0x30 // Size: 0x04
	uint32_t FirstSlotBulletId; // Offset: 0x34 // Size: 0x04
	uint32_t SecondSlotBulletId; // Offset: 0x38 // Size: 0x04
	int32_t FirstSlotTypeSpecificID_Weapon; // Offset: 0x3c // Size: 0x04
	int32_t SecondSlotTypeSpecificID_Weapon; // Offset: 0x40 // Size: 0x04
	bool IsCommander; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
	struct FString PlayerName; // Offset: 0x48 // Size: 0x10
	char BatBeState; // Offset: 0x58 // Size: 0x01
	char BannerState; // Offset: 0x59 // Size: 0x01
	char CurrentNextLifeRespawnState; // Offset: 0x5a // Size: 0x01
	bool bIsSingleParachute; // Offset: 0x5b // Size: 0x01
	uint16_t DyingCount; // Offset: 0x5c // Size: 0x02
	char pad_0x5E[0x2]; // Offset: 0x5e // Size: 0x02
	float DyingTimeoutSec; // Offset: 0x60 // Size: 0x04
	float DyingTime; // Offset: 0x64 // Size: 0x04
	float RespawningTimeoutSec; // Offset: 0x68 // Size: 0x04
	float RespawningTime; // Offset: 0x6c // Size: 0x04
	int32_t UseItemID; // Offset: 0x70 // Size: 0x04
	uint32_t AIHostPlayerKey; // Offset: 0x74 // Size: 0x04
	bool bAIHosting; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x3]; // Offset: 0x79 // Size: 0x03
	int32_t AIHostFunc1; // Offset: 0x7c // Size: 0x04
	int32_t AIHostFunc2; // Offset: 0x80 // Size: 0x04
	int32_t AIHostFunc3; // Offset: 0x84 // Size: 0x04
	int32_t AIHostFunc4; // Offset: 0x88 // Size: 0x04
	int32_t AIHostFunc5; // Offset: 0x8c // Size: 0x04
	bool bUseSecIcon; // Offset: 0x90 // Size: 0x01
	bool bShowNextLife; // Offset: 0x91 // Size: 0x01
	char pad_0x92[0x6]; // Offset: 0x92 // Size: 0x06
};

// Object Name: ScriptStruct AClient.InGameTimeConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FInGameTimeConfig {
	// Fields
	float Transfer; // Offset: 0x00 // Size: 0x04
	float Unfollow; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.InGameHealthAndShieldData
// Size: 0x28 // Inherited bytes: 0x00
struct FInGameHealthAndShieldData {
	// Fields
	float HealthShineValue; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString DefaultColor; // Offset: 0x08 // Size: 0x10
	struct FString DyingBloodColor; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.InGameShieldQualityData
// Size: 0x90 // Inherited bytes: 0x00
struct FInGameShieldQualityData {
	// Fields
	struct FString QualityTexturePath; // Offset: 0x00 // Size: 0x10
	struct FString QualityBgPath; // Offset: 0x10 // Size: 0x10
	struct FString WeaponRootQualityTexturePath; // Offset: 0x20 // Size: 0x10
	struct FString WeaponRootQualityBgPath; // Offset: 0x30 // Size: 0x10
	struct FString HeadItemQualityTexturePath; // Offset: 0x40 // Size: 0x10
	struct FString HeadItemQualityBgPath; // Offset: 0x50 // Size: 0x10
	struct FString ItemQualityPath; // Offset: 0x60 // Size: 0x10
	struct FString ShieldExpColorTextHex; // Offset: 0x70 // Size: 0x10
	struct FString ShieldExpColorFrameHex; // Offset: 0x80 // Size: 0x10
};

// Object Name: ScriptStruct AClient.InGameTeamInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FInGameTeamInfo {
	// Fields
	struct FString Color; // Offset: 0x00 // Size: 0x10
	struct FString TeamLeaderTexturePath; // Offset: 0x10 // Size: 0x10
	struct FString TeamMemberBgTexturePath; // Offset: 0x20 // Size: 0x10
	struct FString TeamMemberBgColor; // Offset: 0x30 // Size: 0x10
	struct FString TeamMemberNameBgColor; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct AClient.InstanceArray
// Size: 0x10 // Inherited bytes: 0x00
struct FInstanceArray {
	// Fields
	struct TArray<struct UAPInGameUserWidget*> Datas; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SingleUIConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FSingleUIConfig {
	// Fields
	struct FString UIType; // Offset: 0x00 // Size: 0x10
	struct FString Layer; // Offset: 0x10 // Size: 0x10
	struct FString BpPath; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameWeaponConfigDataCache
// Size: 0x28 // Inherited bytes: 0x00
struct FApgameWeaponConfigDataCache {
	// Fields
	struct UWeaponDataAsset* ConfigData; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x20]; // Offset: 0x08 // Size: 0x20
};

// Object Name: ScriptStruct AClient.ApgameWeaponItemInfoCache
// Size: 0x20 // Inherited bytes: 0x00
struct FApgameWeaponItemInfoCache {
	// Fields
	char bNumberColorListInited : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_1 : 7; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UBattleItemHandleBase* ItemConfig; // Offset: 0x08 // Size: 0x08
	struct TArray<struct FWeapon3DUIChangeNum> NumberColorList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.Weapon3DUIChangeNum
// Size: 0x04 // Inherited bytes: 0x00
struct FWeapon3DUIChangeNum {
	// Fields
	char ColorNum1; // Offset: 0x00 // Size: 0x01
	char ColorNum2; // Offset: 0x01 // Size: 0x01
	char ColorNum3; // Offset: 0x02 // Size: 0x01
	char FlashNum; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AClient.InjuredInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FInjuredInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.ContainerData
// Size: 0x60 // Inherited bytes: 0x00
struct FContainerData {
	// Fields
	struct FItemDefineID ID; // Offset: 0x00 // Size: 0x10
	int32_t count; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FBattleItemAdditionalData> AdditionalDataList; // Offset: 0x18 // Size: 0x10
	int32_t Index; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FItemDefineID TargetID; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x10]; // Offset: 0x40 // Size: 0x10
	enum class EBattleItemPickupReason Reason; // Offset: 0x50 // Size: 0x01
	enum class EItemSpawnReason SpawnReason; // Offset: 0x51 // Size: 0x01
	bool bLongPressReplaced; // Offset: 0x52 // Size: 0x01
	bool bBlackMarket; // Offset: 0x53 // Size: 0x01
	struct TWeakObjectPtr<struct APickUpListWrapperActor> SourceActorWeakPtr; // Offset: 0x54 // Size: 0x08
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct AClient.KnockdownShieldReplicate
// Size: 0x10 // Inherited bytes: 0x00
struct FKnockdownShieldReplicate {
	// Fields
	char Level; // Offset: 0x00 // Size: 0x01
	bool CanRescueSelf; // Offset: 0x01 // Size: 0x01
	bool CanUse; // Offset: 0x02 // Size: 0x01
	bool bActivation; // Offset: 0x03 // Size: 0x01
	int32_t ShieldValue; // Offset: 0x04 // Size: 0x04
	struct UKnockdownShieldItemHandle* Handle; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.LD_ProfilerPreLevelSettings
// Size: 0x48 // Inherited bytes: 0x00
struct FLD_ProfilerPreLevelSettings {
	// Fields
	struct FName DisplayName; // Offset: 0x00 // Size: 0x08
	struct FString LevelPath; // Offset: 0x08 // Size: 0x10
	struct TSoftObjectPtr<ULevelSequence> LevelSequence; // Offset: 0x18 // Size: 0x28
	int32_t LoopCount; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AClient.TutorialData
// Size: 0x10 // Inherited bytes: 0x00
struct FTutorialData {
	// Fields
	struct FName TutorialSubLevelName; // Offset: 0x00 // Size: 0x08
	struct UPlayerEventFlow* TutorialEventFlow; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.LegendTrainingRecorder
// Size: 0x0c // Inherited bytes: 0x00
struct FLegendTrainingRecorder {
	// Fields
	float SequenceStartTime; // Offset: 0x00 // Size: 0x04
	int32_t TacticalSkillNum; // Offset: 0x04 // Size: 0x04
	int32_t UltimateSkillNum; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LineTraceDetailInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FLineTraceDetailInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.NetPickUpWrapperResult
// Size: 0x58 // Inherited bytes: 0x00
struct FNetPickUpWrapperResult {
	// Fields
	int32_t NetGuidValue; // Offset: 0x00 // Size: 0x04
	bool bDeleted; // Offset: 0x04 // Size: 0x01
	bool IsCanPickupByBin; // Offset: 0x05 // Size: 0x01
	enum class EItemSpawnReason SpawnReason; // Offset: 0x06 // Size: 0x01
	char pad_0x7[0x1]; // Offset: 0x07 // Size: 0x01
	struct FPickUpItemData PickupInfo; // Offset: 0x08 // Size: 0x30
	struct FVector Location; // Offset: 0x38 // Size: 0x0c
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TArray<struct FPickUpItemData> PickUpDataList; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct AClient.NetRecoverBannerPlayerInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FNetRecoverBannerPlayerInfo {
	// Fields
	uint32_t RecoverBannerPlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t LegendId; // Offset: 0x04 // Size: 0x04
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	bool bDeleted; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct AClient.PickupItemQualityConfigForLoba
// Size: 0x10 // Inherited bytes: 0x00
struct FPickupItemQualityConfigForLoba {
	// Fields
	struct UObject* BGTextureResource; // Offset: 0x00 // Size: 0x08
	struct UObject* BGTextureResource_Grid; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BlackMarketPickUpWrapperResult
// Size: 0xb0 // Inherited bytes: 0x88
struct FBlackMarketPickUpWrapperResult : FSearchedPickUpWrapperResult {
	// Fields
	struct TArray<struct FSearchedPickUpWrapperResult> PickUpList; // Offset: 0x88 // Size: 0x10
	int32_t ItemQuality; // Offset: 0x98 // Size: 0x04
	enum class EBlackMarketGroupType GroupType; // Offset: 0x9c // Size: 0x01
	bool bShowAsGrid; // Offset: 0x9d // Size: 0x01
	bool bIsEnable; // Offset: 0x9e // Size: 0x01
	char pad_0x9F[0x1]; // Offset: 0x9f // Size: 0x01
	int32_t AmmoNumInClip; // Offset: 0xa0 // Size: 0x04
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
	struct ALobaBlackMarket* BlackMarket; // Offset: 0xa8 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BlackMarketForPickPayer
// Size: 0x28 // Inherited bytes: 0x00
struct FBlackMarketForPickPayer {
	// Fields
	uint32_t RecoverBannerPlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t LegendId; // Offset: 0x04 // Size: 0x04
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	bool bIsEnable; // Offset: 0x18 // Size: 0x01
	bool bDeleted; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x6]; // Offset: 0x1a // Size: 0x06
	struct ALobaBlackMarket* BlackMarket; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ItemTypeIDInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FItemTypeIDInfo {
	// Fields
	struct TArray<int32_t> ItemTypeFilters; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApexSkillThrowerProjectileDataSecond
// Size: 0x0c // Inherited bytes: 0x00
struct FApexSkillThrowerProjectileDataSecond {
	// Fields
	float GravityScale; // Offset: 0x00 // Size: 0x04
	float GravityBase; // Offset: 0x04 // Size: 0x04
	float Bounciness; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LobaTeleportInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FLobaTeleportInfo {
	// Fields
	struct FVector FinalLocation; // Offset: 0x00 // Size: 0x0c
	bool bIsCrouch; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct AClient.LobaBraceletFlyData
// Size: 0x38 // Inherited bytes: 0x00
struct FLobaBraceletFlyData {
	// Fields
	bool bStartFly; // Offset: 0x00 // Size: 0x01
	bool bIsLanded; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	struct FRotator savedAnglesRotator; // Offset: 0x04 // Size: 0x0c
	enum class ETeleportState translocate_wasTeleportSuccessState; // Offset: 0x10 // Size: 0x01
	bool translocate_hasProjectileDropped; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x6]; // Offset: 0x12 // Size: 0x06
	struct TArray<struct FVector> translocate_projectileThrowPathTaken; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FVector> translocate_projectileDropPathTaken; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PickUpWrapperResultForLobaPassive
// Size: 0x10 // Inherited bytes: 0x00
struct FPickUpWrapperResultForLobaPassive {
	// Fields
	int32_t NetGuidValue; // Offset: 0x00 // Size: 0x04
	bool bIsPlayerTombBox; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0xb]; // Offset: 0x05 // Size: 0x0b
};

// Object Name: ScriptStruct AClient.LobbyActorTransformModifierStruct
// Size: 0x48 // Inherited bytes: 0x08
struct FLobbyActorTransformModifierStruct : FTableRowBase {
	// Fields
	struct FVector Scale; // Offset: 0x08 // Size: 0x0c
	struct FVector Offset; // Offset: 0x14 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x20 // Size: 0x0c
	struct FVector BaseOffset; // Offset: 0x2c // Size: 0x0c
	struct FRotator BaseRotation; // Offset: 0x38 // Size: 0x0c
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LobbyActorCameraModifierStruct
// Size: 0xd0 // Inherited bytes: 0x08
struct FLobbyActorCameraModifierStruct : FTableRowBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct FTransform Forward_Near; // Offset: 0x10 // Size: 0x30
	struct FTransform Forward_Far; // Offset: 0x40 // Size: 0x30
	struct FTransform Left_Near; // Offset: 0x70 // Size: 0x30
	struct FTransform Left_Far; // Offset: 0xa0 // Size: 0x30
};

// Object Name: ScriptStruct AClient.LobbyActorRandomPlayerSequenceEntry
// Size: 0x18 // Inherited bytes: 0x00
struct FLobbyActorRandomPlayerSequenceEntry {
	// Fields
	struct UAnimMontage* AnimMontage; // Offset: 0x00 // Size: 0x08
	float ChanceToPlay; // Offset: 0x08 // Size: 0x04
	int32_t MinLoopCount; // Offset: 0x0c // Size: 0x04
	int32_t MaxLoopCount; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponAnimData
// Size: 0x58 // Inherited bytes: 0x00
struct FWeaponAnimData {
	// Fields
	struct FName SocketName; // Offset: 0x00 // Size: 0x08
	struct TSoftObjectPtr<UAnimSequenceBase> WeaponAnimSeq; // Offset: 0x08 // Size: 0x28
	struct TSoftObjectPtr<UAnimSequenceBase> WeaponAnimBase; // Offset: 0x30 // Size: 0x28
};

// Object Name: ScriptStruct AClient.CustomLockPickUpItem
// Size: 0x10 // Inherited bytes: 0x00
struct FCustomLockPickUpItem {
	// Fields
	struct TArray<int32_t> PickUps; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PlayerLODData
// Size: 0x10 // Inherited bytes: 0x00
struct FPlayerLODData {
	// Fields
	struct AApexCharacterBase* PlayerPtr; // Offset: 0x00 // Size: 0x08
	float SquareDistance; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.PlayerLODConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FPlayerLODConfig {
	// Fields
	enum class ELODDeviceGrade Grade; // Offset: 0x00 // Size: 0x01
	char ExceedPlayerNumWhenUseLOD; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int32_t ForceMeshLODLv; // Offset: 0x04 // Size: 0x04
	float MaxDistanceLOD; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LogOccurInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FLogOccurInfo {
	// Fields
	int32_t OccurAccumulate; // Offset: 0x00 // Size: 0x04
	float LastOccurTime; // Offset: 0x04 // Size: 0x04
	struct FString Filename; // Offset: 0x08 // Size: 0x10
	int32_t Line; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString LogOccurPos; // Offset: 0x20 // Size: 0x10
	struct FName Category; // Offset: 0x30 // Size: 0x08
	struct FName LogFMT; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x8]; // Offset: 0x40 // Size: 0x08
};

// Object Name: ScriptStruct AClient.MutableItemSize
// Size: 0x0c // Inherited bytes: 0x00
struct FMutableItemSize {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	int32_t Size; // Offset: 0x04 // Size: 0x04
	int32_t Up2TopSize; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LootBinCreepsData
// Size: 0x30 // Inherited bytes: 0x00
struct FLootBinCreepsData {
	// Fields
	struct FName CreepQuality; // Offset: 0x00 // Size: 0x08
	struct FColor QualityColor; // Offset: 0x08 // Size: 0x04
	struct FVector DestroyColor; // Offset: 0x0c // Size: 0x0c
	int32_t LootSpawnCount; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FName> LootTableNames; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CreepDamageType
// Size: 0x0c // Inherited bytes: 0x00
struct FCreepDamageType {
	// Fields
	enum class EDamageType DamageType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t SkillDamageTypeID; // Offset: 0x04 // Size: 0x04
	float DamageRate; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LootRollerReportData
// Size: 0x70 // Inherited bytes: 0x00
struct FLootRollerReportData {
	// Fields
	char pad_0x0[0x70]; // Offset: 0x00 // Size: 0x70
};

// Object Name: ScriptStruct AClient.LootDronesReportData
// Size: 0x60 // Inherited bytes: 0x00
struct FLootDronesReportData {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x00 // Size: 0x60
};

// Object Name: ScriptStruct AClient.LootDronesHurtFlow
// Size: 0x10 // Inherited bytes: 0x00
struct FLootDronesHurtFlow {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LootRollerTierData
// Size: 0x30 // Inherited bytes: 0x00
struct FLootRollerTierData {
	// Fields
	int32_t RandomWeight; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x8]; // Offset: 0x04 // Size: 0x08
	float MinTime; // Offset: 0x0c // Size: 0x04
	float MaxTime; // Offset: 0x10 // Size: 0x04
	struct FColor EffectColor; // Offset: 0x14 // Size: 0x04
	int32_t LootSpawnCount; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FName> LootTableNames; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApLUTCommands
// Size: 0x40 // Inherited bytes: 0x00
struct FApLUTCommands {
	// Fields
	int32_t Priority; // Offset: 0x00 // Size: 0x04
	int32_t HeroID; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FString> LutCommands; // Offset: 0x08 // Size: 0x10
	struct TSoftClassPtr<UObject> HighLevelEndLut_Ptr; // Offset: 0x18 // Size: 0x28
};

// Object Name: ScriptStruct AClient.SyncToServerMainHandInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FSyncToServerMainHandInfo {
	// Fields
	uint32_t UniqueID; // Offset: 0x00 // Size: 0x04
	bool bReject; // Offset: 0x04 // Size: 0x01
	enum class EMainHandActionType EMainHandActionType; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	int32_t Index; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FHandStateData MainHandInfo; // Offset: 0x10 // Size: 0x40
};

// Object Name: ScriptStruct AClient.SyncMainHandInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FSyncMainHandInfo {
	// Fields
	enum class EMainHandActionType EMainHandActionType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t Index; // Offset: 0x04 // Size: 0x04
	struct FHandStateData MainHandInfo; // Offset: 0x08 // Size: 0x40
};

// Object Name: ScriptStruct AClient.MainTownFreeBattleInviteState
// Size: 0x02 // Inherited bytes: 0x00
struct FMainTownFreeBattleInviteState {
	// Fields
	char TeamIdx; // Offset: 0x00 // Size: 0x01
	char State; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.MainTownFreeBattlePlayerData
// Size: 0x38 // Inherited bytes: 0x00
struct FMainTownFreeBattlePlayerData {
	// Fields
	uint64_t UID; // Offset: 0x00 // Size: 0x08
	int32_t Score; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct AMainTownPlayerController* Player; // Offset: 0x10 // Size: 0x08
	struct FApgameBackpackSnapshot BackpackShot; // Offset: 0x18 // Size: 0x20
};

// Object Name: ScriptStruct AClient.FreeBattleModeWeaponSettings
// Size: 0x08 // Inherited bytes: 0x00
struct FFreeBattleModeWeaponSettings {
	// Fields
	int32_t IdSlot1; // Offset: 0x00 // Size: 0x04
	int32_t IdSlot2; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigHand
// Size: 0x1e0 // Inherited bytes: 0x00
struct FApgameMeleeConfigHand {
	// Fields
	struct FApgameMeleeConfigPoseAnimViews AttackDoorPoseAnims; // Offset: 0x00 // Size: 0xa0
	struct FApgameMeleeConfigPoseAnimViews AttackTargetPoseAnims; // Offset: 0xa0 // Size: 0xa0
	struct FApgameMeleeConfigPoseAnimViews AttackNoTargetPoseAnims; // Offset: 0x140 // Size: 0xa0
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigPoseAnimViews
// Size: 0xa0 // Inherited bytes: 0x00
struct FApgameMeleeConfigPoseAnimViews {
	// Fields
	struct FApgameMeleeConfigPoseRandAnims Fpp; // Offset: 0x00 // Size: 0x50
	struct FApgameMeleeConfigPoseRandAnims Tpp; // Offset: 0x50 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigPoseRandAnims
// Size: 0x50 // Inherited bytes: 0x00
struct FApgameMeleeConfigPoseRandAnims {
	// Fields
	struct FApgameMeleeConfigAnimList Stand; // Offset: 0x00 // Size: 0x10
	struct FApgameMeleeConfigAnimList Crouch; // Offset: 0x10 // Size: 0x10
	struct FApgameMeleeConfigAnimList Sprint; // Offset: 0x20 // Size: 0x10
	struct FApgameMeleeConfigAnimList Jump; // Offset: 0x30 // Size: 0x10
	struct FApgameMeleeConfigAnimList Slide; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigAnimList
// Size: 0x10 // Inherited bytes: 0x00
struct FApgameMeleeConfigAnimList {
	// Fields
	struct TArray<struct FApgameMeleeConfigAnimWithWeight> OptionalList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigAnimWithWeight
// Size: 0x30 // Inherited bytes: 0x00
struct FApgameMeleeConfigAnimWithWeight {
	// Fields
	struct TSoftObjectPtr<UAnimMontage> Anim; // Offset: 0x00 // Size: 0x28
	float Weight; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigResidentEffect
// Size: 0x20 // Inherited bytes: 0x00
struct FApgameMeleeConfigResidentEffect {
	// Fields
	struct FName AttachSocket; // Offset: 0x00 // Size: 0x08
	struct UParticleSystem* ParticleTemplate1p; // Offset: 0x08 // Size: 0x08
	struct UParticleSystem* ParticleTemplate3p; // Offset: 0x10 // Size: 0x08
	struct FName SoundName; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigTableRandAnimPairs
// Size: 0x40 // Inherited bytes: 0x00
struct FApgameMeleeConfigTableRandAnimPairs {
	// Fields
	struct FApgameMeleeConfigRandAnimPairList Stand; // Offset: 0x00 // Size: 0x10
	struct FApgameMeleeConfigRandAnimPairList Crouch; // Offset: 0x10 // Size: 0x10
	struct FApgameMeleeConfigRandAnimPairList OneHandStand; // Offset: 0x20 // Size: 0x10
	struct FApgameMeleeConfigRandAnimPairList OneHandSlide; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigRandAnimPairList
// Size: 0x10 // Inherited bytes: 0x00
struct FApgameMeleeConfigRandAnimPairList {
	// Fields
	struct TArray<struct FApgameMeleeConfigAnimPairWithWeight> OptionalList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigAnimPairWithWeight
// Size: 0x58 // Inherited bytes: 0x00
struct FApgameMeleeConfigAnimPairWithWeight {
	// Fields
	struct TSoftObjectPtr<UAnimMontage> PawnAnim; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> WeaponAnim; // Offset: 0x28 // Size: 0x28
	float Weight; // Offset: 0x50 // Size: 0x04
	int32_t PerAnimEffectIndex; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigTableAnimPairs
// Size: 0x140 // Inherited bytes: 0x00
struct FApgameMeleeConfigTableAnimPairs {
	// Fields
	struct FApgameMeleeConfigAnimPair Stand; // Offset: 0x00 // Size: 0x50
	struct FApgameMeleeConfigAnimPair Crouch; // Offset: 0x50 // Size: 0x50
	struct FApgameMeleeConfigAnimPair OneHandStand; // Offset: 0xa0 // Size: 0x50
	struct FApgameMeleeConfigAnimPair OneHandSlide; // Offset: 0xf0 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigAnimPair
// Size: 0x50 // Inherited bytes: 0x00
struct FApgameMeleeConfigAnimPair {
	// Fields
	struct TSoftObjectPtr<UAnimMontage> PawnAnim; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> WeaponAnim; // Offset: 0x28 // Size: 0x28
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigPoseRandAnimPairs
// Size: 0x50 // Inherited bytes: 0x00
struct FApgameMeleeConfigPoseRandAnimPairs {
	// Fields
	struct FApgameMeleeConfigRandAnimPairList Stand; // Offset: 0x00 // Size: 0x10
	struct FApgameMeleeConfigRandAnimPairList Crouch; // Offset: 0x10 // Size: 0x10
	struct FApgameMeleeConfigRandAnimPairList Sprint; // Offset: 0x20 // Size: 0x10
	struct FApgameMeleeConfigRandAnimPairList Jump; // Offset: 0x30 // Size: 0x10
	struct FApgameMeleeConfigRandAnimPairList Slide; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigPoseAnimPairs
// Size: 0x190 // Inherited bytes: 0x00
struct FApgameMeleeConfigPoseAnimPairs {
	// Fields
	struct FApgameMeleeConfigAnimPair Stand; // Offset: 0x00 // Size: 0x50
	struct FApgameMeleeConfigAnimPair Crouch; // Offset: 0x50 // Size: 0x50
	struct FApgameMeleeConfigAnimPair Sprint; // Offset: 0xa0 // Size: 0x50
	struct FApgameMeleeConfigAnimPair Jump; // Offset: 0xf0 // Size: 0x50
	struct FApgameMeleeConfigAnimPair Slide; // Offset: 0x140 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigAnimSeqViews
// Size: 0x50 // Inherited bytes: 0x00
struct FApgameMeleeConfigAnimSeqViews {
	// Fields
	struct TSoftObjectPtr<UAnimationAsset> Fpp; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UAnimationAsset> Tpp; // Offset: 0x28 // Size: 0x28
};

// Object Name: ScriptStruct AClient.ApgameMeleeConfigAnimViews
// Size: 0x50 // Inherited bytes: 0x00
struct FApgameMeleeConfigAnimViews {
	// Fields
	struct TSoftObjectPtr<UAnimMontage> Fpp; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> Tpp; // Offset: 0x28 // Size: 0x28
};

// Object Name: ScriptStruct AClient.MetaAICounterWatchItem
// Size: 0x30 // Inherited bytes: 0x00
struct FMetaAICounterWatchItem {
	// Fields
	struct FName CounterTag; // Offset: 0x00 // Size: 0x08
	struct FBlackboardKeySelector OutValue; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct AClient.LensFlareSpriteElement
// Size: 0x38 // Inherited bytes: 0x00
struct FLensFlareSpriteElement {
	// Fields
	struct UMaterialInterface* Material; // Offset: 0x00 // Size: 0x08
	struct UCurveFloat* DistanceToOpacityCurve; // Offset: 0x08 // Size: 0x08
	char bSizeIsInScreenSpace : 1; // Offset: 0x10 // Size: 0x01
	char pad_0x10_1 : 7; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float BaseSizeX; // Offset: 0x14 // Size: 0x04
	float BaseSizeY; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct UCurveFloat* DistanceToSizeCurve; // Offset: 0x20 // Size: 0x08
	struct TArray<struct FLensFlareImageInfo> LensFlareImageInfo; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LensFlareImageInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FLensFlareImageInfo {
	// Fields
	float Offset; // Offset: 0x00 // Size: 0x04
	float Scale; // Offset: 0x04 // Size: 0x04
	struct FColor Color; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AirDropPointWidget
// Size: 0x18 // Inherited bytes: 0x00
struct FAirDropPointWidget {
	// Fields
	struct UUserWidget* PointWidget; // Offset: 0x00 // Size: 0x08
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.BombSiteTextConfig
// Size: 0xa0 // Inherited bytes: 0x00
struct FBombSiteTextConfig {
	// Fields
	struct FSlateColor SiteTextColor; // Offset: 0x00 // Size: 0x28
	struct FSlateFontInfo SiteTextFont; // Offset: 0x28 // Size: 0x50
	struct FText Site; // Offset: 0x78 // Size: 0x18
	struct FLinearColor SiteIconColor; // Offset: 0x90 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DynamicMiniMapItem
// Size: 0x10 // Inherited bytes: 0x00
struct FDynamicMiniMapItem {
	// Fields
	struct UUserWidget* Widget; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.HoverTankData
// Size: 0x10 // Inherited bytes: 0x00
struct FHoverTankData {
	// Fields
	struct UUserWidget* IconUI; // Offset: 0x00 // Size: 0x08
	struct AActor* Actor; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.MiniMapItemConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FMiniMapItemConfig {
	// Fields
	int32_t PoolNum; // Offset: 0x00 // Size: 0x04
	struct FVector2D Size; // Offset: 0x04 // Size: 0x08
	bool bIsBigMapScaleDiff; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float BigMapScaleRate; // Offset: 0x10 // Size: 0x04
	bool HasRadius; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	float Radius; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TSoftClassPtr<UObject> WeakWidgetClass; // Offset: 0x20 // Size: 0x28
	bool IsNeedSilde; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float SildeSizeScale; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct AClient.MiniMapItem
// Size: 0x30 // Inherited bytes: 0x00
struct FMiniMapItem {
	// Fields
	struct UUserWidget* Widget; // Offset: 0x00 // Size: 0x08
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	struct FVector TargetLocation; // Offset: 0x14 // Size: 0x0c
	float OriginalAngle; // Offset: 0x20 // Size: 0x04
	float TargetOriginalAngle; // Offset: 0x24 // Size: 0x04
	bool NeedVisible; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	float CircleRadius; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.MiniMapAshBoxInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FMiniMapAshBoxInfo {
	// Fields
	int32_t MapIndex; // Offset: 0x00 // Size: 0x04
	float Timespan; // Offset: 0x04 // Size: 0x04
	char Level; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FVector2D MapPos; // Offset: 0x0c // Size: 0x08
	struct FVector WorldPos; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.MiniMapDynimicUpdateInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FMiniMapDynimicUpdateInfo {
	// Fields
	struct TWeakObjectPtr<struct AActor> CheckActor; // Offset: 0x00 // Size: 0x08
	bool bNeedUpdateYaw; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct AClient.MiniMapPlayerInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FMiniMapPlayerInfo {
	// Fields
	int32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	int32_t LegendId; // Offset: 0x18 // Size: 0x04
	int32_t TeamID; // Offset: 0x1c // Size: 0x04
	int32_t TeamIdx; // Offset: 0x20 // Size: 0x04
	enum class EMiniMapPlayerType Type; // Offset: 0x24 // Size: 0x01
	enum class EMiniMapPlayerState State; // Offset: 0x25 // Size: 0x01
	char pad_0x26[0x2]; // Offset: 0x26 // Size: 0x02
	struct FVector Location; // Offset: 0x28 // Size: 0x0c
	float Yaw; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MiniMapSkillItemCacheInfo
// Size: 0x2c // Inherited bytes: 0x00
struct FMiniMapSkillItemCacheInfo {
	// Fields
	bool IsNeedCreate; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FMiniMapSkillItemInfo Data; // Offset: 0x04 // Size: 0x28
};

// Object Name: ScriptStruct AClient.MiniMapStaticItemCacheInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FMiniMapStaticItemCacheInfo {
	// Fields
	bool IsNeedCreate; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FMiniMapStaticItemInfo Data; // Offset: 0x04 // Size: 0x2c
};

// Object Name: ScriptStruct AClient.SpawnDecoyData
// Size: 0x08 // Inherited bytes: 0x00
struct FSpawnDecoyData {
	// Fields
	float LifeTime; // Offset: 0x00 // Size: 0x04
	float RotationZ; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.TutorialConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FTutorialConfig {
	// Fields
	enum class EShadowMirageTutorialType TutorialType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t VoiceEventID; // Offset: 0x04 // Size: 0x04
	float TutorialRange; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct UTutorialNotifyWidget* UIWidgetClass; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.MissleProjectileRep
// Size: 0x0c // Inherited bytes: 0x00
struct FMissleProjectileRep {
	// Fields
	struct FVector InitialVelocity; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.StateBehaviorNote
// Size: 0x38 // Inherited bytes: 0x00
struct FStateBehaviorNote {
	// Fields
	enum class EBehavior Behavior; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<enum class EHealth> Health; // Offset: 0x08 // Size: 0x10
	struct TArray<enum class EPose> Pose; // Offset: 0x18 // Size: 0x10
	struct TArray<enum class EPendant> Pendant; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AClient.StatePoseNote
// Size: 0x18 // Inherited bytes: 0x00
struct FStatePoseNote {
	// Fields
	enum class EPose Pose; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<enum class EHealth> DependHealth; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.StatePendantNote
// Size: 0x18 // Inherited bytes: 0x00
struct FStatePendantNote {
	// Fields
	enum class EPendant Pendant; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<enum class EHealth> Health; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.StateHealthNote
// Size: 0x18 // Inherited bytes: 0x00
struct FStateHealthNote {
	// Fields
	enum class EHealth Health; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FStateHealthNoteChange> BreakChange; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.StateHealthNoteChange
// Size: 0x02 // Inherited bytes: 0x00
struct FStateHealthNoteChange {
	// Fields
	enum class EPose CurPose; // Offset: 0x00 // Size: 0x01
	enum class EPose ToPose; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.LegendGroupAssetsInfo
// Size: 0xb0 // Inherited bytes: 0x00
struct FLegendGroupAssetsInfo {
	// Fields
	enum class ELegendType ELegendType; // Offset: 0x00 // Size: 0x01
	enum class EMotionGroupAssetLoadStage EMotionGroupAssetLoadStage; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int32_t RefCount; // Offset: 0x04 // Size: 0x04
	struct TSet<int32_t> WaitToLoadMotionIDList; // Offset: 0x08 // Size: 0x50
	struct TMap<int32_t, struct UMotionWarpingDataAsset*> MotionAssets; // Offset: 0x58 // Size: 0x50
	struct UApexAnimNotifySoundLegendSoundGroup_VO* LegendVO; // Offset: 0xa8 // Size: 0x08
};

// Object Name: ScriptStruct AClient.LegendMotionGroupDataTable
// Size: 0x50 // Inherited bytes: 0x00
struct FLegendMotionGroupDataTable {
	// Fields
	struct TSet<int32_t> MotionIDList; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.WorldMotionDataInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FWorldMotionDataInfo {
	// Fields
	struct FString Desc; // Offset: 0x00 // Size: 0x10
	int32_t GameModeID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<int32_t> MotionIDList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CharacterPositionCheckRecord
// Size: 0x48 // Inherited bytes: 0x00
struct FCharacterPositionCheckRecord {
	// Fields
	double Timestamp; // Offset: 0x00 // Size: 0x08
	double TimeLineRTT; // Offset: 0x08 // Size: 0x08
	float CapsuleRadius; // Offset: 0x10 // Size: 0x04
	float CapsuleHalfHeight; // Offset: 0x14 // Size: 0x04
	struct FVector Location; // Offset: 0x18 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x24 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x30 // Size: 0x0c
	struct TWeakObjectPtr<struct UPrimitiveComponent> Base; // Offset: 0x3c // Size: 0x08
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ClientAdjustPositionInfo
// Size: 0x60 // Inherited bytes: 0x00
struct FClientAdjustPositionInfo {
	// Fields
	struct ACharacter* OwnerCharacter; // Offset: 0x00 // Size: 0x08
	struct UPrimitiveComponent* NewBase; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x50]; // Offset: 0x10 // Size: 0x50
};

// Object Name: ScriptStruct AClient.MovementClimbSetting
// Size: 0x18 // Inherited bytes: 0x00
struct FMovementClimbSetting {
	// Fields
	float ClimbLimitHeight; // Offset: 0x00 // Size: 0x04
	float FinalJumpHeight; // Offset: 0x04 // Size: 0x04
	struct UCurveFloat* ClimbLimitSpeedCurve; // Offset: 0x08 // Size: 0x08
	float ClimbOverNextHorizontalCheckDistance; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MovementCameraState
// Size: 0xb0 // Inherited bytes: 0x00
struct FMovementCameraState {
	// Fields
	float EnterVelocity; // Offset: 0x00 // Size: 0x04
	float LeaveVelocity; // Offset: 0x04 // Size: 0x04
	struct FStateLerpArrayInfos EnterCameraState; // Offset: 0x08 // Size: 0x50
	struct FStateLerpArrayInfos LeaveCameraState; // Offset: 0x58 // Size: 0x50
	char pad_0xA8[0x8]; // Offset: 0xa8 // Size: 0x08
};

// Object Name: ScriptStruct AClient.RepMotionData
// Size: 0x78 // Inherited bytes: 0x00
struct FRepMotionData {
	// Fields
	bool bUseMotion; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FMotionWarpingSyncData StartMotionWarpingSyncData; // Offset: 0x08 // Size: 0x50
	struct FMovementSyncData EndMotionWarpingSyncData; // Offset: 0x58 // Size: 0x18
	uint16_t EndMotionRotationYaw; // Offset: 0x70 // Size: 0x02
	char pad_0x72[0x6]; // Offset: 0x72 // Size: 0x06
};

// Object Name: ScriptStruct AClient.MotionWarpingSyncData
// Size: 0x50 // Inherited bytes: 0x00
struct FMotionWarpingSyncData {
	// Fields
	struct UPrimitiveComponent* Base; // Offset: 0x00 // Size: 0x08
	struct UMotionWarpingDataAsset* MotionMovementData; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x40]; // Offset: 0x10 // Size: 0x40
};

// Object Name: ScriptStruct AClient.MovementSyncMultData
// Size: 0x18 // Inherited bytes: 0x00
struct FMovementSyncMultData {
	// Fields
	struct UPrimitiveComponent* Base; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MovementTagAttribute
// Size: 0x14 // Inherited bytes: 0x00
struct FMovementTagAttribute {
	// Fields
	float ClimbNormalAngel; // Offset: 0x00 // Size: 0x04
	float ClimbNormalZ; // Offset: 0x04 // Size: 0x04
	float WalkableFloorAngle; // Offset: 0x08 // Size: 0x04
	float WalkableFloorZ; // Offset: 0x0c // Size: 0x04
	float StepUpScale; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MovementModifyConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FMovementModifyConfig {
	// Fields
	struct TMap<struct FName, struct FMovementModifier> ModifyMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.MovementModifier
// Size: 0x08 // Inherited bytes: 0x00
struct FMovementModifier {
	// Fields
	enum class EMovementAttribute MovementAttribute; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ModifierValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MovementCurveModifierConfigForDistance
// Size: 0x18 // Inherited bytes: 0x00
struct FMovementCurveModifierConfigForDistance {
	// Fields
	enum class EMovementAttribute MovementAttribute; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UCurveFloat* AttributeCurve; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.MovieSceneOutlineSectionTemplate
// Size: 0xb0 // Inherited bytes: 0x18
struct FMovieSceneOutlineSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneIntegerChannel IntegerCurve; // Offset: 0x18 // Size: 0x90
	enum class EMovieSceneBlendType BlendType; // Offset: 0xa8 // Size: 0x01
	char pad_0xA9[0x7]; // Offset: 0xa9 // Size: 0x07
};

// Object Name: ScriptStruct AClient.MovieSceneSubTitleTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FMovieSceneSubTitleTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneSubTitleSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.MPLandingLocation
// Size: 0x28 // Inherited bytes: 0x00
struct FMPLandingLocation {
	// Fields
	bool bMatchGameModeID; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString GameModeID; // Offset: 0x08 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<AActor>> TargetPoints; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MPAirdropSpawnData
// Size: 0x18 // Inherited bytes: 0x00
struct FMPAirdropSpawnData {
	// Fields
	float DropTime; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FLootZoneTypeInfo> LootZoneTypeInfos; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MPPlayerInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FMPPlayerInfo {
	// Fields
	int32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t LegendId; // Offset: 0x04 // Size: 0x04
	float Health; // Offset: 0x08 // Size: 0x04
	int32_t ShieldQuality; // Offset: 0x0c // Size: 0x04
	float Shield; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PushEventRecord
// Size: 0x50 // Inherited bytes: 0x00
struct FPushEventRecord {
	// Fields
	struct TMap<int32_t, float> EventID2LastTriggerTime; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.Subtitle
// Size: 0x38 // Inherited bytes: 0x00
struct FSubtitle {
	// Fields
	struct FText Source; // Offset: 0x00 // Size: 0x18
	struct FText Subtitle; // Offset: 0x18 // Size: 0x18
	int32_t PlayingID; // Offset: 0x30 // Size: 0x04
	float DisappearTime; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MsgCenterConfigMap
// Size: 0x20 // Inherited bytes: 0x00
struct FMsgCenterConfigMap {
	// Fields
	struct TArray<enum class EBroadcastType> Keys; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FMsgCenterConfig> Values; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MsgCenterConfig
// Size: 0x02 // Inherited bytes: 0x00
struct FMsgCenterConfig {
	// Fields
	bool bShowSubtitle; // Offset: 0x00 // Size: 0x01
	bool bPlayAudio; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.BroadcastInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FBroadcastInfo {
	// Fields
	struct FString SpeakerName; // Offset: 0x00 // Size: 0x10
	struct FString Content; // Offset: 0x10 // Size: 0x10
	enum class EBroadcastType Type; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct TArray<struct UAkAudioEvent*> AudioEvents; // Offset: 0x28 // Size: 0x10
	struct AActor* CustomPlayer; // Offset: 0x38 // Size: 0x08
	bool bNeedLocalization; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct AClient.MsgConfigItem
// Size: 0x80 // Inherited bytes: 0x00
struct FMsgConfigItem {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString EventName; // Offset: 0x08 // Size: 0x10
	struct FText SubTitleOwner; // Offset: 0x18 // Size: 0x18
	enum class EMsgTriggerType TriggerType; // Offset: 0x30 // Size: 0x01
	enum class EMsgTriggerConditionType TriggerCondition; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
	struct FString TriggerArgs; // Offset: 0x38 // Size: 0x10
	enum class EMsgReceiverType ReceiverType; // Offset: 0x48 // Size: 0x01
	enum class EMsgTriggerConditionType ReceiverCondition; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x6]; // Offset: 0x4a // Size: 0x06
	struct FString ReceiverArgs; // Offset: 0x50 // Size: 0x10
	enum class EMsgPlayer PlayerType; // Offset: 0x60 // Size: 0x01
	enum class EVOSoundType VOSoundType; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x2]; // Offset: 0x62 // Size: 0x02
	int32_t Priority; // Offset: 0x64 // Size: 0x04
	bool SoloDoNotTrigger; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x3]; // Offset: 0x69 // Size: 0x03
	float TriggerProbability; // Offset: 0x6c // Size: 0x04
	bool IsLocalPlayed; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x3]; // Offset: 0x71 // Size: 0x03
	float EventCD; // Offset: 0x74 // Size: 0x04
	bool IgnoreSubtitleSwitch; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x3]; // Offset: 0x79 // Size: 0x03
	float ReceiveCD; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct AClient.RespawnStartSpots
// Size: 0x10 // Inherited bytes: 0x00
struct FRespawnStartSpots {
	// Fields
	struct TArray<struct AApexPlayerStart*> Spots; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MPSelectLegendStatus
// Size: 0x18 // Inherited bytes: 0x00
struct FMPSelectLegendStatus {
	// Fields
	enum class ESelectLegendStage Stage; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float BeginTime; // Offset: 0x04 // Size: 0x04
	float Duration; // Offset: 0x08 // Size: 0x04
	int32_t CampIdx; // Offset: 0x0c // Size: 0x04
	int32_t TeamIdx; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MPSelectLegendSettings
// Size: 0x68 // Inherited bytes: 0x00
struct FMPSelectLegendSettings {
	// Fields
	enum class ESelectLegendMode SelectLegendCampMode; // Offset: 0x00 // Size: 0x01
	enum class ESelectLegendMode SelectLegendTeamMode; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int32_t MaxTeamEveryCamp; // Offset: 0x04 // Size: 0x04
	int32_t MaxPlayerEveryTeam; // Offset: 0x08 // Size: 0x04
	bool bIsCampLimit; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	int32_t LegendLimit; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TMap<int32_t, int32_t> SubLegendLimits; // Offset: 0x18 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ApexNavigationLink
// Size: 0x78 // Inherited bytes: 0x50
struct FApexNavigationLink : FNavigationLink {
	// Fields
	struct FVector LeftExtent; // Offset: 0x50 // Size: 0x0c
	struct FVector RightExtent; // Offset: 0x5c // Size: 0x0c
	char pad_0x68[0x10]; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ObjectDistanceInOutInterfaceTickFunction
// Size: 0x58 // Inherited bytes: 0x50
struct FObjectDistanceInOutInterfaceTickFunction : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApexOBInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FApexOBInfo {
	// Fields
	struct AActor* OBViewTarget; // Offset: 0x00 // Size: 0x08
	struct AApexCharacter* RelevantCharacter; // Offset: 0x08 // Size: 0x08
	struct AApexPlayerState* RelevantCharacterPlayerState; // Offset: 0x10 // Size: 0x08
	int32_t CurrentOBTeamId; // Offset: 0x18 // Size: 0x04
	int32_t CurrentOBPlayerKey; // Offset: 0x1c // Size: 0x04
	char HasRelevantCharacter : 1; // Offset: 0x20 // Size: 0x01
	char InOBMode : 1; // Offset: 0x20 // Size: 0x01
	char pad_0x20_2 : 6; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct AClient.LaunchPadRuntimeData
// Size: 0x28 // Inherited bytes: 0x00
struct FLaunchPadRuntimeData {
	// Fields
	bool IsLevelPersistent; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t LaunchCharacterCount; // Offset: 0x04 // Size: 0x04
	int32_t OwnerPlayerKey; // Offset: 0x08 // Size: 0x04
	int32_t MaxNumLimit; // Offset: 0x0c // Size: 0x04
	int32_t AutoPingID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FJumpCharacterData> JumpCharacterArray; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.JumpCharacterData
// Size: 0x10 // Inherited bytes: 0x00
struct FJumpCharacterData {
	// Fields
	struct AApexCharacterBase* TargetCharacter; // Offset: 0x00 // Size: 0x08
	bool IsSlidingEnter; // Offset: 0x08 // Size: 0x01
	bool IsStrongJump; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
	float JumpDelay; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.LaunchCharacterConfigData
// Size: 0x30 // Inherited bytes: 0x00
struct FLaunchCharacterConfigData {
	// Fields
	enum class EPawnState PawnState; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Slop; // Offset: 0x04 // Size: 0x04
	bool bInfiniteSlop; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float BaseVelocity; // Offset: 0x0c // Size: 0x04
	bool ShouldOverrideXY; // Offset: 0x10 // Size: 0x01
	bool ShouldOverrideZ; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x6]; // Offset: 0x12 // Size: 0x06
	struct UCurveFloat* DirectionVelocityCurve; // Offset: 0x18 // Size: 0x08
	enum class EMovementFallingAction LaunchReason; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	struct FVector IntersectionBox; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.LaunchItemConfigData
// Size: 0x08 // Inherited bytes: 0x00
struct FLaunchItemConfigData {
	// Fields
	float Slop; // Offset: 0x00 // Size: 0x04
	float BaseVelocity; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.DelayDoVoidData
// Size: 0x18 // Inherited bytes: 0x00
struct FDelayDoVoidData {
	// Fields
	struct AApexCharacter* Character; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MoverDataInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FMoverDataInfo {
	// Fields
	struct AVoidMover* Mover; // Offset: 0x00 // Size: 0x08
	struct AApexCharacter* Character; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BlackHoleDataInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FBlackHoleDataInfo {
	// Fields
	float EnterDoorTimer; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct AApexCharacter* Character; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.STR_Effect
// Size: 0x50 // Inherited bytes: 0x08
struct FSTR_Effect : FTableRowBase {
	// Fields
	struct FName Describe; // Offset: 0x08 // Size: 0x08
	char StencilValue; // Offset: 0x10 // Size: 0x01
	bool Fill_Occluded_Visible; // Offset: 0x11 // Size: 0x01
	bool Fill_Unoccluded_Visible; // Offset: 0x12 // Size: 0x01
	bool Outline_Occluded_Visible; // Offset: 0x13 // Size: 0x01
	bool Outline_Unoccluded_Visible; // Offset: 0x14 // Size: 0x01
	bool Fill_No_Scanline; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
	float Outline_No_Scanline; // Offset: 0x18 // Size: 0x04
	float Opacity; // Offset: 0x1c // Size: 0x04
	float Outline_Width; // Offset: 0x20 // Size: 0x04
	float Glow_Intensity; // Offset: 0x24 // Size: 0x04
	float Pulse_Frequency; // Offset: 0x28 // Size: 0x04
	float Pulse_MinIntensity; // Offset: 0x2c // Size: 0x04
	float Scanline_Tiling; // Offset: 0x30 // Size: 0x04
	float Scanline_Width; // Offset: 0x34 // Size: 0x04
	int32_t Priority; // Offset: 0x38 // Size: 0x04
	bool UsesFresnel; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	int32_t OutlineGroupId; // Offset: 0x40 // Size: 0x04
	int32_t RimDistanceEnd; // Offset: 0x44 // Size: 0x04
	bool UsePerfectOutlineGroup; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	int32_t PerfectOutlineGroupId; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ActorOutlineData
// Size: 0x108 // Inherited bytes: 0x00
struct FActorOutlineData {
	// Fields
	char pad_0x0[0x108]; // Offset: 0x00 // Size: 0x108
};

// Object Name: ScriptStruct AClient.ParachuteOverrideConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FParachuteOverrideConfig {
	// Fields
	bool bForceHorizontalRotationAtStart; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ParachuteNoControlTimeSinceStart; // Offset: 0x04 // Size: 0x04
	float InitSpeedLength; // Offset: 0x08 // Size: 0x04
	float InitResapwnSpeedLength; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.CreatePSParams
// Size: 0x58 // Inherited bytes: 0x00
struct FCreatePSParams {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> EmitterTemplate; // Offset: 0x00 // Size: 0x28
	struct FVector Location; // Offset: 0x28 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x34 // Size: 0x0c
	struct FVector Scale; // Offset: 0x40 // Size: 0x0c
	bool bAutoDestroy; // Offset: 0x4c // Size: 0x01
	enum class EPSCPoolMethod PoolingMethod; // Offset: 0x4d // Size: 0x01
	enum class EAPRenderPass RenderPass; // Offset: 0x4e // Size: 0x01
	bool bNotCreateForLowGrade; // Offset: 0x4f // Size: 0x01
	bool bActive; // Offset: 0x50 // Size: 0x01
	bool bHidden; // Offset: 0x51 // Size: 0x01
	bool bReleased; // Offset: 0x52 // Size: 0x01
	char pad_0x53[0x5]; // Offset: 0x53 // Size: 0x05
};

// Object Name: ScriptStruct AClient.CreatePSAtLocationParams
// Size: 0x60 // Inherited bytes: 0x58
struct FCreatePSAtLocationParams : FCreatePSParams {
	// Fields
	struct UObject* WorldContextObject; // Offset: 0x58 // Size: 0x08
};

// Object Name: ScriptStruct AClient.CreatePSAttachedParams
// Size: 0x70 // Inherited bytes: 0x58
struct FCreatePSAttachedParams : FCreatePSParams {
	// Fields
	struct USceneComponent* AttachToComponent; // Offset: 0x58 // Size: 0x08
	struct FName AttachPointName; // Offset: 0x60 // Size: 0x08
	int32_t LocationType; // Offset: 0x68 // Size: 0x04
	bool bApplyParentFov; // Offset: 0x6c // Size: 0x01
	bool bApplyParentDither; // Offset: 0x6d // Size: 0x01
	bool bApplyUIFov; // Offset: 0x6e // Size: 0x01
	char pad_0x6F[0x1]; // Offset: 0x6f // Size: 0x01
};

// Object Name: ScriptStruct AClient.ParticleTimeToolNow
// Size: 0x18 // Inherited bytes: 0x00
struct FParticleTimeToolNow {
	// Fields
	int32_t EventID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	int64_t EndTime; // Offset: 0x08 // Size: 0x08
	struct UObject* Item; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ParticleTimeToolConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FParticleTimeToolConfig {
	// Fields
	struct TSoftObjectPtr<UObject> Item; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.PartyStagePhaseRepInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FPartyStagePhaseRepInfo {
	// Fields
	int32_t StagePhaseID; // Offset: 0x00 // Size: 0x04
	float StageStartTimeSpan; // Offset: 0x04 // Size: 0x04
	float StagePhaseStartTimeSpan; // Offset: 0x08 // Size: 0x04
	float StagePhaseEndTimeSpan; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.PartyStageConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FPartyStageConfig {
	// Fields
	float Duration; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FPartyStageActionInfo> Actions; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PartyStageActionInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FPartyStageActionInfo {
	// Fields
	int32_t ActionID; // Offset: 0x00 // Size: 0x04
	float StartTime; // Offset: 0x04 // Size: 0x04
	struct FTimerHandle ActionTimerHandle; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PartyStageAction
// Size: 0x100 // Inherited bytes: 0x00
struct FPartyStageAction {
	// Fields
	bool IsCrossPhaseAction; // Offset: 0x00 // Size: 0x01
	bool IsOnlyOnce; // Offset: 0x01 // Size: 0x01
	enum class EStageActionType Type; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x5]; // Offset: 0x03 // Size: 0x05
	struct UActorComponent* ActionComponent; // Offset: 0x08 // Size: 0x08
	struct UAnimationAsset* ActionAnim; // Offset: 0x10 // Size: 0x08
	bool bAnimationLoop; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct UAkAudioEvent* Sound; // Offset: 0x20 // Size: 0x08
	float SoundLength; // Offset: 0x28 // Size: 0x04
	struct FVector SoundLoc; // Offset: 0x2c // Size: 0x0c
	struct UMaterialInstanceDynamic* MaterialInstanceDynamic; // Offset: 0x38 // Size: 0x08
	int32_t MaterialIndex; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct UMaterialInterface* MaterialToChange; // Offset: 0x48 // Size: 0x08
	struct TArray<struct FPartyStageActionMeterialParam> MaterialParams; // Offset: 0x50 // Size: 0x10
	struct UParticleSystem* Particle; // Offset: 0x60 // Size: 0x08
	struct FVector ParticleLoc; // Offset: 0x68 // Size: 0x0c
	struct FRotator ParticleRot; // Offset: 0x74 // Size: 0x0c
	struct FVector ParticleScale; // Offset: 0x80 // Size: 0x0c
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct AActor* SpawnActorClass; // Offset: 0x90 // Size: 0x08
	struct FName SpawnLootTableName; // Offset: 0x98 // Size: 0x08
	struct FVector SpawnPos; // Offset: 0xa0 // Size: 0x0c
	struct FRotator SpawnRot; // Offset: 0xac // Size: 0x0c
	bool bRandomDir; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x3]; // Offset: 0xb9 // Size: 0x03
	int32_t SpawnLootNum; // Offset: 0xbc // Size: 0x04
	enum class EItemSpawnReason SpawnLootReason; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x3]; // Offset: 0xc1 // Size: 0x03
	float MinAdditionalSpeed; // Offset: 0xc4 // Size: 0x04
	float MaxAdditionalSpeed; // Offset: 0xc8 // Size: 0x04
	struct FName AddBuffName; // Offset: 0xcc // Size: 0x08
	float CureSelfTime; // Offset: 0xd4 // Size: 0x04
	bool IsDitherIn; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x3]; // Offset: 0xd9 // Size: 0x03
	float DitherTime; // Offset: 0xdc // Size: 0x04
	struct ULevelSequence* LevelSequence; // Offset: 0xe0 // Size: 0x08
	struct FTimerHandle ActionSelfTimerHandle; // Offset: 0xe8 // Size: 0x08
	struct FTimerHandle ActionCheckTimerHandle; // Offset: 0xf0 // Size: 0x08
	float StartStepupTimeSpan; // Offset: 0xf8 // Size: 0x04
	bool IsTrigged; // Offset: 0xfc // Size: 0x01
	char pad_0xFD[0x3]; // Offset: 0xfd // Size: 0x03
};

// Object Name: ScriptStruct AClient.PartyStageActionMeterialParam
// Size: 0x58 // Inherited bytes: 0x00
struct FPartyStageActionMeterialParam {
	// Fields
	enum class EPartyStageMeterialParamType ParamType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FName MaterialParamName; // Offset: 0x04 // Size: 0x08
	struct FLinearColor TargetColor; // Offset: 0x0c // Size: 0x10
	float TargetValue; // Offset: 0x1c // Size: 0x04
	struct FLinearColor CurrentColor; // Offset: 0x20 // Size: 0x10
	float CurrentValue; // Offset: 0x30 // Size: 0x04
	bool bIsStepup; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	float StepupTime; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FTimerHandle StepupTimerHandle; // Offset: 0x40 // Size: 0x08
	struct FTimerHandle CheckTimerHandle; // Offset: 0x48 // Size: 0x08
	float StartStepupTimeSpan; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PathfinderSyncData
// Size: 0x7c // Inherited bytes: 0x00
struct FPathfinderSyncData {
	// Fields
	enum class EGrapplingHookState State; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FPathfinderHitStruct Hit; // Offset: 0x04 // Size: 0x54
	struct FPathfinderTraceStruct Trace; // Offset: 0x58 // Size: 0x20
	int32_t GrappleHookCnt; // Offset: 0x78 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PathfinderTraceStruct
// Size: 0x20 // Inherited bytes: 0x00
struct FPathfinderTraceStruct {
	// Fields
	struct FVector TraceStart; // Offset: 0x00 // Size: 0x0c
	struct FVector TraceEnd; // Offset: 0x0c // Size: 0x0c
	struct TWeakObjectPtr<struct USceneComponent> BaseSceneComp; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PathfinderHitStruct
// Size: 0x54 // Inherited bytes: 0x00
struct FPathfinderHitStruct {
	// Fields
	char bBlockingHit : 1; // Offset: 0x00 // Size: 0x01
	char bStartPenetrating : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_2 : 6; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ZiplineTime; // Offset: 0x04 // Size: 0x04
	struct FVector_NetQuantize Location; // Offset: 0x08 // Size: 0x0c
	struct FVector_NetQuantize ImpactPoint; // Offset: 0x14 // Size: 0x0c
	struct FVector_NetQuantizeNormal ImpactNormal; // Offset: 0x20 // Size: 0x0c
	struct FVector_NetQuantize TraceStart; // Offset: 0x2c // Size: 0x0c
	struct FVector_NetQuantize TraceEnd; // Offset: 0x38 // Size: 0x0c
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x44 // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x4c // Size: 0x08
};

// Object Name: ScriptStruct AClient.PathfinderFlexibleCDConf
// Size: 0x28 // Inherited bytes: 0x00
struct FPathfinderFlexibleCDConf {
	// Fields
	bool bEnableFlexibleCD; // Offset: 0x00 // Size: 0x01
	bool ActiveCDOnExitInAir; // Offset: 0x01 // Size: 0x01
	bool bEnableMaxConnTimeLimit; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	float MaxConnectTime; // Offset: 0x04 // Size: 0x04
	float MinCDDuration; // Offset: 0x08 // Size: 0x04
	float MaxCDDuration; // Offset: 0x0c // Size: 0x04
	float CDSlope; // Offset: 0x10 // Size: 0x04
	float CDConstantAddition; // Offset: 0x14 // Size: 0x04
	bool bIgnoreZDistance; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct UModifyAttributeData* ModifyAttributeDataClass; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PathfinderTacticalSkillUIClickProxyRuntimeData
// Size: 0x20 // Inherited bytes: 0x00
struct FPathfinderTacticalSkillUIClickProxyRuntimeData {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct AClient.PawnStateDisable
// Size: 0x02 // Inherited bytes: 0x00
struct FPawnStateDisable {
	// Fields
	enum class EPawnState PawnState; // Offset: 0x00 // Size: 0x01
	int8_t Disabled; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.PawnStateRelationTable
// Size: 0x10 // Inherited bytes: 0x00
struct FPawnStateRelationTable {
	// Fields
	struct TArray<struct FPawnStateRelation> Relations; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PawnStateRelation
// Size: 0x48 // Inherited bytes: 0x00
struct FPawnStateRelation {
	// Fields
	char pad_0x0[0x48]; // Offset: 0x00 // Size: 0x48
};

// Object Name: ScriptStruct AClient.StatePath
// Size: 0x0c // Inherited bytes: 0x00
struct FStatePath {
	// Fields
	float Timestamp; // Offset: 0x00 // Size: 0x04
	bool bEnter; // Offset: 0x04 // Size: 0x01
	enum class EPawnState State; // Offset: 0x05 // Size: 0x01
	bool bSync; // Offset: 0x06 // Size: 0x01
	enum class EMovementMode MovementMode; // Offset: 0x07 // Size: 0x01
	char CustomMovementMode; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct AClient.StateBlockMap
// Size: 0x18 // Inherited bytes: 0x00
struct FStateBlockMap {
	// Fields
	enum class EPawnState State; // Offset: 0x00 // Size: 0x01
	bool bRemove; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct TArray<struct FStateBlockData> StateBlockData; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.StateBlockData
// Size: 0x08 // Inherited bytes: 0x00
struct FStateBlockData {
	// Fields
	enum class EPawnState BlockState; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t BlockCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.OverrideStateSyncData
// Size: 0x02 // Inherited bytes: 0x00
struct FOverrideStateSyncData {
	// Fields
	enum class EPawnState SrcPawnState; // Offset: 0x00 // Size: 0x01
	enum class EPawnState DestPawnState; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.PerkBlackBoardDataBase
// Size: 0x08 // Inherited bytes: 0x00
struct FPerkBlackBoardDataBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PerkBlackBoardData_Common
// Size: 0x28 // Inherited bytes: 0x08
struct FPerkBlackBoardData_Common : FPerkBlackBoardDataBase {
	// Fields
	int32_t IntProperty; // Offset: 0x08 // Size: 0x04
	float FloatProperty; // Offset: 0x0c // Size: 0x04
	bool BooleanProperty; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString StringProperty; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PhantomBraidSyncInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FPhantomBraidSyncInfo {
	// Fields
	struct TArray<struct FPhantomRecordNodeData> RepPathList; // Offset: 0x00 // Size: 0x10
	float MoveSpeed; // Offset: 0x10 // Size: 0x04
	float MinMoveDuration; // Offset: 0x14 // Size: 0x04
	float MaxMoveDuration; // Offset: 0x18 // Size: 0x04
	enum class EPhantomRecordStatus RecordStatus; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct AClient.PhantomRecordNodeData
// Size: 0x4c // Inherited bytes: 0x00
struct FPhantomRecordNodeData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	struct FVector OwnerVel; // Offset: 0x18 // Size: 0x0c
	float RecordWolrdTime; // Offset: 0x24 // Size: 0x04
	bool IsOnMovable; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	struct TWeakObjectPtr<struct UPrimitiveComponent> MovementBase; // Offset: 0x2c // Size: 0x08
	struct FVector RelativeLocation; // Offset: 0x34 // Size: 0x0c
	struct FRotator RelativeRotation; // Offset: 0x40 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.PhantomVoidSyncData
// Size: 0x10 // Inherited bytes: 0x00
struct FPhantomVoidSyncData {
	// Fields
	struct AApexCharacter* Character; // Offset: 0x00 // Size: 0x08
	float Duration; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AutoPickDropAnimStore
// Size: 0x14 // Inherited bytes: 0x00
struct FAutoPickDropAnimStore {
	// Fields
	int32_t ItemSpecificID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x10]; // Offset: 0x04 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PickupBoxBtnQualityCfg
// Size: 0x30 // Inherited bytes: 0x00
struct FPickupBoxBtnQualityCfg {
	// Fields
	struct FLinearColor ColorBG; // Offset: 0x00 // Size: 0x10
	struct FLinearColor ColorIcon; // Offset: 0x10 // Size: 0x10
	struct FLinearColor ColorSelect; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.TombBoxData
// Size: 0x78 // Inherited bytes: 0x00
struct FTombBoxData {
	// Fields
	bool isNear; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FText TombName; // Offset: 0x08 // Size: 0x18
	int32_t Quality; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FSearchedPickUpWrapperResult> WrapperList; // Offset: 0x28 // Size: 0x10
	struct FSearchedPickUpTombBoxResult TombBoxResult; // Offset: 0x38 // Size: 0x38
	char pad_0x70[0x8]; // Offset: 0x70 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SearchedPickUpTombBoxResult
// Size: 0x38 // Inherited bytes: 0x00
struct FSearchedPickUpTombBoxResult {
	// Fields
	struct APlayerTombBox* TombBox; // Offset: 0x00 // Size: 0x08
	int32_t SearchedPickUpTime; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FSearchedPickUpWrapperResult> WrapperList; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FSearchedPickUpWrapperResult> SeekerWrapperList; // Offset: 0x20 // Size: 0x10
	int32_t Quality; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PickupWrapperMeshes
// Size: 0xe0 // Inherited bytes: 0x08
struct FPickupWrapperMeshes : FTableRowBase {
	// Fields
	int32_t MeshID; // Offset: 0x08 // Size: 0x04
	int32_t ParentID; // Offset: 0x0c // Size: 0x04
	int32_t Level; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Name; // Offset: 0x18 // Size: 0x10
	struct FString ItemDescription; // Offset: 0x28 // Size: 0x10
	struct TSoftObjectPtr<UStaticMesh> Mesh; // Offset: 0x38 // Size: 0x28
	struct TSoftObjectPtr<UPaperSprite> BigIcon; // Offset: 0x60 // Size: 0x28
	struct TSoftObjectPtr<UPaperSprite> SmallIcon; // Offset: 0x88 // Size: 0x28
	struct TSoftObjectPtr<UStaticMesh> StaticMeshEffect; // Offset: 0xb0 // Size: 0x28
	struct FName AttachPoint; // Offset: 0xd8 // Size: 0x08
};

// Object Name: ScriptStruct AClient.RandowSpawnItemEntry
// Size: 0x0c // Inherited bytes: 0x00
struct FRandowSpawnItemEntry {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	float Weight; // Offset: 0x04 // Size: 0x04
	int32_t ItemCount; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PickupItemConfigData
// Size: 0x50 // Inherited bytes: 0x00
struct FPickupItemConfigData {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FText ItemName; // Offset: 0x08 // Size: 0x18
	struct FText ShotItemDesc; // Offset: 0x20 // Size: 0x18
	struct FName ItemSmallIcon; // Offset: 0x38 // Size: 0x08
	struct FName ItemBigIcon; // Offset: 0x40 // Size: 0x08
	int32_t ItemQuality; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct AClient.PickUpReqData
// Size: 0x88 // Inherited bytes: 0x00
struct FPickUpReqData {
	// Fields
	struct APickUpWrapperActor* PickupActor; // Offset: 0x00 // Size: 0x08
	struct FPickUpItemData PickUpData; // Offset: 0x08 // Size: 0x30
	bool bIsAutoPickUp; // Offset: 0x38 // Size: 0x01
	bool bIsReplace; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x6]; // Offset: 0x3a // Size: 0x06
	struct FPickUpItemData ReplaceItemData; // Offset: 0x40 // Size: 0x30
	struct FItemDefineID TargetID; // Offset: 0x70 // Size: 0x10
	bool bLobaMarket; // Offset: 0x80 // Size: 0x01
	bool bLongPressReplace; // Offset: 0x81 // Size: 0x01
	bool bQuickReplace; // Offset: 0x82 // Size: 0x01
	char pad_0x83[0x5]; // Offset: 0x83 // Size: 0x05
};

// Object Name: ScriptStruct AClient.ItemObjectSpawnInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FItemObjectSpawnInfo {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
	struct TArray<struct FItemSpawnInfo> ItemSpawnInfos; // Offset: 0x20 // Size: 0x10
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ItemSpawnInfo
// Size: 0x90 // Inherited bytes: 0x00
struct FItemSpawnInfo {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t DeriveID; // Offset: 0x04 // Size: 0x04
	struct UObject* ItemClass; // Offset: 0x08 // Size: 0x08
	int32_t ItemCount; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString MetaData; // Offset: 0x18 // Size: 0x10
	struct FVector Pos; // Offset: 0x28 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x34 // Size: 0x0c
	float Radious; // Offset: 0x40 // Size: 0x04
	float Scale; // Offset: 0x44 // Size: 0x04
	struct AActor* Owner; // Offset: 0x48 // Size: 0x08
	bool bSpawnAtGround; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x3]; // Offset: 0x51 // Size: 0x03
	uint32_t DropPlayerId; // Offset: 0x54 // Size: 0x04
	char pad_0x58[0x38]; // Offset: 0x58 // Size: 0x38
};

// Object Name: ScriptStruct AClient.ItemConfig
// Size: 0x40 // Inherited bytes: 0x00
struct FItemConfig {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x00 // Size: 0x40
};

// Object Name: ScriptStruct AClient.PickupLootCombineReportData
// Size: 0xc8 // Inherited bytes: 0x00
struct FPickupLootCombineReportData {
	// Fields
	char pad_0x0[0xc8]; // Offset: 0x00 // Size: 0xc8
};

// Object Name: ScriptStruct AClient.PickupLootCombineItemData
// Size: 0x1c // Inherited bytes: 0x00
struct FPickupLootCombineItemData {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x00 // Size: 0x1c
};

// Object Name: ScriptStruct AClient.PickupItemReportData
// Size: 0x60 // Inherited bytes: 0x00
struct FPickupItemReportData {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x00 // Size: 0x60
};

// Object Name: ScriptStruct AClient.LootObjectInfoContainer
// Size: 0x10 // Inherited bytes: 0x00
struct FLootObjectInfoContainer {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PickupItemQualityConfig
// Size: 0xa8 // Inherited bytes: 0x00
struct FPickupItemQualityConfig {
	// Fields
	struct FLinearColor ColorBG; // Offset: 0x00 // Size: 0x10
	struct FLinearColor ColorCommon; // Offset: 0x10 // Size: 0x10
	struct FLinearColor ColorSelect; // Offset: 0x20 // Size: 0x10
	struct FLinearColor ColorRecommend; // Offset: 0x30 // Size: 0x10
	struct FLinearColor ColorRecommendSelect; // Offset: 0x40 // Size: 0x10
	struct FLinearColor ColorMask; // Offset: 0x50 // Size: 0x10
	struct FLinearColor ColorRecommendLight; // Offset: 0x60 // Size: 0x10
	struct FLinearColor ProcessColor; // Offset: 0x70 // Size: 0x10
	struct FSlateColor ArmorTextColor; // Offset: 0x80 // Size: 0x28
};

// Object Name: ScriptStruct AClient.PickupProbModel
// Size: 0xf8 // Inherited bytes: 0x00
struct FPickupProbModel {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct TArray<float> Probes; // Offset: 0x08 // Size: 0x10
	struct TArray<int32_t> BrotherIndexes; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FItemConfig> ItemConfigs; // Offset: 0x28 // Size: 0x10
	struct TMap<int32_t, int32_t> GroupIDToLimitCount; // Offset: 0x38 // Size: 0x50
	char pad_0x88[0x70]; // Offset: 0x88 // Size: 0x70
};

// Object Name: ScriptStruct AClient.WeightRandomUtil
// Size: 0x28 // Inherited bytes: 0x00
struct FWeightRandomUtil {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.EnsureRefreshData
// Size: 0x50 // Inherited bytes: 0x00
struct FEnsureRefreshData {
	// Fields
	struct TSet<int32_t> ContainKeyIDSet; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.PickupEnsureHeapData
// Size: 0x08 // Inherited bytes: 0x00
struct FPickupEnsureHeapData {
	// Fields
	int32_t NextEnsureRefreshCount; // Offset: 0x00 // Size: 0x04
	int32_t EnsureRefreshKey; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SpawnItemHistory
// Size: 0x50 // Inherited bytes: 0x00
struct FSpawnItemHistory {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ApgamePickupSkinResources
// Size: 0x30 // Inherited bytes: 0x08
struct FApgamePickupSkinResources : FApgameSkinMemMgrSkinResources {
	// Fields
	char pad_0x8[0x28]; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct AClient.DynamicStaticMeshParam
// Size: 0x80 // Inherited bytes: 0x00
struct FDynamicStaticMeshParam {
	// Fields
	struct TSoftObjectPtr<UStaticMesh> StaticMeshPtr; // Offset: 0x00 // Size: 0x28
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> MaterialInterfacesPtr; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FTransform Transform; // Offset: 0x40 // Size: 0x30
	bool bLoadAsync; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0xf]; // Offset: 0x71 // Size: 0x0f
};

// Object Name: ScriptStruct AClient.PickUpEffectMaterialData
// Size: 0x20 // Inherited bytes: 0x00
struct FPickUpEffectMaterialData {
	// Fields
	struct UMeshComponent* MeshComponent; // Offset: 0x00 // Size: 0x08
	struct UMaterialInstanceDynamic* MaterialDynamic; // Offset: 0x08 // Size: 0x08
	struct UMaterialInterface* BaseMaterial; // Offset: 0x10 // Size: 0x08
	int32_t MaterialIndex; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.PingSlotItemInfo
// Size: 0x02 // Inherited bytes: 0x00
struct FPingSlotItemInfo {
	// Fields
	enum class EHitPingType PingType; // Offset: 0x00 // Size: 0x01
	enum class EDingType DingType; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.PingAimedInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FPingAimedInfo {
	// Fields
	int32_t PingType; // Offset: 0x00 // Size: 0x04
	int32_t PingIndex; // Offset: 0x04 // Size: 0x04
	bool bIsSelf; // Offset: 0x08 // Size: 0x01
	enum class EPingButtonVisualType ButtonState; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
};

// Object Name: ScriptStruct AClient.AutoMarkInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FAutoMarkInfo {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	float Duration; // Offset: 0x04 // Size: 0x04
	float DistanceSquared; // Offset: 0x08 // Size: 0x04
	struct TWeakObjectPtr<struct AApexCharacterBase> Char; // Offset: 0x0c // Size: 0x08
	bool bIsMarked; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct AClient.SiglePingInfo
// Size: 0xa8 // Inherited bytes: 0x00
struct FSiglePingInfo {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	int32_t PingType; // Offset: 0x04 // Size: 0x04
	int32_t DingType; // Offset: 0x08 // Size: 0x04
	int32_t FromType; // Offset: 0x0c // Size: 0x04
	uint64_t CreateTime; // Offset: 0x10 // Size: 0x08
	uint32_t SourcePlayerID; // Offset: 0x18 // Size: 0x04
	uint32_t ReservePlayerID; // Offset: 0x1c // Size: 0x04
	struct FVector SourcePosition; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString PlayerName; // Offset: 0x30 // Size: 0x10
	int32_t TeamColor; // Offset: 0x40 // Size: 0x04
	bool bIsTeamLeader; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
	int32_t ItemID; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	uint64_t ItemUUID; // Offset: 0x50 // Size: 0x08
	int32_t ItemDeriveID; // Offset: 0x58 // Size: 0x04
	struct TWeakObjectPtr<struct AActor> ReferenceActor; // Offset: 0x5c // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> PriComp; // Offset: 0x64 // Size: 0x08
	struct FVector PositionOffset; // Offset: 0x6c // Size: 0x0c
	bool IsEnemy; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x3]; // Offset: 0x79 // Size: 0x03
	uint32_t SkillOwnerPlayerKey; // Offset: 0x7c // Size: 0x04
	struct FString SkillOwnerPlayerName; // Offset: 0x80 // Size: 0x10
	enum class EPingDataReportType ReportType; // Offset: 0x90 // Size: 0x01
	bool IsItemAutoMark; // Offset: 0x91 // Size: 0x01
	bool IsAutoMarkEnemy; // Offset: 0x92 // Size: 0x01
	bool bSkillAutoMark; // Offset: 0x93 // Size: 0x01
	float SkillCooling; // Offset: 0x94 // Size: 0x04
	uint32_t MapFlagsPlayerKey; // Offset: 0x98 // Size: 0x04
	bool bIsRecommendItem; // Offset: 0x9c // Size: 0x01
	bool bIsPingThroughBlock; // Offset: 0x9d // Size: 0x01
	bool bNeedPlayAudio; // Offset: 0x9e // Size: 0x01
	enum class EPingActionType ActionType; // Offset: 0x9f // Size: 0x01
	char pad_0xA0[0x8]; // Offset: 0xa0 // Size: 0x08
};

// Object Name: ScriptStruct AClient.AsynServerPingPositionInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FAsynServerPingPositionInfo {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	struct FVector ActorPosition; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.SimpleServerPingInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FSimpleServerPingInfo {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	float LiveEndTime; // Offset: 0x04 // Size: 0x04
	float VisibleEndTime; // Offset: 0x08 // Size: 0x04
	bool IsPingVisible; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	uint64_t ItemUUID; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PingReportData
// Size: 0x48 // Inherited bytes: 0x00
struct FPingReportData {
	// Fields
	char pad_0x0[0x48]; // Offset: 0x00 // Size: 0x48
};

// Object Name: ScriptStruct AClient.PingDataLua
// Size: 0x18 // Inherited bytes: 0x00
struct FPingDataLua {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	int64_t ItemUUID; // Offset: 0x08 // Size: 0x08
	int32_t RevervePlayerKey; // Offset: 0x10 // Size: 0x04
	bool IsReverseSelf; // Offset: 0x14 // Size: 0x01
	bool IsRealEnemy; // Offset: 0x15 // Size: 0x01
	bool IsSelf; // Offset: 0x16 // Size: 0x01
	char pad_0x17[0x1]; // Offset: 0x17 // Size: 0x01
};

// Object Name: ScriptStruct AClient.PingUserWidgetPoolData
// Size: 0x20 // Inherited bytes: 0x00
struct FPingUserWidgetPoolData {
	// Fields
	struct TWeakObjectPtr<struct UPingWidgetBase> OwnerUserWidget; // Offset: 0x00 // Size: 0x08
	bool IsUsing; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int32_t Index; // Offset: 0x0c // Size: 0x04
	enum class EPingVisualType VisualType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	uint64_t CreateTime; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AClient.LastTempInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FLastTempInfo {
	// Fields
	int32_t ItemID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	int64_t ItemUUID; // Offset: 0x08 // Size: 0x08
	int32_t DeriveID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.LastRecordInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FLastRecordInfo {
	// Fields
	struct FVector RecordPosition; // Offset: 0x00 // Size: 0x0c
	float CreateTime; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.DataArray
// Size: 0x10 // Inherited bytes: 0x00
struct FDataArray {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.APointDamageEvent
// Size: 0xa8 // Inherited bytes: 0xa8
struct FAPointDamageEvent : FPointDamageEvent {
};

// Object Name: ScriptStruct AClient.FinisherDamageEvent
// Size: 0xa8 // Inherited bytes: 0xa8
struct FFinisherDamageEvent : FAPointDamageEvent {
};

// Object Name: ScriptStruct AClient.ARadialDamageEvent
// Size: 0x40 // Inherited bytes: 0x40
struct FARadialDamageEvent : FRadialDamageEvent {
};

// Object Name: ScriptStruct AClient.ApexRadialDamageEvent
// Size: 0x48 // Inherited bytes: 0x40
struct FApexRadialDamageEvent : FARadialDamageEvent {
	// Fields
	char pad_0x40[0x8]; // Offset: 0x40 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApexPointDamageEvent
// Size: 0xb0 // Inherited bytes: 0xa8
struct FApexPointDamageEvent : FAPointDamageEvent {
	// Fields
	char pad_0xA8[0x8]; // Offset: 0xa8 // Size: 0x08
};

// Object Name: ScriptStruct AClient.GeneralDamageEvent
// Size: 0xb0 // Inherited bytes: 0xa8
struct FGeneralDamageEvent : FAPointDamageEvent {
	// Fields
	char pad_0xA8[0x8]; // Offset: 0xa8 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BuffDamageEvent
// Size: 0xb0 // Inherited bytes: 0xb0
struct FBuffDamageEvent : FGeneralDamageEvent {
};

// Object Name: ScriptStruct AClient.DronesBombDamageEvent
// Size: 0x40 // Inherited bytes: 0x40
struct FDronesBombDamageEvent : FRadialDamageEvent {
};

// Object Name: ScriptStruct AClient.BombDamageEvent
// Size: 0x40 // Inherited bytes: 0x40
struct FBombDamageEvent : FARadialDamageEvent {
};

// Object Name: ScriptStruct AClient.BlackMarketDamageEvent
// Size: 0xa8 // Inherited bytes: 0xa8
struct FBlackMarketDamageEvent : FAPointDamageEvent {
};

// Object Name: ScriptStruct AClient.MeleeDamageEvent
// Size: 0xb8 // Inherited bytes: 0xa8
struct FMeleeDamageEvent : FAPointDamageEvent {
	// Fields
	char pad_0xA8[0x10]; // Offset: 0xa8 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PoisonDamageEvent
// Size: 0xa8 // Inherited bytes: 0xa8
struct FPoisonDamageEvent : FAPointDamageEvent {
};

// Object Name: ScriptStruct AClient.ShootWeaponDamageEvent
// Size: 0xf0 // Inherited bytes: 0xa8
struct FShootWeaponDamageEvent : FAPointDamageEvent {
	// Fields
	char pad_0xA8[0x44]; // Offset: 0xa8 // Size: 0x44
	float DamageImpulse; // Offset: 0xec // Size: 0x04
};

// Object Name: ScriptStruct AClient.ClientSimulateDamageInfos
// Size: 0x18 // Inherited bytes: 0x00
struct FClientSimulateDamageInfos {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct AClient.BodyPartCfg
// Size: 0x28 // Inherited bytes: 0x00
struct FBodyPartCfg {
	// Fields
	float DamageScale; // Offset: 0x00 // Size: 0x04
	float Durability; // Offset: 0x04 // Size: 0x04
	float DamageReduceScale; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString BodyDurabilityIndexName; // Offset: 0x10 // Size: 0x10
	struct FName HitEffectTagOverride; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SelectLoadoutConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FSelectLoadoutConfig {
	// Fields
	int32_t LoadoutID; // Offset: 0x00 // Size: 0x04
	int32_t WeaponFittingID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GMStatisticsData
// Size: 0x44 // Inherited bytes: 0x00
struct FGMStatisticsData {
	// Fields
	char TeamRank; // Offset: 0x00 // Size: 0x01
	char Rank; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int32_t KillNum; // Offset: 0x04 // Size: 0x04
	int32_t DeathNum; // Offset: 0x08 // Size: 0x04
	float DamageAmount; // Offset: 0x0c // Size: 0x04
	float SurviveTime; // Offset: 0x10 // Size: 0x04
	float TeamSurviveTime; // Offset: 0x14 // Size: 0x04
	int32_t RescueNum; // Offset: 0x18 // Size: 0x04
	int32_t RevivalNum; // Offset: 0x1c // Size: 0x04
	int32_t AssistNum; // Offset: 0x20 // Size: 0x04
	int32_t ComboKill; // Offset: 0x24 // Size: 0x04
	float HeadShotRate; // Offset: 0x28 // Size: 0x04
	float RecoveryHP; // Offset: 0x2c // Size: 0x04
	int32_t MeleeKillNum; // Offset: 0x30 // Size: 0x04
	int32_t GrenadeLikeItemKill; // Offset: 0x34 // Size: 0x04
	float MoveDistance; // Offset: 0x38 // Size: 0x04
	int32_t RevivalByOtherNum; // Offset: 0x3c // Size: 0x04
	int32_t KillCountBySelf; // Offset: 0x40 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CanHelingSelfData
// Size: 0x08 // Inherited bytes: 0x00
struct FCanHelingSelfData {
	// Fields
	bool CanHealingSelf; // Offset: 0x00 // Size: 0x01
	bool CanShowDuration; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float Duration; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MagmaRiseStateCameraEffectCfg
// Size: 0x40 // Inherited bytes: 0x00
struct FMagmaRiseStateCameraEffectCfg {
	// Fields
	struct FMagmaRiseCameraSpringArmCfg Normal; // Offset: 0x00 // Size: 0x14
	struct FMagmaRiseCameraSpringArmCfg Acc; // Offset: 0x14 // Size: 0x14
	struct UCameraShake* MagmaRiseCameraShake; // Offset: 0x28 // Size: 0x08
	bool EnableCameraLag; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	float CameraLagSpeed; // Offset: 0x34 // Size: 0x04
	float CameraLagMaxDistance; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.MagmaRiseCameraSpringArmCfg
// Size: 0x14 // Inherited bytes: 0x00
struct FMagmaRiseCameraSpringArmCfg {
	// Fields
	float TargetArmLength; // Offset: 0x00 // Size: 0x04
	bool bLerpFormCurArmLength; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	float StartArmLength; // Offset: 0x08 // Size: 0x04
	float ArmLengthLerpDuration; // Offset: 0x0c // Size: 0x04
	float NearClippingPlane; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PhysicalSurfaceAddBuff
// Size: 0x10 // Inherited bytes: 0x00
struct FPhysicalSurfaceAddBuff {
	// Fields
	enum class EPhysicalSurface SurfaceType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FName AddBuffName; // Offset: 0x04 // Size: 0x08
	bool IsDelayBuff; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct AClient.CureRepData
// Size: 0x0c // Inherited bytes: 0x00
struct FCureRepData {
	// Fields
	bool IsInCD; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float RecoverCD; // Offset: 0x04 // Size: 0x04
	bool IsBreakShield; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct AClient.UseReplicatorAnimMontageData
// Size: 0x50 // Inherited bytes: 0x00
struct FUseReplicatorAnimMontageData {
	// Fields
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_FPP; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_TPP; // Offset: 0x28 // Size: 0x28
};

// Object Name: ScriptStruct AClient.LegendSkinData
// Size: 0x08 // Inherited bytes: 0x00
struct FLegendSkinData {
	// Fields
	int32_t LegendSkinID; // Offset: 0x00 // Size: 0x04
	bool IsFavor; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.ReplayPriorityStruct
// Size: 0x10 // Inherited bytes: 0x08
struct FReplayPriorityStruct : FTableRowBase {
	// Fields
	float Priority; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ColorBlindnessQuality
// Size: 0x10 // Inherited bytes: 0x00
struct FColorBlindnessQuality {
	// Fields
	struct TArray<struct FLinearColor> QualityColorArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CharacterDeathInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FCharacterDeathInfo {
	// Fields
	bool bIsDeath; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t MurderWeaponSkinId; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillFlowData
// Size: 0x30 // Inherited bytes: 0x00
struct FSkillFlowData {
	// Fields
	struct FString DataName; // Offset: 0x00 // Size: 0x10
	bool bIsString; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString DataString; // Offset: 0x18 // Size: 0x10
	float DataFloat; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.KillAssistInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FKillAssistInfo {
	// Fields
	bool IsKiller; // Offset: 0x00 // Size: 0x01
	bool bHeadShot; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int32_t ComboKill; // Offset: 0x04 // Size: 0x04
	bool IsRevenge; // Offset: 0x08 // Size: 0x01
	bool IsShutDown; // Offset: 0x09 // Size: 0x01
	bool IsFirstBlood; // Offset: 0x0a // Size: 0x01
	bool IsMeleeAttack; // Offset: 0x0b // Size: 0x01
	bool IsGrenadeAttack; // Offset: 0x0c // Size: 0x01
	bool IsLongDistance; // Offset: 0x0d // Size: 0x01
	bool IsSuperLongDistance; // Offset: 0x0e // Size: 0x01
	char pad_0xF[0x1]; // Offset: 0x0f // Size: 0x01
};

// Object Name: ScriptStruct AClient.ParachuteEffectSuitCfg
// Size: 0x50 // Inherited bytes: 0x00
struct FParachuteEffectSuitCfg {
	// Fields
	struct FParticleEffectSetCfg ParachuteEffects; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ParticleEffectSetCfg
// Size: 0x50 // Inherited bytes: 0x00
struct FParticleEffectSetCfg {
	// Fields
	struct TMap<enum class EParachuteEffectType, struct TSoftObjectPtr<UParticleSystem>> ParachuteEffects; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.APProjAnimInstanceProxy
// Size: 0x7c0 // Inherited bytes: 0x7b0
struct FAPProjAnimInstanceProxy : FAnimInstanceProxy {
	// Fields
	struct UProjAnimationComponent* ProjAnimationComponent; // Offset: 0x7a8 // Size: 0x08
	struct UAPProjAnimInstance* ParentAnimInst; // Offset: 0x7b0 // Size: 0x08
	bool bSkillGrenadeHold; // Offset: 0x7b8 // Size: 0x01
	bool bSkillGrenadePinPull; // Offset: 0x7b9 // Size: 0x01
	bool bSkillThrowGrenade; // Offset: 0x7ba // Size: 0x01
	bool bSkillGrenadeLand; // Offset: 0x7bb // Size: 0x01
	bool bSkillGrenadeActivate; // Offset: 0x7bc // Size: 0x01
	bool bSkillGrenadeDeploy; // Offset: 0x7bd // Size: 0x01
	bool bSkillGrenadeReady; // Offset: 0x7be // Size: 0x01
	bool bSkillGrenadeDestroy; // Offset: 0x7bf // Size: 0x01
};

// Object Name: ScriptStruct AClient.CaveAni
// Size: 0x18 // Inherited bytes: 0x00
struct FCaveAni {
	// Fields
	float DeltaTime; // Offset: 0x00 // Size: 0x04
	bool bLongBright; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct TArray<int32_t> CavesIndex; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PawnProxyPhantomVoidStatus
// Size: 0x0c // Inherited bytes: 0x00
struct FPawnProxyPhantomVoidStatus {
	// Fields
	bool bEnter; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t InstigatorTeamID; // Offset: 0x04 // Size: 0x04
	int32_t InstigatorCampID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PawnProxyVoidStatus
// Size: 0x05 // Inherited bytes: 0x00
struct FPawnProxyVoidStatus {
	// Fields
	bool bEnter; // Offset: 0x00 // Size: 0x01
	struct FCharacterVoidParams VoidParams; // Offset: 0x01 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PawnProxyMaterialConfig
// Size: 0x40 // Inherited bytes: 0x08
struct FPawnProxyMaterialConfig : FTableRowBase {
	// Fields
	struct FString Description; // Offset: 0x08 // Size: 0x10
	struct TSoftObjectPtr<UMaterialInterface> ReplaceMaterial; // Offset: 0x18 // Size: 0x28
};

// Object Name: ScriptStruct AClient.PawnProxyParticleConfig
// Size: 0x70 // Inherited bytes: 0x08
struct FPawnProxyParticleConfig : FTableRowBase {
	// Fields
	struct FString Description; // Offset: 0x08 // Size: 0x10
	struct TSoftObjectPtr<UParticleSystem> Template_Effect; // Offset: 0x18 // Size: 0x28
	enum class EPSCPoolMethod PoolingMethod; // Offset: 0x40 // Size: 0x01
	enum class EAPRenderPass RenderPass; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x2]; // Offset: 0x42 // Size: 0x02
	struct FVector OffsetLocation; // Offset: 0x44 // Size: 0x0c
	struct FRotator OffsetRotation; // Offset: 0x50 // Size: 0x0c
	bool bNotCreateForLowGrade; // Offset: 0x5c // Size: 0x01
	bool bEnableAttach; // Offset: 0x5d // Size: 0x01
	enum class EAttachLocation AttachLocation; // Offset: 0x5e // Size: 0x01
	char pad_0x5F[0x1]; // Offset: 0x5f // Size: 0x01
	struct FName AttachSocketName; // Offset: 0x60 // Size: 0x08
	bool bUseActorRot; // Offset: 0x68 // Size: 0x01
	bool bTouchGround; // Offset: 0x69 // Size: 0x01
	char pad_0x6A[0x6]; // Offset: 0x6a // Size: 0x06
};

// Object Name: ScriptStruct AClient.RemoteWeaponSoundPlay
// Size: 0x50 // Inherited bytes: 0x00
struct FRemoteWeaponSoundPlay {
	// Fields
	struct UAkComponent* AKComp; // Offset: 0x00 // Size: 0x08
	struct UApexSoundSpeakerComponent* Speaker; // Offset: 0x08 // Size: 0x08
	struct FApexSoundCallback SoundCallback; // Offset: 0x10 // Size: 0x28
	float PlayTime; // Offset: 0x38 // Size: 0x04
	int32_t SoundSeq; // Offset: 0x3c // Size: 0x04
	struct FVector SoundPos; // Offset: 0x40 // Size: 0x0c
	bool bSetPos; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
};

// Object Name: ScriptStruct AClient.ApexSoundCallback
// Size: 0x28 // Inherited bytes: 0x00
struct FApexSoundCallback {
	// Fields
	struct UApexSoundCallbackConfig* CallBackConfig; // Offset: 0x00 // Size: 0x08
	int32_t SoundSeq; // Offset: 0x08 // Size: 0x04
	struct FDelegate SoundEventCB; // Offset: 0x0c // Size: 0x10
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct AActor* Actor; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct AClient.RemoteWeaponSoundRecord
// Size: 0x18 // Inherited bytes: 0x00
struct FRemoteWeaponSoundRecord {
	// Fields
	struct TWeakObjectPtr<struct AApexCharacter> Character; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FRemoteWeaponSoundData> SoundData; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RemoteWeaponSoundData
// Size: 0x20 // Inherited bytes: 0x00
struct FRemoteWeaponSoundData {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t WeaponID; // Offset: 0x04 // Size: 0x04
	struct FVector SoundPos; // Offset: 0x08 // Size: 0x0c
	float SoundTime; // Offset: 0x14 // Size: 0x04
	int32_t SoundAction; // Offset: 0x18 // Size: 0x04
	bool bEnemy; // Offset: 0x1c // Size: 0x01
	bool bLoop; // Offset: 0x1d // Size: 0x01
	bool bStop; // Offset: 0x1e // Size: 0x01
	char pad_0x1F[0x1]; // Offset: 0x1f // Size: 0x01
};

// Object Name: ScriptStruct AClient.ProxyActorData
// Size: 0xa0 // Inherited bytes: 0x00
struct FProxyActorData {
	// Fields
	struct FProxyActorMovementData MovementData; // Offset: 0x00 // Size: 0x24
	float SimulateServerTimeStamp; // Offset: 0x24 // Size: 0x04
	struct UPrimitiveComponent* Base; // Offset: 0x28 // Size: 0x08
	char ReplicatedMovementMode; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	uint64_t StateMask; // Offset: 0x38 // Size: 0x08
	struct TArray<struct FProxyActorWeaponData> WeaponData; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FBulletHitInfoReplicateData> BulletHitData; // Offset: 0x50 // Size: 0x10
	struct FProxyActorHurtData HurtData; // Offset: 0x60 // Size: 0x30
	struct FProxyActorKnockdownShieldData KnockdownShieldData; // Offset: 0x90 // Size: 0x02
	char pad_0x92[0x2]; // Offset: 0x92 // Size: 0x02
	struct FProxyActorRescueData RescueData; // Offset: 0x94 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.ProxyActorRescueData
// Size: 0x0c // Inherited bytes: 0x00
struct FProxyActorRescueData {
	// Fields
	bool bEnable; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t SourcePlayerKey; // Offset: 0x04 // Size: 0x04
	int32_t TargetPlayerKey; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ProxyActorKnockdownShieldData
// Size: 0x02 // Inherited bytes: 0x00
struct FProxyActorKnockdownShieldData {
	// Fields
	bool bEnable; // Offset: 0x00 // Size: 0x01
	char Level; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.ProxyActorHurtData
// Size: 0x30 // Inherited bytes: 0x00
struct FProxyActorHurtData {
	// Fields
	int32_t VictimPlayerKey; // Offset: 0x00 // Size: 0x04
	float Damage; // Offset: 0x04 // Size: 0x04
	int32_t DamageType; // Offset: 0x08 // Size: 0x04
	int32_t AttackerPlayerKey; // Offset: 0x0c // Size: 0x04
	char AvatarDamagePosition; // Offset: 0x10 // Size: 0x01
	char bIsHeadShotDamage : 1; // Offset: 0x11 // Size: 0x01
	char bIsFatalHealthCost : 1; // Offset: 0x11 // Size: 0x01
	char bIsHitShield : 1; // Offset: 0x11 // Size: 0x01
	char bIsShieldBroken : 1; // Offset: 0x11 // Size: 0x01
	char pad_0x11_4 : 4; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	uint32_t ShootID; // Offset: 0x14 // Size: 0x04
	uint32_t PelletID; // Offset: 0x18 // Size: 0x04
	float AimPercent; // Offset: 0x1c // Size: 0x04
	char AimChargeLevel; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	double TimeOutServerTime; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ProxyActorMovementData
// Size: 0x24 // Inherited bytes: 0x00
struct FProxyActorMovementData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	struct FVector Velocity; // Offset: 0x18 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.ProxyActorBasicData
// Size: 0x14 // Inherited bytes: 0x00
struct FProxyActorBasicData {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int32_t LegendId; // Offset: 0x04 // Size: 0x04
	int32_t LegendSkinID; // Offset: 0x08 // Size: 0x04
	bool bServerDestroy; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	int32_t ProxyListIndex; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.QuickItemArray
// Size: 0x10 // Inherited bytes: 0x00
struct FQuickItemArray {
	// Fields
	struct TArray<int32_t> ItemIDArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CircleAudioConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FCircleAudioConfig {
	// Fields
	struct FName AudioID_CircleMoving; // Offset: 0x00 // Size: 0x08
	struct FName AudioID_CircleStop; // Offset: 0x08 // Size: 0x08
	struct FName AudioID_CircleStay; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.RadiationCircleStateRep
// Size: 0x3c // Inherited bytes: 0x00
struct FRadiationCircleStateRep {
	// Fields
	enum class ECircleInfo CircleInfo; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector BlueCircle; // Offset: 0x04 // Size: 0x0c
	struct FVector WhiteCircle; // Offset: 0x10 // Size: 0x0c
	struct FVector NextWhiteCircle; // Offset: 0x1c // Size: 0x0c
	int32_t CircleWaveIndex; // Offset: 0x28 // Size: 0x04
	float StartTimeSpan; // Offset: 0x2c // Size: 0x04
	float EndTimeSpan; // Offset: 0x30 // Size: 0x04
	bool IsPreInitMiniMapShow; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x7]; // Offset: 0x35 // Size: 0x07
};

// Object Name: ScriptStruct AClient.RecoverProp_HeroAudioConfig
// Size: 0x58 // Inherited bytes: 0x00
struct FRecoverProp_HeroAudioConfig {
	// Fields
	enum class ELegendType LegendType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TSoftObjectPtr<UAkAudioEvent> AkEvent_1P; // Offset: 0x08 // Size: 0x28
	struct TSoftObjectPtr<UAkAudioEvent> AkEvent_3P; // Offset: 0x30 // Size: 0x28
};

// Object Name: ScriptStruct AClient.RecoverPropItemList
// Size: 0x10 // Inherited bytes: 0x00
struct FRecoverPropItemList {
	// Fields
	struct TArray<struct UBaseRecoverPropItem*> RecoverPropItems; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RecoverPropBuffInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FRecoverPropBuffInfo {
	// Fields
	struct FString Tag; // Offset: 0x00 // Size: 0x10
	int32_t ItemID; // Offset: 0x10 // Size: 0x04
	enum class ERecoverPropBuffType eBuffType; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	float Value; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.RecoverPropSyncInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FRecoverPropSyncInfo {
	// Fields
	int32_t UniqueID; // Offset: 0x00 // Size: 0x04
	int32_t ItemID; // Offset: 0x04 // Size: 0x04
	float StartTimestamp; // Offset: 0x08 // Size: 0x04
	enum class ERecoverPropUseType ERecoverPropUseType; // Offset: 0x0c // Size: 0x01
	bool bContinuous; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
};

// Object Name: ScriptStruct AClient.ScrollChildData
// Size: 0x10 // Inherited bytes: 0x00
struct FScrollChildData {
	// Fields
	int32_t OffSetIndex; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct URecycleScrollItem* Widget; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ScrollItemData
// Size: 0x08 // Inherited bytes: 0x00
struct FScrollItemData {
	// Fields
	int32_t Index; // Offset: 0x00 // Size: 0x04
	int32_t Data; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ReplicatorSignItemColor
// Size: 0x40 // Inherited bytes: 0x00
struct FReplicatorSignItemColor {
	// Fields
	struct FLinearColor BgColor; // Offset: 0x00 // Size: 0x10
	struct FLinearColor BgOutLineColor; // Offset: 0x10 // Size: 0x10
	struct FLinearColor BgFigureColor; // Offset: 0x20 // Size: 0x10
	struct FLinearColor BgProgressColor; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AircraftBornConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FAircraftBornConfig {
	// Fields
	struct FVector BornLocation; // Offset: 0x00 // Size: 0x0c
	float BornYaw; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ApexSceneCameraInfo
// Size: 0x38 // Inherited bytes: 0x08
struct FApexSceneCameraInfo : FTableRowBase {
	// Fields
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x14 // Size: 0x0c
	float FOV; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct ALevelSequenceActor* SequenceActor; // Offset: 0x28 // Size: 0x08
	float BlendTime; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ScriptAIFakeBroadConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FScriptAIFakeBroadConfig {
	// Fields
	int32_t StartSec; // Offset: 0x00 // Size: 0x04
	int32_t TeamNum; // Offset: 0x04 // Size: 0x04
	int32_t CD; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AIScript
// Size: 0x50 // Inherited bytes: 0x00
struct FAIScript {
	// Fields
	uint32_t TeamAIRoleNum; // Offset: 0x00 // Size: 0x04
	uint32_t NormalAINum; // Offset: 0x04 // Size: 0x04
	bool IsByTeam; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float Timeout; // Offset: 0x0c // Size: 0x04
	uint32_t LimitTimes; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct UBehaviorTree*> TeammateAIRoles; // Offset: 0x18 // Size: 0x10
	struct TArray<struct UBehaviorTree*> NormalAIRoles; // Offset: 0x28 // Size: 0x10
	struct TArray<struct UEnvQuery*> NormalAIEQSInstance; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct AClient.UnfoldAppointmentFlow
// Size: 0x48 // Inherited bytes: 0x40
struct FUnfoldAppointmentFlow : FSecBasic {
	// Fields
	int32_t UnfoldAppointmentListCnt; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponFlow
// Size: 0xa8 // Inherited bytes: 0x40
struct FWeaponFlow : FSecBasic {
	// Fields
	int32_t WeaponID; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TMap<int32_t, int32_t> AttachList; // Offset: 0x48 // Size: 0x50
	int32_t ShootBulletCount; // Offset: 0x98 // Size: 0x04
	int32_t HitCount; // Offset: 0x9c // Size: 0x04
	int32_t HeadHitCount; // Offset: 0xa0 // Size: 0x04
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponHitFlow
// Size: 0x98 // Inherited bytes: 0x40
struct FWeaponHitFlow : FSecBasic {
	// Fields
	int32_t WeaponID; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TMap<int32_t, struct FAimHitFlow> WeaponHitData; // Offset: 0x48 // Size: 0x50
};

// Object Name: ScriptStruct AClient.AimHitFlow
// Size: 0x58 // Inherited bytes: 0x00
struct FAimHitFlow {
	// Fields
	int32_t AimID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<int32_t, struct FOpticalHitFlow> AimHitData; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct AClient.OpticalHitFlow
// Size: 0x58 // Inherited bytes: 0x00
struct FOpticalHitFlow {
	// Fields
	int32_t OpticalID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<int32_t, struct FBarrelHitFlow> OpticalHitData; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct AClient.BarrelHitFlow
// Size: 0x58 // Inherited bytes: 0x00
struct FBarrelHitFlow {
	// Fields
	int32_t BarrelID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<int32_t, struct FHopUpHitFlow> BarrelHitData; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct AClient.HopUpHitFlow
// Size: 0x18 // Inherited bytes: 0x00
struct FHopUpHitFlow {
	// Fields
	int32_t HopUpID; // Offset: 0x00 // Size: 0x04
	struct FBaseHitFlow BaseHitData; // Offset: 0x04 // Size: 0x14
};

// Object Name: ScriptStruct AClient.BaseHitFlow
// Size: 0x14 // Inherited bytes: 0x00
struct FBaseHitFlow {
	// Fields
	int32_t ShootCount; // Offset: 0x00 // Size: 0x04
	int32_t ShootBulletCount; // Offset: 0x04 // Size: 0x04
	int32_t CostBulletCount; // Offset: 0x08 // Size: 0x04
	int32_t HitCount; // Offset: 0x0c // Size: 0x04
	int32_t HeadHitCount; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SecWatchSpectatingFlow
// Size: 0x50 // Inherited bytes: 0x40
struct FSecWatchSpectatingFlow : FSecBasic {
	// Fields
	struct FString WatchedOpenID; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SecGameEndWatchFlow
// Size: 0x90 // Inherited bytes: 0x40
struct FSecGameEndWatchFlow : FSecBasic {
	// Fields
	struct FString WatchRoleID1; // Offset: 0x40 // Size: 0x10
	uint64_t WatchTime1; // Offset: 0x50 // Size: 0x08
	struct FString WatchRoleID2; // Offset: 0x58 // Size: 0x10
	int32_t WatchTime2; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString WatchRoleID3; // Offset: 0x70 // Size: 0x10
	uint64_t WatchTime3; // Offset: 0x80 // Size: 0x08
	uint64_t TotalTime; // Offset: 0x88 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SecPlayerWatchBattleFlow
// Size: 0xb0 // Inherited bytes: 0x40
struct FSecPlayerWatchBattleFlow : FSecBasic {
	// Fields
	uint64_t UID; // Offset: 0x40 // Size: 0x08
	uint64_t WatchUID; // Offset: 0x48 // Size: 0x08
	uint64_t GameID; // Offset: 0x50 // Size: 0x08
	int32_t mode; // Offset: 0x58 // Size: 0x04
	int32_t SubMode; // Offset: 0x5c // Size: 0x04
	int32_t WatchPlatID; // Offset: 0x60 // Size: 0x04
	int32_t WatchType; // Offset: 0x64 // Size: 0x04
	int32_t WatchTime; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString DeviceID; // Offset: 0x70 // Size: 0x10
	struct FString ClientIP; // Offset: 0x80 // Size: 0x10
	struct FString WatchDeviceId; // Offset: 0x90 // Size: 0x10
	struct FString WatchClientIP; // Offset: 0xa0 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SecReviveFlow
// Size: 0x60 // Inherited bytes: 0x40
struct FSecReviveFlow : FSecBasic {
	// Fields
	int32_t ReviveFlowID; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString ReviveRoleID; // Offset: 0x48 // Size: 0x10
	int32_t ReviveRoleType; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct AClient.SecHurtFlow
// Size: 0xa8 // Inherited bytes: 0x40
struct FSecHurtFlow : FSecBasic {
	// Fields
	int32_t HurtFlowID; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString EnemyRoleID; // Offset: 0x48 // Size: 0x10
	int32_t HurtTime; // Offset: 0x58 // Size: 0x04
	int32_t HurtDamage; // Offset: 0x5c // Size: 0x04
	int32_t EnemyLegendID; // Offset: 0x60 // Size: 0x04
	int32_t EnemyGunType; // Offset: 0x64 // Size: 0x04
	int32_t EnemyGunID; // Offset: 0x68 // Size: 0x04
	int32_t EnemySkillID; // Offset: 0x6c // Size: 0x04
	int32_t HurtFrom; // Offset: 0x70 // Size: 0x04
	int32_t HitType; // Offset: 0x74 // Size: 0x04
	int32_t HPstart; // Offset: 0x78 // Size: 0x04
	int32_t HPEnd; // Offset: 0x7c // Size: 0x04
	int32_t ArmorHPStart; // Offset: 0x80 // Size: 0x04
	int32_t ArmorHPEnd; // Offset: 0x84 // Size: 0x04
	int32_t PlayerKilled; // Offset: 0x88 // Size: 0x04
	int32_t HurtType; // Offset: 0x8c // Size: 0x04
	int32_t HurtID; // Offset: 0x90 // Size: 0x04
	int32_t RealHurtType; // Offset: 0x94 // Size: 0x04
	int32_t RealHurtID; // Offset: 0x98 // Size: 0x04
	int32_t ArmorKill; // Offset: 0x9c // Size: 0x04
	int32_t IfIsAI; // Offset: 0xa0 // Size: 0x04
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SecAtackFlow
// Size: 0x128 // Inherited bytes: 0x40
struct FSecAtackFlow : FSecBasic {
	// Fields
	int32_t RoleIsAI; // Offset: 0x40 // Size: 0x04
	int32_t AtackFlowID; // Offset: 0x44 // Size: 0x04
	struct FString TargetOpenID; // Offset: 0x48 // Size: 0x10
	struct FString TargetRoleID; // Offset: 0x58 // Size: 0x10
	struct FString TargetUserName; // Offset: 0x68 // Size: 0x10
	int32_t TargetIsAI; // Offset: 0x78 // Size: 0x04
	int32_t gunType; // Offset: 0x7c // Size: 0x04
	int32_t GunID; // Offset: 0x80 // Size: 0x04
	int32_t SightType; // Offset: 0x84 // Size: 0x04
	int32_t MagazineMax; // Offset: 0x88 // Size: 0x04
	int32_t MagazineLeft; // Offset: 0x8c // Size: 0x04
	int32_t Recoil; // Offset: 0x90 // Size: 0x04
	int32_t PlayerPose; // Offset: 0x94 // Size: 0x04
	int32_t ShotPose; // Offset: 0x98 // Size: 0x04
	int32_t FireType; // Offset: 0x9c // Size: 0x04
	int32_t PlayerPositionX; // Offset: 0xa0 // Size: 0x04
	int32_t PlayerPositionY; // Offset: 0xa4 // Size: 0x04
	int32_t PlayerPositionZ; // Offset: 0xa8 // Size: 0x04
	int32_t GunPositionX; // Offset: 0xac // Size: 0x04
	int32_t GunPositionY; // Offset: 0xb0 // Size: 0x04
	int32_t GunPositionZ; // Offset: 0xb4 // Size: 0x04
	int32_t BulletsBornPositionX; // Offset: 0xb8 // Size: 0x04
	int32_t BulletsBornPositionY; // Offset: 0xbc // Size: 0x04
	int32_t BulletsBornPositionZ; // Offset: 0xc0 // Size: 0x04
	int32_t HitPositionX; // Offset: 0xc4 // Size: 0x04
	int32_t HitPositionY; // Offset: 0xc8 // Size: 0x04
	int32_t HitPositionZ; // Offset: 0xcc // Size: 0x04
	int32_t HitPart; // Offset: 0xd0 // Size: 0x04
	int32_t HPstart; // Offset: 0xd4 // Size: 0x04
	int32_t HPEnd; // Offset: 0xd8 // Size: 0x04
	int32_t ArmorHPStart; // Offset: 0xdc // Size: 0x04
	int32_t ArmorHPEnd; // Offset: 0xe0 // Size: 0x04
	int32_t PlayerKill; // Offset: 0xe4 // Size: 0x04
	int32_t ArmorKill; // Offset: 0xe8 // Size: 0x04
	int32_t RecoilMoveX; // Offset: 0xec // Size: 0x04
	int32_t RecoilMoveY; // Offset: 0xf0 // Size: 0x04
	int32_t WeaponAimFOV; // Offset: 0xf4 // Size: 0x04
	int32_t BulletDamageBuff; // Offset: 0xf8 // Size: 0x04
	int32_t BulletDamageDebuff; // Offset: 0xfc // Size: 0x04
	int32_t AutoAimSpeed; // Offset: 0x100 // Size: 0x04
	int32_t AutoAimSpeedRateMax; // Offset: 0x104 // Size: 0x04
	int32_t AutoAimRangeMax; // Offset: 0x108 // Size: 0x04
	int32_t AutoAimRangeRateMax; // Offset: 0x10c // Size: 0x04
	int32_t iZoneAreaID; // Offset: 0x110 // Size: 0x04
	int32_t LegendId; // Offset: 0x114 // Size: 0x04
	int32_t HurtDamage; // Offset: 0x118 // Size: 0x04
	int32_t BarrelID; // Offset: 0x11c // Size: 0x04
	int32_t HopUpID; // Offset: 0x120 // Size: 0x04
	int32_t CircleCount; // Offset: 0x124 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SecCircleFlow
// Size: 0x68 // Inherited bytes: 0x40
struct FSecCircleFlow : FSecBasic {
	// Fields
	int32_t GameStartTime; // Offset: 0x40 // Size: 0x04
	int32_t NewCircleBornTime; // Offset: 0x44 // Size: 0x04
	int32_t NewCircleCount; // Offset: 0x48 // Size: 0x04
	int32_t OldCircleMoveTime; // Offset: 0x4c // Size: 0x04
	int32_t OldCircleMoveEndTime; // Offset: 0x50 // Size: 0x04
	int32_t PlayerOutTime; // Offset: 0x54 // Size: 0x04
	float NewCirclePositionX; // Offset: 0x58 // Size: 0x04
	float NewCirclePositionY; // Offset: 0x5c // Size: 0x04
	float NewCirclePositionRadius; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SecJumpFlow
// Size: 0x60 // Inherited bytes: 0x40
struct FSecJumpFlow : FSecBasic {
	// Fields
	int32_t GameStartTime; // Offset: 0x40 // Size: 0x04
	int32_t StartJumpTime; // Offset: 0x44 // Size: 0x04
	int32_t EndJumpTime; // Offset: 0x48 // Size: 0x04
	int32_t PlayerJumpTime; // Offset: 0x4c // Size: 0x04
	int32_t PlayerLandTime; // Offset: 0x50 // Size: 0x04
	int32_t PlayerSpeedMax1; // Offset: 0x54 // Size: 0x04
	int32_t PlayerSpeedMax2; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct AClient.SecRoundEndFlow
// Size: 0x170 // Inherited bytes: 0x40
struct FSecRoundEndFlow : FSecBasic {
	// Fields
	int32_t GameEndFlowID; // Offset: 0x40 // Size: 0x04
	int32_t OverTime; // Offset: 0x44 // Size: 0x04
	int32_t RoundTime; // Offset: 0x48 // Size: 0x04
	int32_t EndType; // Offset: 0x4c // Size: 0x04
	int32_t KillCount; // Offset: 0x50 // Size: 0x04
	int32_t AssistsCount; // Offset: 0x54 // Size: 0x04
	int32_t DropCount; // Offset: 0x58 // Size: 0x04
	int32_t SaveCount; // Offset: 0x5c // Size: 0x04
	int32_t RebornCount; // Offset: 0x60 // Size: 0x04
	int32_t AliveType; // Offset: 0x64 // Size: 0x04
	int32_t GoldGet; // Offset: 0x68 // Size: 0x04
	int32_t DiamondGet; // Offset: 0x6c // Size: 0x04
	int32_t ExpGet; // Offset: 0x70 // Size: 0x04
	int32_t WinRank; // Offset: 0x74 // Size: 0x04
	int32_t TotalPlayers; // Offset: 0x78 // Size: 0x04
	int32_t PlayerRank; // Offset: 0x7c // Size: 0x04
	int32_t RankEnd; // Offset: 0x80 // Size: 0x04
	int32_t SeasonID; // Offset: 0x84 // Size: 0x04
	int32_t mode; // Offset: 0x88 // Size: 0x04
	int32_t SubMode; // Offset: 0x8c // Size: 0x04
	int32_t PlayerNumber; // Offset: 0x90 // Size: 0x04
	int32_t RealPlayerNumber; // Offset: 0x94 // Size: 0x04
	int32_t TotalChangedPointValue; // Offset: 0x98 // Size: 0x04
	int32_t ChangedRatingValue; // Offset: 0x9c // Size: 0x04
	int32_t RatingValueAfterChanged; // Offset: 0xa0 // Size: 0x04
	int32_t CurrentROundRank; // Offset: 0xa4 // Size: 0x04
	int32_t GunHitTimes; // Offset: 0xa8 // Size: 0x04
	int32_t GunShotTimes; // Offset: 0xac // Size: 0x04
	int32_t TotalHeadShotRate; // Offset: 0xb0 // Size: 0x04
	int32_t OldSegmentLevel; // Offset: 0xb4 // Size: 0x04
	int32_t NewSegmentLevel; // Offset: 0xb8 // Size: 0x04
	int32_t FriendCount; // Offset: 0xbc // Size: 0x04
	int32_t AfterLevel; // Offset: 0xc0 // Size: 0x04
	int32_t IsObExit; // Offset: 0xc4 // Size: 0x04
	int32_t SurvivalTime; // Offset: 0xc8 // Size: 0x04
	int32_t DamageAmount; // Offset: 0xcc // Size: 0x04
	int32_t HealTimes; // Offset: 0xd0 // Size: 0x04
	int32_t HealAmount; // Offset: 0xd4 // Size: 0x04
	int32_t MovingDistance; // Offset: 0xd8 // Size: 0x04
	int32_t HeadshotCounts; // Offset: 0xdc // Size: 0x04
	int32_t GunKillingTimes; // Offset: 0xe0 // Size: 0x04
	int32_t MeleeKillTimes; // Offset: 0xe4 // Size: 0x04
	int32_t MeleeDamageAmount; // Offset: 0xe8 // Size: 0x04
	int32_t CreepingTime; // Offset: 0xec // Size: 0x04
	int32_t DrivingTime; // Offset: 0xf0 // Size: 0x04
	int32_t WalkingDistance; // Offset: 0xf4 // Size: 0x04
	int32_t StayTimeInPoisonedArea; // Offset: 0xf8 // Size: 0x04
	int32_t TotalDamage; // Offset: 0xfc // Size: 0x04
	int32_t TotalHeal; // Offset: 0x100 // Size: 0x04
	int32_t SegmentProtect; // Offset: 0x104 // Size: 0x04
	int32_t IsMvp; // Offset: 0x108 // Size: 0x04
	int32_t Pronetime; // Offset: 0x10c // Size: 0x04
	int32_t FollowState; // Offset: 0x110 // Size: 0x04
	int32_t TouchDownAreaID; // Offset: 0x114 // Size: 0x04
	int32_t StartToRescueTimes; // Offset: 0x118 // Size: 0x04
	int32_t AIKillCount; // Offset: 0x11c // Size: 0x04
	int32_t KillHeadShotCount; // Offset: 0x120 // Size: 0x04
	int32_t RoundCircleCount; // Offset: 0x124 // Size: 0x04
	int32_t HurtTeammateCount; // Offset: 0x128 // Size: 0x04
	int32_t TeamRank; // Offset: 0x12c // Size: 0x04
	int32_t TeamTotalPlayers; // Offset: 0x130 // Size: 0x04
	int32_t TeamPeopleCount; // Offset: 0x134 // Size: 0x04
	int32_t TeamID; // Offset: 0x138 // Size: 0x04
	int32_t TeamPlayer1AliveType; // Offset: 0x13c // Size: 0x04
	int32_t TeamPlayer2AliveType; // Offset: 0x140 // Size: 0x04
	int32_t TeamPlayer1Kill; // Offset: 0x144 // Size: 0x04
	int32_t TeamPlayer2Kill; // Offset: 0x148 // Size: 0x04
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
	struct FString TeamPlayerMoreAliveType; // Offset: 0x150 // Size: 0x10
	struct FString TeamPlayerMoreKill; // Offset: 0x160 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SecRoundStartFlow
// Size: 0xf0 // Inherited bytes: 0x40
struct FSecRoundStartFlow : FSecBasic {
	// Fields
	int32_t SecGameStartFlowFlowID; // Offset: 0x40 // Size: 0x04
	int32_t SvrUserMoney1; // Offset: 0x44 // Size: 0x04
	int32_t SvrUserMoney2; // Offset: 0x48 // Size: 0x04
	int32_t SvrUserMoney3; // Offset: 0x4c // Size: 0x04
	int32_t SvrRoundRank; // Offset: 0x50 // Size: 0x04
	int32_t SvrRoundRank1; // Offset: 0x54 // Size: 0x04
	int32_t SvrRoundRank2; // Offset: 0x58 // Size: 0x04
	int32_t GameType; // Offset: 0x5c // Size: 0x04
	int32_t TeamType; // Offset: 0x60 // Size: 0x04
	int32_t AutoMatch; // Offset: 0x64 // Size: 0x04
	int32_t TeamPeopleCount; // Offset: 0x68 // Size: 0x04
	int32_t playerCount; // Offset: 0x6c // Size: 0x04
	int32_t AICount; // Offset: 0x70 // Size: 0x04
	int32_t TeamID; // Offset: 0x74 // Size: 0x04
	struct FString TeamPlayer2; // Offset: 0x78 // Size: 0x10
	int32_t TeamPlayer1Rank; // Offset: 0x88 // Size: 0x04
	int32_t TeamPlayer2Rank; // Offset: 0x8c // Size: 0x04
	int32_t TeamPlayer1Teammate; // Offset: 0x90 // Size: 0x04
	int32_t TeamPlayer2Teammate; // Offset: 0x94 // Size: 0x04
	int32_t TeamPlayer1TeammatePlatid; // Offset: 0x98 // Size: 0x04
	int32_t TeamPlayer2TeammatePlatid; // Offset: 0x9c // Size: 0x04
	int32_t RoomID; // Offset: 0xa0 // Size: 0x04
	int32_t TeamPlayer1Friend; // Offset: 0xa4 // Size: 0x04
	int32_t TeamPlayer2Friend; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct FString TeamPlayerMoreRank; // Offset: 0xb0 // Size: 0x10
	struct FString TeamPlayerMoreTeammate; // Offset: 0xc0 // Size: 0x10
	struct FString TeamPlayerMoreTeammatePlatid; // Offset: 0xd0 // Size: 0x10
	struct FString TeamPlayerMoreFriend; // Offset: 0xe0 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SecMailFlow
// Size: 0x98 // Inherited bytes: 0x40
struct FSecMailFlow : FSecBasic {
	// Fields
	struct FString ReceiverRoleID; // Offset: 0x40 // Size: 0x10
	struct FString ReceiverRoleName; // Offset: 0x50 // Size: 0x10
	int32_t ReceiverRoleLevel; // Offset: 0x60 // Size: 0x04
	int32_t ReceiverRoleBattlePoint; // Offset: 0x64 // Size: 0x04
	int32_t MailType; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString TitleContents; // Offset: 0x70 // Size: 0x10
	struct FString ChatContents; // Offset: 0x80 // Size: 0x10
	int32_t MsgType; // Offset: 0x90 // Size: 0x04
	int32_t MailID; // Offset: 0x94 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SecRankingListFlow
// Size: 0x48 // Inherited bytes: 0x40
struct FSecRankingListFlow : FSecBasic {
	// Fields
	int32_t ListType; // Offset: 0x40 // Size: 0x04
	int32_t Ranking; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SecSNSGetFlow
// Size: 0x78 // Inherited bytes: 0x40
struct FSecSNSGetFlow : FSecBasic {
	// Fields
	struct FString ReceiverRoleID; // Offset: 0x40 // Size: 0x10
	struct FString ReceiverRoleName; // Offset: 0x50 // Size: 0x10
	int32_t ReceiverRoleLevel; // Offset: 0x60 // Size: 0x04
	int32_t GetMode; // Offset: 0x64 // Size: 0x04
	struct FString EditContents; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SecEditFlow
// Size: 0x60 // Inherited bytes: 0x40
struct FSecEditFlow : FSecBasic {
	// Fields
	int32_t EditType; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString EditContents; // Offset: 0x48 // Size: 0x10
	int32_t MsgType; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct AClient.SecTalkFlow
// Size: 0xb8 // Inherited bytes: 0x40
struct FSecTalkFlow : FSecBasic {
	// Fields
	struct FString RoleGroupID; // Offset: 0x40 // Size: 0x10
	struct FString RoleGroupName; // Offset: 0x50 // Size: 0x10
	struct FString ReceiverRoleID; // Offset: 0x60 // Size: 0x10
	struct FString ReceiverRoleName; // Offset: 0x70 // Size: 0x10
	int32_t ReceiverRoleLevel; // Offset: 0x80 // Size: 0x04
	int32_t ChatType; // Offset: 0x84 // Size: 0x04
	struct FString ChatContents; // Offset: 0x88 // Size: 0x10
	struct FString UserSign; // Offset: 0x98 // Size: 0x10
	int32_t MsgType; // Offset: 0xa8 // Size: 0x04
	int32_t MsgCharType; // Offset: 0xac // Size: 0x04
	int64_t TotalCash; // Offset: 0xb0 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SecLogin
// Size: 0x108 // Inherited bytes: 0x40
struct FSecLogin : FSecBasic {
	// Fields
	struct FString SystemSoftware; // Offset: 0x40 // Size: 0x10
	struct FString SystemHardware; // Offset: 0x50 // Size: 0x10
	struct FString TelecomOper; // Offset: 0x60 // Size: 0x10
	struct FString Network; // Offset: 0x70 // Size: 0x10
	int32_t RegChannel; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString AndroidId; // Offset: 0x88 // Size: 0x10
	struct FString RealIMEI; // Offset: 0x98 // Size: 0x10
	struct FString Idfv; // Offset: 0xa8 // Size: 0x10
	float RegisterTime; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct FString TotalGameTime; // Offset: 0xc0 // Size: 0x10
	int32_t PlayerFriendsNum; // Offset: 0xd0 // Size: 0x04
	int32_t RoleTotalCash; // Offset: 0xd4 // Size: 0x04
	int64_t CouponNum; // Offset: 0xd8 // Size: 0x08
	int64_t Money1Num; // Offset: 0xe0 // Size: 0x08
	int64_t Money2Num; // Offset: 0xe8 // Size: 0x08
	int64_t Money3Num; // Offset: 0xf0 // Size: 0x08
	int64_t Money4Num; // Offset: 0xf8 // Size: 0x08
	int64_t isNear; // Offset: 0x100 // Size: 0x08
};

// Object Name: ScriptStruct AClient.LegendLoadoutInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FLegendLoadoutInfo {
	// Fields
	int32_t LegendId; // Offset: 0x00 // Size: 0x04
	int32_t LoadoutID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ChooseLegendFlow
// Size: 0xa8 // Inherited bytes: 0x00
struct FChooseLegendFlow {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0xa4]; // Offset: 0x04 // Size: 0xa4
};

// Object Name: ScriptStruct AClient.SequenceTimerData
// Size: 0x18 // Inherited bytes: 0x00
struct FSequenceTimerData {
	// Fields
	float Time; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x14]; // Offset: 0x04 // Size: 0x14
};

// Object Name: ScriptStruct AClient.DrawQualityParams
// Size: 0x10 // Inherited bytes: 0x00
struct FDrawQualityParams {
	// Fields
	struct TArray<struct FDrawQualityParam> Params; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.DrawQualityParam
// Size: 0x18 // Inherited bytes: 0x00
struct FDrawQualityParam {
	// Fields
	struct FString ParamName; // Offset: 0x00 // Size: 0x10
	int32_t ParamValue; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.MirageTutorialRunningData
// Size: 0x28 // Inherited bytes: 0x00
struct FMirageTutorialRunningData {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.UpdateAllAnimDataAssetFidelityTickFunction
// Size: 0x58 // Inherited bytes: 0x50
struct FUpdateAllAnimDataAssetFidelityTickFunction : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SignificanceTickIntervalPolicy
// Size: 0x08 // Inherited bytes: 0x00
struct FSignificanceTickIntervalPolicy {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SignificanceTickIntervalByScreenSizePolicy
// Size: 0x48 // Inherited bytes: 0x08
struct FSignificanceTickIntervalByScreenSizePolicy : FSignificanceTickIntervalPolicy {
	// Fields
	struct FName Tag; // Offset: 0x08 // Size: 0x08
	struct FSignificanceScreenSizeThresholdSettings SignificanceSettingsVisible; // Offset: 0x10 // Size: 0x10
	struct FSignificanceDistanceThresholdSettings SignificanceSettingsInvisible; // Offset: 0x20 // Size: 0x10
	struct FSignificanceTickIntervalSettings SignificanceTickSettings; // Offset: 0x30 // Size: 0x18
};

// Object Name: ScriptStruct AClient.SignificanceTickIntervalSettings
// Size: 0x18 // Inherited bytes: 0x00
struct FSignificanceTickIntervalSettings {
	// Fields
	struct TArray<struct FSignificanceTickInterval> SignificanceTickInterval; // Offset: 0x00 // Size: 0x10
	char PropagateToChildComponent : 1; // Offset: 0x10 // Size: 0x01
	char pad_0x10_1 : 7; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct AClient.SignificanceTickInterval
// Size: 0x08 // Inherited bytes: 0x00
struct FSignificanceTickInterval {
	// Fields
	float Significance; // Offset: 0x00 // Size: 0x04
	float ActorTickInterval; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SignificanceDistanceThresholdSettings
// Size: 0x10 // Inherited bytes: 0x00
struct FSignificanceDistanceThresholdSettings {
	// Fields
	struct TArray<struct FSignificanceDistanceThresholds> SignificanceThresholds; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SignificanceDistanceThresholds
// Size: 0x08 // Inherited bytes: 0x00
struct FSignificanceDistanceThresholds {
	// Fields
	float Significance; // Offset: 0x00 // Size: 0x04
	float MaxDistance; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SignificanceScreenSizeThresholdSettings
// Size: 0x10 // Inherited bytes: 0x00
struct FSignificanceScreenSizeThresholdSettings {
	// Fields
	struct TArray<struct FSignificanceScreenSizeThresholds> SignificanceThresholds; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SignificanceScreenSizeThresholds
// Size: 0x08 // Inherited bytes: 0x00
struct FSignificanceScreenSizeThresholds {
	// Fields
	float Significance; // Offset: 0x00 // Size: 0x04
	float ScreenSize; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SignificanceTickIntervalByDistancePolicy
// Size: 0x48 // Inherited bytes: 0x08
struct FSignificanceTickIntervalByDistancePolicy : FSignificanceTickIntervalPolicy {
	// Fields
	struct FName Tag; // Offset: 0x08 // Size: 0x08
	struct FSignificanceDistanceThresholdSettings SignificanceSettingsVisible; // Offset: 0x10 // Size: 0x10
	struct FSignificanceDistanceThresholdSettings SignificanceSettingsInvisible; // Offset: 0x20 // Size: 0x10
	struct FSignificanceTickIntervalSettings SignificanceTickSettings; // Offset: 0x30 // Size: 0x18
};

// Object Name: ScriptStruct AClient.MsgTipItemData
// Size: 0x10 // Inherited bytes: 0x00
struct FMsgTipItemData {
	// Fields
	struct USimpleMsgBubbleWidget* SubBubbleUI; // Offset: 0x00 // Size: 0x08
	struct FTimerHandle TimerID; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BuffAffectedActorData
// Size: 0x10 // Inherited bytes: 0x00
struct FBuffAffectedActorData {
	// Fields
	struct AActor* BuffActor; // Offset: 0x00 // Size: 0x08
	float DeltaTime; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.CountDownTipItemWithDelegate
// Size: 0x88 // Inherited bytes: 0x00
struct FCountDownTipItemWithDelegate {
	// Fields
	struct FCountDownTipItem Item; // Offset: 0x00 // Size: 0x78
	struct FDelegate UpdateDelegate; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CountDownTipItem
// Size: 0x78 // Inherited bytes: 0x00
struct FCountDownTipItem {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FName Key; // Offset: 0x08 // Size: 0x08
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x10 // Size: 0x08
	struct FText Text1; // Offset: 0x18 // Size: 0x18
	struct FText Text2; // Offset: 0x30 // Size: 0x18
	struct FLinearColor Color; // Offset: 0x48 // Size: 0x10
	float Rate; // Offset: 0x58 // Size: 0x04
	float Duration; // Offset: 0x5c // Size: 0x04
	char pad_0x60[0x10]; // Offset: 0x60 // Size: 0x10
	bool RequireDisplay; // Offset: 0x70 // Size: 0x01
	bool IsShowWarningIcon; // Offset: 0x71 // Size: 0x01
	char pad_0x72[0x2]; // Offset: 0x72 // Size: 0x02
	int32_t HeroID; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillMovementConfig
// Size: 0x14 // Inherited bytes: 0x00
struct FSkillMovementConfig {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x00 // Size: 0x14
};

// Object Name: ScriptStruct AClient.SkillPoseReplaceTPPMontageDataSet
// Size: 0x40 // Inherited bytes: 0x00
struct FSkillPoseReplaceTPPMontageDataSet {
	// Fields
	struct TArray<struct TSoftObjectPtr<UAnimMontage>> AnimMontageSet_Stand; // Offset: 0x00 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimMontage>> AnimMontageSet_Crouch; // Offset: 0x10 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimMontage>> AnimMontageSet_Jump; // Offset: 0x20 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimMontage>> AnimMontageSet_Sprint; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SkillReplicationPolicy
// Size: 0x10 // Inherited bytes: 0x00
struct FSkillReplicationPolicy {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FName Tag; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SkillReplicationCullDistancePolicy
// Size: 0x30 // Inherited bytes: 0x10
struct FSkillReplicationCullDistancePolicy : FSkillReplicationPolicy {
	// Fields
	struct TArray<struct FSkillReplicationBoundsSizeThreshold> ThresholdSettings; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FSkillNetCullDistanceSquaredData> ReplicationSettings; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SkillNetCullDistanceSquaredData
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillNetCullDistanceSquaredData {
	// Fields
	float Significance; // Offset: 0x00 // Size: 0x04
	float NetCullDistanceSquared; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillReplicationBoundsSizeThreshold
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillReplicationBoundsSizeThreshold {
	// Fields
	float Significance; // Offset: 0x00 // Size: 0x04
	float MaxBoundsSize; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillSequenceCmd
// Size: 0x70 // Inherited bytes: 0x00
struct FSkillSequenceCmd {
	// Fields
	struct FSkillSequenceCmdParams Params; // Offset: 0x00 // Size: 0x60
	uint32_t Value; // Offset: 0x60 // Size: 0x04
	enum class ESkillCmdType CmdType; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
	int32_t SkillIndex; // Offset: 0x68 // Size: 0x04
	int32_t FrameSpace; // Offset: 0x6c // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillSequenceCmdParams
// Size: 0x60 // Inherited bytes: 0x00
struct FSkillSequenceCmdParams {
	// Fields
	enum class EUTSkillEventType EventType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t TriggerIndex; // Offset: 0x04 // Size: 0x04
	struct FString AntiData; // Offset: 0x08 // Size: 0x10
	struct FPredictionKey PredictionKey; // Offset: 0x18 // Size: 0x10
	enum class EUTSkillStopReason StopReason; // Offset: 0x28 // Size: 0x01
	bool bCheckEnableBackSwing; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x6]; // Offset: 0x2a // Size: 0x06
	struct FString UAESkillEventString; // Offset: 0x30 // Size: 0x10
	enum class EUAESkillEvent UAESkillEventEnum; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x3]; // Offset: 0x41 // Size: 0x03
	struct FVector ActorLocation; // Offset: 0x44 // Size: 0x0c
	struct FRotator ControllerRotation; // Offset: 0x50 // Size: 0x0c
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillTestCaseParams
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillTestCaseParams {
	// Fields
	enum class ESkillType SkillType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t SkillIndex; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SkillWidgetPool
// Size: 0x10 // Inherited bytes: 0x00
struct FSkillWidgetPool {
	// Fields
	struct TArray<struct UUserWidget*> CacheObjects; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SkillUIInstData
// Size: 0x58 // Inherited bytes: 0x00
struct FSkillUIInstData {
	// Fields
	int32_t PanelIndex; // Offset: 0x00 // Size: 0x04
	int32_t SkillIndex; // Offset: 0x04 // Size: 0x04
	struct FString PanelName; // Offset: 0x08 // Size: 0x10
	struct FString UIDefineType; // Offset: 0x18 // Size: 0x10
	struct USkillUIOperationData* UIOperationData; // Offset: 0x28 // Size: 0x08
	struct UUserWidget* SkillBtnWidget; // Offset: 0x30 // Size: 0x08
	struct UUserWidget* SkillBPWidget; // Offset: 0x38 // Size: 0x08
	struct UUserWidget* CancelBtnBPWidget; // Offset: 0x40 // Size: 0x08
	struct UUserWidget* UndoBtnBPWidget; // Offset: 0x48 // Size: 0x08
	struct UUserWidget* AncillaryBtnUI; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SmoothPathConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FSmoothPathConfig {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct AClient.BankArray
// Size: 0x10 // Inherited bytes: 0x00
struct FBankArray {
	// Fields
	struct TArray<struct TSoftObjectPtr<UAkAudioBank>> Banks; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AnimSyncParams
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimSyncParams {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SubModelNames
// Size: 0x10 // Inherited bytes: 0x00
struct FSubModelNames {
	// Fields
	struct TArray<struct FName> ModelNames; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.TargetPointStruct
// Size: 0x98 // Inherited bytes: 0x00
struct FTargetPointStruct {
	// Fields
	bool bIsShow; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Opacity; // Offset: 0x04 // Size: 0x04
	struct FText TipsText; // Offset: 0x08 // Size: 0x18
	bool bIsShowDistance; // Offset: 0x20 // Size: 0x01
	bool bIsShowTextBG; // Offset: 0x21 // Size: 0x01
	bool bIsShowProgressBar; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x1]; // Offset: 0x23 // Size: 0x01
	float ProgressPercent; // Offset: 0x24 // Size: 0x04
	bool bNeedChangeTexture; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct TSoftObjectPtr<UPaperSprite> BGTexture; // Offset: 0x30 // Size: 0x28
	struct TSoftObjectPtr<UPaperSprite> MainTexture; // Offset: 0x58 // Size: 0x28
	struct FText TopText; // Offset: 0x80 // Size: 0x18
};

// Object Name: ScriptStruct AClient.MemberSetting
// Size: 0x2c // Inherited bytes: 0x00
struct FMemberSetting {
	// Fields
	int32_t LegendId; // Offset: 0x00 // Size: 0x04
	int32_t TeamID; // Offset: 0x04 // Size: 0x04
	int32_t ItemID; // Offset: 0x08 // Size: 0x04
	int32_t CampID; // Offset: 0x0c // Size: 0x04
	int32_t EnemyTeamID; // Offset: 0x10 // Size: 0x04
	struct FVector Location; // Offset: 0x14 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x20 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.TeammateDataInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FTeammateDataInfo {
	// Fields
	int32_t item_id; // Offset: 0x00 // Size: 0x04
	bool is_recommend; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int32_t Weight; // Offset: 0x08 // Size: 0x04
	int32_t Quality; // Offset: 0x0c // Size: 0x04
	int32_t ping_index; // Offset: 0x10 // Size: 0x04
	float create_time; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ThermiteFireDamageUnit
// Size: 0x10 // Inherited bytes: 0x00
struct FThermiteFireDamageUnit {
	// Fields
	struct TWeakObjectPtr<struct AActor> WeakDamageActor; // Offset: 0x00 // Size: 0x08
	float DeltaTime; // Offset: 0x08 // Size: 0x04
	int32_t OverlapNum; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AniSequences
// Size: 0x58 // Inherited bytes: 0x00
struct FAniSequences {
	// Fields
	struct TMap<struct FString, struct FAniSequence> SeqMap; // Offset: 0x00 // Size: 0x50
	bool bLoop; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
};

// Object Name: ScriptStruct AClient.NormalTitileDataSet_TabRes
// Size: 0x30 // Inherited bytes: 0x00
struct FNormalTitileDataSet_TabRes {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t TypeID; // Offset: 0x04 // Size: 0x04
	struct FText TitleName; // Offset: 0x08 // Size: 0x18
	struct TArray<float> ParamList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.LegendTitileDataSet_TabRes
// Size: 0x40 // Inherited bytes: 0x30
struct FLegendTitileDataSet_TabRes : FNormalTitileDataSet_TabRes {
	// Fields
	struct TArray<int32_t> TrackerIDList; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RecordButtonInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FRecordButtonInfo {
	// Fields
	enum class ETouchTakeOverType TakeOverType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct TWeakObjectPtr<struct UWidget> NodeWidget; // Offset: 0x04 // Size: 0x08
};

// Object Name: ScriptStruct AClient.TouchTakeOverArray
// Size: 0x10 // Inherited bytes: 0x00
struct FTouchTakeOverArray {
	// Fields
	struct TArray<struct FTouchTakeOverInfo> DataList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.TownTakeOverBrocastData
// Size: 0x08 // Inherited bytes: 0x00
struct FTownTakeOverBrocastData {
	// Fields
	float BroadCD; // Offset: 0x00 // Size: 0x04
	int32_t EventID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.TownTakeOverSpawnData
// Size: 0x40 // Inherited bytes: 0x00
struct FTownTakeOverSpawnData {
	// Fields
	struct FTransform SpawnTrans; // Offset: 0x00 // Size: 0x30
	struct TArray<struct FVector> TTOZipLineAttachEndOffsets; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.PersonalTrackerData
// Size: 0x140 // Inherited bytes: 0x00
struct FPersonalTrackerData {
	// Fields
	char pad_0x0[0x140]; // Offset: 0x00 // Size: 0x140
};

// Object Name: ScriptStruct AClient.TrackerData
// Size: 0x18 // Inherited bytes: 0x00
struct FTrackerData {
	// Fields
	float Value; // Offset: 0x00 // Size: 0x04
	int32_t TrackerType; // Offset: 0x04 // Size: 0x04
	int32_t LegendId; // Offset: 0x08 // Size: 0x04
	int32_t TrackerParam1; // Offset: 0x0c // Size: 0x04
	int32_t TrackerParam2; // Offset: 0x10 // Size: 0x04
	int32_t TrackerID; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.SignDirectionForTrackInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FSignDirectionForTrackInfo {
	// Fields
	struct FVector ServerWorldLocation; // Offset: 0x00 // Size: 0x0c
	struct FRotator ServerWorldRotator; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct AClient.FootprintInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FFootprintInfo {
	// Fields
	struct UPrimitiveComponent* MovementBase; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x20]; // Offset: 0x08 // Size: 0x20
};

// Object Name: ScriptStruct AClient.TrackingVisionShowInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FTrackingVisionShowInfo {
	// Fields
	struct TSoftObjectPtr<UObject> TrackingVisionIcon; // Offset: 0x00 // Size: 0x28
	int32_t IconIndex; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FText TrackingVisionTip; // Offset: 0x30 // Size: 0x18
	int32_t PingType; // Offset: 0x48 // Size: 0x04
	int32_t PingType2; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct AClient.TrackEvents
// Size: 0x10 // Inherited bytes: 0x00
struct FTrackEvents {
	// Fields
	struct TArray<struct FDelegate> Events; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ChapterInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FChapterInfo {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
};

// Object Name: ScriptStruct AClient.LuaChapterInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FLuaChapterInfo {
	// Fields
	struct UObject* Owner; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x20]; // Offset: 0x08 // Size: 0x20
};

// Object Name: ScriptStruct AClient.TrainSaveData
// Size: 0x18 // Inherited bytes: 0x00
struct FTrainSaveData {
	// Fields
	float Velocity; // Offset: 0x00 // Size: 0x04
	float DistanceToStartPoint; // Offset: 0x04 // Size: 0x04
	float Timestamp; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct AApexRail* Rail; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct AClient.TrainstateConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FTrainstateConfig {
	// Fields
	struct UTrainState* State; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.EmulatorInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FEmulatorInfo {
	// Fields
	bool bEmulator; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString EmulatorName; // Offset: 0x08 // Size: 0x10
	bool bRoot; // Offset: 0x18 // Size: 0x01
	bool bMalware; // Offset: 0x19 // Size: 0x01
	bool bCDN; // Offset: 0x1a // Size: 0x01
	bool bCS; // Offset: 0x1b // Size: 0x01
	bool bPermission; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct AClient.OP_TutorialTaskTotalRecorder
// Size: 0x88 // Inherited bytes: 0x00
struct FOP_TutorialTaskTotalRecorder {
	// Fields
	int32_t HistoryGameCount; // Offset: 0x00 // Size: 0x04
	int32_t HistoryPlayTime; // Offset: 0x04 // Size: 0x04
	int32_t HistoryFireCount; // Offset: 0x08 // Size: 0x04
	int32_t HistoryHitRate; // Offset: 0x0c // Size: 0x04
	int32_t AcceptQuestCount; // Offset: 0x10 // Size: 0x04
	int32_t CompleteQuestCount; // Offset: 0x14 // Size: 0x04
	int32_t LoginCount; // Offset: 0x18 // Size: 0x04
	int32_t IsReview; // Offset: 0x1c // Size: 0x04
	struct FString CostAmmo; // Offset: 0x20 // Size: 0x10
	char pad_0x30[0x58]; // Offset: 0x30 // Size: 0x58
};

// Object Name: ScriptStruct AClient.OP_TutorialTaskSequenceRecorder
// Size: 0x158 // Inherited bytes: 0x88
struct FOP_TutorialTaskSequenceRecorder : FOP_TutorialTaskTotalRecorder {
	// Fields
	struct FString RoleID; // Offset: 0x88 // Size: 0x10
	struct FString dtEventTime; // Offset: 0x98 // Size: 0x10
	struct FString QuestID; // Offset: 0xa8 // Size: 0x10
	int32_t QuestIDInt; // Offset: 0xb8 // Size: 0x04
	int32_t IsFinished; // Offset: 0xbc // Size: 0x04
	int64_t CompletedQuestTiming; // Offset: 0xc0 // Size: 0x08
	int32_t CompletedQuestTime; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
	struct FString CompletedQuestCoordinate; // Offset: 0xd0 // Size: 0x10
	struct FString CompletedQuestPlayerHP; // Offset: 0xe0 // Size: 0x10
	struct FString CompletedQuestPlayerShield; // Offset: 0xf0 // Size: 0x10
	int32_t CompletedQuestCostAmmo; // Offset: 0x100 // Size: 0x04
	int32_t CompletedQuestHitRate; // Offset: 0x104 // Size: 0x04
	char pad_0x108[0x4]; // Offset: 0x108 // Size: 0x04
	int32_t CompletedQuestFireTime; // Offset: 0x10c // Size: 0x04
	int32_t CompletedQuestHitTime; // Offset: 0x110 // Size: 0x04
	int32_t CompletedQuestADSFireTime; // Offset: 0x114 // Size: 0x04
	int32_t CompletedQuestADSHitTime; // Offset: 0x118 // Size: 0x04
	int32_t CompletedQuestClimbTime; // Offset: 0x11c // Size: 0x04
	int32_t CompletedQuestSlideTime; // Offset: 0x120 // Size: 0x04
	char pad_0x124[0x4]; // Offset: 0x124 // Size: 0x04
	struct FString SlidePosition; // Offset: 0x128 // Size: 0x10
	int32_t CurrentSavePointID; // Offset: 0x138 // Size: 0x04
	int32_t CurrentSavePointIDUseCount; // Offset: 0x13c // Size: 0x04
	int32_t IsFinishAllQuest; // Offset: 0x140 // Size: 0x04
	int32_t PlayTime; // Offset: 0x144 // Size: 0x04
	int32_t Perspective; // Offset: 0x148 // Size: 0x04
	int32_t IsSkip; // Offset: 0x14c // Size: 0x04
	int32_t ABTag; // Offset: 0x150 // Size: 0x04
	int32_t RockerState; // Offset: 0x154 // Size: 0x04
};

// Object Name: ScriptStruct AClient.EA_TutorialTaskTotalRecorder
// Size: 0x24 // Inherited bytes: 0x00
struct FEA_TutorialTaskTotalRecorder {
	// Fields
	int32_t TotalTime; // Offset: 0x00 // Size: 0x04
	int32_t TotalFireTimes; // Offset: 0x04 // Size: 0x04
	int32_t TotalHitTimes; // Offset: 0x08 // Size: 0x04
	int32_t TotalADSFireTimes; // Offset: 0x0c // Size: 0x04
	int32_t TotalADSHitTimes; // Offset: 0x10 // Size: 0x04
	int32_t TotalClimbTimes; // Offset: 0x14 // Size: 0x04
	int32_t TotalSlideTimes; // Offset: 0x18 // Size: 0x04
	int32_t TotalUltimateDmgToEnemy; // Offset: 0x1c // Size: 0x04
	int32_t TotalUltimateDmgToSelf; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct AClient.EA_TutorialTaskSequenceRecorder
// Size: 0x118 // Inherited bytes: 0x24
struct FEA_TutorialTaskSequenceRecorder : FEA_TutorialTaskTotalRecorder {
	// Fields
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString RoleID; // Offset: 0x28 // Size: 0x10
	struct FString dtEventTime; // Offset: 0x38 // Size: 0x10
	struct FString QuestID; // Offset: 0x48 // Size: 0x10
	int64_t CompletedQuestTiming; // Offset: 0x58 // Size: 0x08
	int32_t CompletedQuestTime; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FString CompletedQuestCoordinate; // Offset: 0x68 // Size: 0x10
	int32_t IsFinished; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	struct FString QuestAmmo; // Offset: 0x80 // Size: 0x10
	char pad_0x90[0x50]; // Offset: 0x90 // Size: 0x50
	struct FString SlideCoordinate; // Offset: 0xe0 // Size: 0x10
	int32_t FireTimes; // Offset: 0xf0 // Size: 0x04
	int32_t HitTimes; // Offset: 0xf4 // Size: 0x04
	int32_t ADSFireTimes; // Offset: 0xf8 // Size: 0x04
	int32_t ADSHitTimes; // Offset: 0xfc // Size: 0x04
	int32_t ClimbTimes; // Offset: 0x100 // Size: 0x04
	int32_t SlideTimes; // Offset: 0x104 // Size: 0x04
	int32_t UltimateDmgToEnemy; // Offset: 0x108 // Size: 0x04
	int32_t UltimateDmgToSelf; // Offset: 0x10c // Size: 0x04
	int32_t AcceptQuestCount; // Offset: 0x110 // Size: 0x04
	int32_t CompleteQuestCount; // Offset: 0x114 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AnimListMapValueData
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimListMapValueData {
	// Fields
	struct TArray<struct FAnimListData> AnimListMapValue; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.AnimListData
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimListData {
	// Fields
	int32_t LayerID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UAnimationAsset* Animation; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.FeedDistanceToManagerTickFunction
// Size: 0x58 // Inherited bytes: 0x50
struct FFeedDistanceToManagerTickFunction : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.AsyncLoadCharAnimParams
// Size: 0x88 // Inherited bytes: 0x00
struct FAsyncLoadCharAnimParams {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
	struct TMap<int32_t, struct TSoftObjectPtr<UAnimationAsset>> CustomAnimMap; // Offset: 0x28 // Size: 0x50
	char pad_0x78[0x10]; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct AClient.CharacterAnimStartAsynLoadParam
// Size: 0x02 // Inherited bytes: 0x00
struct FCharacterAnimStartAsynLoadParam {
	// Fields
	enum class ECharacterAnimTypeAsynLoaded AnimType; // Offset: 0x00 // Size: 0x01
	enum class ECharacterViewType CharacterViewType; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.CharacterAnimAsynLoadCompleteParam
// Size: 0x48 // Inherited bytes: 0x00
struct FCharacterAnimAsynLoadCompleteParam {
	// Fields
	enum class ECharacterAnimTypeAsynLoaded AnimTypeAsynLoaded; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString AnimsCatorgeryName; // Offset: 0x08 // Size: 0x10
	enum class ECharacterViewType CharacterViewType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct TSoftObjectPtr<UAnimationAsset> SoftPtrAnimation; // Offset: 0x20 // Size: 0x28
};

// Object Name: ScriptStruct AClient.CharacterAsynLoadedTypeAnim
// Size: 0x78 // Inherited bytes: 0x00
struct FCharacterAsynLoadedTypeAnim {
	// Fields
	enum class ECharacterAnimTypeAsynLoaded AnimTypeAsynLoaded; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString AnimsCatorgeryName; // Offset: 0x08 // Size: 0x10
	struct FCharacterAnimTypeAsynLoadedPhaseData Anim; // Offset: 0x18 // Size: 0x60
};

// Object Name: ScriptStruct AClient.CharacterAnimTypeAsynLoadedPhaseData
// Size: 0x60 // Inherited bytes: 0x00
struct FCharacterAnimTypeAsynLoadedPhaseData {
	// Fields
	struct FString PhaseName; // Offset: 0x00 // Size: 0x10
	struct TMap<enum class ECharacterViewType, struct TSoftObjectPtr<UAnimationAsset>> PhaseAnimSoftPtr; // Offset: 0x10 // Size: 0x50
};

// Object Name: ScriptStruct AClient.PlayerVehAnimList
// Size: 0x48 // Inherited bytes: 0x00
struct FPlayerVehAnimList {
	// Fields
	struct UAnimationAsset* IdleAnim; // Offset: 0x00 // Size: 0x08
	struct UAnimationAsset* IdleMotorbikeAnim; // Offset: 0x08 // Size: 0x08
	struct UAnimationAsset* VacateMotorbikeAnim; // Offset: 0x10 // Size: 0x08
	struct UAnimationAsset* LeanOutAnim; // Offset: 0x18 // Size: 0x08
	struct UAnimationAsset* LeanInAnim; // Offset: 0x20 // Size: 0x08
	struct UAnimationAsset* AimAnim; // Offset: 0x28 // Size: 0x08
	struct UAnimationAsset* WeaponIdleAddition; // Offset: 0x30 // Size: 0x08
	struct UAnimationAsset* WeaponAimAddition; // Offset: 0x38 // Size: 0x08
	struct UAnimationAsset* WeaponReloadAddition; // Offset: 0x40 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PlayerAnimData
// Size: 0x10 // Inherited bytes: 0x00
struct FPlayerAnimData {
	// Fields
	struct UAnimationAsset* Animation; // Offset: 0x00 // Size: 0x08
	float Rate; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BPTableItem
// Size: 0x28 // Inherited bytes: 0x00
struct FBPTableItem {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Name; // Offset: 0x08 // Size: 0x10
	struct FString Path; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ServerStartFlyInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FServerStartFlyInfo {
	// Fields
	struct FVector InitLocation; // Offset: 0x00 // Size: 0x0c
	struct FRotator InitRotation; // Offset: 0x0c // Size: 0x0c
	struct FVector InitVelocity; // Offset: 0x18 // Size: 0x0c
	struct FVector FinishLocation; // Offset: 0x24 // Size: 0x0c
	struct FRotator FinishRotation; // Offset: 0x30 // Size: 0x0c
	bool bValid; // Offset: 0x3c // Size: 0x01
	bool HasLaunched; // Offset: 0x3d // Size: 0x01
	char pad_0x3E[0x2]; // Offset: 0x3e // Size: 0x02
};

// Object Name: ScriptStruct AClient.NativeMigrationData
// Size: 0x02 // Inherited bytes: 0x00
struct FNativeMigrationData {
	// Fields
	bool bStartFlyOnThrowGrenadeEvent; // Offset: 0x00 // Size: 0x01
	bool bUnbindEventOnStartFly; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AClient.SkillAction_Add3DWidgetUIData
// Size: 0x70 // Inherited bytes: 0x00
struct FSkillAction_Add3DWidgetUIData {
	// Fields
	struct TSoftClassPtr<UObject> UserWidget; // Offset: 0x00 // Size: 0x28
	struct FName AttachSocket; // Offset: 0x28 // Size: 0x08
	struct FTransform Trans; // Offset: 0x30 // Size: 0x30
	struct FVector2D DrawSize; // Offset: 0x60 // Size: 0x08
	bool bIsHideAfterSkill; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: ScriptStruct AClient.SkillAction_ApexSkillComponentAttachCreateData
// Size: 0x30 // Inherited bytes: 0x00
struct FSkillAction_ApexSkillComponentAttachCreateData {
	// Fields
	struct TSoftClassPtr<UObject> ActorComponentClsTemplate; // Offset: 0x00 // Size: 0x28
	struct UActorComponent* ActorComponentObjTemplate; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SkillAction_AttachActorCreateData
// Size: 0x40 // Inherited bytes: 0x00
struct FSkillAction_AttachActorCreateData {
	// Fields
	struct AActor* ActorTemplate; // Offset: 0x00 // Size: 0x08
	struct FName AttachSocketName; // Offset: 0x08 // Size: 0x08
	struct FVector RelativeLocation; // Offset: 0x10 // Size: 0x0c
	struct FRotator RelativeRotation; // Offset: 0x1c // Size: 0x0c
	bool DestroyAfterSkill; // Offset: 0x28 // Size: 0x01
	bool DestroyAfterPhase; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
	float LifeSpan; // Offset: 0x2c // Size: 0x04
	struct FName AttrTag; // Offset: 0x30 // Size: 0x08
	float PlayRate; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.LegendAttrModifyItemList
// Size: 0x10 // Inherited bytes: 0x00
struct FLegendAttrModifyItemList {
	// Fields
	struct TArray<struct FAttrModifyItem> AttrModifiers; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ConditionActionStatusData
// Size: 0x01 // Inherited bytes: 0x00
struct FConditionActionStatusData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.TestSkillMeleeHurtMontageData
// Size: 0xa0 // Inherited bytes: 0x00
struct FTestSkillMeleeHurtMontageData {
	// Fields
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Forward; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Right; // Offset: 0x28 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Left; // Offset: 0x50 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Backward; // Offset: 0x78 // Size: 0x28
};

// Object Name: ScriptStruct AClient.SkillAction_HideUIData
// Size: 0x28 // Inherited bytes: 0x00
struct FSkillAction_HideUIData {
	// Fields
	struct TSoftClassPtr<UObject> OperaterUI; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.InvisibleEffectStruct
// Size: 0x30 // Inherited bytes: 0x00
struct FInvisibleEffectStruct {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
	struct TArray<struct UMaterialInterface*> CacheMaterialForTpp; // Offset: 0x10 // Size: 0x10
	struct TArray<struct UMaterialInterface*> CacheMaterialForFpp; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.HeroVoiceConfig
// Size: 0xa8 // Inherited bytes: 0x00
struct FHeroVoiceConfig {
	// Fields
	struct TSoftObjectPtr<UAkAudioEvent> VoiceEvent; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UAkAudioEvent> VoiceEventSolo; // Offset: 0x28 // Size: 0x28
	struct TSoftObjectPtr<UAkAudioEvent> VoiceEventTeam; // Offset: 0x50 // Size: 0x28
	struct FString VoiceName; // Offset: 0x78 // Size: 0x10
	struct FString VoiceNameSolo; // Offset: 0x88 // Size: 0x10
	struct FString VoiceNameTeam; // Offset: 0x98 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SAPlayMontageInstanceStruct
// Size: 0xc8 // Inherited bytes: 0x00
struct FSAPlayMontageInstanceStruct {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
	struct UAnimMontage* AnimMontage; // Offset: 0x10 // Size: 0x08
	char pad_0x18[0x48]; // Offset: 0x18 // Size: 0x48
	struct UAnimMontage* AnimMontageTpp; // Offset: 0x60 // Size: 0x08
	struct UAnimMontage* AnimMontageFpp; // Offset: 0x68 // Size: 0x08
	char pad_0x70[0x58]; // Offset: 0x70 // Size: 0x58
};

// Object Name: ScriptStruct AClient.SkillPoseMontageDataSet
// Size: 0x50 // Inherited bytes: 0x00
struct FSkillPoseMontageDataSet {
	// Fields
	struct TArray<struct TSoftObjectPtr<UAnimMontage>> AnimMontageSet_Stand; // Offset: 0x00 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimMontage>> AnimMontageSet_Crouch; // Offset: 0x10 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimMontage>> AnimMontageSet_Sprint; // Offset: 0x20 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimMontage>> AnimMontageSet_Jump; // Offset: 0x30 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimMontage>> AnimMontageSet_Dying; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SkillPoseMontageDataWholeCategory
// Size: 0x3c0 // Inherited bytes: 0x00
struct FSkillPoseMontageDataWholeCategory {
	// Fields
	struct FSkillPoseMontageDataWithSliding PoseMontageData; // Offset: 0x00 // Size: 0xf0
	struct FSkillPoseMontageDataWithSliding FPPPoseMontageData; // Offset: 0xf0 // Size: 0xf0
	struct FSkillPoseMontageDataWithSliding PoseMontageData_Low; // Offset: 0x1e0 // Size: 0xf0
	struct FSkillPoseMontageDataWithSliding FPPPoseMontageData_Low; // Offset: 0x2d0 // Size: 0xf0
};

// Object Name: ScriptStruct AClient.SkillPoseMontageData
// Size: 0xc8 // Inherited bytes: 0x00
struct FSkillPoseMontageData {
	// Fields
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Stand; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Crouch; // Offset: 0x28 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Sprint; // Offset: 0x50 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Jump; // Offset: 0x78 // Size: 0x28
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Dying; // Offset: 0xa0 // Size: 0x28
};

// Object Name: ScriptStruct AClient.SkillPoseMontageDataWithSliding
// Size: 0xf0 // Inherited bytes: 0xc8
struct FSkillPoseMontageDataWithSliding : FSkillPoseMontageData {
	// Fields
	struct TSoftObjectPtr<UAnimMontage> AnimMontage_Slide; // Offset: 0xc8 // Size: 0x28
};

// Object Name: ScriptStruct AClient.HeroAudioConfig
// Size: 0x58 // Inherited bytes: 0x00
struct FHeroAudioConfig {
	// Fields
	enum class ELegendType LegendType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TSoftObjectPtr<UAkAudioEvent> AkEvent_1P; // Offset: 0x08 // Size: 0x28
	struct TSoftObjectPtr<UAkAudioEvent> AkEvent_3P; // Offset: 0x30 // Size: 0x28
};

// Object Name: ScriptStruct AClient.SkillAction_PushToMHStackData
// Size: 0x30 // Inherited bytes: 0x00
struct FSkillAction_PushToMHStackData {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
};

// Object Name: ScriptStruct AClient.SkillReplaceJumpAnimData
// Size: 0x28 // Inherited bytes: 0x00
struct FSkillReplaceJumpAnimData {
	// Fields
	enum class ECharacterJumpType CharacterJumpType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FChararacterJumpAnimData> TPPPoseData; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FChararacterJumpAnimData> FPPPoseAnim; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ChararacterJumpAnimData
// Size: 0x30 // Inherited bytes: 0x00
struct FChararacterJumpAnimData {
	// Fields
	enum class ECharacterJumpPhase JumpPhase; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TSoftObjectPtr<UAnimationAsset> PhaseAnimSoftPtr; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct AClient.SkillReplaceCharAnimData
// Size: 0x48 // Inherited bytes: 0x00
struct FSkillReplaceCharAnimData {
	// Fields
	enum class ECharacterAnimType CharacterAnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct TSoftObjectPtr<UAnimationAsset>> PoseAnimList; // Offset: 0x08 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimationAsset>> FPPPoseAnimList; // Offset: 0x18 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UAnimationAsset>> PoseUnarmedAnimList; // Offset: 0x28 // Size: 0x10
	struct FConditionalReplaceAnimData ConditionalAnimData; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SelectPhase
// Size: 0x10 // Inherited bytes: 0x00
struct FSelectPhase {
	// Fields
	int32_t NewPhaseID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UUAESkillCondition* JumpCondition; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SkillAction_ShowUIData
// Size: 0x28 // Inherited bytes: 0x00
struct FSkillAction_ShowUIData {
	// Fields
	struct TSoftClassPtr<UObject> OperaterUI; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.SkillAction_SpawnActorCreateData
// Size: 0x68 // Inherited bytes: 0x00
struct FSkillAction_SpawnActorCreateData {
	// Fields
	struct AActor* ActorTemplate; // Offset: 0x00 // Size: 0x08
	struct UUTSkillLocationPicker* LocationPicker; // Offset: 0x08 // Size: 0x08
	bool bLocalSpawn; // Offset: 0x10 // Size: 0x01
	bool bClientSpawn; // Offset: 0x11 // Size: 0x01
	bool bKeepActor; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x1]; // Offset: 0x13 // Size: 0x01
	int32_t StorageIndex; // Offset: 0x14 // Size: 0x04
	bool bStorageEvenNotCharacterOwner; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int32_t NumLimit; // Offset: 0x1c // Size: 0x04
	bool bAddToController; // Offset: 0x20 // Size: 0x01
	bool bEnableAttach; // Offset: 0x21 // Size: 0x01
	bool bAttachScreenNode; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x1]; // Offset: 0x23 // Size: 0x01
	struct FName AttachSocketName; // Offset: 0x24 // Size: 0x08
	enum class EAttachmentRule AttachmentRule; // Offset: 0x2c // Size: 0x01
	enum class EAttachmentRule ScaleAttachmentRule; // Offset: 0x2d // Size: 0x01
	char pad_0x2E[0x2]; // Offset: 0x2e // Size: 0x02
	struct FVector OffsetLocation; // Offset: 0x30 // Size: 0x0c
	struct FRotator OffsetRotation; // Offset: 0x3c // Size: 0x0c
	struct FVector OffsetLocation_Server; // Offset: 0x48 // Size: 0x0c
	struct FRotator OffsetRotation_Server; // Offset: 0x54 // Size: 0x0c
	bool bLocationFirst; // Offset: 0x60 // Size: 0x01
	bool bIgnoreParentRotation; // Offset: 0x61 // Size: 0x01
	enum class ESpawnActorCollisionHandlingMethod SpawnActorCollisionHandlingMethod; // Offset: 0x62 // Size: 0x01
	char pad_0x63[0x5]; // Offset: 0x63 // Size: 0x05
};

// Object Name: ScriptStruct AClient.SkillAction_SpawnProjectileCreateData
// Size: 0x40 // Inherited bytes: 0x00
struct FSkillAction_SpawnProjectileCreateData {
	// Fields
	int32_t SpawnCount; // Offset: 0x00 // Size: 0x04
	float TimeInterval; // Offset: 0x04 // Size: 0x04
	float RandomRadius; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct AMissleProjectile* ProjectileTemplate; // Offset: 0x10 // Size: 0x08
	struct FName LaunchSocketName; // Offset: 0x18 // Size: 0x08
	struct FVector LaunchOffsetLocation; // Offset: 0x20 // Size: 0x0c
	struct FRotator LaunchOffsetRotation; // Offset: 0x2c // Size: 0x0c
	float Speed; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.LegendAttrModifyConfigList
// Size: 0x50 // Inherited bytes: 0x00
struct FLegendAttrModifyConfigList {
	// Fields
	struct TMap<struct FString, struct FWeaponAttrModifyConfig> AttrModifyConfigList; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.SkillAttrStateModifiersData
// Size: 0x20 // Inherited bytes: 0x00
struct FSkillAttrStateModifiersData {
	// Fields
	enum class EPawnState State; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FAttrModifyItem> AttrModifiers; // Offset: 0x08 // Size: 0x10
	bool HasEnabled; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct AClient.StimFovCfgAIMData
// Size: 0x44 // Inherited bytes: 0x00
struct FStimFovCfgAIMData {
	// Fields
	enum class ESightType SightType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float sightScale; // Offset: 0x04 // Size: 0x04
	float PhaseOneDuration; // Offset: 0x08 // Size: 0x04
	float PhaseTwoDuration; // Offset: 0x0c // Size: 0x04
	char pad_0x10[0x34]; // Offset: 0x10 // Size: 0x34
};

// Object Name: ScriptStruct AClient.StimSkillAttrStateModifiersData
// Size: 0x30 // Inherited bytes: 0x00
struct FStimSkillAttrStateModifiersData {
	// Fields
	enum class EPawnState State; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString debuffStatus; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FAttrModifyItem> AttrModifiers; // Offset: 0x18 // Size: 0x10
	bool HasEnabled; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct AClient.SkillConfigIDData
// Size: 0x20 // Inherited bytes: 0x00
struct FSkillConfigIDData {
	// Fields
	int32_t SkillConfigId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FSkillFlowData> DataList; // Offset: 0x08 // Size: 0x10
	bool bHasInited; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int32_t UseCount; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.UTSkillPicker_FanCreateData
// Size: 0x38 // Inherited bytes: 0x00
struct FUTSkillPicker_FanCreateData {
	// Fields
	float Radius; // Offset: 0x00 // Size: 0x04
	float Angle; // Offset: 0x04 // Size: 0x04
	struct FVector Offset; // Offset: 0x08 // Size: 0x0c
	bool Random; // Offset: 0x14 // Size: 0x01
	bool PickMinAngleTarget; // Offset: 0x15 // Size: 0x01
	bool IsCheckHeadshot; // Offset: 0x16 // Size: 0x01
	bool IsShowDebugFan; // Offset: 0x17 // Size: 0x01
	struct FColor DebugColor; // Offset: 0x18 // Size: 0x04
	bool NeedAddSingleTrace; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	float SingleTraceLength; // Offset: 0x20 // Size: 0x04
	int32_t ConeLineDensity; // Offset: 0x24 // Size: 0x04
	bool EnableVelModifyRadius; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct UCurveFloat* VelModifyRadiusCurve; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SkillLocPickInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FSkillLocPickInfo {
	// Fields
	bool bIsLocOK; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FVector> PosList; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FVector> RelativePosList; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FRotator> RotList; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FString> StrList; // Offset: 0x38 // Size: 0x10
	struct TArray<struct UPrimitiveComponent*> BaseList; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SkillPreloadData
// Size: 0x30 // Inherited bytes: 0x00
struct FSkillPreloadData {
	// Fields
	struct TSoftObjectPtr<UObject> ObjectPtr; // Offset: 0x00 // Size: 0x28
	enum class ESkillPreloadPlatform MatchPlatform; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct AClient.UAESkillUIStateChangedParams
// Size: 0x04 // Inherited bytes: 0x00
struct FUAESkillUIStateChangedParams {
	// Fields
	bool bIncludeSkillBtnWidget; // Offset: 0x00 // Size: 0x01
	bool bIncludePanelWidget; // Offset: 0x01 // Size: 0x01
	bool bIncludeCancelBtnWidget; // Offset: 0x02 // Size: 0x01
	bool bIncludeUndoBtnWidget; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AClient.UAESkillUIData
// Size: 0x320 // Inherited bytes: 0x00
struct FUAESkillUIData {
	// Fields
	struct FUAESkillUIMode StandardUIMode; // Offset: 0x00 // Size: 0x188
	struct FUAESkillUIMode SimpleUIMode; // Offset: 0x188 // Size: 0x188
	struct FUAESkillGuideTips GuideTipsSetting; // Offset: 0x310 // Size: 0x0c
	char pad_0x31C[0x4]; // Offset: 0x31c // Size: 0x04
};

// Object Name: ScriptStruct AClient.UAESkillGuideTips
// Size: 0x0c // Inherited bytes: 0x00
struct FUAESkillGuideTips {
	// Fields
	float ShowTipsHoldTime; // Offset: 0x00 // Size: 0x04
	float ShowTipsMoveRange; // Offset: 0x04 // Size: 0x04
	enum class ESkillUIBtnStatus ShowTipsStatus; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct AClient.UAESkillUIMode
// Size: 0x188 // Inherited bytes: 0x00
struct FUAESkillUIMode {
	// Fields
	struct FString UIDefineName; // Offset: 0x00 // Size: 0x10
	enum class ESkillUISlot UISlot; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct TSoftClassPtr<UObject> SkillBtnBPTemplate; // Offset: 0x18 // Size: 0x28
	struct TSoftClassPtr<UObject> SkillBtnBPTemplatePlanB; // Offset: 0x40 // Size: 0x28
	struct UUserWidget* SkillBtnBP; // Offset: 0x68 // Size: 0x08
	struct TSoftClassPtr<UObject> AuxiliaryBtnBPTemplate; // Offset: 0x70 // Size: 0x28
	struct TSoftClassPtr<UObject> AuxiliaryBtnBPTemplatePlanB; // Offset: 0x98 // Size: 0x28
	struct UUserWidget* AuxiliaryBtnBP; // Offset: 0xc0 // Size: 0x08
	struct TSoftClassPtr<UObject> SkillBPTemplate; // Offset: 0xc8 // Size: 0x28
	struct TSoftClassPtr<UObject> SkillBPTemplatePlanB; // Offset: 0xf0 // Size: 0x28
	struct UUserWidget* SkillBP; // Offset: 0x118 // Size: 0x08
	struct TSoftClassPtr<UObject> CancelBtnBPTemplate; // Offset: 0x120 // Size: 0x28
	struct UUserWidget* CancelBtnBP; // Offset: 0x148 // Size: 0x08
	struct TSoftClassPtr<UObject> UndoBtnBPTemplate; // Offset: 0x150 // Size: 0x28
	struct UUserWidget* UndoBtnBP; // Offset: 0x178 // Size: 0x08
	struct USkillUIOperationData* UIOperationData; // Offset: 0x180 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PingServerInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FPingServerInfo {
	// Fields
	struct FString ZoneName; // Offset: 0x00 // Size: 0x10
	struct FString ServerName; // Offset: 0x10 // Size: 0x10
	struct FString AddrIP; // Offset: 0x20 // Size: 0x10
	float LastDelayMilliSecond; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<float> delayMilliSecond; // Offset: 0x38 // Size: 0x10
	int32_t NACount; // Offset: 0x48 // Size: 0x04
	bool IsAccess; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
	float curTime; // Offset: 0x50 // Size: 0x04
	float LastReqTime; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct AClient.GameplayInvisibleEffectResourceSet
// Size: 0x02 // Inherited bytes: 0x02
struct FGameplayInvisibleEffectResourceSet : FGameplayResourceSet {
};

// Object Name: ScriptStruct AClient.LeakUIItemInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FLeakUIItemInfo {
	// Fields
	bool bUIHasLuaRef; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString ClassName; // Offset: 0x08 // Size: 0x10
	struct FString FullName; // Offset: 0x18 // Size: 0x10
	struct FString NativeRef; // Offset: 0x28 // Size: 0x10
	struct FString LuaRef; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AClient.OBTeamData
// Size: 0x20 // Inherited bytes: 0x00
struct FOBTeamData {
	// Fields
	uint64_t TeamMateUID; // Offset: 0x00 // Size: 0x08
	int32_t TeamID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct AApexPlayerState*> Teammates; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.UIStateTraceList
// Size: 0x10 // Inherited bytes: 0x00
struct FUIStateTraceList {
	// Fields
	struct TArray<struct TWeakObjectPtr<struct UUserWidget>> TraceList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.UIStateList
// Size: 0x10 // Inherited bytes: 0x00
struct FUIStateList {
	// Fields
	struct TArray<struct FApexUIStateBaseInfo> StateList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApexUIStateBaseInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FApexUIStateBaseInfo {
	// Fields
	struct FName BlueprintNodeName; // Offset: 0x00 // Size: 0x08
	struct FName FuncName; // Offset: 0x08 // Size: 0x08
	bool IgnoreExistState; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct TArray<struct FString> IgnoreSimpleModeIDList; // Offset: 0x18 // Size: 0x10
	bool bInnerEnterShow; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	struct FName StateKey; // Offset: 0x2c // Size: 0x08
	bool FinalVisible; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
};

// Object Name: ScriptStruct AClient.ApexSimulateUIStateInfo
// Size: 0x30 // Inherited bytes: 0x08
struct FApexSimulateUIStateInfo : FTableRowBase {
	// Fields
	struct FName BlueprintNodeName; // Offset: 0x08 // Size: 0x08
	struct FName FuncName; // Offset: 0x10 // Size: 0x08
	float DefaultAlphaValue; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FString> SimpleModeIDList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApexUIStateInfo
// Size: 0x90 // Inherited bytes: 0x08
struct FApexUIStateInfo : FTableRowBase {
	// Fields
	struct TMap<enum class ECharacterUIState, bool> UIStates; // Offset: 0x08 // Size: 0x50
	struct FApexUIStateBaseInfo BaseInfo; // Offset: 0x58 // Size: 0x38
};

// Object Name: ScriptStruct AClient.UnmannedMoveData
// Size: 0x28 // Inherited bytes: 0x00
struct FUnmannedMoveData {
	// Fields
	float Velocity; // Offset: 0x00 // Size: 0x04
	float Distance; // Offset: 0x04 // Size: 0x04
	float Timestamp; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString RailID; // Offset: 0x10 // Size: 0x10
	int32_t RailIndex; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ImpactBeaconFX
// Size: 0x10 // Inherited bytes: 0x00
struct FImpactBeaconFX {
	// Fields
	struct FVector TracePos; // Offset: 0x00 // Size: 0x0c
	bool Explode; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct AClient.MissileLaunchInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FMissileLaunchInfo {
	// Fields
	struct FVector LaunchLocation; // Offset: 0x00 // Size: 0x0c
	struct FVector TargetLocation; // Offset: 0x0c // Size: 0x0c
	struct FVector LaunchVelocityLocal; // Offset: 0x18 // Size: 0x0c
	struct FVector LaunchVelocity; // Offset: 0x24 // Size: 0x0c
	float GravityPhase1; // Offset: 0x30 // Size: 0x04
	float TimePhase1; // Offset: 0x34 // Size: 0x04
	struct FVector SecondLaunchImpulse; // Offset: 0x38 // Size: 0x0c
	float GravityPhase2; // Offset: 0x44 // Size: 0x04
	float DistRatioPhase2; // Offset: 0x48 // Size: 0x04
	float GravityPhase3; // Offset: 0x4c // Size: 0x04
	float TimePhase3; // Offset: 0x50 // Size: 0x04
	float GravityPhaseFinal; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ImpactPointFX
// Size: 0x14 // Inherited bytes: 0x00
struct FImpactPointFX {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x00 // Size: 0x14
};

// Object Name: ScriptStruct AClient.ParticleConfigSkywardDiveStruct
// Size: 0x58 // Inherited bytes: 0x00
struct FParticleConfigSkywardDiveStruct {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> ParticleSystemTemplate; // Offset: 0x00 // Size: 0x28
	struct FName AttachSocketName; // Offset: 0x28 // Size: 0x08
	bool bAutoDestroy; // Offset: 0x30 // Size: 0x01
	enum class EPSCPoolMethod PoolingMethod; // Offset: 0x31 // Size: 0x01
	enum class EAPRenderPass RenderPass; // Offset: 0x32 // Size: 0x01
	char pad_0x33[0x1]; // Offset: 0x33 // Size: 0x01
	struct FVector OffsetLocation; // Offset: 0x34 // Size: 0x0c
	struct FRotator OffsetRotation; // Offset: 0x40 // Size: 0x0c
	enum class EAttachLocation AttachLocation; // Offset: 0x4c // Size: 0x01
	bool bApplyParentFov; // Offset: 0x4d // Size: 0x01
	bool bApplyUIFov; // Offset: 0x4e // Size: 0x01
	bool bApplyParentDither; // Offset: 0x4f // Size: 0x01
	bool bNotCreateForLowGrade; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
};

// Object Name: ScriptStruct AClient.TeamMemberInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FTeamMemberInfo {
	// Fields
	struct AApexCharacter* TeammateChar; // Offset: 0x00 // Size: 0x08
	enum class ECharacterCameraMode CameraMode; // Offset: 0x08 // Size: 0x01
	bool IsCaptain; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	struct TArray<struct TWeakObjectPtr<struct UParticleSystemAsync>> JetFxPSAsyncs; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.VehiclePassengerSetting
// Size: 0x40 // Inherited bytes: 0x00
struct FVehiclePassengerSetting {
	// Fields
	enum class ECharacterOnVehicleType CharacterOnVehicleType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector FPPCameraRootOffset; // Offset: 0x04 // Size: 0x0c
	struct FVector4 VehicleTPPRotationLimit; // Offset: 0x10 // Size: 0x10
	struct FVector4 VehicleFPPRotationLimit; // Offset: 0x20 // Size: 0x10
	struct UCurveVector* Speed2TPPCameraRootOffset; // Offset: 0x30 // Size: 0x08
	struct UCurveFloat* Fov2TPPCameraSpringArmLengthCurve; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ViewAssistInfo
// Size: 0x88 // Inherited bytes: 0x00
struct FViewAssistInfo {
	// Fields
	struct AShootWeapon* TriggerWeapon; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x28]; // Offset: 0x08 // Size: 0x28
	struct UCurveFloat* Speed2SnappingSpeedCurve; // Offset: 0x30 // Size: 0x08
	struct UCurveFloat* Distance2SpeedFactorCurve; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x48]; // Offset: 0x40 // Size: 0x48
};

// Object Name: ScriptStruct AClient.ExtraVisualSoundInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FExtraVisualSoundInfo {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ArcItems
// Size: 0x10 // Inherited bytes: 0x00
struct FArcItems {
	// Fields
	struct TArray<struct UVisualSoundArcItem*> ArcItems; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.EnteredVoidInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FEnteredVoidInfo {
	// Fields
	struct TWeakObjectPtr<struct AApexCharacter> Character; // Offset: 0x00 // Size: 0x08
	bool isEnter; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct AClient.OverlapMoverInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FOverlapMoverInfo {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.VoidMoveSynData
// Size: 0x24 // Inherited bytes: 0x00
struct FVoidMoveSynData {
	// Fields
	int32_t CurPointIndex; // Offset: 0x00 // Size: 0x04
	int32_t NextPointIndex; // Offset: 0x04 // Size: 0x04
	bool bArrive; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FVector BlockLocation; // Offset: 0x0c // Size: 0x0c
	struct FRotator CurRotation; // Offset: 0x18 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.MovePathData
// Size: 0x30 // Inherited bytes: 0x00
struct FMovePathData {
	// Fields
	struct AApexCharacter* TargetCharacter; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FRecordPathNodeData> MovePathList; // Offset: 0x08 // Size: 0x10
	struct AVoidDoorActor* OwnerDoor; // Offset: 0x18 // Size: 0x08
	float PathMoveTime; // Offset: 0x20 // Size: 0x04
	bool bReversal; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	float MinMoveDuration; // Offset: 0x28 // Size: 0x04
	float DirUpdateInterval; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.RecordPathNodeData
// Size: 0x1c // Inherited bytes: 0x00
struct FRecordPathNodeData {
	// Fields
	struct FVector Origin; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	bool WasCrouched; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
};

// Object Name: ScriptStruct AClient.EnteredPylonInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FEnteredPylonInfo {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.WattsonWireCollision
// Size: 0x40 // Inherited bytes: 0x00
struct FWattsonWireCollision {
	// Fields
	struct TArray<struct AActor*> CurActorList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct AActor*> AddActorList; // Offset: 0x10 // Size: 0x10
	struct TArray<struct AActor*> EndActorList; // Offset: 0x20 // Size: 0x10
	struct TArray<struct AActor*> NextFrameEndActorList; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AClient.WaveNpcSetting
// Size: 0x20 // Inherited bytes: 0x00
struct FWaveNpcSetting {
	// Fields
	struct TArray<struct FActiveSetting> ActiveConditions; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FGroupNpcSetting> Groups; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.GroupNpcSetting
// Size: 0x30 // Inherited bytes: 0x00
struct FGroupNpcSetting {
	// Fields
	struct AApexCharacter* Template; // Offset: 0x00 // Size: 0x08
	int32_t Num; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct AActor*> BornLocActors; // Offset: 0x10 // Size: 0x10
	bool Random; // Offset: 0x20 // Size: 0x01
	bool Key; // Offset: 0x21 // Size: 0x01
	char pad_0x22[0x6]; // Offset: 0x22 // Size: 0x06
	struct UApexEntityDispatcher* Dispatcher; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ActiveSetting
// Size: 0x08 // Inherited bytes: 0x00
struct FActiveSetting {
	// Fields
	enum class EActiveType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Value; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.DynamicMatConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FDynamicMatConfig {
	// Fields
	struct TArray<struct UMaterialInstanceDynamic*> DynamicMatList; // Offset: 0x00 // Size: 0x10
	bool bOnlyAimShow; // Offset: 0x10 // Size: 0x01
	bool bOnlyNotEquipShow; // Offset: 0x11 // Size: 0x01
	bool bUpdateDisShow; // Offset: 0x12 // Size: 0x01
	bool bUpdateDirShow; // Offset: 0x13 // Size: 0x01
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct UMeshComponent* MeshComponent; // Offset: 0x18 // Size: 0x08
	struct UWidgetComponent* WidgetComponent; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ViewAssistQuickSnappingConfig
// Size: 0x14 // Inherited bytes: 0x00
struct FViewAssistQuickSnappingConfig {
	// Fields
	char EnableQuickFireSnapping : 1; // Offset: 0x00 // Size: 0x01
	char EnableQuickAimSnapping : 1; // Offset: 0x00 // Size: 0x01
	char EnableQuickPitchSnapping : 1; // Offset: 0x00 // Size: 0x01
	char DebugDrawQuickSnapping : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_4 : 4; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float QuickSnappingCD; // Offset: 0x04 // Size: 0x04
	float QuickSnappingMaxDistance; // Offset: 0x08 // Size: 0x04
	float QuickSnappingTime; // Offset: 0x0c // Size: 0x04
	float QuickSnappingMaxDistance2Reticle; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ViewAssistTickSnappingConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FViewAssistTickSnappingConfig {
	// Fields
	char EnableTickSnapping : 1; // Offset: 0x00 // Size: 0x01
	char EnableTickPitchSnapping : 1; // Offset: 0x00 // Size: 0x01
	char DebugDrawTickSnapping : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_3 : 5; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float TickSnappingMaxDistance2Reticle; // Offset: 0x04 // Size: 0x04
	float TickSnappingMaxDistance; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct UCurveFloat* TickSnappingDistanceFactor; // Offset: 0x10 // Size: 0x08
	float TickSnappingSpeed; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ViewAssistEdgeSnappingConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FViewAssistEdgeSnappingConfig {
	// Fields
	char EnableEdgePushing : 1; // Offset: 0x00 // Size: 0x01
	char EnablePitchEdgePushing : 1; // Offset: 0x00 // Size: 0x01
	char EnableDebugEdgePushing : 1; // Offset: 0x00 // Size: 0x01
	char KeepEdgePushingEvenAttach : 1; // Offset: 0x00 // Size: 0x01
	char bTriggerByLeftScreenInput : 1; // Offset: 0x00 // Size: 0x01
	char bTriggerByRightScreenInput : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_6 : 2; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float EdgePushingRadius; // Offset: 0x04 // Size: 0x04
	float EdgePushingWidth; // Offset: 0x08 // Size: 0x04
	float EdgePushingMaxDistance; // Offset: 0x0c // Size: 0x04
	struct UCurveFloat* EdgePushingDistanceFactor; // Offset: 0x10 // Size: 0x08
	float EdgePushingMinSpeed; // Offset: 0x18 // Size: 0x04
	float BaseEdgePushingSpeed; // Offset: 0x1c // Size: 0x04
	float EdgePushingTime; // Offset: 0x20 // Size: 0x04
	float EdgePushingCD; // Offset: 0x24 // Size: 0x04
	float GamePadTriggerThreshold; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ViewAssistFireSnappingConfig
// Size: 0xd8 // Inherited bytes: 0x00
struct FViewAssistFireSnappingConfig {
	// Fields
	char EnableFireSnapping : 1; // Offset: 0x00 // Size: 0x01
	char EnableFirePitchSnapping : 1; // Offset: 0x00 // Size: 0x01
	char EnableFireSnappingDebug : 1; // Offset: 0x00 // Size: 0x01
	char KeepFireSnappingEvenAttach : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_4 : 4; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float FireSnappingCD; // Offset: 0x04 // Size: 0x04
	struct TMap<enum class ESightType, float> BaseFireSnappingSpeed; // Offset: 0x08 // Size: 0x50
	float NoAimFireSnappingSpeed; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct TMap<enum class ESightType, float> FireSnappingMaxDistance2Reticle; // Offset: 0x60 // Size: 0x50
	float NoAimFireSnappingMaxDistance2Reticle; // Offset: 0xb0 // Size: 0x04
	float MaxFireSnappingDistance; // Offset: 0xb4 // Size: 0x04
	struct UCurveFloat* FireSnappingDistanceFactor; // Offset: 0xb8 // Size: 0x08
	float EnemyCrouchFireSnappingSizeFactor; // Offset: 0xc0 // Size: 0x04
	float EnemyDyingFireSnappingSizeFactor; // Offset: 0xc4 // Size: 0x04
	float FireSnappingTime; // Offset: 0xc8 // Size: 0x04
	char ConsiderEnemySpeed : 1; // Offset: 0xcc // Size: 0x01
	char pad_0xCC_1 : 7; // Offset: 0xcc // Size: 0x01
	char pad_0xCD[0x3]; // Offset: 0xcd // Size: 0x03
	struct UCurveFloat* Speed2SnappingSpeedCurve; // Offset: 0xd0 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ViewAssistAimSnappingConfig
// Size: 0xd8 // Inherited bytes: 0x00
struct FViewAssistAimSnappingConfig {
	// Fields
	char EnableAimSnapping : 1; // Offset: 0x00 // Size: 0x01
	char EnableAimPitchSnapping : 1; // Offset: 0x00 // Size: 0x01
	char EnableAimSnappingDebug : 1; // Offset: 0x00 // Size: 0x01
	char KeepAimSnappingEvenAttach : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_4 : 4; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float AimSnappingCD; // Offset: 0x04 // Size: 0x04
	struct TMap<enum class ESightType, float> BaseAimSnappingSpeed; // Offset: 0x08 // Size: 0x50
	float AimSnappingMaxDistance2Reticle; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct TMap<enum class ESightType, float> AimSnappingSightFactor; // Offset: 0x60 // Size: 0x50
	float MaxAimSnappingDistance; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04
	struct UCurveFloat* AimSnappingDistanceFactor; // Offset: 0xb8 // Size: 0x08
	float EnemyCrouchAimSnappingSizeFactor; // Offset: 0xc0 // Size: 0x04
	float EnemyDyingAimSnappingSizeFactor; // Offset: 0xc4 // Size: 0x04
	float AimSnappingTime; // Offset: 0xc8 // Size: 0x04
	char ConsiderEnemySpeed : 1; // Offset: 0xcc // Size: 0x01
	char pad_0xCC_1 : 7; // Offset: 0xcc // Size: 0x01
	char pad_0xCD[0x3]; // Offset: 0xcd // Size: 0x03
	struct UCurveFloat* Speed2SnappingSpeedCurve; // Offset: 0xd0 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ViewAssistFireViewMoveConfig
// Size: 0x40 // Inherited bytes: 0x00
struct FViewAssistFireViewMoveConfig {
	// Fields
	char EnableFireViewAssist : 1; // Offset: 0x00 // Size: 0x01
	char EnableFireViewAssistDebug : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_2 : 6; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float FireDecelerateRadius; // Offset: 0x04 // Size: 0x04
	float FireAccelerateRadius; // Offset: 0x08 // Size: 0x04
	float FireMaxDistance; // Offset: 0x0c // Size: 0x04
	float FireAccelerateFactor; // Offset: 0x10 // Size: 0x04
	float FireBaseDecelerateSpeed; // Offset: 0x14 // Size: 0x04
	float FireEdgeDecelerateWidth; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct UCurveFloat* FireEdgeDecelerateFactor; // Offset: 0x20 // Size: 0x08
	struct UCurveFloat* FireDistanceFactor; // Offset: 0x28 // Size: 0x08
	struct UCurveFloat* FireDecelerateCurve; // Offset: 0x30 // Size: 0x08
	float FireDecelerateTime; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ViewAssistAimViewMoveConfig
// Size: 0x38 // Inherited bytes: 0x00
struct FViewAssistAimViewMoveConfig {
	// Fields
	char EnableAimViewAssist : 1; // Offset: 0x00 // Size: 0x01
	char EnableAimViewAssistDebug : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_2 : 6; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float AimDecelerateRadius; // Offset: 0x04 // Size: 0x04
	float AimAccelerateRadius; // Offset: 0x08 // Size: 0x04
	float AimMaxDistance; // Offset: 0x0c // Size: 0x04
	float AimEdgeDecelerateWidth; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct UCurveFloat* AimEdgeDecelerateFactor; // Offset: 0x18 // Size: 0x08
	float AimingAccelerateFactor; // Offset: 0x20 // Size: 0x04
	float AimBaseDecelerateSpeed; // Offset: 0x24 // Size: 0x04
	struct UCurveFloat* AimDistanceFactor; // Offset: 0x28 // Size: 0x08
	struct UCurveFloat* AimDecelerateCurve; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ViewAssistViewMoveConfig
// Size: 0x38 // Inherited bytes: 0x00
struct FViewAssistViewMoveConfig {
	// Fields
	char EnableViewAssist : 1; // Offset: 0x00 // Size: 0x01
	char EnableViewAssistDebug : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_2 : 6; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ViewAccelerateRadius; // Offset: 0x04 // Size: 0x04
	float ViewDecelerateRadius; // Offset: 0x08 // Size: 0x04
	float EdgeDecelerateWidth; // Offset: 0x0c // Size: 0x04
	struct UCurveFloat* EdgeDecelerateFactor; // Offset: 0x10 // Size: 0x08
	float MaxDistance; // Offset: 0x18 // Size: 0x04
	float BaseAccelerateSpeed; // Offset: 0x1c // Size: 0x04
	float BaseDecelerateSpeed; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct UCurveFloat* DistanceFactor; // Offset: 0x28 // Size: 0x08
	struct UCurveFloat* DecelerateCurve; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameWeaponAttachPosToSocketOverride
// Size: 0x0c // Inherited bytes: 0x00
struct FApgameWeaponAttachPosToSocketOverride {
	// Fields
	enum class EWeaponAttchSocketPosition Pos; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FName SocketName; // Offset: 0x04 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ReplayWeaponHitRecordData
// Size: 0x20 // Inherited bytes: 0x00
struct FReplayWeaponHitRecordData {
	// Fields
	struct TArray<int32_t> HitBodyNum; // Offset: 0x00 // Size: 0x10
	int32_t FireTotalNum; // Offset: 0x10 // Size: 0x04
	int32_t FireHitNum; // Offset: 0x14 // Size: 0x04
	int32_t WeaponID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.AttachmentData
// Size: 0x20 // Inherited bytes: 0x00
struct FAttachmentData {
	// Fields
	bool bDefaultAttachment; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UBackpackWeaponAttachHandleBase* ItemConfig; // Offset: 0x08 // Size: 0x08
	struct FItemDefineID ItemDefineID; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ApgameChargeConsumeItem
// Size: 0x68 // Inherited bytes: 0x00
struct FApgameChargeConsumeItem {
	// Fields
	struct FItemDefineID Item; // Offset: 0x00 // Size: 0x10
	int32_t ConsumeNum; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TMap<enum class EWeaponOrOwnerCondition, int32_t> Condition2ConsumeNums; // Offset: 0x18 // Size: 0x50
};

// Object Name: ScriptStruct AClient.WeaponReloadStageConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FWeaponReloadStageConfig {
	// Fields
	enum class EWeaponReloadStage ReloadStage; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Time; // Offset: 0x04 // Size: 0x04
	bool bInterraptStore; // Offset: 0x08 // Size: 0x01
	bool bClearClipBullet; // Offset: 0x09 // Size: 0x01
	bool bAddClipBullet; // Offset: 0x0a // Size: 0x01
	char pad_0xB[0x1]; // Offset: 0x0b // Size: 0x01
	int32_t AddBulletNum; // Offset: 0x0c // Size: 0x04
	bool bCirculate; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t CirculationTime; // Offset: 0x14 // Size: 0x04
	bool bInterraptByFire; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float FireInterraptTime; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.CompareEnemyInfo
// Size: 0x01 // Inherited bytes: 0x00
struct FCompareEnemyInfo {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AClient.AutoAimEnemyInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FAutoAimEnemyInfo {
	// Fields
	struct AApexCharacter* EnemyPawn; // Offset: 0x00 // Size: 0x08
	float DisToScreenCenterSq; // Offset: 0x08 // Size: 0x04
	struct FVector WorldLocation; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct AClient.AutoAimingConfig
// Size: 0x7c // Inherited bytes: 0x00
struct FAutoAimingConfig {
	// Fields
	struct FAutoAimingRangeConfig OuterRange; // Offset: 0x00 // Size: 0x3c
	struct FAutoAimingRangeConfig InnerRange; // Offset: 0x3c // Size: 0x3c
	float followTimeMax; // Offset: 0x78 // Size: 0x04
};

// Object Name: ScriptStruct AClient.AutoAimingRangeConfig
// Size: 0x3c // Inherited bytes: 0x00
struct FAutoAimingRangeConfig {
	// Fields
	float Speed; // Offset: 0x00 // Size: 0x04
	float RangeRate; // Offset: 0x04 // Size: 0x04
	float SpeedRate; // Offset: 0x08 // Size: 0x04
	float RangeRateSight; // Offset: 0x0c // Size: 0x04
	float SpeedRateSight; // Offset: 0x10 // Size: 0x04
	float CrouchRate; // Offset: 0x14 // Size: 0x04
	float ProneRate; // Offset: 0x18 // Size: 0x04
	float DyingRate; // Offset: 0x1c // Size: 0x04
	float FreeFallRate; // Offset: 0x20 // Size: 0x04
	float LandingRate; // Offset: 0x24 // Size: 0x04
	float adsorbMaxRange; // Offset: 0x28 // Size: 0x04
	float adsorbMinRange; // Offset: 0x2c // Size: 0x04
	float adsorbMaxAttenuationDis; // Offset: 0x30 // Size: 0x04
	float adsorbMinAttenuationDis; // Offset: 0x34 // Size: 0x04
	float adsorbActiveMinRange; // Offset: 0x38 // Size: 0x04
};

// Object Name: ScriptStruct AClient.RecoilPoseFactor
// Size: 0x20 // Inherited bytes: 0x00
struct FRecoilPoseFactor {
	// Fields
	struct FRecoilFactor4D FactorADS; // Offset: 0x00 // Size: 0x10
	struct FRecoilFactor4D FactorNoADS; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.RecoilFactor4D
// Size: 0x10 // Inherited bytes: 0x00
struct FRecoilFactor4D {
	// Fields
	struct FVector2D RecoilFactor; // Offset: 0x00 // Size: 0x08
	struct FVector2D RandomFactor; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.WeaponAntiCheatConfig
// Size: 0x98 // Inherited bytes: 0x00
struct FWeaponAntiCheatConfig {
	// Fields
	float ShootHeightRatio; // Offset: 0x00 // Size: 0x04
	float ShootRadiusRatio; // Offset: 0x04 // Size: 0x04
	struct UCurveFloat* ShootHalfHeightAlwCurve; // Offset: 0x08 // Size: 0x08
	struct UCurveFloat* ShootRadiusAlwCurve; // Offset: 0x10 // Size: 0x08
	struct UCurveFloat* ShootMoveRatioRTTCurve; // Offset: 0x18 // Size: 0x08
	float HitHeightRatio; // Offset: 0x20 // Size: 0x04
	float HitRadiusRatio; // Offset: 0x24 // Size: 0x04
	struct UCurveFloat* HitHalfHeightAlwCurve; // Offset: 0x28 // Size: 0x08
	struct UCurveFloat* HitRadiusAlwCurve; // Offset: 0x30 // Size: 0x08
	struct UCurveFloat* HitMoveRatioRTTCurve; // Offset: 0x38 // Size: 0x08
	float HeadHitFloorRatio; // Offset: 0x40 // Size: 0x04
	float HeadHitRadiusRatio; // Offset: 0x44 // Size: 0x04
	float BodyHitFloorRatio; // Offset: 0x48 // Size: 0x04
	float BodyHitHeightRatio; // Offset: 0x4c // Size: 0x04
	float BodyHitRadiusRatio; // Offset: 0x50 // Size: 0x04
	float HitPlayerScaleRatio; // Offset: 0x54 // Size: 0x04
	float MoveSpeedScaleRatio; // Offset: 0x58 // Size: 0x04
	float ShootRateCheckMulCoff; // Offset: 0x5c // Size: 0x04
	int32_t ValidBulletNumTolerance; // Offset: 0x60 // Size: 0x04
	float ValidBulletCheckMulCoff; // Offset: 0x64 // Size: 0x04
	float ShootForWardAngle; // Offset: 0x68 // Size: 0x04
	float PlayerForWardAngleFPP; // Offset: 0x6c // Size: 0x04
	float PlayerForWardAngleTPP; // Offset: 0x70 // Size: 0x04
	float ShootForWardDitance; // Offset: 0x74 // Size: 0x04
	int32_t ShootForWardCounts; // Offset: 0x78 // Size: 0x04
	float ShootDistanceRadiusRatio; // Offset: 0x7c // Size: 0x04
	int32_t ShootImpactPointCounts; // Offset: 0x80 // Size: 0x04
	int32_t ShootNoViewMoveCounts; // Offset: 0x84 // Size: 0x04
	float ShootAutoAimAlwAngle; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct UCurveFloat* ShootAutoAimAngleCurve; // Offset: 0x90 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SwitchServerConfirmData
// Size: 0x10 // Inherited bytes: 0x00
struct FSwitchServerConfirmData {
	// Fields
	enum class EWeaponSaveSlot ServerCurrentSlot; // Offset: 0x00 // Size: 0x01
	enum class EWeaponSaveSlot ServerTargetSlot; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	double SwitchTime; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.SwitchClientPredictData
// Size: 0x10 // Inherited bytes: 0x00
struct FSwitchClientPredictData {
	// Fields
	enum class EWeaponSaveSlot CurrentSlot; // Offset: 0x00 // Size: 0x01
	enum class EWeaponSaveSlot TargetSlot; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	double SwitchTime; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.BulletHitPerformData
// Size: 0xc0 // Inherited bytes: 0x00
struct FBulletHitPerformData {
	// Fields
	struct FCanvasIcon2D NormalIcon; // Offset: 0x00 // Size: 0x18
	struct FCanvasIcon2D HeadShootIcon; // Offset: 0x18 // Size: 0x18
	struct UObject* NormalIconObj; // Offset: 0x30 // Size: 0x08
	struct UObject* HeadShootIconObj; // Offset: 0x38 // Size: 0x08
	struct TArray<struct FBulletHitPositionData> PositionList; // Offset: 0x40 // Size: 0x10
	float DefaultShowTime; // Offset: 0x50 // Size: 0x04
	struct FVector2D Offset; // Offset: 0x54 // Size: 0x08
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct TMap<uint32_t, struct FBulletHitData> BulletHitMap; // Offset: 0x60 // Size: 0x50
	struct TArray<uint32_t> RemovedShootIdList; // Offset: 0xb0 // Size: 0x10
};

// Object Name: ScriptStruct AClient.BulletHitData
// Size: 0x68 // Inherited bytes: 0x00
struct FBulletHitData {
	// Fields
	float ShowLeftTime; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<char, bool> PelletHitMap; // Offset: 0x08 // Size: 0x50
	struct FVector2D RandomOffset; // Offset: 0x58 // Size: 0x08
	float AimPercent; // Offset: 0x60 // Size: 0x04
	char AimChargeLevel; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
};

// Object Name: ScriptStruct AClient.BulletHitPositionData
// Size: 0x08 // Inherited bytes: 0x00
struct FBulletHitPositionData {
	// Fields
	float Offset; // Offset: 0x00 // Size: 0x04
	float LogicRotate; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.CanvasIcon2D
// Size: 0x18 // Inherited bytes: 0x00
struct FCanvasIcon2D {
	// Fields
	struct UTexture2D* Texture; // Offset: 0x00 // Size: 0x08
	float U; // Offset: 0x08 // Size: 0x04
	float V; // Offset: 0x0c // Size: 0x04
	float UL; // Offset: 0x10 // Size: 0x04
	float VL; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponCrossHairPerformData
// Size: 0x70 // Inherited bytes: 0x00
struct FWeaponCrossHairPerformData {
	// Fields
	struct TArray<struct FWeaponCrossHairIconData> CrossHair; // Offset: 0x00 // Size: 0x10
	struct FLinearColor CrossHairColor; // Offset: 0x10 // Size: 0x10
	struct TMap<int32_t, struct FShoulderCrossHairConfig> ShoulderCrossHairConfig; // Offset: 0x20 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ShoulderCrossHairConfig
// Size: 0x48 // Inherited bytes: 0x00
struct FShoulderCrossHairConfig {
	// Fields
	int32_t ReplaceIndex; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FWeaponCrossHairIconData ReplaceCrossHair; // Offset: 0x08 // Size: 0x40
};

// Object Name: ScriptStruct AClient.WeaponCrossHairIconData
// Size: 0x40 // Inherited bytes: 0x00
struct FWeaponCrossHairIconData {
	// Fields
	struct FCanvasIcon2D Icon; // Offset: 0x00 // Size: 0x18
	struct UObject* IconObj; // Offset: 0x18 // Size: 0x08
	float Offset; // Offset: 0x20 // Size: 0x04
	float Alpha; // Offset: 0x24 // Size: 0x04
	float IconRotate; // Offset: 0x28 // Size: 0x04
	float LogicRotate; // Offset: 0x2c // Size: 0x04
	struct FVector2D Scale2D; // Offset: 0x30 // Size: 0x08
	bool IsSpreadEnable; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

// Object Name: ScriptStruct AClient.InvincibleHitPerformData
// Size: 0x78 // Inherited bytes: 0x70
struct FInvincibleHitPerformData : FWeaponCrossHairPerformData {
	// Fields
	float ShowTime; // Offset: 0x70 // Size: 0x04
	float LastHitLeftTime; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponCrossHairHitPerformData
// Size: 0xb8 // Inherited bytes: 0x70
struct FWeaponCrossHairHitPerformData : FWeaponCrossHairPerformData {
	// Fields
	float DefaultShowTime; // Offset: 0x70 // Size: 0x04
	float QuickShootInterval; // Offset: 0x74 // Size: 0x04
	float QuickShowTime; // Offset: 0x78 // Size: 0x04
	float DamageStartScale; // Offset: 0x7c // Size: 0x04
	float DamageEndScale; // Offset: 0x80 // Size: 0x04
	float DamageMiddleScale; // Offset: 0x84 // Size: 0x04
	struct FLinearColor HeadShootColor; // Offset: 0x88 // Size: 0x10
	struct FLinearColor KillColor; // Offset: 0x98 // Size: 0x10
	float ShowHitCrosshairLeftTime; // Offset: 0xa8 // Size: 0x04
	float LastHitLeftTime; // Offset: 0xac // Size: 0x04
	float CurDamageScale; // Offset: 0xb0 // Size: 0x04
	bool bQuickShoot; // Offset: 0xb4 // Size: 0x01
	bool bHeadShoot; // Offset: 0xb5 // Size: 0x01
	bool bFatalHit; // Offset: 0xb6 // Size: 0x01
	char pad_0xB7[0x1]; // Offset: 0xb7 // Size: 0x01
};

// Object Name: ScriptStruct AClient.WeaponCrossHairAimChargeConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponCrossHairAimChargeConfig {
	// Fields
	struct FVector2D CrosshairPack; // Offset: 0x00 // Size: 0x08
	struct FLinearColor CrossHairColor; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AClient.MuzzleFxStruct
// Size: 0x40 // Inherited bytes: 0x00
struct FMuzzleFxStruct {
	// Fields
	struct FVector LocalMuzzelFXScale; // Offset: 0x00 // Size: 0x0c
	struct FVector ScopeMuzzelFXScale; // Offset: 0x0c // Size: 0x0c
	struct UCurveFloat* MuzzleFXFOVScaleCurve; // Offset: 0x18 // Size: 0x08
	struct FVector RemoteMuzzelFXScale; // Offset: 0x20 // Size: 0x0c
	struct FFXDistancaScaleStruct RemoteMuzzleFXDistanceScale; // Offset: 0x2c // Size: 0x10
	bool bUseMuzzleLight; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
};

// Object Name: ScriptStruct AClient.FXDistancaScaleStruct
// Size: 0x10 // Inherited bytes: 0x00
struct FFXDistancaScaleStruct {
	// Fields
	float FXStartScaleDistance; // Offset: 0x00 // Size: 0x04
	float FXEndScaleDistance; // Offset: 0x04 // Size: 0x04
	float FXStartScaleValue; // Offset: 0x08 // Size: 0x04
	float FXEndScaleValue; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponComponentOptimizationSettings
// Size: 0x0a // Inherited bytes: 0x00
struct FWeaponComponentOptimizationSettings {
	// Fields
	struct FWeaponComConfig Hold; // Offset: 0x00 // Size: 0x05
	struct FWeaponComConfig Back; // Offset: 0x05 // Size: 0x05
};

// Object Name: ScriptStruct AClient.WeaponComConfig
// Size: 0x05 // Inherited bytes: 0x00
struct FWeaponComConfig {
	// Fields
	bool Tick_Authority; // Offset: 0x00 // Size: 0x01
	bool Tick_AI; // Offset: 0x01 // Size: 0x01
	bool Tick_Autonomous; // Offset: 0x02 // Size: 0x01
	bool Tick_Simulated; // Offset: 0x03 // Size: 0x01
	bool Tick_OBSimulated; // Offset: 0x04 // Size: 0x01
};

// Object Name: ScriptStruct AClient.ScopeZeroPointConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FScopeZeroPointConfig {
	// Fields
	int32_t ScopeItemID; // Offset: 0x00 // Size: 0x04
	int32_t ScopeSight; // Offset: 0x04 // Size: 0x04
	struct TArray<float> ZeroPointDistanceArray; // Offset: 0x08 // Size: 0x10
	struct TArray<float> ZeroPointUIBiasArray; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AClient.SpecificWeaponSoundConfig
// Size: 0xa8 // Inherited bytes: 0x00
struct FSpecificWeaponSoundConfig {
	// Fields
	enum class EWeaponFireMode FireMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t AttachmentID; // Offset: 0x04 // Size: 0x04
	struct TMap<enum class EWeaponAction, struct UAkAudioEvent*> SoundDataMap; // Offset: 0x08 // Size: 0x50
	struct TMap<enum class EWeaponAction, struct UAkAudioEvent*> SoundDataMap_3P; // Offset: 0x58 // Size: 0x50
};

// Object Name: ScriptStruct AClient.SpecificBulletEffectConfig
// Size: 0x120 // Inherited bytes: 0x00
struct FSpecificBulletEffectConfig {
	// Fields
	enum class EWeaponFireMode FireMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t AttachmentID; // Offset: 0x04 // Size: 0x04
	struct FBulletEffectConfig EffectConfig; // Offset: 0x08 // Size: 0x118
};

// Object Name: ScriptStruct AClient.BulletEffectConfig
// Size: 0x118 // Inherited bytes: 0x00
struct FBulletEffectConfig {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> NormalTailFx1P; // Offset: 0x00 // Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> ChargeTailFx1P; // Offset: 0x28 // Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> BeamTailFx3P; // Offset: 0x50 // Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> LensTail1P; // Offset: 0x78 // Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> LensTail3P; // Offset: 0xa0 // Size: 0x28
	struct TSoftObjectPtr<UHitEffectDataAsset> DefaultHitEffects; // Offset: 0xc8 // Size: 0x28
	struct TSoftObjectPtr<UHitEffectDataAsset> SpecialHitEffects; // Offset: 0xf0 // Size: 0x28
};

// Object Name: ScriptStruct AClient.MainBoneMaterialEffect
// Size: 0x20 // Inherited bytes: 0x00
struct FMainBoneMaterialEffect {
	// Fields
	struct FString EffectName; // Offset: 0x00 // Size: 0x10
	struct FName MaterialParam; // Offset: 0x10 // Size: 0x08
	enum class EWeaponFrameEffectEvent MainEvent; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct AClient.FrameAudioEffect
// Size: 0x58 // Inherited bytes: 0x00
struct FFrameAudioEffect {
	// Fields
	enum class EWeaponFrameEffectEvent TriggerEvent; // Offset: 0x00 // Size: 0x01
	enum class EWeaponFrameAudioEventType EffectType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct TMap<struct FName, struct FString> Param2Detail; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct AClient.FrameParticleEffect
// Size: 0xc0 // Inherited bytes: 0x00
struct FFrameParticleEffect {
	// Fields
	struct FString EffectName; // Offset: 0x00 // Size: 0x10
	struct TSoftObjectPtr<UParticleSystem> ParticleFPP; // Offset: 0x10 // Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> ParticleFPPADS; // Offset: 0x38 // Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> ParticleTPPSelf; // Offset: 0x60 // Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> ParticleTPPOther; // Offset: 0x88 // Size: 0x28
	struct FName AttachSocket; // Offset: 0xb0 // Size: 0x08
	enum class EWeaponFrameEffectEvent ParticleEvent; // Offset: 0xb8 // Size: 0x01
	bool StopWhenEventLeave; // Offset: 0xb9 // Size: 0x01
	char pad_0xBA[0x6]; // Offset: 0xba // Size: 0x06
};

// Object Name: ScriptStruct AClient.FrameStaticEffect
// Size: 0xf8 // Inherited bytes: 0x00
struct FFrameStaticEffect {
	// Fields
	struct FString EffectName; // Offset: 0x00 // Size: 0x10
	struct TSoftObjectPtr<UStaticMesh> StaticMeshPathFPP; // Offset: 0x10 // Size: 0x28
	struct TSoftObjectPtr<UStaticMesh> StaticMeshPathTPP; // Offset: 0x38 // Size: 0x28
	struct FName AttachSocket; // Offset: 0x60 // Size: 0x08
	struct TArray<struct FName> MaterialValues; // Offset: 0x68 // Size: 0x10
	enum class EWeaponFrameEffectEvent EffectEvent; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x7]; // Offset: 0x79 // Size: 0x07
	struct TMap<enum class EWeaponFrameEffectEvent, struct FFrameMeshEffectEventContent> EventContents; // Offset: 0x80 // Size: 0x50
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> OverrideMaterialsFPP; // Offset: 0xd0 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> OverrideMaterialsTPP; // Offset: 0xe0 // Size: 0x10
	bool HideWhenEventLeave; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x7]; // Offset: 0xf1 // Size: 0x07
};

// Object Name: ScriptStruct AClient.FrameMeshEffectEventContent
// Size: 0x20 // Inherited bytes: 0x00
struct FFrameMeshEffectEventContent {
	// Fields
	struct TArray<struct FName> DynamicMaterialParameterNames; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FFrameMeshEffect> StaticMaterialParameters; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.FrameMeshEffect
// Size: 0xa0 // Inherited bytes: 0x00
struct FFrameMeshEffect {
	// Fields
	struct TMap<struct FName, float> StaticScalarMaterialParameters; // Offset: 0x00 // Size: 0x50
	struct TMap<struct FName, struct FVector> StaticVectorMaterialParameters; // Offset: 0x50 // Size: 0x50
};

// Object Name: ScriptStruct AClient.WeaponFireModeInfo
// Size: 0x3c // Inherited bytes: 0x00
struct FWeaponFireModeInfo {
	// Fields
	enum class EWeaponFireMode FireMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FName BallisticName; // Offset: 0x04 // Size: 0x08
	float ShootInterval; // Offset: 0x0c // Size: 0x04
	int32_t ShootMultiMax; // Offset: 0x10 // Size: 0x04
	int32_t ShootBullets; // Offset: 0x14 // Size: 0x04
	float FireInterval; // Offset: 0x18 // Size: 0x04
	float LensInterval; // Offset: 0x1c // Size: 0x04
	float FinalShootInterval; // Offset: 0x20 // Size: 0x04
	float LinkInterval; // Offset: 0x24 // Size: 0x04
	bool bCanLinkFire; // Offset: 0x28 // Size: 0x01
	bool bCanAutoAimShoot; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
	float AutoAimShootWaitTime; // Offset: 0x2c // Size: 0x04
	float DoubleClickInterval; // Offset: 0x30 // Size: 0x04
	bool bCanSingleAimShoot; // Offset: 0x34 // Size: 0x01
	bool bCanShotgunReleaseShoot; // Offset: 0x35 // Size: 0x01
	char pad_0x36[0x2]; // Offset: 0x36 // Size: 0x02
	int32_t UnlockItemID; // Offset: 0x38 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponHitPartCoff
// Size: 0x20 // Inherited bytes: 0x00
struct FWeaponHitPartCoff {
	// Fields
	float Base_ChargeBullet; // Offset: 0x00 // Size: 0x04
	float head; // Offset: 0x04 // Size: 0x04
	float Head_SkullPiercer; // Offset: 0x08 // Size: 0x04
	float Head_ChargeBullet; // Offset: 0x0c // Size: 0x04
	float Body; // Offset: 0x10 // Size: 0x04
	float Body_ChargeBullet; // Offset: 0x14 // Size: 0x04
	float Thighs; // Offset: 0x18 // Size: 0x04
	float Thighs_ChargeBullet; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BulletHitDamageSimulateInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FBulletHitDamageSimulateInfo {
	// Fields
	float HPstart; // Offset: 0x00 // Size: 0x04
	float HPEnd; // Offset: 0x04 // Size: 0x04
	float ShieldStart; // Offset: 0x08 // Size: 0x04
	float ShieldEnd; // Offset: 0x0c // Size: 0x04
	float BulletDamageBuff; // Offset: 0x10 // Size: 0x04
	float BulletDamageDebuff; // Offset: 0x14 // Size: 0x04
	bool bIsFatalHealth; // Offset: 0x18 // Size: 0x01
	bool bIsHitShield; // Offset: 0x19 // Size: 0x01
	bool bIsBreakShield; // Offset: 0x1a // Size: 0x01
	bool bCanTakeDamage; // Offset: 0x1b // Size: 0x01
	float RangeReviseFactor; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AClient.SDeviation
// Size: 0x30 // Inherited bytes: 0x00
struct FSDeviation {
	// Fields
	float DeviationBase; // Offset: 0x00 // Size: 0x04
	float DeviationShoulderShoot; // Offset: 0x04 // Size: 0x04
	float ShoulderShootFixFactor; // Offset: 0x08 // Size: 0x04
	float DeviationShootGain; // Offset: 0x0c // Size: 0x04
	float DeviationShootFall; // Offset: 0x10 // Size: 0x04
	float DeviationShootFactor; // Offset: 0x14 // Size: 0x04
	float DeviationShootMax; // Offset: 0x18 // Size: 0x04
	float DeviationMaxMove; // Offset: 0x1c // Size: 0x04
	float DeviationMoveMultiplier; // Offset: 0x20 // Size: 0x04
	float DeviationStanceStand; // Offset: 0x24 // Size: 0x04
	float DeviationStanceCrouch; // Offset: 0x28 // Size: 0x04
	float DeviationStanceJump; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AClient.BulletReadyData
// Size: 0x50 // Inherited bytes: 0x00
struct FBulletReadyData {
	// Fields
	struct FTransform TargetPosInfo; // Offset: 0x00 // Size: 0x30
	uint32_t ShootID; // Offset: 0x30 // Size: 0x04
	char PelletID; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	struct FVector EffectBulletEnd; // Offset: 0x38 // Size: 0x0c
	bool bTraceEfficient; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0xb]; // Offset: 0x45 // Size: 0x0b
};

// Object Name: ScriptStruct AClient.FireRecordInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FFireRecordInfo {
	// Fields
	float AimingChargeValue; // Offset: 0x00 // Size: 0x04
	bool bHasCharge; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct AClient.WeaponImportStateData
// Size: 0x08 // Inherited bytes: 0x00
struct FWeaponImportStateData {
	// Fields
	enum class EFreshWeaponStateType StateType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t StateIndex; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.WeaponFrameEffectParticleComp
// Size: 0x10 // Inherited bytes: 0x00
struct FWeaponFrameEffectParticleComp {
	// Fields
	struct UParticleSystemComponent* ParticleSysCompFpp; // Offset: 0x00 // Size: 0x08
	struct UParticleSystemComponent* ParticleSysCompTpp; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ApgameWeaponAttachmentSkinResources
// Size: 0x38 // Inherited bytes: 0x08
struct FApgameWeaponAttachmentSkinResources : FApgameSkinMemMgrSkinResources {
	// Fields
	char pad_0x8[0x30]; // Offset: 0x08 // Size: 0x30
};

// Object Name: ScriptStruct AClient.ApgameWeaponSkinResources
// Size: 0xc0 // Inherited bytes: 0x08
struct FApgameWeaponSkinResources : FApgameSkinMemMgrSkinResources {
	// Fields
	char pad_0x8[0xb8]; // Offset: 0x08 // Size: 0xb8
};

// Object Name: ScriptStruct AClient.ApgameOneHandWeaponSkinResources
// Size: 0x58 // Inherited bytes: 0x00
struct FApgameOneHandWeaponSkinResources {
	// Fields
	char pad_0x0[0x58]; // Offset: 0x00 // Size: 0x58
};

// Object Name: ScriptStruct AClient.WeekChallengeLevelSettings
// Size: 0x30 // Inherited bytes: 0x00
struct FWeekChallengeLevelSettings {
	// Fields
	struct FName SubLevelName; // Offset: 0x00 // Size: 0x08
	struct TSoftClassPtr<UObject> WeekChallengeDefine; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct AClient.UseAngleConfigData
// Size: 0x08 // Inherited bytes: 0x00
struct FUseAngleConfigData {
	// Fields
	float StartAngle; // Offset: 0x00 // Size: 0x04
	float EndAngle; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ReplicatingRepStateData
// Size: 0x08 // Inherited bytes: 0x00
struct FReplicatingRepStateData {
	// Fields
	enum class EReplicatingState State; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t Level; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ReplicatorUIItemData
// Size: 0x90 // Inherited bytes: 0x00
struct FReplicatorUIItemData {
	// Fields
	enum class EReplicateType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FText DaliyName; // Offset: 0x08 // Size: 0x18
	bool bHaveSingle; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	struct FName IconPath; // Offset: 0x24 // Size: 0x08
	int32_t ItemNum; // Offset: 0x2c // Size: 0x04
	int32_t ItemQuality; // Offset: 0x30 // Size: 0x04
	int32_t ItemID; // Offset: 0x34 // Size: 0x04
	bool bHaveDouble; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	struct FName IconPath2; // Offset: 0x3c // Size: 0x08
	int32_t ItemNum2; // Offset: 0x44 // Size: 0x04
	int32_t ItemQuality2; // Offset: 0x48 // Size: 0x04
	int32_t ItemID2; // Offset: 0x4c // Size: 0x04
	int32_t CostNum; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FText ItemName; // Offset: 0x58 // Size: 0x18
	struct FText ItemDetail; // Offset: 0x70 // Size: 0x18
	bool IsRecommend; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x7]; // Offset: 0x89 // Size: 0x07
};

// Object Name: ScriptStruct AClient.ControllerMappingRuntimeArray
// Size: 0x10 // Inherited bytes: 0x00
struct FControllerMappingRuntimeArray {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ControllerMappingRuntimeInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FControllerMappingRuntimeInfo {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x00 // Size: 0x14
};

// Object Name: ScriptStruct AClient.ControllerMappingKeysInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FControllerMappingKeysInfo {
	// Fields
	enum class EControllerMappingPriority UIPriority; // Offset: 0x00 // Size: 0x01
	bool BlockAllLowerPriority; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct TMap<enum class EGamepadKeyType, struct FName> Keys2FunctionName; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ActorRuntimeParticleInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FActorRuntimeParticleInfo {
	// Fields
	struct TMap<enum class EParachuteEffectType, struct UParticleSystemComponent*> Type2Component; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ActorParticleInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FActorParticleInfo {
	// Fields
	struct TMap<int32_t, struct UParticleEffectBase*> MapEffect2ParticleEffectObject; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AClient.ParachuteStateCameraEffectCfg
// Size: 0x40 // Inherited bytes: 0x00
struct FParachuteStateCameraEffectCfg {
	// Fields
	struct FParachuteCameraSpringArmCfg Normal; // Offset: 0x00 // Size: 0x14
	struct FParachuteCameraSpringArmCfg Acc; // Offset: 0x14 // Size: 0x14
	struct UCameraShake* ParachuteCameraShake; // Offset: 0x28 // Size: 0x08
	float NearClippingPlane; // Offset: 0x30 // Size: 0x04
	bool EnableCameraLag; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	float CameraLagSpeed; // Offset: 0x38 // Size: 0x04
	float CameraLagMaxDistance; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ParachuteCameraSpringArmCfg
// Size: 0x14 // Inherited bytes: 0x00
struct FParachuteCameraSpringArmCfg {
	// Fields
	float TargetArmLength; // Offset: 0x00 // Size: 0x04
	bool bLerpFormCurArmLength; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	float StartArmLength; // Offset: 0x08 // Size: 0x04
	float ArmLengthLerpDuration; // Offset: 0x0c // Size: 0x04
	float ExpressionButtonShowTime; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ParachuteInputConfig
// Size: 0x78 // Inherited bytes: 0x00
struct FParachuteInputConfig {
	// Fields
	float InputTriggerThreshold; // Offset: 0x00 // Size: 0x04
	float DefaultInitSpeed; // Offset: 0x04 // Size: 0x04
	float SpeedModifier; // Offset: 0x08 // Size: 0x04
	float AcceModifier; // Offset: 0x0c // Size: 0x04
	float MaxPitchForwardAngle; // Offset: 0x10 // Size: 0x04
	float MaxPitchBackAngle; // Offset: 0x14 // Size: 0x04
	float RotationYawSpeed; // Offset: 0x18 // Size: 0x04
	float RotationPitchSpeed; // Offset: 0x1c // Size: 0x04
	struct FVector2D AutoDiveSpeedRange; // Offset: 0x20 // Size: 0x08
	struct FVector2D SpeedPitchAngleRange; // Offset: 0x28 // Size: 0x08
	struct UCurveFloat* SpeedPct2CapableSmallestSpeedPitchAngleCurve; // Offset: 0x30 // Size: 0x08
	struct FVector2D SpeedRange; // Offset: 0x38 // Size: 0x08
	struct UCurveFloat* DiveRate2TargetSpeedCurve; // Offset: 0x40 // Size: 0x08
	float Speed_LeftRight; // Offset: 0x48 // Size: 0x04
	float JetForceFactor; // Offset: 0x4c // Size: 0x04
	struct UCurveFloat* JetForceCurve; // Offset: 0x50 // Size: 0x08
	float DragFactor; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct UCurveFloat* DragCurve; // Offset: 0x60 // Size: 0x08
	float Acce_LeftRight; // Offset: 0x68 // Size: 0x04
	float DragAcceExtra_Backforward; // Offset: 0x6c // Size: 0x04
	float Lerp2CorrectPosSpeed; // Offset: 0x70 // Size: 0x04
	float Lerp2CorrectQuatSpeed; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ParachuteStartInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FParachuteStartInfo {
	// Fields
	char bIsStartOrStop : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_1 : 7; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<int32_t> ParachuteTeamPlayerKeys; // Offset: 0x08 // Size: 0x10
	enum class EParachuteTriggerReason ParachuteReason; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct AClient.TriggerHintItem
// Size: 0x40 // Inherited bytes: 0x00
struct FTriggerHintItem {
	// Fields
	struct TSoftObjectPtr<UAkAudioEvent> AudioEvent; // Offset: 0x00 // Size: 0x28
	struct FText Tip; // Offset: 0x28 // Size: 0x18
};

// Object Name: ScriptStruct AClient.ZiplineIndexDist
// Size: 0x08 // Inherited bytes: 0x00
struct FZiplineIndexDist {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ZiplineBatchData
// Size: 0x28 // Inherited bytes: 0x00
struct FZiplineBatchData {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AClient.ZiplineElevatorInfo
// Size: 0x24 // Inherited bytes: 0x00
struct FZiplineElevatorInfo {
	// Fields
	float AutoDownT; // Offset: 0x00 // Size: 0x04
	float DeltaRadius; // Offset: 0x04 // Size: 0x04
	struct FZiplineDownInfo DownInfo; // Offset: 0x08 // Size: 0x1c
};

// Object Name: ScriptStruct AClient.ZiplineDownInfo
// Size: 0x1c // Inherited bytes: 0x00
struct FZiplineDownInfo {
	// Fields
	enum class EZiplineDownPreset DownPreset; // Offset: 0x00 // Size: 0x01
	bool bMaintainSlideVel; // Offset: 0x01 // Size: 0x01
	bool bLimitSlideVel; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	float MaxSlideVel; // Offset: 0x04 // Size: 0x04
	enum class EZiplineDirH HorizonDirType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float ConstYaw; // Offset: 0x0c // Size: 0x04
	float HorizonVel; // Offset: 0x10 // Size: 0x04
	bool bJumpOnly; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	float VelZ; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ZiplineTipInfo
// Size: 0x24 // Inherited bytes: 0x00
struct FZiplineTipInfo {
	// Fields
	float AutoDownDist; // Offset: 0x00 // Size: 0x04
	float AutoDirDist; // Offset: 0x04 // Size: 0x04
	struct FZiplineDownInfo DownInfo; // Offset: 0x08 // Size: 0x1c
};

// Object Name: ScriptStruct AClient.ZiplineBasePlayerInfo
// Size: 0x80 // Inherited bytes: 0x00
struct FZiplineBasePlayerInfo {
	// Fields
	struct AApexCharacterBase* Player; // Offset: 0x00 // Size: 0x08
	float LengthT; // Offset: 0x08 // Size: 0x04
	float RideTime; // Offset: 0x0c // Size: 0x04
	float VelValue; // Offset: 0x10 // Size: 0x04
	struct FVector StartPos; // Offset: 0x14 // Size: 0x0c
	struct FRotator StartRot; // Offset: 0x20 // Size: 0x0c
	struct FVector EndPos; // Offset: 0x2c // Size: 0x0c
	struct FRotator EndRot; // Offset: 0x38 // Size: 0x0c
	bool bToEnd; // Offset: 0x44 // Size: 0x01
	bool bIsOver; // Offset: 0x45 // Size: 0x01
	bool bNeedFirstJump; // Offset: 0x46 // Size: 0x01
	bool bNeedSetView; // Offset: 0x47 // Size: 0x01
	struct FVector CurVelocity; // Offset: 0x48 // Size: 0x0c
	struct FVector LastPos; // Offset: 0x54 // Size: 0x0c
	bool bHasReachZipline; // Offset: 0x60 // Size: 0x01
	bool bNeedPlayRushAudio; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x2]; // Offset: 0x62 // Size: 0x02
	int32_t Index; // Offset: 0x64 // Size: 0x04
	bool bIsFinish; // Offset: 0x68 // Size: 0x01
	bool bBlockDown; // Offset: 0x69 // Size: 0x01
	bool bBlockMaintainSpeed; // Offset: 0x6a // Size: 0x01
	char pad_0x6B[0x1]; // Offset: 0x6b // Size: 0x01
	float BlockUpperZ; // Offset: 0x6c // Size: 0x04
	float ViewTurnValue; // Offset: 0x70 // Size: 0x04
	float AIDownT; // Offset: 0x74 // Size: 0x04
	float NowT; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct AClient.ZiplinePlayerInfo
// Size: 0x88 // Inherited bytes: 0x00
struct FZiplinePlayerInfo {
	// Fields
	struct AApexCharacter* Player; // Offset: 0x00 // Size: 0x08
	float LengthT; // Offset: 0x08 // Size: 0x04
	float RideTime; // Offset: 0x0c // Size: 0x04
	float VelValue; // Offset: 0x10 // Size: 0x04
	struct FVector StartPos; // Offset: 0x14 // Size: 0x0c
	struct FRotator StartRot; // Offset: 0x20 // Size: 0x0c
	struct FVector EndPos; // Offset: 0x2c // Size: 0x0c
	struct FRotator EndRot; // Offset: 0x38 // Size: 0x0c
	bool bToEnd; // Offset: 0x44 // Size: 0x01
	bool bIsOver; // Offset: 0x45 // Size: 0x01
	bool bNeedFirstJump; // Offset: 0x46 // Size: 0x01
	bool bNeedSetView; // Offset: 0x47 // Size: 0x01
	struct FVector CurVelocity; // Offset: 0x48 // Size: 0x0c
	struct FVector LastPos; // Offset: 0x54 // Size: 0x0c
	bool bHasReachZipline; // Offset: 0x60 // Size: 0x01
	bool bNeedPlayRushAudio; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x2]; // Offset: 0x62 // Size: 0x02
	int32_t Index; // Offset: 0x64 // Size: 0x04
	bool bIsFinish; // Offset: 0x68 // Size: 0x01
	bool bBlockDown; // Offset: 0x69 // Size: 0x01
	bool bBlockMaintainSpeed; // Offset: 0x6a // Size: 0x01
	char pad_0x6B[0x1]; // Offset: 0x6b // Size: 0x01
	float BlockUpperZ; // Offset: 0x6c // Size: 0x04
	float ViewTurnValue; // Offset: 0x70 // Size: 0x04
	float AIDownT; // Offset: 0x74 // Size: 0x04
	float NowT; // Offset: 0x78 // Size: 0x04
	float BetweenSpaceOffset; // Offset: 0x7c // Size: 0x04
	float RideTimeCopy; // Offset: 0x80 // Size: 0x04
	float ServerTime; // Offset: 0x84 // Size: 0x04
};

// Object Name: ScriptStruct AClient.ZiplinePoint
// Size: 0x30 // Inherited bytes: 0x00
struct FZiplinePoint {
	// Fields
	struct FVector Position; // Offset: 0x00 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x0c // Size: 0x0c
	struct FVector Accelerate; // Offset: 0x18 // Size: 0x0c
	struct FVector OldPosition; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct AClient.ZiplineGunPredictionActorLaunchData
// Size: 0x60 // Inherited bytes: 0x00
struct FZiplineGunPredictionActorLaunchData {
	// Fields
	bool bLaunched; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector NearLoc; // Offset: 0x04 // Size: 0x0c
	struct FVector FarLoc; // Offset: 0x10 // Size: 0x0c
	struct FRotator NearRot; // Offset: 0x1c // Size: 0x0c
	struct FRotator FarRot; // Offset: 0x28 // Size: 0x0c
	struct FVector NearP; // Offset: 0x34 // Size: 0x0c
	struct FVector FarP; // Offset: 0x40 // Size: 0x0c
	enum class EHolderType FarHolderType; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
	struct TWeakObjectPtr<struct AActor> NearBase; // Offset: 0x50 // Size: 0x08
	struct TWeakObjectPtr<struct AActor> FarBase; // Offset: 0x58 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ZiplineInstanceData
// Size: 0x38 // Inherited bytes: 0x00
struct FZiplineInstanceData {
	// Fields
	int32_t InstanceIdxStart; // Offset: 0x00 // Size: 0x04
	int32_t InstanceCount; // Offset: 0x04 // Size: 0x04
	int32_t PrimitiveDataIdx; // Offset: 0x08 // Size: 0x04
	struct FZiplineBuildData BuildData; // Offset: 0x0c // Size: 0x2c
};

// Object Name: ScriptStruct AClient.ZiplineBuildData
// Size: 0x2c // Inherited bytes: 0x00
struct FZiplineBuildData {
	// Fields
	struct FVector ZiplineStart; // Offset: 0x00 // Size: 0x0c
	struct FVector ZiplineEnd; // Offset: 0x0c // Size: 0x0c
	int32_t CurveSeparateNum; // Offset: 0x18 // Size: 0x04
	int32_t NumSegments; // Offset: 0x1c // Size: 0x04
	float TileMaterial; // Offset: 0x20 // Size: 0x04
	struct FVector2D ZiplineMinMax; // Offset: 0x24 // Size: 0x08
};

// Object Name: ScriptStruct AClient.ZiplineFlowData
// Size: 0x58 // Inherited bytes: 0x00
struct FZiplineFlowData {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
	struct UZiplineComponent* RideZipline; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.WiggleParam
// Size: 0x20 // Inherited bytes: 0x00
struct FWiggleParam {
	// Fields
	float Bias; // Offset: 0x00 // Size: 0x04
	float Amplitude; // Offset: 0x04 // Size: 0x04
	float Frequency; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FVector2D> ParamList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AClient.ZiplinePlayerFlowData
// Size: 0x58 // Inherited bytes: 0x00
struct FZiplinePlayerFlowData {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
	struct UZiplineComponent* RideZipline; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct AClient.PlayerZiplineHeroInfo
// Size: 0x7c // Inherited bytes: 0x00
struct FPlayerZiplineHeroInfo {
	// Fields
	float CheckSphereOffsetZ; // Offset: 0x00 // Size: 0x04
	struct FVector CheckTPPOffset; // Offset: 0x04 // Size: 0x0c
	struct FVector RideOffsetHorizon_FPP; // Offset: 0x10 // Size: 0x0c
	struct FVector RideOffsetVertical_FPP; // Offset: 0x1c // Size: 0x0c
	struct FVector RideOffsetHorizon_TPP; // Offset: 0x28 // Size: 0x0c
	struct FVector RideOffsetVertical_TPP; // Offset: 0x34 // Size: 0x0c
	struct FVector MeshOffsetHorizon_FPP; // Offset: 0x40 // Size: 0x0c
	struct FVector MeshOffsetVertical_FPP; // Offset: 0x4c // Size: 0x0c
	struct FVector MeshOffsetHorizon_TPP; // Offset: 0x58 // Size: 0x0c
	struct FVector MeshOffsetVertical_TPP; // Offset: 0x64 // Size: 0x0c
	float CollisionIgnoreHeight; // Offset: 0x70 // Size: 0x04
	float CollisionHeight; // Offset: 0x74 // Size: 0x04
	float CollisionUpperHeight; // Offset: 0x78 // Size: 0x04
};

// Object Name: ScriptStruct AClient.PlayerZiplineUnifiedInfo
// Size: 0x1a0 // Inherited bytes: 0x00
struct FPlayerZiplineUnifiedInfo {
	// Fields
	float MaxAltDirTime; // Offset: 0x00 // Size: 0x04
	float IgnoreDist; // Offset: 0x04 // Size: 0x04
	float VerticalZiplinePitchOffsetFPP; // Offset: 0x08 // Size: 0x04
	float VerticalZiplinePitchOffsetTPP; // Offset: 0x0c // Size: 0x04
	float MaxNetDownZiplineValidDist; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct UCurveFloat* AlterViewDirCurve; // Offset: 0x18 // Size: 0x08
	struct UCameraShake* ShakeClass; // Offset: 0x20 // Size: 0x08
	float ShakeVelMin; // Offset: 0x28 // Size: 0x04
	float ShakeTriggerTime; // Offset: 0x2c // Size: 0x04
	float RushSpeedLimit; // Offset: 0x30 // Size: 0x04
	float SwitchT1; // Offset: 0x34 // Size: 0x04
	float SwitchT2; // Offset: 0x38 // Size: 0x04
	float SwitchT3; // Offset: 0x3c // Size: 0x04
	struct FZiplineWiggleParam WiggleVerticalConfig; // Offset: 0x40 // Size: 0x20
	struct FZiplineWiggleParam WiggleHorizonConfig_LR; // Offset: 0x60 // Size: 0x20
	struct FZiplineWiggleParam WiggleHorizonConfig_UD; // Offset: 0x80 // Size: 0x20
	float WiggleAnchorUpZ; // Offset: 0xa0 // Size: 0x04
	float WiggleSpeedMultiple; // Offset: 0xa4 // Size: 0x04
	float WiggleFadeTimeRide; // Offset: 0xa8 // Size: 0x04
	float WiggleFadeTimeDown; // Offset: 0xac // Size: 0x04
	float WiggleAnglePower; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0xc]; // Offset: 0xb4 // Size: 0x0c
	struct FTransform WiggleTransOri_FPP; // Offset: 0xc0 // Size: 0x30
	struct FTransform WiggleTransOri_TPP; // Offset: 0xf0 // Size: 0x30
	float BounceDurationTime; // Offset: 0x120 // Size: 0x04
	float BounceAmountVertical; // Offset: 0x124 // Size: 0x04
	float BounceAmountHorizon; // Offset: 0x128 // Size: 0x04
	float BounceNumber; // Offset: 0x12c // Size: 0x04
	float BounceBaseNum; // Offset: 0x130 // Size: 0x04
	float ElevatorBlendTime; // Offset: 0x134 // Size: 0x04
	float ElevatorPower; // Offset: 0x138 // Size: 0x04
	char pad_0x13C[0x4]; // Offset: 0x13c // Size: 0x04
	struct UParticleSystem* ParticleBack_Friend; // Offset: 0x140 // Size: 0x08
	struct UParticleSystem* ParticleBack_Enemy; // Offset: 0x148 // Size: 0x08
	struct FName ParticleBack_Socket_L; // Offset: 0x150 // Size: 0x08
	struct FName ParticleBack_Socket_R; // Offset: 0x158 // Size: 0x08
	float ParticleDelayTime; // Offset: 0x160 // Size: 0x04
	struct FRotator ParticleRotator; // Offset: 0x164 // Size: 0x0c
	struct AZiplineMagnetic* MagneticTemplate; // Offset: 0x170 // Size: 0x08
	int32_t ZiplineJumpGuideID; // Offset: 0x178 // Size: 0x04
	float ZiplineAutoClickSpaceTime; // Offset: 0x17c // Size: 0x04
	bool bDisableZiplinePreviewWhenHideBtn; // Offset: 0x180 // Size: 0x01
	char pad_0x181[0x3]; // Offset: 0x181 // Size: 0x03
	float CapsuleRadius; // Offset: 0x184 // Size: 0x04
	float CapsuleHalfHeight; // Offset: 0x188 // Size: 0x04
	float CheckUpOffset; // Offset: 0x18c // Size: 0x04
	bool bShowCheckDebug; // Offset: 0x190 // Size: 0x01
	enum class ECollisionChannel LandBlockChannel; // Offset: 0x191 // Size: 0x01
	char pad_0x192[0xe]; // Offset: 0x192 // Size: 0x0e
};

// Object Name: ScriptStruct AClient.ZiplineWiggleParam
// Size: 0x20 // Inherited bytes: 0x00
struct FZiplineWiggleParam {
	// Fields
	float Bias; // Offset: 0x00 // Size: 0x04
	float Amplitude; // Offset: 0x04 // Size: 0x04
	float Frequency; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FVector2D> ParamList; // Offset: 0x10 // Size: 0x10
};

