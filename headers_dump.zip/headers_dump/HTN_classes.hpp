#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class HTN.AITask_HTNMoveTo
// Size: 0x110 // Inherited bytes: 0x108
struct UAITask_HTNMoveTo : UAITask_MoveTo {
	// Fields
	char pad_0x108[0x8]; // Offset: 0x108 // Size: 0x08
};

// Object Name: Class HTN.AITask_MakeHTNPlan
// Size: 0x158 // Inherited bytes: 0x68
struct UAITask_MakeHTNPlan : UAITask {
	// Fields
	struct UHTNComponent* OwnerComponent; // Offset: 0x68 // Size: 0x08
	struct UHTN* TopLevelHTN; // Offset: 0x70 // Size: 0x08
	struct UBlackboardComponent* BlackboardComponent; // Offset: 0x78 // Size: 0x08
	char pad_0x80[0xa8]; // Offset: 0x80 // Size: 0xa8
	struct UHTNTask* CurrentTask; // Offset: 0x128 // Size: 0x08
	char pad_0x130[0x20]; // Offset: 0x130 // Size: 0x20
	char bIsWaitingForTaskToProducePlanSteps : 1; // Offset: 0x150 // Size: 0x01
	char pad_0x150_1 : 7; // Offset: 0x150 // Size: 0x01
	char pad_0x151[0x7]; // Offset: 0x151 // Size: 0x07
};

// Object Name: Class HTN.EnvQueryContext_HTNBlueprintBase
// Size: 0x40 // Inherited bytes: 0x28
struct UEnvQueryContext_HTNBlueprintBase : UEnvQueryContext {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct AActor* TempQuerierActor; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08

	// Functions

	// Object Name: Function HTN.EnvQueryContext_HTNBlueprintBase.ProvideSingleLocation
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const]
	void ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function HTN.EnvQueryContext_HTNBlueprintBase.ProvideSingleActor
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	void ProvideSingleActor(struct UObject* QuerierObject, struct AActor* QuerierActor, struct AActor*& ResultingActor); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.EnvQueryContext_HTNBlueprintBase.ProvideLocationsSet
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	void ProvideLocationsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct FVector>& ResultingLocationSet); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function HTN.EnvQueryContext_HTNBlueprintBase.ProvideActorsSet
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	void ProvideActorsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct AActor*>& ResultingActorsSet); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function HTN.EnvQueryContext_HTNBlueprintBase.GetWorldState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorldStateProxy* GetWorldState(); // Offset: 0x101e36e24 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HTN.EnvQueryContext_HTNBlueprintBase.GetQuerierLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetQuerierLocation(); // Offset: 0x101e36dec // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class HTN.EnvQueryContext_HTNQuerierLocation
// Size: 0x28 // Inherited bytes: 0x28
struct UEnvQueryContext_HTNQuerierLocation : UEnvQueryContext {
};

// Object Name: Class HTN.HTN
// Size: 0x60 // Inherited bytes: 0x28
struct UHTN : UObject {
	// Fields
	struct TArray<struct UHTNStandaloneNode*> StartNodes; // Offset: 0x28 // Size: 0x10
	struct TArray<struct UHTNDecorator*> RootDecorators; // Offset: 0x38 // Size: 0x10
	struct TArray<struct UHTNService*> RootServices; // Offset: 0x48 // Size: 0x10
	struct UBlackboardData* BlackboardAsset; // Offset: 0x58 // Size: 0x08
};

// Object Name: Class HTN.HTNBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UHTNBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HTN.HTNBlueprintLibrary.RunHTN
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool RunHTN(struct AAIController* AIController, struct UHTN* HTNAsset); // Offset: 0x101e37aa4 // Return & Params: Num(3) Size(0x11)
};

// Object Name: Class HTN.HTNNodeLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UHTNNodeLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetWorldStateValueAsVector(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, struct FVector Value); // Offset: 0x101e37fa4 // Return & Params: Num(3) Size(0x3c)

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetWorldStateValueAsString(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, struct FString Value); // Offset: 0x101e381e8 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetWorldStateValueAsRotator(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, struct FRotator Value); // Offset: 0x101e37e78 // Return & Params: Num(3) Size(0x3c)

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetWorldStateValueAsObject(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, struct UObject* Value); // Offset: 0x101e388f8 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetWorldStateValueAsName(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, struct FName Value); // Offset: 0x101e380d0 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetWorldStateValueAsInt(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, int32_t Value); // Offset: 0x101e385b0 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetWorldStateValueAsFloat(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, float Value); // Offset: 0x101e38498 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsEnum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetWorldStateValueAsEnum(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, char Value); // Offset: 0x101e386c8 // Return & Params: Num(3) Size(0x31)

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetWorldStateValueAsClass(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, struct UObject* Value); // Offset: 0x101e387e0 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function HTN.HTNNodeLibrary.SetWorldStateValueAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetWorldStateValueAsBool(struct UHTNNode* Node, struct FBlackboardKeySelector& Key, bool Value); // Offset: 0x101e38378 // Return & Params: Num(3) Size(0x31)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector GetWorldStateValueAsVector(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e38af4 // Return & Params: Num(3) Size(0x3c)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString GetWorldStateValueAsString(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e38cb8 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FRotator GetWorldStateValueAsRotator(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e38a10 // Return & Params: Num(3) Size(0x3c)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* GetWorldStateValueAsObject(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e39310 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FName GetWorldStateValueAsName(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e38bd8 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t GetWorldStateValueAsInt(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e38f90 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float GetWorldStateValueAsFloat(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e38eb0 // Return & Params: Num(3) Size(0x34)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsEnum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	char GetWorldStateValueAsEnum(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e39070 // Return & Params: Num(3) Size(0x31)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* GetWorldStateValueAsClass(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e39150 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetWorldStateValueAsBool(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e38dd0 // Return & Params: Num(3) Size(0x31)

	// Object Name: Function HTN.HTNNodeLibrary.GetWorldStateValueAsActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct AActor* GetWorldStateValueAsActor(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e39230 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function HTN.HTNNodeLibrary.GetSelfLocationFromWorldState
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector GetSelfLocationFromWorldState(struct UHTNNode* Node); // Offset: 0x101e393f0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function HTN.HTNNodeLibrary.GetOwnersWorldState
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UWorldStateProxy* GetOwnersWorldState(struct UHTNNode* Node); // Offset: 0x101e395f4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.HTNNodeLibrary.GetLocationFromWorldState
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool GetLocationFromWorldState(struct UHTNNode* Node, struct FBlackboardKeySelector& KeySelector, struct FVector& OutLocation, struct AActor*& OutActor); // Offset: 0x101e39470 // Return & Params: Num(5) Size(0x49)

	// Object Name: Function HTN.HTNNodeLibrary.ForceReplan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ForceReplan(struct UHTNNode* Node, bool bForceAbortPlan, bool bForceRestartActivePlanning); // Offset: 0x101e39670 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function HTN.HTNNodeLibrary.ClearWorldStateValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ClearWorldStateValue(struct UHTNNode* Node, struct FBlackboardKeySelector& Key); // Offset: 0x101e37da0 // Return & Params: Num(2) Size(0x30)
};

// Object Name: Class HTN.HTNComponent
// Size: 0x298 // Inherited bytes: 0x150
struct UHTNComponent : UBrainComponent {
	// Fields
	char pad_0x150[0x8]; // Offset: 0x150 // Size: 0x08
	int32_t MaxPlanLength; // Offset: 0x158 // Size: 0x04
	char pad_0x15C[0x4]; // Offset: 0x15c // Size: 0x04
	struct FMulticastInlineDelegate PlanExecutionStartedBPEvent; // Offset: 0x160 // Size: 0x10
	char pad_0x170[0x18]; // Offset: 0x170 // Size: 0x18
	struct FMulticastInlineDelegate PlanExecutionFinishedBPEvent; // Offset: 0x188 // Size: 0x10
	char pad_0x198[0x18]; // Offset: 0x198 // Size: 0x18
	struct UHTN* CurrentHTNAsset; // Offset: 0x1b0 // Size: 0x08
	struct UAITask_MakeHTNPlan* CurrentPlanningTask; // Offset: 0x1b8 // Size: 0x08
	char pad_0x1C0[0x40]; // Offset: 0x1c0 // Size: 0x40
	struct TArray<struct UHTNNode*> InstancedNodes; // Offset: 0x200 // Size: 0x10
	struct TArray<char> PlanMemory; // Offset: 0x210 // Size: 0x10
	struct UWorldStateProxy* PlanningWorldStateProxy; // Offset: 0x220 // Size: 0x08
	struct UWorldStateProxy* BlackboardProxy; // Offset: 0x228 // Size: 0x08
	struct TMap<struct UHTNExtension*, struct UHTNExtension*> Extensions; // Offset: 0x230 // Size: 0x50
	char pad_0x280[0x18]; // Offset: 0x280 // Size: 0x18

	// Functions

	// Object Name: Function HTN.HTNComponent.StopHTN
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopHTN(bool bDisregardLatentAbort); // Offset: 0x101e3abdc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNComponent.StartHTN
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartHTN(struct UHTN* Asset); // Offset: 0x101e3ac60 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HTN.HTNComponent.SetDynamicHTN
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetDynamicHTN(struct FGameplayTag InjectTag, struct UHTN* HTN, bool bForceAbortCurrentPlanIfChanged); // Offset: 0x101e3a218 // Return & Params: Num(4) Size(0x12)

	// Object Name: Function HTN.HTNComponent.RemoveExtensionByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveExtensionByClass(struct UHTNExtension* ExtensionClass); // Offset: 0x101e3a554 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HTN.HTNComponent.NotifyEventBasedDecoratorCondition
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool NotifyEventBasedDecoratorCondition(struct UHTNDecorator* Decorator, bool bRawConditionValue, bool bCanAbortPlanInstantly); // Offset: 0x101e3a974 // Return & Params: Num(4) Size(0xb)

	// Object Name: Function HTN.HTNComponent.IsWaitingForAbortingTasks
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsWaitingForAbortingTasks(); // Offset: 0x101e3a8a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNComponent.IsPlanning
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlanning(); // Offset: 0x101e3a870 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNComponent.HasPlan
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasPlan(); // Offset: 0x101e3a90c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNComponent.HasDeferredAbort
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasDeferredAbort(); // Offset: 0x101e3a83c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNComponent.HasActiveTasks
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasActiveTasks(); // Offset: 0x101e3a8d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNComponent.HasActivePlan
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasActivePlan(); // Offset: 0x101e3a940 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNComponent.GetWorldStateProxy
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorldStateProxy* GetWorldStateProxy(bool bForPlanning); // Offset: 0x101e3a750 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.HTNComponent.GetPlanningWorldStateProxy
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorldStateProxy* GetPlanningWorldStateProxy(); // Offset: 0x101e3a804 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HTN.HTNComponent.GetDynamicHTN
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UHTN* GetDynamicHTN(struct FGameplayTag InjectTag); // Offset: 0x101e3a330 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.HTNComponent.GetCurrentHTN
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UHTN* GetCurrentHTN(); // Offset: 0x101e3a820 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HTN.HTNComponent.GetCooldownEndTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCooldownEndTime(struct UObject* CooldownOwner); // Offset: 0x101e3a4c8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HTN.HTNComponent.GetBlackboardProxy
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorldStateProxy* GetBlackboardProxy(); // Offset: 0x101e3a7e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HTN.HTNComponent.ForceReplan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceReplan(bool bForceAbortPlan, bool bForceRestartActivePlanning, bool bForceDeferToNextFrame); // Offset: 0x101e3aa9c // Return & Params: Num(3) Size(0x3)

	// Object Name: Function HTN.HTNComponent.FindOrAddExtensionByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UHTNExtension* FindOrAddExtensionByClass(struct UHTNExtension* ExtensionClass); // Offset: 0x101e3a5e0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.HTNComponent.CancelActivePlanning
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelActivePlanning(); // Offset: 0x101e3abc8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HTN.HTNComponent.BP_FindExtensionByClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|Const]
	struct UHTNExtension* BP_FindExtensionByClass(enum class EHTNFindExtensionResult& OutResult, struct UHTNExtension* ExtensionClass); // Offset: 0x101e3a66c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNComponent.AddCooldownDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCooldownDuration(struct UObject* CooldownOwner, float CooldownDuration, bool bAddToExistingDuration); // Offset: 0x101e3a3bc // Return & Params: Num(3) Size(0xd)
};

// Object Name: Class HTN.HTNNode
// Size: 0x60 // Inherited bytes: 0x28
struct UHTNNode : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FString NodeName; // Offset: 0x30 // Size: 0x10
	struct UHTNNode* TemplateNode; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
	struct UHTN* HTNAsset; // Offset: 0x50 // Size: 0x08
	struct UHTNComponent* OwnerComponent; // Offset: 0x58 // Size: 0x08

	// Functions

	// Object Name: Function HTN.HTNNode.GetTemplateNode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UHTNNode* GetTemplateNode(); // Offset: 0x101e404e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HTN.HTNNode.GetOwnerComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UHTNComponent* GetOwnerComponent(); // Offset: 0x101e40508 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HTN.HTNNode.GetNodeName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetNodeName(); // Offset: 0x101e4045c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class HTN.HTNDecorator
// Size: 0x68 // Inherited bytes: 0x60
struct UHTNDecorator : UHTNNode {
	// Fields
	char pad_0x60_0 : 6; // Offset: 0x60 // Size: 0x01
	char bInverseCondition : 1; // Offset: 0x60 // Size: 0x01
	char bCheckConditionOnPlanEnter : 1; // Offset: 0x60 // Size: 0x01
	char bCheckConditionOnPlanExit : 1; // Offset: 0x61 // Size: 0x01
	char bCheckConditionOnPlanRecheck : 1; // Offset: 0x61 // Size: 0x01
	char bCheckConditionOnTick : 1; // Offset: 0x61 // Size: 0x01
	char pad_0x61_3 : 5; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x6]; // Offset: 0x62 // Size: 0x06

	// Functions

	// Object Name: Function HTN.HTNDecorator.IsInversed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInversed(); // Offset: 0x101e3b848 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class HTN.HTNDecorator_BlackboardBase
// Size: 0x98 // Inherited bytes: 0x68
struct UHTNDecorator_BlackboardBase : UHTNDecorator {
	// Fields
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0x68 // Size: 0x28
	char bNotifyOnBlackboardKeyValueChange : 1; // Offset: 0x90 // Size: 0x01
	char pad_0x90_1 : 7; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
};

// Object Name: Class HTN.HTNDecorator_Blackboard
// Size: 0xc8 // Inherited bytes: 0x98
struct UHTNDecorator_Blackboard : UHTNDecorator_BlackboardBase {
	// Fields
	int32_t IntValue; // Offset: 0x94 // Size: 0x04
	float FloatValue; // Offset: 0x98 // Size: 0x04
	struct FString StringValue; // Offset: 0xa0 // Size: 0x10
	struct FString CachedDescription; // Offset: 0xb0 // Size: 0x10
	char OperationType; // Offset: 0xc0 // Size: 0x01
	char bCanAbortPlanInstantly : 1; // Offset: 0xc1 // Size: 0x01
	char pad_0xC1_1 : 7; // Offset: 0xc1 // Size: 0x01
	char pad_0xC2[0x6]; // Offset: 0xc2 // Size: 0x06
};

// Object Name: Class HTN.HTNDecorator_BlueprintBase
// Size: 0x80 // Inherited bytes: 0x68
struct UHTNDecorator_BlueprintBase : UHTNDecorator {
	// Fields
	char bShowPropertyDetails : 1; // Offset: 0x62 // Size: 0x01
	char pad_0x68_1 : 7; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x17]; // Offset: 0x69 // Size: 0x17

	// Functions

	// Object Name: Function HTN.HTNDecorator_BlueprintBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveTick(struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn, float DeltaTime); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function HTN.HTNDecorator_BlueprintBase.ReceiveOnPlanExit
	// Flags: [Event|Protected|BlueprintEvent|Const]
	void ReceiveOnPlanExit(struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNDecorator_BlueprintBase.ReceiveOnPlanExecutionStarted
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnPlanExecutionStarted(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNDecorator_BlueprintBase.ReceiveOnPlanExecutionFinished
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnPlanExecutionFinished(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EHTNPlanExecutionFinishedResult Result); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x19)

	// Object Name: Function HTN.HTNDecorator_BlueprintBase.ReceiveOnPlanEnter
	// Flags: [Event|Protected|BlueprintEvent|Const]
	void ReceiveOnPlanEnter(struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNDecorator_BlueprintBase.ReceiveModifyStepCost
	// Flags: [Event|Protected|BlueprintEvent|Const]
	int32_t ReceiveModifyStepCost(int32_t OriginalCost, struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(5) Size(0x24)

	// Object Name: Function HTN.HTNDecorator_BlueprintBase.ReceiveExecutionStart
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecutionStart(struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNDecorator_BlueprintBase.ReceiveExecutionFinish
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecutionFinish(struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn, enum class EHTNNodeResult NodeResult); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x19)

	// Object Name: Function HTN.HTNDecorator_BlueprintBase.PerformConditionCheck
	// Flags: [Event|Protected|BlueprintEvent|Const]
	bool PerformConditionCheck(struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn, enum class EHTNDecoratorConditionCheckType CheckType); // Offset: 0x1043c773c // Return & Params: Num(5) Size(0x1a)
};

// Object Name: Class HTN.HTNDecorator_Cooldown
// Size: 0x78 // Inherited bytes: 0x68
struct UHTNDecorator_Cooldown : UHTNDecorator {
	// Fields
	float CooldownDuration; // Offset: 0x64 // Size: 0x04
	struct FGameplayTag GameplayTag; // Offset: 0x68 // Size: 0x08
	char bLockEvenIfExecutionAborted : 1; // Offset: 0x70 // Size: 0x01
	char pad_0x74_1 : 7; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03
};

// Object Name: Class HTN.HTNExtension
// Size: 0x30 // Inherited bytes: 0x28
struct UHTNExtension : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function HTN.HTNExtension.GetHTNComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UHTNComponent* GetHTNComponent(); // Offset: 0x101e3fdac // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class HTN.HTNExtension_Cooldown
// Size: 0xd0 // Inherited bytes: 0x30
struct UHTNExtension_Cooldown : UHTNExtension {
	// Fields
	struct TMap<struct UObject*, float> CooldownOwnerToEndTime; // Offset: 0x30 // Size: 0x50
	struct TMap<struct FGameplayTag, float> CooldownTagToEndTime; // Offset: 0x80 // Size: 0x50

	// Functions

	// Object Name: Function HTN.HTNExtension_Cooldown.ResetCooldownsByTag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ResetCooldownsByTag(struct FGameplayTag& CooldownTag); // Offset: 0x101e3e5d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HTN.HTNExtension_Cooldown.ResetAllCooldownsWithoutGameplayTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetAllCooldownsWithoutGameplayTag(); // Offset: 0x101e3e5c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HTN.HTNExtension_Cooldown.ResetAllCooldowns
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetAllCooldowns(); // Offset: 0x101e3e5b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HTN.HTNExtension_Cooldown.GetTagCooldownEndTime
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	float GetTagCooldownEndTime(struct FGameplayTag& CooldownTag); // Offset: 0x101e3e898 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HTN.HTNExtension_Cooldown.GetCooldownEndTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCooldownEndTime(struct UObject* CooldownOwner); // Offset: 0x101e3e934 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HTN.HTNExtension_Cooldown.AddTagCooldownDuration
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddTagCooldownDuration(struct FGameplayTag& CooldownTag, float CooldownDuration, bool bAddToExistingDuration); // Offset: 0x101e3e664 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function HTN.HTNExtension_Cooldown.AddCooldownDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCooldownDuration(struct UObject* CooldownOwner, float CooldownDuration, bool bAddToExistingDuration); // Offset: 0x101e3e78c // Return & Params: Num(3) Size(0xd)
};

// Object Name: Class HTN.HTNDecorator_DistanceCheck
// Size: 0xc0 // Inherited bytes: 0x68
struct UHTNDecorator_DistanceCheck : UHTNDecorator {
	// Fields
	struct FBlackboardKeySelector A; // Offset: 0x68 // Size: 0x28
	struct FBlackboardKeySelector B; // Offset: 0x90 // Size: 0x28
	float MinDistance; // Offset: 0xb8 // Size: 0x04
	float MaxDistance; // Offset: 0xbc // Size: 0x04
};

// Object Name: Class HTN.HTNDecorator_DoOnce
// Size: 0x70 // Inherited bytes: 0x68
struct UHTNDecorator_DoOnce : UHTNDecorator {
	// Fields
	struct FGameplayTag GameplayTag; // Offset: 0x64 // Size: 0x08
	char bLockEvenIfExecutionAborted : 1; // Offset: 0x6c // Size: 0x01
	char bCanAbortPlanInstantly : 1; // Offset: 0x6c // Size: 0x01
};

// Object Name: Class HTN.HTNExtension_DoOnce
// Size: 0x100 // Inherited bytes: 0x30
struct UHTNExtension_DoOnce : UHTNExtension {
	// Fields
	char pad_0x30[0x30]; // Offset: 0x30 // Size: 0x30
	struct TSet<struct FGameplayTag> LockedGameplayTags; // Offset: 0x60 // Size: 0x50
	struct TSet<struct UHTNDecorator_DoOnce*> LockedDecorators; // Offset: 0xb0 // Size: 0x50

	// Functions

	// Object Name: Function HTN.HTNExtension_DoOnce.SetDoOnceLocked
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool SetDoOnceLocked(struct FGameplayTag& Tag, bool bNewLocked); // Offset: 0x101e3f2f0 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function HTN.HTNExtension_DoOnce.ResetAllDoOnceDecoratorsWithoutGameplayTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetAllDoOnceDecoratorsWithoutGameplayTag(); // Offset: 0x101e3f2dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HTN.HTNExtension_DoOnce.ResetAllDoOnceDecorators
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetAllDoOnceDecorators(); // Offset: 0x101e3f2c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HTN.HTNExtension_DoOnce.IsDoOnceLocked
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsDoOnceLocked(struct FGameplayTag& Tag); // Offset: 0x101e3f3dc // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class HTN.HTNDecorator_FocusScope
// Size: 0x98 // Inherited bytes: 0x68
struct UHTNDecorator_FocusScope : UHTNDecorator {
	// Fields
	char bSetNewFocus : 1; // Offset: 0x62 // Size: 0x01
	struct FBlackboardKeySelector FocusTarget; // Offset: 0x68 // Size: 0x28
	char bObserveBlackboardValue : 1; // Offset: 0x90 // Size: 0x01
	char bRestoreOldFocusOnExecutionFinish : 1; // Offset: 0x90 // Size: 0x01
	char pad_0x90_3 : 5; // Offset: 0x90 // Size: 0x01
	char FocusPriority; // Offset: 0x91 // Size: 0x01
	char pad_0x92[0x6]; // Offset: 0x92 // Size: 0x06
};

// Object Name: Class HTN.HTNDecorator_GuardValue
// Size: 0xe0 // Inherited bytes: 0x98
struct UHTNDecorator_GuardValue : UHTNDecorator_BlackboardBase {
	// Fields
	struct FWorldstateSetValueContainer Value; // Offset: 0x98 // Size: 0x40
	char bSetValueOnEnterPlan : 1; // Offset: 0xd8 // Size: 0x01
	char bRestoreValueOnExitPlan : 1; // Offset: 0xd8 // Size: 0x01
	char bRestoreValueOnAbort : 1; // Offset: 0xd8 // Size: 0x01
	char pad_0xD8_3 : 5; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x7]; // Offset: 0xd9 // Size: 0x07
};

// Object Name: Class HTN.HTNDecorator_ModifyCost
// Size: 0x70 // Inherited bytes: 0x68
struct UHTNDecorator_ModifyCost : UHTNDecorator {
	// Fields
	float Scale; // Offset: 0x64 // Size: 0x04
	int32_t Bias; // Offset: 0x68 // Size: 0x04
};

// Object Name: Class HTN.HTNDecorator_TraceTest
// Size: 0x110 // Inherited bytes: 0x68
struct UHTNDecorator_TraceTest : UHTNDecorator {
	// Fields
	struct FBlackboardKeySelector TraceFrom; // Offset: 0x68 // Size: 0x28
	float TraceFromZOffset; // Offset: 0x90 // Size: 0x04
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
	struct FBlackboardKeySelector TraceTo; // Offset: 0x98 // Size: 0x28
	float TraceToZOffset; // Offset: 0xc0 // Size: 0x04
	enum class ECollisionChannel CollisionChannel; // Offset: 0xc4 // Size: 0x01
	char bUseComplexCollision : 1; // Offset: 0xc5 // Size: 0x01
	char bIgnoreSelf : 1; // Offset: 0xc5 // Size: 0x01
	char pad_0xC5_2 : 6; // Offset: 0xc5 // Size: 0x01
	enum class EEnvTraceShape TraceShape; // Offset: 0xc6 // Size: 0x01
	char pad_0xC7[0x1]; // Offset: 0xc7 // Size: 0x01
	float TraceExtentX; // Offset: 0xc8 // Size: 0x04
	float TraceExtentY; // Offset: 0xcc // Size: 0x04
	float TraceExtentZ; // Offset: 0xd0 // Size: 0x04
	enum class EDrawDebugTrace DrawDebugType; // Offset: 0xd4 // Size: 0x01
	char pad_0xD5[0x3]; // Offset: 0xd5 // Size: 0x03
	struct FLinearColor DebugColor; // Offset: 0xd8 // Size: 0x10
	struct FLinearColor DebugHitColor; // Offset: 0xe8 // Size: 0x10
	float DebugDrawTime; // Offset: 0xf8 // Size: 0x04
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
	struct TArray<struct AActor*> ActorsToIgnoreBuffer; // Offset: 0x100 // Size: 0x10
};

// Object Name: Class HTN.HTNExtension_BlueprintBase
// Size: 0x30 // Inherited bytes: 0x30
struct UHTNExtension_BlueprintBase : UHTNExtension {
	// Functions

	// Object Name: Function HTN.HTNExtension_BlueprintBase.OnTick
	// Flags: [Event|Protected|BlueprintEvent]
	void OnTick(float DeltaTime); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HTN.HTNExtension_BlueprintBase.OnInitialize
	// Flags: [Event|Protected|BlueprintEvent]
	void OnInitialize(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HTN.HTNExtension_BlueprintBase.OnHTNStarted
	// Flags: [Event|Protected|BlueprintEvent]
	void OnHTNStarted(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HTN.HTNExtension_BlueprintBase.OnCleanup
	// Flags: [Event|Protected|BlueprintEvent]
	void OnCleanup(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class HTN.HTNStandaloneNode
// Size: 0x98 // Inherited bytes: 0x60
struct UHTNStandaloneNode : UHTNNode {
	// Fields
	int32_t MaxRecursionLimit; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<struct UHTNStandaloneNode*> NextNodes; // Offset: 0x68 // Size: 0x10
	struct TArray<struct UHTNDecorator*> Decorators; // Offset: 0x78 // Size: 0x10
	struct TArray<struct UHTNService*> Services; // Offset: 0x88 // Size: 0x10
};

// Object Name: Class HTN.HTNNode_TwoBranches
// Size: 0xa0 // Inherited bytes: 0x98
struct UHTNNode_TwoBranches : UHTNStandaloneNode {
	// Fields
	int32_t NumPrimaryNodes; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
};

// Object Name: Class HTN.HTNNode_AnyOrder
// Size: 0xa0 // Inherited bytes: 0xa0
struct UHTNNode_AnyOrder : UHTNNode_TwoBranches {
};

// Object Name: Class HTN.HTNNode_If
// Size: 0xa0 // Inherited bytes: 0xa0
struct UHTNNode_If : UHTNNode_TwoBranches {
	// Fields
	char bCanConditionsInterruptTrueBranch : 1; // Offset: 0x9c // Size: 0x01
	char bCanConditionsInterruptFalseBranch : 1; // Offset: 0x9c // Size: 0x01
};

// Object Name: Class HTN.HTNNode_Parallel
// Size: 0xa0 // Inherited bytes: 0xa0
struct UHTNNode_Parallel : UHTNNode_TwoBranches {
	// Fields
	char bWaitForSecondaryBranchToComplete : 1; // Offset: 0x9c // Size: 0x01
	char bLoopSecondaryBranchUntilPrimaryBranchCompletes : 1; // Offset: 0x9c // Size: 0x01
};

// Object Name: Class HTN.HTNNode_Prefer
// Size: 0xa0 // Inherited bytes: 0xa0
struct UHTNNode_Prefer : UHTNNode_TwoBranches {
};

// Object Name: Class HTN.HTNNode_Scope
// Size: 0x98 // Inherited bytes: 0x98
struct UHTNNode_Scope : UHTNStandaloneNode {
};

// Object Name: Class HTN.HTNNode_Sequence
// Size: 0xa0 // Inherited bytes: 0xa0
struct UHTNNode_Sequence : UHTNNode_TwoBranches {
};

// Object Name: Class HTN.HTNNode_SubNetwork
// Size: 0xa0 // Inherited bytes: 0x98
struct UHTNNode_SubNetwork : UHTNStandaloneNode {
	// Fields
	struct UHTN* HTN; // Offset: 0x98 // Size: 0x08
};

// Object Name: Class HTN.HTNNode_SubNetworkDynamic
// Size: 0xa8 // Inherited bytes: 0x98
struct UHTNNode_SubNetworkDynamic : UHTNStandaloneNode {
	// Fields
	struct UHTN* DefaultHTN; // Offset: 0x98 // Size: 0x08
	struct FGameplayTag InjectTag; // Offset: 0xa0 // Size: 0x08
};

// Object Name: Class HTN.HTNExtension_SubNetworkDynamic
// Size: 0x80 // Inherited bytes: 0x30
struct UHTNExtension_SubNetworkDynamic : UHTNExtension {
	// Fields
	struct TMap<struct FGameplayTag, struct UHTN*> GameplayTagToDynamicHTN; // Offset: 0x30 // Size: 0x50

	// Functions

	// Object Name: Function HTN.HTNExtension_SubNetworkDynamic.SetDynamicHTN
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetDynamicHTN(struct FGameplayTag InjectTag, struct UHTN* HTN, bool bForceAbortCurrentPlanIfChanged); // Offset: 0x101e416e0 // Return & Params: Num(4) Size(0x12)

	// Object Name: Function HTN.HTNExtension_SubNetworkDynamic.ResetDynamicHTNs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetDynamicHTNs(); // Offset: 0x101e416cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HTN.HTNExtension_SubNetworkDynamic.GetDynamicHTN
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UHTN* GetDynamicHTN(struct FGameplayTag InjectTag); // Offset: 0x101e417f8 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class HTN.HTNService
// Size: 0x70 // Inherited bytes: 0x60
struct UHTNService : UHTNNode {
	// Fields
	float TickInterval; // Offset: 0x60 // Size: 0x04
	float TickIntervalRandomDeviation; // Offset: 0x64 // Size: 0x04
	char bUsePersistentTickCountdown : 1; // Offset: 0x68 // Size: 0x01
	char pad_0x68_1 : 7; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: Class HTN.HTNExtension_ServicePersistentTickCountdown
// Size: 0x80 // Inherited bytes: 0x30
struct UHTNExtension_ServicePersistentTickCountdown : UHTNExtension {
	// Fields
	struct TMap<struct UHTNService*, struct FHNTIntervalCountdown> ServiceToCountdown; // Offset: 0x30 // Size: 0x50
};

// Object Name: Class HTN.HTNService_BlueprintBase
// Size: 0x88 // Inherited bytes: 0x70
struct UHTNService_BlueprintBase : UHTNService {
	// Fields
	char bShowPropertyDetails : 1; // Offset: 0x69 // Size: 0x01
	char pad_0x70_1 : 7; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x17]; // Offset: 0x71 // Size: 0x17

	// Functions

	// Object Name: Function HTN.HTNService_BlueprintBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveTick(struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn, float DeltaTime); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function HTN.HTNService_BlueprintBase.ReceiveOnPlanExecutionStarted
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnPlanExecutionStarted(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNService_BlueprintBase.ReceiveOnPlanExecutionFinished
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnPlanExecutionFinished(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EHTNPlanExecutionFinishedResult Result); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x19)

	// Object Name: Function HTN.HTNService_BlueprintBase.ReceiveExecutionStart
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecutionStart(struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNService_BlueprintBase.ReceiveExecutionFinish
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecutionFinish(struct AActor* Owner, struct AAIController* OwnerAsController, struct APawn* ControlledPawn, enum class EHTNNodeResult NodeResult); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x19)
};

// Object Name: Class HTN.HTNService_ReplanIfLocationChanges
// Size: 0xa0 // Inherited bytes: 0x70
struct UHTNService_ReplanIfLocationChanges : UHTNService {
	// Fields
	float Tolerance; // Offset: 0x6c // Size: 0x04
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0x70 // Size: 0x28
	bool bForceAbortPlan; // Offset: 0x98 // Size: 0x01
	bool bForceRestartActivePlanning; // Offset: 0x99 // Size: 0x01
	char pad_0x9E[0x2]; // Offset: 0x9e // Size: 0x02
};

// Object Name: Class HTN.HTNTask
// Size: 0xa0 // Inherited bytes: 0x98
struct UHTNTask : UHTNStandaloneNode {
	// Fields
	char bShowTaskNameOnCurrentPlanVisualization : 1; // Offset: 0x98 // Size: 0x01
	char pad_0x98_1 : 7; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x7]; // Offset: 0x99 // Size: 0x07
};

// Object Name: Class HTN.HTNTask_BlackboardBase
// Size: 0xc8 // Inherited bytes: 0xa0
struct UHTNTask_BlackboardBase : UHTNTask {
	// Fields
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0xa0 // Size: 0x28
};

// Object Name: Class HTN.HTNTask_BlueprintBase
// Size: 0xf0 // Inherited bytes: 0xa0
struct UHTNTask_BlueprintBase : UHTNTask {
	// Fields
	char pad_0xA0[0x20]; // Offset: 0xa0 // Size: 0x20
	struct UAITask_MakeHTNPlan* OutPlanningTask; // Offset: 0xc0 // Size: 0x08
	struct FHNTIntervalCountdown TickInterval; // Offset: 0xc8 // Size: 0x08
	char bShowPropertyDetails : 1; // Offset: 0xd0 // Size: 0x01
	char pad_0xD0_1 : 7; // Offset: 0xd0 // Size: 0x01
	char pad_0xD1[0x1f]; // Offset: 0xd1 // Size: 0x1f

	// Functions

	// Object Name: Function HTN.HTNTask_BlueprintBase.SubmitPlanStep
	// Flags: [Final|Native|Protected|BlueprintCallable|Const]
	void SubmitPlanStep(int32_t Cost, struct FString Description); // Offset: 0x101e42f64 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function HTN.HTNTask_BlueprintBase.SetPlanningFailureReason
	// Flags: [Final|Native|Protected|BlueprintCallable|Const]
	void SetPlanningFailureReason(struct FString FailureReason); // Offset: 0x101e42edc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HTN.HTNTask_BlueprintBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveTick(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function HTN.HTNTask_BlueprintBase.ReceiveRecheckPlan
	// Flags: [Event|Protected|BlueprintEvent]
	bool ReceiveRecheckPlan(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x19)

	// Object Name: Function HTN.HTNTask_BlueprintBase.ReceiveOnPlanExecutionStarted
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnPlanExecutionStarted(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNTask_BlueprintBase.ReceiveOnPlanExecutionFinished
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnPlanExecutionFinished(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EHTNPlanExecutionFinishedResult Result); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x19)

	// Object Name: Function HTN.HTNTask_BlueprintBase.ReceiveOnFinished
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnFinished(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EHTNNodeResult Result); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x19)

	// Object Name: Function HTN.HTNTask_BlueprintBase.ReceiveExecute
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecute(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNTask_BlueprintBase.ReceiveDescribePlanStepToVisualLog
	// Flags: [Event|Protected|BlueprintEvent|Const]
	void ReceiveDescribePlanStepToVisualLog(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn, struct FName VisLogCategoryName); // Offset: 0x1043c773c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function HTN.HTNTask_BlueprintBase.ReceiveCreatePlanSteps
	// Flags: [Event|Protected|BlueprintEvent|Const]
	void ReceiveCreatePlanSteps(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNTask_BlueprintBase.ReceiveAbort
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveAbort(struct AActor* Owner, struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HTN.HTNTask_BlueprintBase.IsTaskExecuting
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTaskExecuting(); // Offset: 0x101e43064 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNTask_BlueprintBase.IsTaskAborting
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTaskAborting(); // Offset: 0x101e43030 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNTask_BlueprintBase.FinishExecute
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void FinishExecute(bool bSuccess); // Offset: 0x101e42e58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HTN.HTNTask_BlueprintBase.FinishAbort
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void FinishAbort(); // Offset: 0x101e42e44 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class HTN.HTNTask_ClearValue
// Size: 0xc8 // Inherited bytes: 0xc8
struct UHTNTask_ClearValue : UHTNTask_BlackboardBase {
};

// Object Name: Class HTN.HTNTask_EQSQuery
// Size: 0x128 // Inherited bytes: 0xc8
struct UHTNTask_EQSQuery : UHTNTask_BlackboardBase {
	// Fields
	struct FEQSParametrizedQueryExecutionRequestHTN EQSRequest; // Offset: 0xc8 // Size: 0x58
	int32_t MaxNumCandidatePlans; // Offset: 0x120 // Size: 0x04
	int32_t Cost; // Offset: 0x124 // Size: 0x04
};

// Object Name: Class HTN.HTNTask_Fail
// Size: 0xa0 // Inherited bytes: 0xa0
struct UHTNTask_Fail : UHTNTask {
};

// Object Name: Class HTN.HTNTask_MoveTo
// Size: 0xe8 // Inherited bytes: 0xc8
struct UHTNTask_MoveTo : UHTNTask_BlackboardBase {
	// Fields
	float AcceptableRadius; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
	struct UNavigationQueryFilter* FilterClass; // Offset: 0xd0 // Size: 0x08
	float ObservedBlackboardValueTolerance; // Offset: 0xd8 // Size: 0x04
	char bObserveBlackboardValue : 1; // Offset: 0xdc // Size: 0x01
	char bAllowStrafe : 1; // Offset: 0xdc // Size: 0x01
	char bAllowPartialPath : 1; // Offset: 0xdc // Size: 0x01
	char bTrackMovingGoal : 1; // Offset: 0xdc // Size: 0x01
	char bProjectGoalLocation : 1; // Offset: 0xdc // Size: 0x01
	char bReachTestIncludesAgentRadius : 1; // Offset: 0xdc // Size: 0x01
	char bReachTestIncludesGoalRadius : 1; // Offset: 0xdc // Size: 0x01
	char pad_0xDC_7 : 1; // Offset: 0xdc // Size: 0x01
	char bTestPathDuringPlanning : 1; // Offset: 0xdd // Size: 0x01
	char bUsePathCostInsteadOfLength : 1; // Offset: 0xdd // Size: 0x01
	char bForcePlanTimeStringPulling : 1; // Offset: 0xdd // Size: 0x01
	char pad_0xDD_3 : 5; // Offset: 0xdd // Size: 0x01
	char pad_0xDE[0x2]; // Offset: 0xde // Size: 0x02
	float CostPerUnitPathLength; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
};

// Object Name: Class HTN.HTNTask_ResetCooldown
// Size: 0xa8 // Inherited bytes: 0xa0
struct UHTNTask_ResetCooldown : UHTNTask {
	// Fields
	enum class EHTNResetCooldownAffectedCooldowns AffectedCooldowns; // Offset: 0x9c // Size: 0x04
	struct FGameplayTag GameplayTag; // Offset: 0xa0 // Size: 0x08
};

// Object Name: Class HTN.HTNTask_ResetDoOnce
// Size: 0xa8 // Inherited bytes: 0xa0
struct UHTNTask_ResetDoOnce : UHTNTask {
	// Fields
	enum class EHTNResetDoOnceAffectedDecorators AffectedDecorators; // Offset: 0x9c // Size: 0x04
	struct FGameplayTag GameplayTag; // Offset: 0xa0 // Size: 0x08
};

// Object Name: Class HTN.HTNTask_SetValue
// Size: 0x108 // Inherited bytes: 0xc8
struct UHTNTask_SetValue : UHTNTask_BlackboardBase {
	// Fields
	struct FWorldstateSetValueContainer Value; // Offset: 0xc8 // Size: 0x40
};

// Object Name: Class HTN.HTNTask_Success
// Size: 0xa0 // Inherited bytes: 0xa0
struct UHTNTask_Success : UHTNTask {
	// Fields
	int32_t Cost; // Offset: 0x9c // Size: 0x04
};

// Object Name: Class HTN.HTNTask_Wait
// Size: 0xa8 // Inherited bytes: 0xa0
struct UHTNTask_Wait : UHTNTask {
	// Fields
	float WaitTime; // Offset: 0x9c // Size: 0x04
	float RandomDeviation; // Offset: 0xa0 // Size: 0x04
	int32_t Cost; // Offset: 0xa4 // Size: 0x04
};

// Object Name: Class HTN.WorldStateProxy
// Size: 0x48 // Inherited bytes: 0x28
struct UWorldStateProxy : UObject {
	// Fields
	struct UBrainComponent* Owner; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x10]; // Offset: 0x30 // Size: 0x10
	bool bIsEditable; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07

	// Functions

	// Object Name: Function HTN.WorldStateProxy.SetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsVector(struct FName& KeyName, struct FVector Value); // Offset: 0x101e47964 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function HTN.WorldStateProxy.SetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsString(struct FName& KeyName, struct FString Value); // Offset: 0x101e47b18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function HTN.WorldStateProxy.SetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsRotator(struct FName& KeyName, struct FRotator Value); // Offset: 0x101e4788c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function HTN.WorldStateProxy.SetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsObject(struct FName& KeyName, struct UObject* Value); // Offset: 0x101e480ac // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.WorldStateProxy.SetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsName(struct FName& KeyName, struct FName Value); // Offset: 0x101e47a3c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.WorldStateProxy.SetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsInt(struct FName& KeyName, int32_t Value); // Offset: 0x101e47e18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HTN.WorldStateProxy.SetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsFloat(struct FName& KeyName, float Value); // Offset: 0x101e47d3c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HTN.WorldStateProxy.SetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsEnum(struct FName& KeyName, char Value); // Offset: 0x101e47ef4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HTN.WorldStateProxy.SetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsClass(struct FName& KeyName, struct UObject* Value); // Offset: 0x101e47fd0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.WorldStateProxy.SetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsBool(struct FName& KeyName, bool Value); // Offset: 0x101e47c58 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HTN.WorldStateProxy.IsVectorValueSet
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsVectorValueSet(struct FName& KeyName); // Offset: 0x101e477f0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetValueAsVector(struct FName& KeyName); // Offset: 0x101e4822c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FString GetValueAsString(struct FName& KeyName); // Offset: 0x101e4836c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetValueAsRotator(struct FName& KeyName); // Offset: 0x101e48188 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetValueAsObject(struct FName& KeyName); // Offset: 0x101e487f8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FName GetValueAsName(struct FName& KeyName); // Offset: 0x101e482d0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	int32_t GetValueAsInt(struct FName& KeyName); // Offset: 0x101e48588 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	float GetValueAsFloat(struct FName& KeyName); // Offset: 0x101e484ec // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	char GetValueAsEnum(struct FName& KeyName); // Offset: 0x101e48624 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetValueAsClass(struct FName& KeyName); // Offset: 0x101e486c0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetValueAsBool(struct FName& KeyName); // Offset: 0x101e48450 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HTN.WorldStateProxy.GetValueAsActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetValueAsActor(struct FName& KeyName); // Offset: 0x101e4875c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HTN.WorldStateProxy.GetSelfLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetSelfLocation(); // Offset: 0x101e48894 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function HTN.WorldStateProxy.GetRotationFromEntry
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool GetRotationFromEntry(struct FName& KeyName, struct FRotator& ResultRotation); // Offset: 0x101e47610 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HTN.WorldStateProxy.GetLocationFromEntry
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool GetLocationFromEntry(struct FName& KeyName, struct FVector& ResultLocation); // Offset: 0x101e47700 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HTN.WorldStateProxy.GetLocation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool GetLocation(struct FBlackboardKeySelector& KeySelector, struct FVector& OutLocation, struct AActor*& OutActor); // Offset: 0x101e48940 // Return & Params: Num(4) Size(0x41)

	// Object Name: Function HTN.WorldStateProxy.ClearValue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ClearValue(struct FName& KeyName); // Offset: 0x101e47584 // Return & Params: Num(1) Size(0x8)
};

