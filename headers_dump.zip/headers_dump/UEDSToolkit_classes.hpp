#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UEDSToolkit.DSControllerComponent
// Size: 0x150 // Inherited bytes: 0xf0
struct UDSControllerComponent : UActorComponent {
	// Fields
	char pad_0xF0[0x60]; // Offset: 0xf0 // Size: 0x60
};

