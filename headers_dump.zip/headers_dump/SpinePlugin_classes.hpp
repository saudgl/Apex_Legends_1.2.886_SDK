#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SpinePlugin.SpineAtlasAsset
// Size: 0x58 // Inherited bytes: 0x28
struct USpineAtlasAsset : UObject {
	// Fields
	struct TArray<struct UTexture2D*> atlasPages; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FString rawData; // Offset: 0x40 // Size: 0x10
	struct FName atlasFileName; // Offset: 0x50 // Size: 0x08
};

// Object Name: Class SpinePlugin.SpineBoneDriverComponent
// Size: 0x280 // Inherited bytes: 0x260
struct USpineBoneDriverComponent : USceneComponent {
	// Fields
	struct AActor* Target; // Offset: 0x258 // Size: 0x08
	struct FString BoneName; // Offset: 0x260 // Size: 0x10
	bool UseComponentTransform; // Offset: 0x270 // Size: 0x01
	bool UsePosition; // Offset: 0x271 // Size: 0x01
	bool UseRotation; // Offset: 0x272 // Size: 0x01
	bool UseScale; // Offset: 0x273 // Size: 0x01
	char pad_0x27C[0x4]; // Offset: 0x27c // Size: 0x04

	// Functions

	// Object Name: Function SpinePlugin.SpineBoneDriverComponent.BeforeUpdateWorldTransform
	// Flags: [Final|Native|Protected]
	void BeforeUpdateWorldTransform(struct USpineSkeletonComponent* Skeleton); // Offset: 0x10220da68 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpinePlugin.SpineBoneFollowerComponent
// Size: 0x280 // Inherited bytes: 0x260
struct USpineBoneFollowerComponent : USceneComponent {
	// Fields
	struct AActor* Target; // Offset: 0x258 // Size: 0x08
	struct FString BoneName; // Offset: 0x260 // Size: 0x10
	bool UseComponentTransform; // Offset: 0x270 // Size: 0x01
	bool UsePosition; // Offset: 0x271 // Size: 0x01
	bool UseRotation; // Offset: 0x272 // Size: 0x01
	bool UseScale; // Offset: 0x273 // Size: 0x01
	char pad_0x27C[0x4]; // Offset: 0x27c // Size: 0x04
};

// Object Name: Class SpinePlugin.TrackEntry
// Size: 0x90 // Inherited bytes: 0x28
struct UTrackEntry : UObject {
	// Fields
	struct FDelegate animationStart; // Offset: 0x28 // Size: 0x10
	struct FDelegate AnimationInterrupt; // Offset: 0x38 // Size: 0x10
	struct FDelegate AnimationEvent; // Offset: 0x48 // Size: 0x10
	struct FDelegate AnimationComplete; // Offset: 0x58 // Size: 0x10
	struct FDelegate animationEnd; // Offset: 0x68 // Size: 0x10
	struct FDelegate AnimationDispose; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function SpinePlugin.TrackEntry.SetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTrackTime(float trackTime); // Offset: 0x10220ec80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTrackEnd(float trackEnd); // Offset: 0x10220eb98 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float TimeScale); // Offset: 0x10220eab0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMixTime(float mixTime); // Offset: 0x10220e8e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMixDuration(float mixDuration); // Offset: 0x10220e7f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLoop(bool Loop); // Offset: 0x10220f3c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.TrackEntry.SetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEventThreshold(float eventThreshold); // Offset: 0x10220f2d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDrawOrderThreshold(float drawOrderThreshold); // Offset: 0x10220f108 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDelay(float Delay); // Offset: 0x10220ed68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttachmentThreshold(float attachmentThreshold); // Offset: 0x10220f1f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimationStart(float animationStart); // Offset: 0x10220f020 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimationLast(float animationLast); // Offset: 0x10220ee50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimationEnd(float animationEnd); // Offset: 0x10220ef38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAlpha(float Alpha); // Offset: 0x10220e9c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.isValidAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	float isValidAnimation(); // Offset: 0x10220e3d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTrackTime(); // Offset: 0x10220ed18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTrackIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetTrackIndex(); // Offset: 0x10220f484 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTrackEnd(); // Offset: 0x10220ec30 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTimeScale(); // Offset: 0x10220eb48 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetMixTime(); // Offset: 0x10220e978 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetMixDuration(); // Offset: 0x10220e890 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetLoop(); // Offset: 0x10220f448 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.TrackEntry.GetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetEventThreshold(); // Offset: 0x10220f370 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetDrawOrderThreshold(); // Offset: 0x10220f1a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetDelay(); // Offset: 0x10220ee00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAttachmentThreshold(); // Offset: 0x10220f288 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAnimationStart(); // Offset: 0x10220f0b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.getAnimationName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString getAnimationName(); // Offset: 0x10220e458 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.TrackEntry.GetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAnimationLast(); // Offset: 0x10220eee8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAnimationEnd(); // Offset: 0x10220efd0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float getAnimationDuration(); // Offset: 0x10220e404 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAlpha(); // Offset: 0x10220ea60 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class SpinePlugin.SpineSkeletonComponent
// Size: 0x140 // Inherited bytes: 0xf0
struct USpineSkeletonComponent : UActorComponent {
	// Fields
	struct USpineAtlasAsset* Atlas; // Offset: 0xf0 // Size: 0x08
	struct USpineSkeletonDataAsset* SkeletonData; // Offset: 0xf8 // Size: 0x08
	struct FMulticastInlineDelegate BeforeUpdateWorldTransform; // Offset: 0x100 // Size: 0x10
	struct FMulticastInlineDelegate AfterUpdateWorldTransform; // Offset: 0x110 // Size: 0x10
	char pad_0x120[0x20]; // Offset: 0x120 // Size: 0x20

	// Functions

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateWorldTransform(); // Offset: 0x1022117ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToSetupPose(); // Offset: 0x1022117d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSlotsToSetupPose(); // Offset: 0x1022117b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetSkin(struct FString SkinName); // Offset: 0x102211c2c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleY(float ScaleY); // Offset: 0x102211684 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleX(float ScaleX); // Offset: 0x102211734 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetBoneWorldPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetBoneWorldPosition(struct FString BoneName, struct FVector& Position); // Offset: 0x102211800 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBonesToSetupPose(); // Offset: 0x1022117c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetAttachment(struct FString SlotName, struct FString attachmentName); // Offset: 0x1022119ac // Return & Params: Num(3) Size(0x21)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSlot(struct FString SlotName); // Offset: 0x1022112c8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSkin(struct FString SkinName); // Offset: 0x102211b34 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasBone(struct FString BoneName); // Offset: 0x10221148c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasAnimation(struct FString AnimationName); // Offset: 0x102211104 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSlots(struct TArray<struct FString>& Slots); // Offset: 0x1022113c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSkins(struct TArray<struct FString>& Skins); // Offset: 0x102211d24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleY(); // Offset: 0x102211650 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleX(); // Offset: 0x102211700 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetBoneWorldTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FTransform GetBoneWorldTransform(struct FString BoneName); // Offset: 0x1022118d8 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetBones(struct TArray<struct FString>& Bones); // Offset: 0x102211584 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetAnimations(struct TArray<struct FString>& Animations); // Offset: 0x1022111fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float getAnimationDuration(struct FString AnimationName); // Offset: 0x10221100c // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class SpinePlugin.SpineSkeletonAnimationComponent
// Size: 0x240 // Inherited bytes: 0x140
struct USpineSkeletonAnimationComponent : USpineSkeletonComponent {
	// Fields
	struct FDelegate animationStart; // Offset: 0x140 // Size: 0x10
	struct FDelegate AnimationInterrupt; // Offset: 0x150 // Size: 0x10
	struct FDelegate AnimationEvent; // Offset: 0x160 // Size: 0x10
	struct FDelegate AnimationComplete; // Offset: 0x170 // Size: 0x10
	struct FDelegate animationEnd; // Offset: 0x180 // Size: 0x10
	struct FDelegate AnimationDispose; // Offset: 0x190 // Size: 0x10
	struct FString PreviewAnimation; // Offset: 0x1a0 // Size: 0x10
	struct FString PreviewSkin; // Offset: 0x1b0 // Size: 0x10
	char pad_0x1C0[0x8]; // Offset: 0x1c0 // Size: 0x08
	struct TSet<struct UTrackEntry*> trackEntries; // Offset: 0x1c8 // Size: 0x50
	bool bAutoPlaying; // Offset: 0x218 // Size: 0x01
	char pad_0x219[0x27]; // Offset: 0x219 // Size: 0x27

	// Functions

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float TimeScale); // Offset: 0x102210730 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates); // Offset: 0x1022107ac // Return & Params: Num(2) Size(0x5)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetEmptyAnimation(int32_t TrackIndex, float mixDuration); // Offset: 0x1022102ec // Return & Params: Num(3) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoPlay(bool bInAutoPlays); // Offset: 0x102210874 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop); // Offset: 0x102210580 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTimeScale(); // Offset: 0x1022106fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* GetCurrent(int32_t TrackIndex); // Offset: 0x102210150 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTracks(); // Offset: 0x10221013c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTrack(int32_t TrackIndex); // Offset: 0x1022100c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddEmptyAnimation(int32_t TrackIndex, float mixDuration, float Delay); // Offset: 0x1022101dc // Return & Params: Num(4) Size(0x18)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop, float Delay); // Offset: 0x1022103bc // Return & Params: Num(5) Size(0x28)
};

// Object Name: Class SpinePlugin.SpineSkeletonDataAsset
// Size: 0xc0 // Inherited bytes: 0x28
struct USpineSkeletonDataAsset : UObject {
	// Fields
	float DefaultMix; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FSpineAnimationStateMixData> MixData; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FString> Bones; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> Slots; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FString> Skins; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FString> Animations; // Offset: 0x70 // Size: 0x10
	struct TArray<struct FString> Events; // Offset: 0x80 // Size: 0x10
	struct TArray<char> rawData; // Offset: 0x90 // Size: 0x10
	struct FName skeletonDataFileName; // Offset: 0xa0 // Size: 0x08
	char pad_0xA8[0x18]; // Offset: 0xa8 // Size: 0x18
};

// Object Name: Class SpinePlugin.SpineSkeletonRendererComponent
// Size: 0x9c0 // Inherited bytes: 0x610
struct USpineSkeletonRendererComponent : UProceduralMeshComponent {
	// Fields
	struct UMaterialInterface* NormalBlendMaterial; // Offset: 0x608 // Size: 0x08
	struct UMaterialInterface* AdditiveBlendMaterial; // Offset: 0x610 // Size: 0x08
	struct UMaterialInterface* MultiplyBlendMaterial; // Offset: 0x618 // Size: 0x08
	struct UMaterialInterface* ScreenBlendMaterial; // Offset: 0x620 // Size: 0x08
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // Offset: 0x628 // Size: 0x10
	char pad_0x640[0x48]; // Offset: 0x640 // Size: 0x48
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // Offset: 0x688 // Size: 0x10
	char pad_0x698[0x50]; // Offset: 0x698 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // Offset: 0x6e8 // Size: 0x10
	char pad_0x6F8[0x50]; // Offset: 0x6f8 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // Offset: 0x748 // Size: 0x10
	char pad_0x758[0x50]; // Offset: 0x758 // Size: 0x50
	float DepthOffset; // Offset: 0x7a8 // Size: 0x04
	struct FName TextureParameterName; // Offset: 0x7ac // Size: 0x08
	struct FLinearColor Color; // Offset: 0x7b4 // Size: 0x10
	bool bCreateCollision; // Offset: 0x7c4 // Size: 0x01
	char pad_0x7C5[0x1fb]; // Offset: 0x7c5 // Size: 0x1fb
};

// Object Name: Class SpinePlugin.SpineWidget
// Size: 0x6a0 // Inherited bytes: 0x110
struct USpineWidget : UWidget {
	// Fields
	enum class ESpineWidgetAreaType AreaType; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x3]; // Offset: 0x111 // Size: 0x03
	float Scale; // Offset: 0x114 // Size: 0x04
	struct FVector2D ScaleAnchor; // Offset: 0x118 // Size: 0x08
	struct USpineAtlasAsset* Atlas; // Offset: 0x120 // Size: 0x08
	struct USpineSkeletonDataAsset* SkeletonData; // Offset: 0x128 // Size: 0x08
	struct UMaterialInterface* NormalBlendMaterial; // Offset: 0x130 // Size: 0x08
	struct UMaterialInterface* AdditiveBlendMaterial; // Offset: 0x138 // Size: 0x08
	struct UMaterialInterface* MultiplyBlendMaterial; // Offset: 0x140 // Size: 0x08
	struct UMaterialInterface* ScreenBlendMaterial; // Offset: 0x148 // Size: 0x08
	struct FName TextureParameterName; // Offset: 0x150 // Size: 0x08
	float DepthOffset; // Offset: 0x158 // Size: 0x04
	struct FLinearColor Color; // Offset: 0x15c // Size: 0x10
	char pad_0x16C[0x4]; // Offset: 0x16c // Size: 0x04
	struct FSlateBrush Brush; // Offset: 0x170 // Size: 0x88
	struct FString SequenceSkin; // Offset: 0x1f8 // Size: 0x10
	struct FString SequencePlay; // Offset: 0x208 // Size: 0x10
	float SequenceTimeScale; // Offset: 0x218 // Size: 0x04
	struct FDelegate BeforeUpdateWorldTransform; // Offset: 0x21c // Size: 0x10
	struct FDelegate AfterUpdateWorldTransform; // Offset: 0x22c // Size: 0x10
	struct FDelegate animationStart; // Offset: 0x23c // Size: 0x10
	struct FDelegate AnimationInterrupt; // Offset: 0x24c // Size: 0x10
	struct FDelegate AnimationEvent; // Offset: 0x25c // Size: 0x10
	struct FDelegate AnimationComplete; // Offset: 0x26c // Size: 0x10
	struct FDelegate animationEnd; // Offset: 0x27c // Size: 0x10
	struct FDelegate AnimationDispose; // Offset: 0x28c // Size: 0x10
	char pad_0x29C[0x3c]; // Offset: 0x29c // Size: 0x3c
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // Offset: 0x2d8 // Size: 0x10
	char pad_0x2E8[0x50]; // Offset: 0x2e8 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // Offset: 0x338 // Size: 0x10
	char pad_0x348[0x50]; // Offset: 0x348 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // Offset: 0x398 // Size: 0x10
	char pad_0x3A8[0x50]; // Offset: 0x3a8 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // Offset: 0x3f8 // Size: 0x10
	char pad_0x408[0x240]; // Offset: 0x408 // Size: 0x240
	struct TSet<struct UTrackEntry*> trackEntries; // Offset: 0x648 // Size: 0x50
	bool bAutoPlaying; // Offset: 0x698 // Size: 0x01
	char pad_0x699[0x7]; // Offset: 0x699 // Size: 0x07

	// Functions

	// Object Name: Function SpinePlugin.SpineWidget.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateWorldTransform(); // Offset: 0x1022141c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.Tick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Tick(float DeltaTime, bool CallDelegates); // Offset: 0x102212de0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function SpinePlugin.SpineWidget.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToSetupPose(); // Offset: 0x1022141ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float TimeScale); // Offset: 0x102213818 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSlotsToSetupPose(); // Offset: 0x102214184 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetSkin(struct FString SkinName); // Offset: 0x102214488 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.SetSequenceTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequenceTimeScale(float InSequenceTimeScale); // Offset: 0x102212ea8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetSequenceSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequenceSkin(struct FString InSequenceSkin); // Offset: 0x102212fac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.SetSequencePlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequencePlay(struct FString InSequencePlay); // Offset: 0x102212f24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleY(float ScaleY); // Offset: 0x102214058 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleX(float ScaleX); // Offset: 0x102214108 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetScale
	// Flags: [Native|Public|BlueprintCallable]
	void SetScale(float InScale); // Offset: 0x102212d28 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates); // Offset: 0x102213894 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function SpinePlugin.SpineWidget.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetEmptyAnimation(int32_t TrackIndex, float mixDuration); // Offset: 0x1022133d4 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.SetDefaultSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetDefaultSkin(); // Offset: 0x10221435c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.SpineWidget.SetColor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void SetColor(struct FLinearColor InColor); // Offset: 0x102212c64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBonesToSetupPose(); // Offset: 0x102214198 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoPlay(bool bInAutoPlays); // Offset: 0x10221395c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.SpineWidget.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetAttachment(struct FString SlotName, struct FString attachmentName); // Offset: 0x1022141d4 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function SpinePlugin.SpineWidget.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop); // Offset: 0x102213668 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function SpinePlugin.SpineWidget.SequenceReset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SequenceReset(); // Offset: 0x102213034 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.RefreshProperties
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshProperties(); // Offset: 0x102212c50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSlot(struct FString SlotName); // Offset: 0x102213c9c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSkin(struct FString SkinName); // Offset: 0x102214390 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasBone(struct FString BoneName); // Offset: 0x102213e60 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasAnimation(struct FString AnimationName); // Offset: 0x102213ad8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTimeScale(); // Offset: 0x1022137e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSlots(struct TArray<struct FString>& Slots); // Offset: 0x102213d94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSkins(struct TArray<struct FString>& Skins); // Offset: 0x102214580 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleY(); // Offset: 0x102214024 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleX(); // Offset: 0x1022140d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScale(); // Offset: 0x102212dac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetCurrentTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* GetCurrentTrack(int32_t TrackIndex); // Offset: 0x1022131ac // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetCurrentAnimationName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetCurrentAnimationName(int32_t TrackIndex); // Offset: 0x1022130d8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function SpinePlugin.SpineWidget.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* GetCurrent(int32_t TrackIndex); // Offset: 0x102213238 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FLinearColor GetColor(); // Offset: 0x102212ce8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetBones(struct TArray<struct FString>& Bones); // Offset: 0x102213f58 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetAnimations(struct TArray<struct FString>& Animations); // Offset: 0x102213bd0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float getAnimationDuration(struct FString AnimationName); // Offset: 0x1022139e0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function SpinePlugin.SpineWidget.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTracks(); // Offset: 0x1022130c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTrack(int32_t TrackIndex); // Offset: 0x102213048 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddEmptyAnimation(int32_t TrackIndex, float mixDuration, float Delay); // Offset: 0x1022132c4 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function SpinePlugin.SpineWidget.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop, float Delay); // Offset: 0x1022134a4 // Return & Params: Num(5) Size(0x28)
};

