#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GoogleLVL.GoogleLVLAPI
// Size: 0x28 // Inherited bytes: 0x28
struct UGoogleLVLAPI : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function GoogleLVL.GoogleLVLAPI.RemoveObserver
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveObserver(struct TScriptInterface<IGoogleLVLObserver> Observer); // Offset: 0x101f419cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function GoogleLVL.GoogleLVLAPI.DestroyGooglePlayLicenseChecker
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestroyGooglePlayLicenseChecker(); // Offset: 0x101f419a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GoogleLVL.GoogleLVLAPI.CheckGooglePlayLicense
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CheckGooglePlayLicense(); // Offset: 0x101f419b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GoogleLVL.GoogleLVLAPI.AddObserver
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddObserver(struct TScriptInterface<IGoogleLVLObserver> Observer); // Offset: 0x101f41a50 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class GoogleLVL.GoogleLVLObserver
// Size: 0x28 // Inherited bytes: 0x28
struct UGoogleLVLObserver : UInterface {
	// Functions

	// Object Name: Function GoogleLVL.GoogleLVLObserver.OnDontAllow
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void OnDontAllow(int32_t policyReason); // Offset: 0x101f41f2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GoogleLVL.GoogleLVLObserver.OnApplicationError
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void OnApplicationError(int32_t ErrorCode); // Offset: 0x101f41ea8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GoogleLVL.GoogleLVLObserver.OnAllow
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void OnAllow(int32_t policyReason); // Offset: 0x101f41fb0 // Return & Params: Num(1) Size(0x4)
};

