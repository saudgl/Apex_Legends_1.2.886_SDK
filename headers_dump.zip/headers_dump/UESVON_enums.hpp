#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum UESVON.ESVONPathfindingRequestResult
enum class ESVONPathfindingRequestResult : uint8 {
	Failed = 0,
	ReadyToPath = 1,
	AlreadyAtGoal = 2,
	Deferred = 3,
	Success = 4,
	ESVONPathfindingRequestResult_MAX = 5
};

// Object Name: Enum UESVON.EBuildTrigger
enum class EBuildTrigger : uint8 {
	OnEdit = 0,
	Manual = 1,
	EBuildTrigger_MAX = 2
};

// Object Name: Enum UESVON.ESVONPathCostType
enum class ESVONPathCostType : uint8 {
	MANHATTAN = 0,
	EUCLIDEAN = 1,
	ESVONPathCostType_MAX = 2
};

// Object Name: Enum UESVON.ESVONPathPostProcess
enum class ESVONPathPostProcess : uint8 {
	None = 0,
	StringPulling = 1,
	NaiveTrace = 2,
	ESVONPathPostProcess_MAX = 3
};

