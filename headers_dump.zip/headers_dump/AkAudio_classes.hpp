#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AkAudio.ActivedAkEventCollector
// Size: 0x38 // Inherited bytes: 0x30
struct UActivedAkEventCollector : UWorldSubsystem {
	// Fields
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class AkAudio.AkAcousticPortal
// Size: 0x340 // Inherited bytes: 0x2a0
struct AAkAcousticPortal : AVolume {
	// Fields
	enum class AkAcousticPortalState InitialState; // Offset: 0x2a0 // Size: 0x01
	char pad_0x2A1[0x3]; // Offset: 0x2a1 // Size: 0x03
	float ObstructionRefreshInterval; // Offset: 0x2a4 // Size: 0x04
	enum class ECollisionChannel ObstructionCollisionChannel; // Offset: 0x2a8 // Size: 0x01
	char pad_0x2A9[0x97]; // Offset: 0x2a9 // Size: 0x97

	// Functions

	// Object Name: Function AkAudio.AkAcousticPortal.OpenPortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenPortal(); // Offset: 0x1023223b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAcousticPortal.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class AkAcousticPortalState GetCurrentState(); // Offset: 0x10232236c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkAcousticPortal.ClosePortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClosePortal(); // Offset: 0x1023223a0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkPortalComponent
// Size: 0x260 // Inherited bytes: 0x260
struct UAkPortalComponent : USceneComponent {
};

// Object Name: Class AkAudio.AkAcousticTexture
// Size: 0x80 // Inherited bytes: 0x80
struct UAkAcousticTexture : UPhysicalMaterial {
};

// Object Name: Class AkAudio.AkAmbientSound
// Size: 0x308 // Inherited bytes: 0x268
struct AAkAmbientSound : AActor {
	// Fields
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x268 // Size: 0x08
	struct UAkAudioEvent* AkEvent; // Offset: 0x270 // Size: 0x08
	struct UAkComponent* AkComponent; // Offset: 0x278 // Size: 0x08
	bool StopWhenOwnerIsDestroyed; // Offset: 0x280 // Size: 0x01
	bool AutoPost; // Offset: 0x281 // Size: 0x01
	char pad_0x282[0x2]; // Offset: 0x282 // Size: 0x02
	float ValidDistance; // Offset: 0x284 // Size: 0x04
	bool bIsPrimary; // Offset: 0x288 // Size: 0x01
	char pad_0x289[0x7]; // Offset: 0x289 // Size: 0x07
	struct UAkAudioEvent* StopingEvent; // Offset: 0x290 // Size: 0x08
	enum class EAkMultiPositionMode PositionType; // Offset: 0x298 // Size: 0x01
	char pad_0x299[0x6f]; // Offset: 0x299 // Size: 0x6f

	// Functions

	// Object Name: Function AkAudio.AkAmbientSound.StopAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void StopAmbientSound(); // Offset: 0x102322b30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAmbientSound.StartAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void StartAmbientSound(); // Offset: 0x102322b44 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAmbientSound.PlayEvent
	// Flags: [Final|Native|Public]
	void PlayEvent(); // Offset: 0x102322ae8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAmbientSound.IsNearLeadingCharacter
	// Flags: [Final|Native|Protected|BlueprintCallable]
	bool IsNearLeadingCharacter(); // Offset: 0x102322afc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkAndroidInitializationSettings
// Size: 0x190 // Inherited bytes: 0x28
struct UAkAndroidInitializationSettings : UObject {
	// Fields
	struct FAkCommonInitializationSettingsWithSampleRateAndAudioLevel CommonSettings; // Offset: 0x28 // Size: 0x88
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0xb0 // Size: 0x28
	struct FAkAudioLevelFolderPaths AudioLevelSettings; // Offset: 0xd8 // Size: 0x70
	struct FAkAndroidAdvancedInitializationSettings AdvancedSettings; // Offset: 0x148 // Size: 0x48

	// Functions

	// Object Name: Function AkAudio.AkAndroidInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x102323328 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkAudioType
// Size: 0x30 // Inherited bytes: 0x28
struct UAkAudioType : UObject {
	// Fields
	uint32_t ShortID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class AkAudio.AkAudioBank
// Size: 0x50 // Inherited bytes: 0x30
struct UAkAudioBank : UAkAudioType {
	// Fields
	bool AutoLoad; // Offset: 0x2c // Size: 0x01
	char pad_0x31[0x1f]; // Offset: 0x31 // Size: 0x1f

	// Functions

	// Object Name: Function AkAudio.AkAudioBank.OnCompleteAkBankUnload
	// Flags: [Final|Native|Private]
	void OnCompleteAkBankUnload(enum class EAkResult res); // Offset: 0x1023236a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkAudioBank.OnCompleteAkBankLoad
	// Flags: [Final|Native|Private]
	void OnCompleteAkBankLoad(enum class EAkResult res); // Offset: 0x102323724 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkAudioEvent
// Size: 0x48 // Inherited bytes: 0x30
struct UAkAudioEvent : UAkAudioType {
	// Fields
	struct UAkAudioBank* RequiredBank; // Offset: 0x30 // Size: 0x08
	float MaxAttenuationRadius; // Offset: 0x38 // Size: 0x04
	bool IsInfinite; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	float MinimumDuration; // Offset: 0x40 // Size: 0x04
	float MaximumDuration; // Offset: 0x44 // Size: 0x04
};

// Object Name: Class AkAudio.AkComponent
// Size: 0x460 // Inherited bytes: 0x260
struct UAkComponent : USceneComponent {
	// Fields
	bool bUseSpatialAudio; // Offset: 0x258 // Size: 0x01
	struct UAkAuxBus* EarlyReflectionAuxBus; // Offset: 0x260 // Size: 0x08
	struct FString EarlyReflectionAuxBusName; // Offset: 0x268 // Size: 0x10
	int32_t EarlyReflectionOrder; // Offset: 0x278 // Size: 0x04
	float EarlyReflectionBusSendGain; // Offset: 0x27c // Size: 0x04
	float EarlyReflectionMaxPathLength; // Offset: 0x280 // Size: 0x04
	enum class ECollisionChannel OcclusionCollisionChannel; // Offset: 0x284 // Size: 0x01
	char EnableOcclusion : 1; // Offset: 0x285 // Size: 0x01
	char pad_0x286_1 : 7; // Offset: 0x286 // Size: 0x01
	char pad_0x287[0x5]; // Offset: 0x287 // Size: 0x05
	char EnableSpotReflectors : 1; // Offset: 0x28c // Size: 0x01
	char pad_0x28C_1 : 7; // Offset: 0x28c // Size: 0x01
	char pad_0x28D[0x3]; // Offset: 0x28d // Size: 0x03
	float roomReverbAuxBusGain; // Offset: 0x290 // Size: 0x04
	int32_t diffractionMaxEdges; // Offset: 0x294 // Size: 0x04
	int32_t diffractionMaxPaths; // Offset: 0x298 // Size: 0x04
	float diffractionMaxPathLength; // Offset: 0x29c // Size: 0x04
	char DrawFirstOrderReflections : 1; // Offset: 0x2a0 // Size: 0x01
	char DrawSecondOrderReflections : 1; // Offset: 0x2a0 // Size: 0x01
	char DrawHigherOrderReflections : 1; // Offset: 0x2a0 // Size: 0x01
	char DrawDiffraction : 1; // Offset: 0x2a0 // Size: 0x01
	char AutoPost : 1; // Offset: 0x2a0 // Size: 0x01
	char EnableTickOptimize : 1; // Offset: 0x2a0 // Size: 0x01
	char DistanceDelay : 1; // Offset: 0x2a0 // Size: 0x01
	char pad_0x2A0_7 : 1; // Offset: 0x2a0 // Size: 0x01
	bool StopWhenOwnerDestroyed; // Offset: 0x2a1 // Size: 0x01
	char pad_0x2A2[0x2]; // Offset: 0x2a2 // Size: 0x02
	float AttenuationScalingFactor; // Offset: 0x2a4 // Size: 0x04
	float OcclusionRefreshInterval; // Offset: 0x2a8 // Size: 0x04
	bool bUseReverbVolumes; // Offset: 0x2ac // Size: 0x01
	char pad_0x2AD[0x3]; // Offset: 0x2ad // Size: 0x03
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x2b0 // Size: 0x08
	struct FString EventName; // Offset: 0x2b8 // Size: 0x10
	char pad_0x2C8[0x1]; // Offset: 0x2c8 // Size: 0x01
	bool IsApplyRemoteSound; // Offset: 0x2c9 // Size: 0x01
	char pad_0x2CA[0x196]; // Offset: 0x2ca // Size: 0x196

	// Functions

	// Object Name: Function AkAudio.AkComponent.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void UseReverbVolumes(bool inUseReverbVolumes); // Offset: 0x102325000 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkComponent.UseEarlyReflections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UseEarlyReflections(struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName); // Offset: 0x102324e14 // Return & Params: Num(6) Size(0x28)

	// Object Name: Function AkAudio.AkComponent.Stop
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x102325798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkComponent.SetUseSpatialAudio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUseSpatialAudio(bool bNewValue); // Offset: 0x1023261b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkComponent.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetSwitch(struct FString SwitchGroup, struct FString SwitchState); // Offset: 0x1023251a0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function AkAudio.AkComponent.SetStopWhenOwnerDestroyed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetStopWhenOwnerDestroyed(bool bStopWhenOwnerDestroyed); // Offset: 0x10232511c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkComponent.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetRTPCValue(struct FString RTPC, float Value, int32_t InterpolationTimeMs); // Offset: 0x102325638 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkComponent.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetOutputBusVolume(float BusVolume); // Offset: 0x102324d98 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.SetListeners
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	void SetListeners(struct TArray<struct UAkComponent*>& Listeners); // Offset: 0x102325084 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkComponent.SetAttenuationScalingFactor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetAttenuationScalingFactor(float Value); // Offset: 0x102324d1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PostTrigger(struct FString Trigger); // Offset: 0x102325338 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEnd
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int32_t PostAssociatedAkEventAndWaitForEnd(struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Offset: 0x102325ecc // Return & Params: Num(3) Size(0x2c)

	// Object Name: Function AkAudio.AkComponent.PostAssociatedAkEvent
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	int32_t PostAssociatedAkEvent(int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources); // Offset: 0x10232601c // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function AkAudio.AkComponent.PostAkEventForTimerCallbackWithName
	// Flags: [Final|Native|Public]
	void PostAkEventForTimerCallbackWithName(struct FString in_EventName); // Offset: 0x1023257ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkComponent.PostAkEventForTimerCallback
	// Flags: [Final|Native|Public|HasOutParms]
	void PostAkEventForTimerCallback(struct FString in_EventName, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources); // Offset: 0x102325834 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function AkAudio.AkComponent.PostAkEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	int32_t PostAkEventByName(struct FString in_EventName); // Offset: 0x102325a18 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function AkAudio.AkComponent.PostAkEventAndWaitForEnd
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int32_t PostAkEventAndWaitForEnd(struct UAkAudioEvent* AkEvent, struct FString in_EventName, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Offset: 0x102325ab0 // Return & Params: Num(5) Size(0x44)

	// Object Name: Function AkAudio.AkComponent.PostAkEvent
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	int32_t PostAkEvent(struct UAkAudioEvent* AkEvent, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString in_EventName); // Offset: 0x102325c98 // Return & Params: Num(6) Size(0x44)

	// Object Name: Function AkAudio.AkComponent.PlayEvent
	// Flags: [Final|Native|Public]
	void PlayEvent(); // Offset: 0x102324cc0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkComponent.GetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	void GetRTPCValue(struct FString RTPC, int32_t PlayingID, enum class ERTPCValueType InputValueType, float& Value, enum class ERTPCValueType& OutputValueType); // Offset: 0x102325424 // Return & Params: Num(5) Size(0x1d)

	// Object Name: Function AkAudio.AkComponent.GetAttenuationRadius
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAttenuationRadius(); // Offset: 0x102324ce8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.ForceRefreshOcclusion
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void ForceRefreshOcclusion(); // Offset: 0x102324cd4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkAudioInputComponent
// Size: 0x470 // Inherited bytes: 0x460
struct UAkAudioInputComponent : UAkComponent {
	// Fields
	char pad_0x460[0x10]; // Offset: 0x460 // Size: 0x10

	// Functions

	// Object Name: Function AkAudio.AkAudioInputComponent.PostAssociatedAudioInputEvent
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	int32_t PostAssociatedAudioInputEvent(); // Offset: 0x102323e5c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class AkAudio.AkAuxBus
// Size: 0x40 // Inherited bytes: 0x30
struct UAkAuxBus : UAkAudioType {
	// Fields
	struct UAkAudioBank* RequiredBank; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class AkAudio.AkCheckBox
// Size: 0xaf0 // Inherited bytes: 0x128
struct UAkCheckBox : UContentWidget {
	// Fields
	char pad_0x128[0x358]; // Offset: 0x128 // Size: 0x358
	enum class ECheckBoxState CheckedState; // Offset: 0x480 // Size: 0x01
	char pad_0x481[0x3]; // Offset: 0x481 // Size: 0x03
	struct FDelegate CheckedStateDelegate; // Offset: 0x484 // Size: 0x10
	char pad_0x494[0x4]; // Offset: 0x494 // Size: 0x04
	struct FCheckBoxStyle WidgetStyle; // Offset: 0x498 // Size: 0x580
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0xa18 // Size: 0x01
	bool IsFocusable; // Offset: 0xa19 // Size: 0x01
	char pad_0xA1A[0x6]; // Offset: 0xa1a // Size: 0x06
	struct FAkBoolPropertyToControl ThePropertyToControl; // Offset: 0xa20 // Size: 0x10
	struct FAkWwiseItemToControl ItemToControl; // Offset: 0xa30 // Size: 0x40
	struct FMulticastInlineDelegate AkOnCheckStateChanged; // Offset: 0xa70 // Size: 0x10
	struct FMulticastInlineDelegate OnItemDropped; // Offset: 0xa80 // Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDropped; // Offset: 0xa90 // Size: 0x10
	char pad_0xAA0[0x50]; // Offset: 0xaa0 // Size: 0x50

	// Functions

	// Object Name: Function AkAudio.AkCheckBox.SetIsChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsChecked(bool InIsChecked); // Offset: 0x102324634 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.SetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCheckedState(enum class ECheckBoxState InCheckedState); // Offset: 0x1023245b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.SetAkItemId
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetAkItemId(struct FGuid& ItemID); // Offset: 0x10232452c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkCheckBox.SetAkBoolProperty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAkBoolProperty(struct FString ItemProperty); // Offset: 0x102324470 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkCheckBox.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x102324720 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.IsChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsChecked(); // Offset: 0x1023246ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.GetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECheckBoxState GetCheckedState(); // Offset: 0x1023246b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.GetAkProperty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetAkProperty(); // Offset: 0x1023243d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkCheckBox.GetAkItemId
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FGuid GetAkItemId(); // Offset: 0x1023244f8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkGameplayStatics
// Size: 0x28 // Inherited bytes: 0x28
struct UAkGameplayStatics : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkGameplayStatics.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void UseReverbVolumes(bool inUseReverbVolumes, struct AActor* Actor); // Offset: 0x102327d68 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.UseEarlyReflections
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UseEarlyReflections(struct AActor* Actor, struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName); // Offset: 0x102327b48 // Return & Params: Num(7) Size(0x30)

	// Object Name: Function AkAudio.AkGameplayStatics.UnloadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void UnloadBankByName(struct FString BankName, bool IsAsync); // Offset: 0x102326f28 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkGameplayStatics.UnloadBankAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void UnloadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankUnloadedCallback); // Offset: 0x102326ff4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.UnloadBank
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnloadBank(struct UAkAudioBank* Bank, struct FString BankName, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject); // Offset: 0x1023270e0 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function AkAudio.AkGameplayStatics.StopProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopProfilerCapture(); // Offset: 0x102326d80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopOutputCapture(); // Offset: 0x102326e14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopAllAmbientSounds(struct UObject* WorldContextObject); // Offset: 0x10232742c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.StopAll
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopAll(); // Offset: 0x1023275c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopActor
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopActor(struct AActor* Actor); // Offset: 0x1023275d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.StartProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StartProfilerCapture(struct FString Filename); // Offset: 0x102326d94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.StartOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StartOutputCapture(struct FString Filename); // Offset: 0x102326ea8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.StartAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StartAllAmbientSounds(struct UObject* WorldContextObject); // Offset: 0x1023274a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.SpawnAkComponentAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAkComponent* SpawnAkComponentAtLocation(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct UAkAuxBus* EarlyReflectionsBus, struct FVector Location, struct FRotator Orientation, bool AutoPost, struct FString EventName, struct FString EarlyReflectionsBusName, bool AutoDestroy); // Offset: 0x10232895c // Return & Params: Num(10) Size(0x68)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetSwitch(struct FName SwitchGroup, struct FName SwitchState, struct AActor* Actor); // Offset: 0x1023283b4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.SetState
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetState(struct FName StateGroup, struct FName State); // Offset: 0x102328560 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSpeakerAngles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetSpeakerAngles(struct TArray<float>& SpeakerAngles, float HeightAngle, struct FString DeviceShareset); // Offset: 0x102327704 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AkAudio.AkGameplayStatics.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	bool SetRTPCValue(struct FName RTPC, float Value, int32_t InterpolationTimeMs, struct AActor* Actor); // Offset: 0x102328814 // Return & Params: Num(5) Size(0x19)

	// Object Name: Function AkAudio.AkGameplayStatics.SetPanningRule
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPanningRule(enum class PanningRule PanRule); // Offset: 0x102327958 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkGameplayStatics.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetOutputBusVolume(float BusVolume, struct AActor* Actor); // Offset: 0x102327a90 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOcclusionScalingFactor(float ScalingFactor); // Offset: 0x102326d04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkGameplayStatics.SetOcclusionRefreshInterval
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetOcclusionRefreshInterval(float RefreshInterval, struct AActor* Actor); // Offset: 0x10232764c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetMultiplePositions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMultiplePositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType); // Offset: 0x10232823c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function AkAudio.AkGameplayStatics.SetMultipleChannelMaskEmitterPositions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMultipleChannelMaskEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FAkChannelMask> ChannelMasks, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType); // Offset: 0x102327e2c // Return & Params: Num(4) Size(0x29)

	// Object Name: Function AkAudio.AkGameplayStatics.SetMultipleChannelEmitterPositions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMultipleChannelEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<enum class AkChannelConfiguration> ChannelMasks, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType); // Offset: 0x102328034 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function AkAudio.AkGameplayStatics.SetLanguageWithPriority
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SetLanguageWithPriority(struct FString PriorityLanguage); // Offset: 0x102326b50 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkGameplayStatics.SetCultureLanguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SetCultureLanguage(struct FString CultureName); // Offset: 0x102326c58 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkGameplayStatics.SetBusConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetBusConfig(struct FString BusName, enum class AkChannelConfiguration ChannelConfiguration); // Offset: 0x1023279cc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkGameplayStatics.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void PostTrigger(struct FName Trigger, struct AActor* Actor); // Offset: 0x1023284ac // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.PostExternalEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t PostExternalEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FString> InfoNames, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Offset: 0x102329eb8 // Return & Params: Num(8) Size(0x54)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t PostEventByName(struct FString EventName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed); // Offset: 0x10232940c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAttachedByActorRole
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t PostEventAttachedByActorRole(struct AActor* Actor, struct UAkAudioEvent* LocallyAkEvent, struct UAkAudioEvent* OthersAkEvent, struct AActor* AttachActor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Offset: 0x1023297ec // Return & Params: Num(10) Size(0x64)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAttached
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t PostEventAttached(struct UAkAudioEvent* AkEvent, struct AActor* Actor, struct FName AttachPointName, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Offset: 0x10232a298 // Return & Params: Num(6) Size(0x34)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAtLocationByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	void PostEventAtLocationByName(struct FString EventName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject); // Offset: 0x102328f24 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAtLocationByActorRole
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	int32_t PostEventAtLocationByActorRole(struct AActor* Actor, struct UAkAudioEvent* LocallyAkEvent, struct UAkAudioEvent* OthersAkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject); // Offset: 0x102329068 // Return & Params: Num(8) Size(0x4c)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	int32_t PostEventAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject); // Offset: 0x10232927c // Return & Params: Num(6) Size(0x3c)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t PostEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Offset: 0x102329ba0 // Return & Params: Num(8) Size(0x54)

	// Object Name: Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t PostAndWaitForEndOfEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString EventName, struct FLatentActionInfo LatentInfo); // Offset: 0x102329524 // Return & Params: Num(7) Size(0x54)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadInitBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void LoadInitBank(); // Offset: 0x10232724c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void LoadBankByName(struct FString BankName, bool IsAsync); // Offset: 0x102327260 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBankAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LoadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankLoadedCallback); // Offset: 0x10232732c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.IsGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsGame(struct UObject* WorldContextObject); // Offset: 0x10232a4a4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AkAudio.AkGameplayStatics.IsEditor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEditor(); // Offset: 0x10232a520 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkGameplayStatics.GetSpeakerAngles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetSpeakerAngles(struct TArray<float>& SpeakerAngles, float& HeightAngle, struct FString DeviceShareset); // Offset: 0x102327824 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AkAudio.AkGameplayStatics.GetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetRTPCValue(struct FName RTPC, int32_t PlayingID, enum class ERTPCValueType InputValueType, float& Value, enum class ERTPCValueType& OutputValueType, struct AActor* Actor); // Offset: 0x102328614 // Return & Params: Num(6) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.GetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetOcclusionScalingFactor(); // Offset: 0x102326ce0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkGameplayStatics.GetCultureLanguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetCultureLanguage(); // Offset: 0x102326bd8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.GetAkComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UAkComponent* GetAkComponent(struct USceneComponent* AttachToComponent, bool& ComponentCreated, struct FName AttachPointName, struct FVector Location, enum class EAttachLocation LocationType); // Offset: 0x10232a554 // Return & Params: Num(6) Size(0x30)

	// Object Name: Function AkAudio.AkGameplayStatics.ExecuteActionOnPlayingID
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void ExecuteActionOnPlayingID(enum class AkActionOnEventType ActionType, int32_t PlayingID, int32_t TransitionDuration, enum class EAkCurveInterpolation FadeCurve); // Offset: 0x102328c20 // Return & Params: Num(4) Size(0xd)

	// Object Name: Function AkAudio.AkGameplayStatics.ExecuteActionOnEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void ExecuteActionOnEvent(struct UAkAudioEvent* AkEvent, enum class AkActionOnEventType ActionType, struct AActor* Actor, int32_t TransitionDuration, enum class EAkCurveInterpolation FadeCurve, int32_t PlayingID); // Offset: 0x102328d5c // Return & Params: Num(6) Size(0x24)

	// Object Name: Function AkAudio.AkGameplayStatics.ClearExtSrcCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearExtSrcCache(); // Offset: 0x102326b3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.ClearBanks
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void ClearBanks(); // Offset: 0x102327418 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.CancelEventCallback
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CancelEventCallback(struct FDelegate& PostEventCallback); // Offset: 0x102327514 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.AddOutputCaptureMarker
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void AddOutputCaptureMarker(struct FString MarkerText); // Offset: 0x102326e28 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkCallbackInfo
// Size: 0x30 // Inherited bytes: 0x28
struct UAkCallbackInfo : UObject {
	// Fields
	struct UAkComponent* AkComponent; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class AkAudio.AkEventCallbackInfo
// Size: 0x38 // Inherited bytes: 0x30
struct UAkEventCallbackInfo : UAkCallbackInfo {
	// Fields
	int32_t PlayingID; // Offset: 0x30 // Size: 0x04
	int32_t EventID; // Offset: 0x34 // Size: 0x04
};

// Object Name: Class AkAudio.AkMIDIEventCallbackInfo
// Size: 0x40 // Inherited bytes: 0x38
struct UAkMIDIEventCallbackInfo : UAkEventCallbackInfo {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08

	// Functions

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetType
	// Flags: [Final|Native|Public|BlueprintCallable]
	enum class EAkMidiEventType GetType(); // Offset: 0x10232ec08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetProgramChange
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetProgramChange(struct FAkMidiProgramChange& AsProgramChange); // Offset: 0x10232e6ec // Return & Params: Num(2) Size(0x4)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetPitchBend
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetPitchBend(struct FAkMidiPitchBend& AsPitchBend); // Offset: 0x10232e8c8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOn
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetNoteOn(struct FAkMidiNoteOnOff& AsNoteOn); // Offset: 0x10232ea9c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOff
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetNoteOff(struct FAkMidiNoteOnOff& AsNoteOff); // Offset: 0x10232ea00 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetNoteAftertouch
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetNoteAftertouch(struct FAkMidiNoteAftertouch& AsNoteAftertouch); // Offset: 0x10232e82c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetGeneric
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetGeneric(struct FAkMidiGeneric& AsGeneric); // Offset: 0x10232eb38 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetChannelAftertouch
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetChannelAftertouch(struct FAkMidiChannelAftertouch& AsChannelAftertouch); // Offset: 0x10232e78c // Return & Params: Num(2) Size(0x4)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	char GetChannel(); // Offset: 0x10232ebd4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetCc
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetCc(struct FAkMidiCc& AsCc); // Offset: 0x10232e964 // Return & Params: Num(2) Size(0x5)
};

// Object Name: Class AkAudio.AkMarkerCallbackInfo
// Size: 0x50 // Inherited bytes: 0x38
struct UAkMarkerCallbackInfo : UAkEventCallbackInfo {
	// Fields
	int32_t Identifier; // Offset: 0x38 // Size: 0x04
	int32_t Position; // Offset: 0x3c // Size: 0x04
	struct FString Label; // Offset: 0x40 // Size: 0x10
};

// Object Name: Class AkAudio.AkDurationCallbackInfo
// Size: 0x50 // Inherited bytes: 0x38
struct UAkDurationCallbackInfo : UAkEventCallbackInfo {
	// Fields
	float Duration; // Offset: 0x38 // Size: 0x04
	float EstimatedDuration; // Offset: 0x3c // Size: 0x04
	int32_t AudioNodeID; // Offset: 0x40 // Size: 0x04
	int32_t MediaID; // Offset: 0x44 // Size: 0x04
	bool bStreaming; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
};

// Object Name: Class AkAudio.AkMusicSyncCallbackInfo
// Size: 0x70 // Inherited bytes: 0x30
struct UAkMusicSyncCallbackInfo : UAkCallbackInfo {
	// Fields
	int32_t PlayingID; // Offset: 0x30 // Size: 0x04
	struct FAkSegmentInfo SegmentInfo; // Offset: 0x34 // Size: 0x24
	enum class EAkCallbackType MusicSyncType; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
	struct FString UserCueName; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class AkAudio.AkIOSInitializationSettings
// Size: 0x198 // Inherited bytes: 0x28
struct UAkIOSInitializationSettings : UObject {
	// Fields
	struct FAkCommonInitializationSettingsWithSampleRateAndAudioLevel CommonSettings; // Offset: 0x28 // Size: 0x88
	struct FAkAudioSession AudioSession; // Offset: 0xb0 // Size: 0x0c
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0xc0 // Size: 0x28
	struct FAkAudioLevelFolderPaths AudioLevelSettings; // Offset: 0xe8 // Size: 0x70
	struct FAkAdvancedInitializationSettings AdvancedSettings; // Offset: 0x158 // Size: 0x3c
	char pad_0x194[0x4]; // Offset: 0x194 // Size: 0x04
};

// Object Name: Class AkAudio.AkItemBoolPropertiesConv
// Size: 0x28 // Inherited bytes: 0x28
struct UAkItemBoolPropertiesConv : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkBoolPropertyToControlToText(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl); // Offset: 0x102334900 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkBoolPropertyToControlToString(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl); // Offset: 0x102334a04 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkItemBoolProperties
// Size: 0x150 // Inherited bytes: 0x110
struct UAkItemBoolProperties : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x110 // Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDragged; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x20]; // Offset: 0x130 // Size: 0x20

	// Functions

	// Object Name: Function AkAudio.AkItemBoolProperties.SetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetSearchText(struct FString newText); // Offset: 0x102334d38 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkItemBoolProperties.GetSelectedProperty
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSelectedProperty(); // Offset: 0x102334e40 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkItemBoolProperties.GetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSearchText(); // Offset: 0x102334dc0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkItemPropertiesConv
// Size: 0x28 // Inherited bytes: 0x28
struct UAkItemPropertiesConv : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkPropertyToControlToText(struct FAkPropertyToControl& INAkPropertyToControl); // Offset: 0x1023352e8 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkPropertyToControlToString(struct FAkPropertyToControl& INAkPropertyToControl); // Offset: 0x1023353ec // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkItemProperties
// Size: 0x150 // Inherited bytes: 0x110
struct UAkItemProperties : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x110 // Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDragged; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x20]; // Offset: 0x130 // Size: 0x20

	// Functions

	// Object Name: Function AkAudio.AkItemProperties.SetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetSearchText(struct FString newText); // Offset: 0x102335720 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkItemProperties.GetSelectedProperty
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSelectedProperty(); // Offset: 0x102335828 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkItemProperties.GetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSearchText(); // Offset: 0x1023357a8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkLateReverbComponent
// Size: 0x2a0 // Inherited bytes: 0x260
struct UAkLateReverbComponent : USceneComponent {
	// Fields
	char bEnable : 1; // Offset: 0x258 // Size: 0x01
	struct UAkAuxBus* AuxBus; // Offset: 0x260 // Size: 0x08
	struct FString AuxBusName; // Offset: 0x268 // Size: 0x10
	float SendLevel; // Offset: 0x278 // Size: 0x04
	float FadeRate; // Offset: 0x27c // Size: 0x04
	float Priority; // Offset: 0x280 // Size: 0x04
	char pad_0x284_1 : 7; // Offset: 0x284 // Size: 0x01
	char pad_0x285[0x3]; // Offset: 0x285 // Size: 0x03
	struct UAkLateReverbComponent* NextLowerPriorityComponent; // Offset: 0x288 // Size: 0x08
	char pad_0x290[0x10]; // Offset: 0x290 // Size: 0x10
};

// Object Name: Class AkAudio.AkLinuxInitializationSettings
// Size: 0x100 // Inherited bytes: 0x28
struct UAkLinuxInitializationSettings : UObject {
	// Fields
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x28 // Size: 0x70
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xc0 // Size: 0x40

	// Functions

	// Object Name: Function AkAudio.AkLinuxInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x102335e08 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkLuminInitializationSettings
// Size: 0x100 // Inherited bytes: 0x28
struct UAkLuminInitializationSettings : UObject {
	// Fields
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x28 // Size: 0x70
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xc0 // Size: 0x40

	// Functions

	// Object Name: Function AkAudio.AkLuminInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x1023360a4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkMacInitializationSettings
// Size: 0x100 // Inherited bytes: 0x28
struct UAkMacInitializationSettings : UObject {
	// Fields
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x28 // Size: 0x70
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xc0 // Size: 0x40

	// Functions

	// Object Name: Function AkAudio.AkMacInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x102336340 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkPS4InitializationSettings
// Size: 0x100 // Inherited bytes: 0x28
struct UAkPS4InitializationSettings : UObject {
	// Fields
	struct FAkCommonInitializationSettings CommonSettings; // Offset: 0x28 // Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x90 // Size: 0x28
	struct FAkPS4AdvancedInitializationSettings AdvancedSettings; // Offset: 0xb8 // Size: 0x48

	// Functions

	// Object Name: Function AkAudio.AkPS4InitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x1023366c0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkReverbVolume
// Size: 0x2d8 // Inherited bytes: 0x2a0
struct AAkReverbVolume : AVolume {
	// Fields
	char bEnabled : 1; // Offset: 0x2a0 // Size: 0x01
	char pad_0x2A0_1 : 7; // Offset: 0x2a0 // Size: 0x01
	char pad_0x2A1[0x7]; // Offset: 0x2a1 // Size: 0x07
	struct UAkAuxBus* AuxBus; // Offset: 0x2a8 // Size: 0x08
	struct FString AuxBusName; // Offset: 0x2b0 // Size: 0x10
	float SendLevel; // Offset: 0x2c0 // Size: 0x04
	float FadeRate; // Offset: 0x2c4 // Size: 0x04
	float Priority; // Offset: 0x2c8 // Size: 0x04
	char pad_0x2CC[0x4]; // Offset: 0x2cc // Size: 0x04
	struct UAkLateReverbComponent* LateReverbComponent; // Offset: 0x2d0 // Size: 0x08
};

// Object Name: Class AkAudio.AkRoomComponent
// Size: 0x280 // Inherited bytes: 0x260
struct UAkRoomComponent : USceneComponent {
	// Fields
	char bEnable : 1; // Offset: 0x258 // Size: 0x01
	struct UAkRoomComponent* NextLowerPriorityComponent; // Offset: 0x260 // Size: 0x08
	float Priority; // Offset: 0x268 // Size: 0x04
	float WallOcclusion; // Offset: 0x26c // Size: 0x04
	char pad_0x270_1 : 7; // Offset: 0x270 // Size: 0x01
	char pad_0x271[0xf]; // Offset: 0x271 // Size: 0x0f
};

// Object Name: Class AkAudio.AkSettings
// Size: 0x1e0 // Inherited bytes: 0x28
struct UAkSettings : UObject {
	// Fields
	bool bCloseAkAudioModule; // Offset: 0x28 // Size: 0x01
	char MaxSimultaneousReverbVolumes; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x6]; // Offset: 0x2a // Size: 0x06
	struct FFilePath WwiseProjectPath; // Offset: 0x30 // Size: 0x10
	struct FDirectoryPath WwiseSoundBankFolder; // Offset: 0x40 // Size: 0x10
	bool bAutoConnectToWAAPI; // Offset: 0x50 // Size: 0x01
	bool bEnableAutoAssetSync; // Offset: 0x51 // Size: 0x01
	enum class ECollisionChannel DefaultOcclusionCollisionChannel; // Offset: 0x52 // Size: 0x01
	bool SoundOcclusionToggle; // Offset: 0x53 // Size: 0x01
	int32_t OcclusionOpenGrade; // Offset: 0x54 // Size: 0x04
	struct TMap<struct FString, struct FString> UnrealCultureToWwiseCulture; // Offset: 0x58 // Size: 0x50
	bool bEnableMultiCoreRendering; // Offset: 0xa8 // Size: 0x01
	bool MigratedEnableMultiCoreRendering; // Offset: 0xa9 // Size: 0x01
	char pad_0xAA[0x6]; // Offset: 0xaa // Size: 0x06
	struct FDirectoryPath WwiseWindowsInstallationPath; // Offset: 0xb0 // Size: 0x10
	struct FFilePath WwiseMacInstallationPath; // Offset: 0xc0 // Size: 0x10
	int32_t SoundSpeed; // Offset: 0xd0 // Size: 0x04
	int32_t MaxDelayTime; // Offset: 0xd4 // Size: 0x04
	struct FString AudioRegionFileFolder; // Offset: 0xd8 // Size: 0x10
	float ThirdPersonAudioRegionCheckInterval; // Offset: 0xe8 // Size: 0x04
	float RemoteAudioRegionCheckInterval; // Offset: 0xec // Size: 0x04
	bool bEnableEnemyAudioRegionUpdate; // Offset: 0xf0 // Size: 0x01
	bool bEnableRemoteAudioRegionUpdate; // Offset: 0xf1 // Size: 0x01
	bool EnableCharacterFolder; // Offset: 0xf2 // Size: 0x01
	bool EnableExtensionFolder; // Offset: 0xf3 // Size: 0x01
	bool EnableSingleExternalSourceObjectMode; // Offset: 0xf4 // Size: 0x01
	char pad_0xF5[0x3]; // Offset: 0xf5 // Size: 0x03
	struct TArray<struct FVoFolderData> VoFolders; // Offset: 0xf8 // Size: 0x10
	struct FString KeyWordsForEventNotUsingExtSrc; // Offset: 0x108 // Size: 0x10
	struct TArray<struct FVoTemplateData> VoTemplates; // Offset: 0x118 // Size: 0x10
	struct TMap<struct FString, struct FString> WemSuffixMapWithExternalSourceName; // Offset: 0x128 // Size: 0x50
	struct TArray<struct FString> HighFreqLogs; // Offset: 0x178 // Size: 0x10
	struct FString OutMemoryLogTxt; // Offset: 0x188 // Size: 0x10
	bool bReportOutMemoryLog; // Offset: 0x198 // Size: 0x01
	char pad_0x199[0x47]; // Offset: 0x199 // Size: 0x47
};

// Object Name: Class AkAudio.AkSettingsPerUser
// Size: 0x60 // Inherited bytes: 0x28
struct UAkSettingsPerUser : UObject {
	// Fields
	struct FDirectoryPath WwiseWindowsInstallationPath; // Offset: 0x28 // Size: 0x10
	struct FFilePath WwiseMacInstallationPath; // Offset: 0x38 // Size: 0x10
	struct FString WaapiIPAddress; // Offset: 0x48 // Size: 0x10
	uint32_t WaapiPort; // Offset: 0x58 // Size: 0x04
	bool SuppressWwiseProjectPathWarnings; // Offset: 0x5c // Size: 0x01
	char pad_0x5D[0x3]; // Offset: 0x5d // Size: 0x03
};

// Object Name: Class AkAudio.AkSlider
// Size: 0x538 // Inherited bytes: 0x110
struct UAkSlider : UWidget {
	// Fields
	float Value; // Offset: 0x110 // Size: 0x04
	struct FDelegate ValueDelegate; // Offset: 0x114 // Size: 0x10
	char pad_0x124[0x4]; // Offset: 0x124 // Size: 0x04
	struct FSliderStyle WidgetStyle; // Offset: 0x128 // Size: 0x340
	enum class EOrientation Orientation; // Offset: 0x468 // Size: 0x01
	char pad_0x469[0x3]; // Offset: 0x469 // Size: 0x03
	struct FLinearColor SliderBarColor; // Offset: 0x46c // Size: 0x10
	struct FLinearColor SliderHandleColor; // Offset: 0x47c // Size: 0x10
	bool IndentHandle; // Offset: 0x48c // Size: 0x01
	bool Locked; // Offset: 0x48d // Size: 0x01
	char pad_0x48E[0x2]; // Offset: 0x48e // Size: 0x02
	float StepSize; // Offset: 0x490 // Size: 0x04
	bool IsFocusable; // Offset: 0x494 // Size: 0x01
	char pad_0x495[0x3]; // Offset: 0x495 // Size: 0x03
	struct FAkPropertyToControl ThePropertyToControl; // Offset: 0x498 // Size: 0x10
	struct FAkWwiseItemToControl ItemToControl; // Offset: 0x4a8 // Size: 0x40
	struct FMulticastInlineDelegate OnValueChanged; // Offset: 0x4e8 // Size: 0x10
	struct FMulticastInlineDelegate OnItemDropped; // Offset: 0x4f8 // Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDropped; // Offset: 0x508 // Size: 0x10
	char pad_0x518[0x20]; // Offset: 0x518 // Size: 0x20

	// Functions

	// Object Name: Function AkAudio.AkSlider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValue(float InValue); // Offset: 0x10233797c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkSlider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStepSize(float InValue); // Offset: 0x1023377f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkSlider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderHandleColor(struct FLinearColor InValue); // Offset: 0x102337700 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.SetSliderBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderBarColor(struct FLinearColor InValue); // Offset: 0x10233777c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLocked(bool InValue); // Offset: 0x102337874 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkSlider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIndentHandle(bool InValue); // Offset: 0x1023378f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkSlider.SetAkSliderItemProperty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAkSliderItemProperty(struct FString ItemProperty); // Offset: 0x1023375b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.SetAkSliderItemId
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetAkSliderItemId(struct FGuid& ItemID); // Offset: 0x102337674 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValue(); // Offset: 0x1023379f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkSlider.GetAkSliderItemProperty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetAkSliderItemProperty(); // Offset: 0x102337518 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.GetAkSliderItemId
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FGuid GetAkSliderItemId(); // Offset: 0x102337640 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkSpatialAudioVolume
// Size: 0x2b8 // Inherited bytes: 0x2a0
struct AAkSpatialAudioVolume : AVolume {
	// Fields
	struct UAkSurfaceReflectorSetComponent* SurfaceReflectorSet; // Offset: 0x2a0 // Size: 0x08
	struct UAkLateReverbComponent* LateReverb; // Offset: 0x2a8 // Size: 0x08
	struct UAkRoomComponent* Room; // Offset: 0x2b0 // Size: 0x08
};

// Object Name: Class AkAudio.AkSpotReflector
// Size: 0x298 // Inherited bytes: 0x268
struct AAkSpotReflector : AActor {
	// Fields
	struct UAkAuxBus* AuxBus; // Offset: 0x268 // Size: 0x08
	struct FString AuxBusName; // Offset: 0x270 // Size: 0x10
	struct UAkAcousticTexture* AcousticTexture; // Offset: 0x280 // Size: 0x08
	float DistanceScalingFactor; // Offset: 0x288 // Size: 0x04
	float Level; // Offset: 0x28c // Size: 0x04
	char pad_0x290[0x8]; // Offset: 0x290 // Size: 0x08
};

// Object Name: Class AkAudio.AkSurfaceReflectorSetComponent
// Size: 0x290 // Inherited bytes: 0x260
struct UAkSurfaceReflectorSetComponent : USceneComponent {
	// Fields
	char bEnableSurfaceReflectors : 1; // Offset: 0x258 // Size: 0x01
	struct TArray<struct FAkPoly> AcousticPolys; // Offset: 0x260 // Size: 0x10
	char bEnableDiffraction : 1; // Offset: 0x270 // Size: 0x01
	char bEnableDiffractionOnBoundaryEdges : 1; // Offset: 0x270 // Size: 0x01
	char pad_0x270_3 : 5; // Offset: 0x270 // Size: 0x01
	char pad_0x271[0x7]; // Offset: 0x271 // Size: 0x07
	struct AActor* AssociatedRoom; // Offset: 0x278 // Size: 0x08
	char pad_0x280[0x10]; // Offset: 0x280 // Size: 0x10

	// Functions

	// Object Name: Function AkAudio.AkSurfaceReflectorSetComponent.UpdateSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateSurfaceReflectorSet(); // Offset: 0x102338358 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkSurfaceReflectorSetComponent.SendSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendSurfaceReflectorSet(); // Offset: 0x102338380 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkSurfaceReflectorSetComponent.RemoveSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveSurfaceReflectorSet(); // Offset: 0x10233836c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkSwitchInitializationSettings
// Size: 0xf8 // Inherited bytes: 0x28
struct UAkSwitchInitializationSettings : UObject {
	// Fields
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x28 // Size: 0x70
	struct FAkCommunicationSettings CommunicationSettings; // Offset: 0x98 // Size: 0x20
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xb8 // Size: 0x40

	// Functions

	// Object Name: Function AkAudio.AkSwitchInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x10233b728 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkWaapiCalls
// Size: 0x28 // Inherited bytes: 0x28
struct UAkWaapiCalls : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkWaapiCalls.Unsubscribe
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject Unsubscribe(struct FAkWaapiSubscriptionId& SubscriptionId, bool& UnsubscriptionDone); // Offset: 0x10233bd90 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function AkAudio.AkWaapiCalls.SubscribeToWaapi
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SubscribeToWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiOptions, struct FDelegate& Callback, struct FAkWaapiSubscriptionId& SubscriptionId, bool& SubscriptionDone); // Offset: 0x10233bf4c // Return & Params: Num(6) Size(0x50)

	// Object Name: Function AkAudio.AkWaapiCalls.SetSubscriptionID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription, int32_t ID); // Offset: 0x10233c82c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AkAudio.AkWaapiCalls.RegisterWaapiProjectLoadedCallback
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool RegisterWaapiProjectLoadedCallback(struct FDelegate& Callback); // Offset: 0x10233c6e0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkWaapiCalls.RegisterWaapiConnectionLostCallback
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool RegisterWaapiConnectionLostCallback(struct FDelegate& Callback); // Offset: 0x10233c620 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkWaapiCalls.GetSubscriptionID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t GetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription); // Offset: 0x10233c7a0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkWaapiSubscriptionIdToText(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId); // Offset: 0x10233bbc8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkWaapiSubscriptionIdToString(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId); // Offset: 0x10233bcc0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkWaapiCalls.CallWaapi
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject CallWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiArgs, struct FAKWaapiJsonObject& WaapiOptions); // Offset: 0x10233c2d0 // Return & Params: Num(4) Size(0x40)
};

// Object Name: Class AkAudio.SAkWaapiFieldNamesConv
// Size: 0x28 // Inherited bytes: 0x28
struct USAkWaapiFieldNamesConv : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkWaapiFieldNamesToText(struct FAkWaapiFieldNames& INAkWaapiFieldNames); // Offset: 0x10233ced0 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkWaapiFieldNamesToString(struct FAkWaapiFieldNames& INAkWaapiFieldNames); // Offset: 0x10233cfd4 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkWaapiJsonManager
// Size: 0x28 // Inherited bytes: 0x28
struct UAkWaapiJsonManager : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetStringField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetStringField(struct FAkWaapiFieldNames& FieldName, struct FString FieldValue, struct FAKWaapiJsonObject Target); // Offset: 0x10233f710 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetObjectField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject FieldValue, struct FAKWaapiJsonObject Target); // Offset: 0x10233ecd4 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetNumberField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetNumberField(struct FAkWaapiFieldNames& FieldName, float FieldValue, struct FAKWaapiJsonObject Target); // Offset: 0x10233f0f0 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetBoolField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetBoolField(struct FAkWaapiFieldNames& FieldName, bool FieldValue, struct FAKWaapiJsonObject Target); // Offset: 0x10233f3f8 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetArrayStringFields
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetArrayStringFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FString>& FieldStringValues, struct FAKWaapiJsonObject Target); // Offset: 0x10233e970 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetArrayObjectFields
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetArrayObjectFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FAKWaapiJsonObject>& FieldObjectValues, struct FAKWaapiJsonObject Target); // Offset: 0x10233e5c0 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetStringField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString GetStringField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x10233e390 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetObjectField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject GetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x10233dae8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetNumberField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	float GetNumberField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x10233dfa8 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetIntegerField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t GetIntegerField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x10233ddb4 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetBoolField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetBoolField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x10233e19c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetArrayField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FAKWaapiJsonObject> GetArrayField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x10233d76c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToText
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAKWaapiJsonObjectToText(struct FAKWaapiJsonObject INAKWaapiJsonObject); // Offset: 0x10233d394 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAKWaapiJsonObjectToString(struct FAKWaapiJsonObject INAKWaapiJsonObject); // Offset: 0x10233d598 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkWaapiUriConv
// Size: 0x28 // Inherited bytes: 0x28
struct UAkWaapiUriConv : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkWaapiUriToText(struct FAkWaapiUri& INAkWaapiUri); // Offset: 0x1023400bc // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkWaapiUriToString(struct FAkWaapiUri& INAkWaapiUri); // Offset: 0x1023401c0 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkWindowsInitializationSettings
// Size: 0x190 // Inherited bytes: 0x28
struct UAkWindowsInitializationSettings : UObject {
	// Fields
	struct FAkCommonInitializationSettingsWithSampleRateAndAudioLevel CommonSettings; // Offset: 0x28 // Size: 0x88
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0xb0 // Size: 0x28
	struct FAkAudioLevelFolderPaths AudioLevelSettings; // Offset: 0xd8 // Size: 0x70
	struct FAkWindowsAdvancedInitializationSettings AdvancedSettings; // Offset: 0x148 // Size: 0x48

	// Functions

	// Object Name: Function AkAudio.AkWindowsInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x102340680 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkWwiseTree
// Size: 0x150 // Inherited bytes: 0x110
struct UAkWwiseTree : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x110 // Size: 0x10
	struct FMulticastInlineDelegate OnItemDragged; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x20]; // Offset: 0x130 // Size: 0x20

	// Functions

	// Object Name: Function AkAudio.AkWwiseTree.SetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetSearchText(struct FString newText); // Offset: 0x1023409b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkWwiseTree.GetSelectedItem
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAkWwiseObjectDetails GetSelectedItem(); // Offset: 0x102340abc // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AkAudio.AkWwiseTree.GetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSearchText(); // Offset: 0x102340a3c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkWwiseTreeSelector
// Size: 0x170 // Inherited bytes: 0x110
struct UAkWwiseTreeSelector : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x110 // Size: 0x10
	struct FMulticastInlineDelegate OnItemDragged; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x40]; // Offset: 0x130 // Size: 0x40
};

// Object Name: Class AkAudio.AkXboxOneInitializationSettings
// Size: 0x108 // Inherited bytes: 0x28
struct UAkXboxOneInitializationSettings : UObject {
	// Fields
	struct FAkCommonInitializationSettings CommonSettings; // Offset: 0x28 // Size: 0x68
	struct FAkXboxOneApuHeapInitializationSettings ApuHeapSettings; // Offset: 0x90 // Size: 0x08
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkXboxOneAdvancedInitializationSettings AdvancedSettings; // Offset: 0xc0 // Size: 0x48

	// Functions

	// Object Name: Function AkAudio.AkXboxOneInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x102341120 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.ApexAkInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UApexAkInterface : UInterface {
};

// Object Name: Class AkAudio.InterpTrackAkAudioEvent
// Size: 0xa8 // Inherited bytes: 0x90
struct UInterpTrackAkAudioEvent : UInterpTrackVectorBase {
	// Fields
	struct TArray<struct FAkAudioEventTrackKey> Events; // Offset: 0x90 // Size: 0x10
	char bContinueEventOnMatineeEnd : 1; // Offset: 0xa0 // Size: 0x01
	char pad_0xA0_1 : 7; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
};

// Object Name: Class AkAudio.InterpTrackAkAudioRTPC
// Size: 0xa8 // Inherited bytes: 0x90
struct UInterpTrackAkAudioRTPC : UInterpTrackFloatBase {
	// Fields
	struct FString Param; // Offset: 0x90 // Size: 0x10
	char bPlayOnReverse : 1; // Offset: 0xa0 // Size: 0x01
	char bContinueRTPCOnMatineeEnd : 1; // Offset: 0xa0 // Size: 0x01
	char pad_0xA0_2 : 6; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
};

// Object Name: Class AkAudio.InterpTrackInstAkAudioEvent
// Size: 0x30 // Inherited bytes: 0x28
struct UInterpTrackInstAkAudioEvent : UInterpTrackInst {
	// Fields
	float LastUpdatePosition; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class AkAudio.InterpTrackInstAkAudioRTPC
// Size: 0x30 // Inherited bytes: 0x28
struct UInterpTrackInstAkAudioRTPC : UInterpTrackInst {
	// Fields
	float LastUpdatePosition; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class AkAudio.MovieSceneAkAudioEventSection
// Size: 0x1d8 // Inherited bytes: 0xd8
struct UMovieSceneAkAudioEventSection : UMovieSceneSection {
	// Fields
	char pad_0xD8[0x58]; // Offset: 0xd8 // Size: 0x58
	struct UAkAudioEvent* Event; // Offset: 0x130 // Size: 0x08
	bool RetriggerEvent; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0x3]; // Offset: 0x139 // Size: 0x03
	int32_t ScrubTailLengthMs; // Offset: 0x13c // Size: 0x04
	bool StopAtSectionEnd; // Offset: 0x140 // Size: 0x01
	char pad_0x141[0x7]; // Offset: 0x141 // Size: 0x07
	struct FString EventName; // Offset: 0x148 // Size: 0x10
	char pad_0x158[0x20]; // Offset: 0x158 // Size: 0x20
	float MaxSourceDuration; // Offset: 0x178 // Size: 0x04
	char pad_0x17C[0x4]; // Offset: 0x17c // Size: 0x04
	struct FString MaxDurationSourceID; // Offset: 0x180 // Size: 0x10
	char pad_0x190[0x48]; // Offset: 0x190 // Size: 0x48
};

// Object Name: Class AkAudio.MovieSceneAkTrack
// Size: 0x70 // Inherited bytes: 0x58
struct UMovieSceneAkTrack : UMovieSceneTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 // Size: 0x10
	char bIsAMasterTrack : 1; // Offset: 0x68 // Size: 0x01
	char pad_0x68_1 : 7; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: Class AkAudio.MovieSceneAkAudioEventTrack
// Size: 0x70 // Inherited bytes: 0x70
struct UMovieSceneAkAudioEventTrack : UMovieSceneAkTrack {
};

// Object Name: Class AkAudio.MovieSceneAkAudioRTPCSection
// Size: 0x238 // Inherited bytes: 0xd8
struct UMovieSceneAkAudioRTPCSection : UMovieSceneSection {
	// Fields
	struct FString Name; // Offset: 0xd8 // Size: 0x10
	struct FRichCurve FloatCurve; // Offset: 0xe8 // Size: 0x80
	struct FMovieSceneFloatChannelSerializationHelper FloatChannelSerializationHelper; // Offset: 0x168 // Size: 0x30
	char pad_0x198[0xa0]; // Offset: 0x198 // Size: 0xa0
};

// Object Name: Class AkAudio.MovieSceneAkAudioRTPCTrack
// Size: 0x70 // Inherited bytes: 0x70
struct UMovieSceneAkAudioRTPCTrack : UMovieSceneAkTrack {
};

