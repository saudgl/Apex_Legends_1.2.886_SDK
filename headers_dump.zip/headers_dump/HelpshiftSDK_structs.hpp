#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct HelpshiftSDK.HelpshiftMapWrapper
// Size: 0x50 // Inherited bytes: 0x00
struct FHelpshiftMapWrapper {
	// Fields
	struct TMap<struct FString, struct FHelpshiftConfigParameter> Data; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct HelpshiftSDK.HelpshiftConfigParameter
// Size: 0x20 // Inherited bytes: 0x00
struct FHelpshiftConfigParameter {
	// Fields
	enum class EHelpshiftConfigParameterValueType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x1f]; // Offset: 0x01 // Size: 0x1f
};

// Object Name: ScriptStruct HelpshiftSDK.HelpshiftCustomIssueFieldParameter
// Size: 0x20 // Inherited bytes: 0x00
struct FHelpshiftCustomIssueFieldParameter {
	// Fields
	enum class EHelpshiftCustomIssueFieldParameterValueType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x1f]; // Offset: 0x01 // Size: 0x1f
};

