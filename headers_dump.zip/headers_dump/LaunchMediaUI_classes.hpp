#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass LaunchMediaUI.LaunchMediaUI_C
// Size: 0x3e0 // Inherited bytes: 0x3b0
struct ULaunchMediaUI_C : UGameUserWidget {
	// Fields
	struct UBp_CommonCG_Skip_C* CGSkip; // Offset: 0x3b0 // Size: 0x08
	struct UBp_CommonMediaWithSubtitle_C* LoopCGMedia; // Offset: 0x3b8 // Size: 0x08
	struct UBp_CommonMediaWithSubtitle_C* OpenCGMedia; // Offset: 0x3c0 // Size: 0x08
	struct UButton* SkipBtn; // Offset: 0x3c8 // Size: 0x08
	struct UTextBlock* Subtitle; // Offset: 0x3d0 // Size: 0x08
	struct UAkComponent* AkComponent; // Offset: 0x3d8 // Size: 0x08

	// Functions

	// Object Name: Function LaunchMediaUI.LaunchMediaUI_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x10)
};

