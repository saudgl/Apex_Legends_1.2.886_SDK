#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum SpinePlugin.ESpineWidgetAreaType
enum class ESpineWidgetAreaType : uint8 {
	Bounds = 0,
	Scale = 1,
	ESpineWidgetAreaType_MAX = 2
};

