#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum GameAction_Runtime.EGameActionAnimationTearDownStrategy
enum class EGameActionAnimationTearDownStrategy : uint8 {
	Stop = 0,
	PlayToEnd = 1,
	EGameActionAnimationTearDownStrategy_MAX = 2
};

// Object Name: Enum GameAction_Runtime.EGameActionSpawnOwnership
enum class EGameActionSpawnOwnership : uint8 {
	Sequence = 0,
	Instance = 1,
	External = 2,
	EGameActionSpawnOwnership_MAX = 3
};

// Object Name: Enum GameAction_Runtime.EGameActionPlayerEndAction
enum class EGameActionPlayerEndAction : uint8 {
	Stop = 0,
	Loop = 1,
	Pause = 2,
	EGameActionPlayerEndAction_MAX = 3
};

