#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GridManager.GridDataTable
// Size: 0xb8 // Inherited bytes: 0x30
struct UGridDataTable : UDataAsset {
	// Fields
	bool bMinimal; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	int32_t Row; // Offset: 0x34 // Size: 0x04
	int32_t Col; // Offset: 0x38 // Size: 0x04
	int32_t MinimalType; // Offset: 0x3c // Size: 0x04
	struct TArray<int32_t> DataTable; // Offset: 0x40 // Size: 0x10
	int32_t MaxTypeCount; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TMap<char, char> ValueMap; // Offset: 0x58 // Size: 0x50
	int32_t RootTreeType; // Offset: 0xa8 // Size: 0x04
	int32_t RootTreeValue; // Offset: 0xac // Size: 0x04
	int32_t Version; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04
};

// Object Name: Class GridManager.GridDataManager
// Size: 0x138 // Inherited bytes: 0x28
struct UGridDataManager : UObject {
	// Fields
	struct FVector Origin; // Offset: 0x28 // Size: 0x0c
	float GridSize; // Offset: 0x34 // Size: 0x04
	int32_t StreamingSize; // Offset: 0x38 // Size: 0x04
	int32_t Row; // Offset: 0x3c // Size: 0x04
	int32_t Col; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct UGridDataTable* GridDataTablePtr; // Offset: 0x48 // Size: 0x08
	struct TSoftObjectPtr<UGridDataTable> GridDataTable; // Offset: 0x50 // Size: 0x28
	struct TArray<struct TSoftObjectPtr<UGridDataTable>> GridDataTableStreaming; // Offset: 0x78 // Size: 0x10
	struct TArray<struct UGridDataTable*> GridDataTableStreamingPtr; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0xa0]; // Offset: 0x98 // Size: 0xa0
};

// Object Name: Class GridManager.SurfaceGridManager
// Size: 0x98 // Inherited bytes: 0x30
struct USurfaceGridManager : UDataAsset {
	// Fields
	struct TSet<struct UGridDataManager*> GridDatas; // Offset: 0x30 // Size: 0x50
	char pad_0x80[0x18]; // Offset: 0x80 // Size: 0x18
};

// Object Name: Class GridManager.SurfaceTypeColorAsset
// Size: 0x80 // Inherited bytes: 0x30
struct USurfaceTypeColorAsset : UDataAsset {
	// Fields
	struct TMap<enum class EPhysicalSurface, struct FColor> SurfaceColorSetting; // Offset: 0x30 // Size: 0x50

	// Functions

	// Object Name: Function GridManager.SurfaceTypeColorAsset.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FColor GetColor(enum class EPhysicalSurface SurfaceType); // Offset: 0x10222c1d8 // Return & Params: Num(2) Size(0x8)
};

