#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum EntityDispatcher_Runtime.EDispatchableActionState
enum class EDispatchableActionState : uint8 {
	Unactived = 0,
	Actived = 1,
	Aborting = 2,
	Finished = 3,
	EDispatchableActionState_MAX = 4
};

// Object Name: Enum EntityDispatcher_Runtime.EDispatchableActionAbortState
enum class EDispatchableActionAbortState : uint8 {
	Initiative = 0,
	Passive = 1,
	EDispatchableActionAbortState_MAX = 2
};

// Object Name: Enum EntityDispatcher_Runtime.EDispatchableActionCompatibleType
enum class EDispatchableActionCompatibleType : uint8 {
	Abort = 0,
	Coexist = 1,
	Invalid = 2,
	EDispatchableActionCompatibleType_MAX = 3
};

// Object Name: Enum EntityDispatcher_Runtime.EActionDispatcherState
enum class EActionDispatcherState : uint8 {
	Unactived = 0,
	Actived = 1,
	Aborting = 2,
	Finished = 3,
	Finishing = 4,
	EActionDispatcherState_MAX = 5
};

