#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class HelpshiftSDK.HelpshiftConfigParameterFunctions
// Size: 0x28 // Inherited bytes: 0x28
struct UHelpshiftConfigParameterFunctions : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.GetString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString GetString(struct FHelpshiftConfigParameter& Variant); // Offset: 0x101f4d7ac // Return & Params: Num(2) Size(0x30)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.GetMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct TMap<struct FString, struct FHelpshiftConfigParameter> GetMap(struct FHelpshiftConfigParameter& Variant); // Offset: 0x101f4d53c // Return & Params: Num(2) Size(0x70)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.GetInteger
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t GetInteger(struct FHelpshiftConfigParameter& Variant); // Offset: 0x101f4d9c4 // Return & Params: Num(2) Size(0x24)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.GetFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float GetFloat(struct FHelpshiftConfigParameter& Variant); // Offset: 0x101f4d924 // Return & Params: Num(2) Size(0x24)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.GetBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetBool(struct FHelpshiftConfigParameter& Variant); // Offset: 0x101f4d884 // Return & Params: Num(2) Size(0x21)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.GetArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct TArray<struct FHelpshiftConfigParameter> GetArray(struct FHelpshiftConfigParameter& Variant); // Offset: 0x101f4d66c // Return & Params: Num(2) Size(0x30)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.Conv_StringToHelpshiftConfigParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHelpshiftConfigParameter Conv_StringToHelpshiftConfigParameter(struct FString Value); // Offset: 0x101f4dc90 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.Conv_MapToHelpshiftConfigParameter
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FHelpshiftConfigParameter Conv_MapToHelpshiftConfigParameter(struct TMap<struct FString, struct FHelpshiftConfigParameter>& Value); // Offset: 0x101f4da64 // Return & Params: Num(2) Size(0x70)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.Conv_intToHelpshiftConfigParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHelpshiftConfigParameter Conv_intToHelpshiftConfigParameter(int32_t Value); // Offset: 0x101f4df08 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.Conv_floatToHelpshiftConfigParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHelpshiftConfigParameter Conv_floatToHelpshiftConfigParameter(float Value); // Offset: 0x101f4de38 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.Conv_boolToHelpshiftConfigParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHelpshiftConfigParameter Conv_boolToHelpshiftConfigParameter(bool Value); // Offset: 0x101f4dd60 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function HelpshiftSDK.HelpshiftConfigParameterFunctions.Conv_ArrayToHelpshiftConfigParameter
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FHelpshiftConfigParameter Conv_ArrayToHelpshiftConfigParameter(struct TArray<struct FHelpshiftConfigParameter>& Value); // Offset: 0x101f4db80 // Return & Params: Num(2) Size(0x30)
};

// Object Name: Class HelpshiftSDK.HelpshiftConstants
// Size: 0x28 // Inherited bytes: 0x28
struct UHelpshiftConstants : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventWidgetToggle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventWidgetToggle(); // Offset: 0x101f4f758 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventSDKSessionStarted
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventSDKSessionStarted(); // Offset: 0x101f4e878 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventSDKSessionEnded
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventSDKSessionEnded(); // Offset: 0x101f4e7ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventReceivedUnreadMessageCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventReceivedUnreadMessageCount(); // Offset: 0x101f4e6d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventMessageAdd
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventMessageAdd(); // Offset: 0x101f4f478 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataSDKVisible
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataSDKVisible(); // Offset: 0x101f4f6a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataMessageTypeText
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataMessageTypeText(); // Offset: 0x101f4f19c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataMessageTypeAttachment
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataMessageTypeAttachment(); // Offset: 0x101f4f250 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataMessageType
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataMessageType(); // Offset: 0x101f4f3c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataMessageCountFromCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataMessageCountFromCache(); // Offset: 0x101f4e568 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataMessageCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataMessageCount(); // Offset: 0x101f4e620 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataMessageBody
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataMessageBody(); // Offset: 0x101f4f310 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataMessage
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataMessage(); // Offset: 0x101f4f538 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataLatestIssuePublishId
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataLatestIssuePublishId(); // Offset: 0x101f4ed00 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataLatestIssueId
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataLatestIssueId(); // Offset: 0x101f4edc8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataIsIssueOpen
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataIsIssueOpen(); // Offset: 0x101f4ec4c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataCsatRating
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataCsatRating(); // Offset: 0x101f4f01c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventDataAdditionalFeedback
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventDataAdditionalFeedback(); // Offset: 0x101f4ef54 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventCsatSubmit
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventCsatSubmit(); // Offset: 0x101f4f0dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventConversationStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventConversationStatus(); // Offset: 0x101f4ee8c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventConversationStart
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventConversationStart(); // Offset: 0x101f4f5e8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventConversationResolved
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventConversationResolved(); // Offset: 0x101f4ea04 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventConversationReopened
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventConversationReopened(); // Offset: 0x101f4e93c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventConversationRejected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventConversationRejected(); // Offset: 0x101f4eacc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftEventConversationEnd
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftEventConversationEnd(); // Offset: 0x101f4eb94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigScreenOrientationPortrait
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t HelpshiftConfigScreenOrientationPortrait(); // Offset: 0x101f4f818 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigScreenOrientationLandscape
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t HelpshiftConfigScreenOrientationLandscape(); // Offset: 0x101f4f834 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigScreenOrientationKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigScreenOrientationKey(); // Offset: 0x101f4fffc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigPresentFullScreenOniPadKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigPresentFullScreenOniPadKey(); // Offset: 0x101f4f84c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigNotificationSoundIdKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigNotificationSoundIdKey(); // Offset: 0x101f4fcec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigNotificationLargeIconKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigNotificationLargeIconKey(); // Offset: 0x101f4fdb0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigNotificationIconKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigNotificationIconKey(); // Offset: 0x101f4fe7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigNotificationChannelIdKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigNotificationChannelIdKey(); // Offset: 0x101f4fc20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigInAppNotificationTextColorKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigInAppNotificationTextColorKey(); // Offset: 0x101f4f910 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigInAppNotificationBannerBackgroundColorKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigInAppNotificationBannerBackgroundColorKey(); // Offset: 0x101f4f9c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigInAppNotificationAppearanceKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigInAppNotificationAppearanceKey(); // Offset: 0x101f4fa94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigEnableLoggingKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigEnableLoggingKey(); // Offset: 0x101f4ff38 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigEnableInAppNotificationsKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigEnableInAppNotificationsKey(); // Offset: 0x101f500bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftConstants.HelpshiftConfigEnableFullPrivacyKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString HelpshiftConfigEnableFullPrivacyKey(); // Offset: 0x101f4fb64 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class HelpshiftSDK.HelpshiftCustomIssueFieldParameterFunctions
// Size: 0x28 // Inherited bytes: 0x28
struct UHelpshiftCustomIssueFieldParameterFunctions : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HelpshiftSDK.HelpshiftCustomIssueFieldParameterFunctions.NewSingleLineParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHelpshiftCustomIssueFieldParameter NewSingleLineParameter(struct FString Value); // Offset: 0x101f514d4 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function HelpshiftSDK.HelpshiftCustomIssueFieldParameterFunctions.NewNumberParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHelpshiftCustomIssueFieldParameter NewNumberParameter(int32_t Value); // Offset: 0x101f51334 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function HelpshiftSDK.HelpshiftCustomIssueFieldParameterFunctions.NewMultiLineParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHelpshiftCustomIssueFieldParameter NewMultiLineParameter(struct FString Value); // Offset: 0x101f51404 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function HelpshiftSDK.HelpshiftCustomIssueFieldParameterFunctions.NewDropdownParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHelpshiftCustomIssueFieldParameter NewDropdownParameter(struct FString Value); // Offset: 0x101f51264 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function HelpshiftSDK.HelpshiftCustomIssueFieldParameterFunctions.NewDateParameter
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FHelpshiftCustomIssueFieldParameter NewDateParameter(struct FDateTime& Value); // Offset: 0x101f51188 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function HelpshiftSDK.HelpshiftCustomIssueFieldParameterFunctions.NewCheckboxParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHelpshiftCustomIssueFieldParameter NewCheckboxParameter(bool Value); // Offset: 0x101f510b0 // Return & Params: Num(2) Size(0x28)
};

// Object Name: Class HelpshiftSDK.HelpshiftSettings
// Size: 0x80 // Inherited bytes: 0x28
struct UHelpshiftSettings : UObject {
	// Fields
	struct FString DomainName; // Offset: 0x28 // Size: 0x10
	bool UsePushNotifications; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct FString AppIdIOS; // Offset: 0x40 // Size: 0x10
	struct FString AppIdAndroid; // Offset: 0x50 // Size: 0x10
	struct FDirectoryPath DrawablePath; // Offset: 0x60 // Size: 0x10
	struct FDirectoryPath SoundPath; // Offset: 0x70 // Size: 0x10
};

// Object Name: Class HelpshiftSDK.HelpshiftDevSettings
// Size: 0x80 // Inherited bytes: 0x80
struct UHelpshiftDevSettings : UHelpshiftSettings {
};

// Object Name: Class HelpshiftSDK.HelpshiftLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UHelpshiftLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.ShowSection
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ShowSection(struct FString SectionId, struct TMap<struct FString, struct FHelpshiftConfigParameter>& Parameters, struct TArray<struct FString>& Tags, struct TMap<struct FString, struct FHelpshiftCustomIssueFieldParameter>& CustomIssueFields); // Offset: 0x101f5279c // Return & Params: Num(4) Size(0xc0)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.ShowQuestion
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ShowQuestion(struct FString QuestionId, struct TMap<struct FString, struct FHelpshiftConfigParameter>& Parameters, struct TArray<struct FString>& Tags, struct TMap<struct FString, struct FHelpshiftCustomIssueFieldParameter>& CustomIssueFields); // Offset: 0x101f52558 // Return & Params: Num(4) Size(0xc0)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.ShowFrequentlyAskedQuestions
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ShowFrequentlyAskedQuestions(struct TMap<struct FString, struct FHelpshiftConfigParameter>& Parameters, struct TArray<struct FString>& Tags, struct TMap<struct FString, struct FHelpshiftCustomIssueFieldParameter>& CustomIssueFields); // Offset: 0x101f529e0 // Return & Params: Num(3) Size(0xb0)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.ShowConversation
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ShowConversation(struct TMap<struct FString, struct FHelpshiftConfigParameter>& Parameters, struct TArray<struct FString>& Tags, struct TMap<struct FString, struct FHelpshiftCustomIssueFieldParameter>& CustomIssueFields); // Offset: 0x101f52bdc // Return & Params: Num(3) Size(0xb0)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.SetLanguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetLanguage(struct FString Language); // Offset: 0x101f524d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.RequestUnreadMessageCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RequestUnreadMessageCount(bool FetchFromServer); // Offset: 0x101f52108 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.RegisterPushToken
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RegisterPushToken(struct FString Token); // Offset: 0x101f52364 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.ParseIosNotificationPayload
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TMap<struct FString, struct FHelpshiftConfigParameter> ParseIosNotificationPayload(struct FString Payload); // Offset: 0x101f51dfc // Return & Params: Num(2) Size(0x60)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.Logout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Logout(); // Offset: 0x101f523f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.Login
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void Login(struct TMap<struct FString, struct FString>& Parameters); // Offset: 0x101f5240c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.LeaveBreadcrumb
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LeaveBreadcrumb(struct FString Breadcrumb); // Offset: 0x101f51f28 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.Init
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Init(struct TMap<struct FString, struct FHelpshiftConfigParameter> Parameters); // Offset: 0x101f52dd8 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.HandlePushIos
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void HandlePushIos(struct TMap<struct FString, struct FHelpshiftConfigParameter>& Parameters, bool IsLaunch); // Offset: 0x101f52184 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.HandlePushAndroid
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void HandlePushAndroid(struct TMap<struct FString, struct FString>& Parameters); // Offset: 0x101f52298 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.ClearBreadcrumbs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearBreadcrumbs(); // Offset: 0x101f51f14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.ClearAnonymousUserOnLogin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearAnonymousUserOnLogin(); // Offset: 0x101f523e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.BindEventDelegate
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BindEventDelegate(struct FDelegate& Callback); // Offset: 0x101f52058 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HelpshiftSDK.HelpshiftLibrary.BindAuthFailureDelegate
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BindAuthFailureDelegate(struct FDelegate& Callback); // Offset: 0x101f51fa8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class HelpshiftSDK.HelpshiftLog
// Size: 0x28 // Inherited bytes: 0x28
struct UHelpshiftLog : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HelpshiftSDK.HelpshiftLog.W
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void W(struct FString Tag, struct FString Message); // Offset: 0x101f5378c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function HelpshiftSDK.HelpshiftLog.V
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void V(struct FString Tag, struct FString Message); // Offset: 0x101f5385c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function HelpshiftSDK.HelpshiftLog.I
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void I(struct FString Tag, struct FString Message); // Offset: 0x101f5392c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function HelpshiftSDK.HelpshiftLog.E
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void E(struct FString Tag, struct FString Message); // Offset: 0x101f536bc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function HelpshiftSDK.HelpshiftLog.D
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void D(struct FString Tag, struct FString Message); // Offset: 0x101f539fc // Return & Params: Num(2) Size(0x20)
};

