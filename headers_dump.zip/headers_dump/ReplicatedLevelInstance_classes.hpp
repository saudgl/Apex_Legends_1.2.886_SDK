#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ReplicatedLevelInstance.ReplicatedLevelInstanceActor
// Size: 0x270 // Inherited bytes: 0x268
struct AReplicatedLevelInstanceActor : AActor {
	// Fields
	struct UReplicatedLevelInstanceComponent* ReplicatedLevelInstance; // Offset: 0x268 // Size: 0x08
};

// Object Name: Class ReplicatedLevelInstance.ReplicatedLevelInstanceLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UReplicatedLevelInstanceLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceLibrary.LoadReplicatedLevelInstanceBySoftObjectPtr
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct AReplicatedLevelInstanceActor* LoadReplicatedLevelInstanceBySoftObjectPtr(struct UObject* WorldContextObject, struct TSoftObjectPtr<UWorld> Level, struct FVector Location, struct FRotator Rotation, float NetCullDistanceSquared); // Offset: 0x1021b28f0 // Return & Params: Num(6) Size(0x58)
};

// Object Name: Class ReplicatedLevelInstance.ReplicatedLevelInstanceComponent
// Size: 0x4c0 // Inherited bytes: 0x260
struct UReplicatedLevelInstanceComponent : USceneComponent {
	// Fields
	struct TSoftObjectPtr<UWorld> Level; // Offset: 0x258 // Size: 0x28
	char pad_0x288[0x10]; // Offset: 0x288 // Size: 0x10
	struct FMulticastInlineDelegate OnLevelShownCompleted; // Offset: 0x298 // Size: 0x10
	char pad_0x2A8[0x18]; // Offset: 0x2a8 // Size: 0x18
	char bIsOnlyLoadStaticLevel : 1; // Offset: 0x2c0 // Size: 0x01
	char bShouldBlockOnLoad : 1; // Offset: 0x2c0 // Size: 0x01
	char pad_0x2C0_2 : 6; // Offset: 0x2c0 // Size: 0x01
	char pad_0x2C1[0x27]; // Offset: 0x2c1 // Size: 0x27
	struct ULevelStreamingDynamic* LevelInstance; // Offset: 0x2e8 // Size: 0x08
	struct TArray<struct ULevelStreamingDynamic*> SubLevelAlwaysLoaded; // Offset: 0x2f0 // Size: 0x10
	struct TArray<struct ULevelStreamingDynamic*> SubLevelScriptLoaded; // Offset: 0x300 // Size: 0x10
	struct FString LevelUniqueNameSuffix; // Offset: 0x310 // Size: 0x10
	char pad_0x320[0x60]; // Offset: 0x320 // Size: 0x60
	struct TArray<int32_t> ShownLevelScriptLoadedIdx; // Offset: 0x380 // Size: 0x10
	char pad_0x390[0xa0]; // Offset: 0x390 // Size: 0xa0
	struct TArray<int32_t> ShownLevelAlwaysLoadedIdx; // Offset: 0x430 // Size: 0x10
	char pad_0x440[0x60]; // Offset: 0x440 // Size: 0x60
	struct TArray<struct ULevelStreaming*> WaitingReloadLevels; // Offset: 0x4a0 // Size: 0x10
	char pad_0x4B0[0x10]; // Offset: 0x4b0 // Size: 0x10

	// Functions

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.WhenScriptLoadedSubLevelUnloadedComplete
	// Flags: [Final|Native|Private]
	void WhenScriptLoadedSubLevelUnloadedComplete(struct ULevelStreaming* LevelStreaming); // Offset: 0x1021b2eec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.WhenLevelShown
	// Flags: [Final|Native|Private]
	void WhenLevelShown(); // Offset: 0x1021b2f68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.WhenAlwaysLoadedSubLevelUnloadedComplete
	// Flags: [Final|Native|Private]
	void WhenAlwaysLoadedSubLevelUnloadedComplete(struct ULevelStreaming* LevelStreaming); // Offset: 0x1021b2e70 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.UnloadSubLevelByName
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void UnloadSubLevelByName(struct FName Name); // Offset: 0x1021b3158 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.UnloadAndRefreshSubLevelScriptLoaded_Client
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnloadAndRefreshSubLevelScriptLoaded_Client(struct FName LevelName); // Offset: 0x1021b2fa4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.UnloadAndRefreshSubLevelScriptLoaded
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void UnloadAndRefreshSubLevelScriptLoaded(struct FName LevelName); // Offset: 0x1021b3020 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.UnloadAllDynamicLevel
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void UnloadAllDynamicLevel(); // Offset: 0x1021b3264 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.SetLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLevel(struct TSoftObjectPtr<UWorld> InLevel); // Offset: 0x1021b328c // Return & Params: Num(1) Size(0x28)

	// Object Name: DelegateFunction ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.ScriptLoadedSubLevelUnLoadedAndRefreshComplete__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void ScriptLoadedSubLevelUnLoadedAndRefreshComplete__DelegateSignature(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.ReloadIsNotStaticSubLevelAlwaysLoaded_Client
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReloadIsNotStaticSubLevelAlwaysLoaded_Client(); // Offset: 0x1021b309c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.ReloadIsNotStaticSubLevelAlwaysLoaded
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void ReloadIsNotStaticSubLevelAlwaysLoaded(); // Offset: 0x1021b30b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.OnRep_ShownLevelDynamicIdx
	// Flags: [Final|Native|Private]
	void OnRep_ShownLevelDynamicIdx(); // Offset: 0x1021b2f90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.OnRep_Level
	// Flags: [Final|Native|Public|HasOutParms]
	void OnRep_Level(struct TSoftObjectPtr<UWorld>& PreLevel); // Offset: 0x1021b3494 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.OnRep_IsOnlyLoadStaticLevel
	// Flags: [Final|Native|Public]
	void OnRep_IsOnlyLoadStaticLevel(); // Offset: 0x1021b3278 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.OnRep_AlwaysLoadedShownLevelDynamicIdx
	// Flags: [Final|Native|Private]
	void OnRep_AlwaysLoadedShownLevelDynamicIdx(); // Offset: 0x1021b2f7c // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.OnLevelShownCompleted__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnLevelShownCompleted__DelegateSignature(struct UReplicatedLevelInstanceComponent* ReplicatedLevelInstance); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.LoadSubLevelByName
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void LoadSubLevelByName(struct FName Name); // Offset: 0x1021b31d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.LoadAllDynamicLevel
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void LoadAllDynamicLevel(); // Offset: 0x1021b3250 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.IsScriptLoadedLevelPendingLoad
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsScriptLoadedLevelPendingLoad(); // Offset: 0x1021b33f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.IsLevelInstanceValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLevelInstanceValid(); // Offset: 0x1021b3460 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.IsContainPendingLoadLevel
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsContainPendingLoadLevel(); // Offset: 0x1021b33c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.IsAlwaysLoadedLevelFullyLoaded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsAlwaysLoadedLevelFullyLoaded(); // Offset: 0x1021b342c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.GetSingleSubLevelScriptLoaded
	// Flags: [Final|Native|Public]
	struct TWeakObjectPtr<struct ULevelStreamingDynamic> GetSingleSubLevelScriptLoaded(struct FName Name); // Offset: 0x1021b30c4 // Return & Params: Num(2) Size(0x10)

	// Object Name: DelegateFunction ReplicatedLevelInstance.ReplicatedLevelInstanceComponent.AlwaysLoadedSubLevelReloadComplete__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void AlwaysLoadedSubLevelReloadComplete__DelegateSignature(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)
};

