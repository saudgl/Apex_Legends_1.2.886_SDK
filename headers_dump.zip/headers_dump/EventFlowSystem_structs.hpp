#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct EventFlowSystem.EventFlowFinishEvent
// Size: 0x10 // Inherited bytes: 0x00
struct FEventFlowFinishEvent {
	// Fields
	struct FDelegate OnEventFlowNodeFinished; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EventFlowSystem.EvaluateEventFlowParameter
// Size: 0x10 // Inherited bytes: 0x00
struct FEvaluateEventFlowParameter {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EventFlowSystem.EventFlowSequenceBranchData
// Size: 0x28 // Inherited bytes: 0x00
struct FEventFlowSequenceBranchData {
	// Fields
	struct UEventFlowElementBase* Element; // Offset: 0x00 // Size: 0x08
	char bAutoFinishOtherBranch : 1; // Offset: 0x08 // Size: 0x01
	char pad_0x8_1 : 7; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct TArray<struct UEventFlowSequenceBase*> NextSequences; // Offset: 0x10 // Size: 0x10
	char bIsInterruptAlways : 1; // Offset: 0x20 // Size: 0x01
	char pad_0x20_1 : 7; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

