#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LevelSequence.LevelSequenceActor
// Size: 0x300 // Inherited bytes: 0x268
struct ALevelSequenceActor : AActor {
	// Fields
	char pad_0x268[0x10]; // Offset: 0x268 // Size: 0x10
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0x278 // Size: 0x24
	char pad_0x29C[0x4]; // Offset: 0x29c // Size: 0x04
	struct ULevelSequencePlayer* SequencePlayer; // Offset: 0x2a0 // Size: 0x08
	struct FSoftObjectPath LevelSequence; // Offset: 0x2a8 // Size: 0x18
	struct TArray<struct AActor*> AdditionalEventReceivers; // Offset: 0x2c0 // Size: 0x10
	struct ULevelSequenceBurnInOptions* BurnInOptions; // Offset: 0x2d0 // Size: 0x08
	struct UMovieSceneBindingOverrides* BindingOverrides; // Offset: 0x2d8 // Size: 0x08
	char bAutoPlay : 1; // Offset: 0x2e0 // Size: 0x01
	char bOverrideInstanceData : 1; // Offset: 0x2e0 // Size: 0x01
	char bReplicatePlayback : 1; // Offset: 0x2e0 // Size: 0x01
	char pad_0x2E0_3 : 5; // Offset: 0x2e0 // Size: 0x01
	char pad_0x2E1[0x7]; // Offset: 0x2e1 // Size: 0x07
	struct UObject* DefaultInstanceData; // Offset: 0x2e8 // Size: 0x08
	struct ULevelSequenceBurnIn* BurnInInstance; // Offset: 0x2f0 // Size: 0x08
	bool bShowBurnin; // Offset: 0x2f8 // Size: 0x01
	char pad_0x2F9[0x7]; // Offset: 0x2f9 // Size: 0x07

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceActor.ShowBurnin
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShowBurnin(); // Offset: 0x1053adea8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequence(struct ULevelSequence* InSequence); // Offset: 0x1053ae0b8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetReplicatePlayback
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetReplicatePlayback(bool ReplicatePlayback); // Offset: 0x1053adf04 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetEventReceivers
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEventReceivers(struct TArray<struct AActor*> AdditionalReceivers); // Offset: 0x1053adf88 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetBinding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset); // Offset: 0x1053adc14 // Return & Params: Num(3) Size(0x29)

	// Object Name: Function LevelSequence.LevelSequenceActor.ResetBindings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetBindings(); // Offset: 0x1053ad88c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.ResetBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetBinding(struct FMovieSceneObjectBindingID Binding); // Offset: 0x1053ad8dc // Return & Params: Num(1) Size(0x18)

	// Object Name: Function LevelSequence.LevelSequenceActor.RemoveBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor); // Offset: 0x1053ad9a8 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LevelSequence.LevelSequenceActor.OnLevelSequenceLoaded__DelegateSignature
	// Flags: [Public|Delegate]
	void OnLevelSequenceLoaded__DelegateSignature(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.LoadSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULevelSequence* LoadSequence(); // Offset: 0x1053ae134 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceActor.HideBurnin
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HideBurnin(); // Offset: 0x1053adebc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.GetSequencePlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULevelSequencePlayer* GetSequencePlayer(); // Offset: 0x1053aded0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceActor.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULevelSequence* GetSequence(); // Offset: 0x1053ae168 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceActor.AddBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset); // Offset: 0x1053adab8 // Return & Params: Num(3) Size(0x21)
};

// Object Name: Class LevelSequence.LevelSequencePlayer
// Size: 0x938 // Inherited bytes: 0x828
struct ULevelSequencePlayer : UMovieSceneSequencePlayer {
	// Fields
	struct FMulticastInlineDelegate OnCameraCut; // Offset: 0x828 // Size: 0x10
	char pad_0x838[0x100]; // Offset: 0x838 // Size: 0x100

	// Functions

	// Object Name: Function LevelSequence.LevelSequencePlayer.GetActiveCameraComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCameraComponent* GetActiveCameraComponent(); // Offset: 0x1053af90c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequencePlayer.CreateLevelSequencePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ALevelSequenceActor*& OutActor); // Offset: 0x1053af944 // Return & Params: Num(5) Size(0x48)
};

// Object Name: Class LevelSequence.DefaultLevelSequenceInstanceData
// Size: 0x70 // Inherited bytes: 0x28
struct UDefaultLevelSequenceInstanceData : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct AActor* TransformOriginActor; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FTransform TransformOrigin; // Offset: 0x40 // Size: 0x30
};

// Object Name: Class LevelSequence.LevelSequenceMetaData
// Size: 0x28 // Inherited bytes: 0x28
struct ULevelSequenceMetaData : UInterface {
};

// Object Name: Class LevelSequence.LevelSequence
// Size: 0x498 // Inherited bytes: 0x348
struct ULevelSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 // Size: 0x08
	struct FLevelSequenceObjectReferenceMap ObjectReferences; // Offset: 0x350 // Size: 0x50
	struct FLevelSequenceBindingReferences BindingReferences; // Offset: 0x3a0 // Size: 0xa0
	struct TMap<struct FString, struct FLevelSequenceObject> PossessedObjects; // Offset: 0x440 // Size: 0x50
	struct UObject* DirectorClass; // Offset: 0x490 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequence.RemoveMetaDataByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveMetaDataByClass(struct UObject* InClass); // Offset: 0x1053ac884 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequence.FindOrAddMetaDataByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* FindOrAddMetaDataByClass(struct UObject* InClass); // Offset: 0x1053ac964 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LevelSequence.LevelSequence.FindMetaDataByClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UObject* FindMetaDataByClass(struct UObject* InClass); // Offset: 0x1053ac9d8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LevelSequence.LevelSequence.CopyMetaData
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* CopyMetaData(struct UObject* InMetaData); // Offset: 0x1053ac8f0 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class LevelSequence.LevelSequenceBurnInInitSettings
// Size: 0x28 // Inherited bytes: 0x28
struct ULevelSequenceBurnInInitSettings : UObject {
};

// Object Name: Class LevelSequence.LevelSequenceBurnInOptions
// Size: 0x50 // Inherited bytes: 0x28
struct ULevelSequenceBurnInOptions : UObject {
	// Fields
	bool bUseBurnIn; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FSoftClassPath BurnInClass; // Offset: 0x30 // Size: 0x18
	struct ULevelSequenceBurnInInitSettings* Settings; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceBurnInOptions.SetBurnIn
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBurnIn(struct FSoftClassPath InBurnInClass); // Offset: 0x1053ad414 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class LevelSequence.LevelSequenceBurnIn
// Size: 0x300 // Inherited bytes: 0x240
struct ULevelSequenceBurnIn : UUserWidget {
	// Fields
	struct FLevelSequencePlayerSnapshot FrameInformation; // Offset: 0x240 // Size: 0xb8
	struct ALevelSequenceActor* LevelSequenceActor; // Offset: 0x2f8 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceBurnIn.SetSettings
	// Flags: [Event|Public|BlueprintEvent]
	void SetSettings(struct UObject* InSettings); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceBurnIn.GetSettingsClass
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct ULevelSequenceBurnInInitSettings* GetSettingsClass(); // Offset: 0x1053aeca8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class LevelSequence.LevelSequenceDirector
// Size: 0x30 // Inherited bytes: 0x28
struct ULevelSequenceDirector : UObject {
	// Fields
	struct ULevelSequencePlayer* Player; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceDirector.OnCreated
	// Flags: [Event|Public|BlueprintEvent]
	void OnCreated(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LevelSequence.LegacyLevelSequenceDirectorBlueprint
// Size: 0xd0 // Inherited bytes: 0xd0
struct ULegacyLevelSequenceDirectorBlueprint : UBlueprint {
};

