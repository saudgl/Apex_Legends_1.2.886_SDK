#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum Chapter_Runtime.EChapterParamType
enum class EChapterParamType : uint8 {
	String = 0,
	Float = 1,
	Number = 2,
	EChapterParamType_MAX = 3
};

