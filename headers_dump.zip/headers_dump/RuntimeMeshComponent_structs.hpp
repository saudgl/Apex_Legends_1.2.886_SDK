#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshAsyncBodySetupData
// Size: 0x18 // Inherited bytes: 0x00
struct FRuntimeMeshAsyncBodySetupData {
	// Fields
	struct UBodySetup* BodySetup; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FRuntimeMeshCollisionSourceSectionInfo> CollisionSources; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionSourceSectionInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionSourceSectionInfo {
	// Fields
	int32_t StartIndex; // Offset: 0x00 // Size: 0x04
	int32_t EndIndex; // Offset: 0x04 // Size: 0x04
	struct TWeakObjectPtr<struct URuntimeMeshProvider> SourceProvider; // Offset: 0x08 // Size: 0x08
	int32_t SectionId; // Offset: 0x10 // Size: 0x04
	enum class ERuntimeMeshCollisionFaceSourceType SourceType; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionData
// Size: 0x58 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionData {
	// Fields
	struct FRuntimeMeshCollisionVertexStream Vertices; // Offset: 0x00 // Size: 0x10
	struct FRuntimeMeshCollisionTriangleStream Triangles; // Offset: 0x10 // Size: 0x10
	struct FRuntimeMeshCollisionTexCoordStream TexCoords; // Offset: 0x20 // Size: 0x10
	struct FRuntimeMeshCollisionMaterialIndexStream MaterialIndices; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FRuntimeMeshCollisionSourceSectionInfo> CollisionSources; // Offset: 0x40 // Size: 0x10
	bool bFlipNormals; // Offset: 0x50 // Size: 0x01
	bool bDeformableMesh; // Offset: 0x51 // Size: 0x01
	bool bFastCook; // Offset: 0x52 // Size: 0x01
	bool bDisableActiveEdgePrecompute; // Offset: 0x53 // Size: 0x01
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionMaterialIndexStream
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionMaterialIndexStream {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionTexCoordStream
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionTexCoordStream {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionTriangleStream
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionTriangleStream {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionVertexStream
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionVertexStream {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionHitInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionHitInfo {
	// Fields
	struct TWeakObjectPtr<struct URuntimeMeshProvider> SourceProvider; // Offset: 0x00 // Size: 0x08
	enum class ERuntimeMeshCollisionFaceSourceType SourceType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int32_t SectionId; // Offset: 0x0c // Size: 0x04
	int32_t FaceIndex; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct UMaterialInterface* Material; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionSettings
// Size: 0x48 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionSettings {
	// Fields
	bool bUseComplexAsSimple; // Offset: 0x00 // Size: 0x01
	bool bUseAsyncCooking; // Offset: 0x01 // Size: 0x01
	enum class ERuntimeMeshCollisionCookingMode CookingMode; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x5]; // Offset: 0x03 // Size: 0x05
	struct TArray<struct FRuntimeMeshCollisionConvexMesh> ConvexElements; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FRuntimeMeshCollisionSphere> Spheres; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FRuntimeMeshCollisionBox> Boxes; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FRuntimeMeshCollisionCapsule> Capsules; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionCapsule
// Size: 0x20 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionCapsule {
	// Fields
	struct FVector Center; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	float Radius; // Offset: 0x18 // Size: 0x04
	float Length; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionBox
// Size: 0x24 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionBox {
	// Fields
	struct FVector Center; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	struct FVector Extents; // Offset: 0x18 // Size: 0x0c
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionSphere
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionSphere {
	// Fields
	struct FVector Center; // Offset: 0x00 // Size: 0x0c
	float Radius; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionConvexMesh
// Size: 0x30 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionConvexMesh {
	// Fields
	struct TArray<struct FVector> VertexBuffer; // Offset: 0x00 // Size: 0x10
	struct FBox BoundingBox; // Offset: 0x10 // Size: 0x1c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshTangent
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshTangent {
	// Fields
	struct FVector TangentX; // Offset: 0x00 // Size: 0x0c
	bool bFlipTangentY; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshRenderableMeshData
// Size: 0x80 // Inherited bytes: 0x00
struct FRuntimeMeshRenderableMeshData {
	// Fields
	struct FRuntimeMeshVertexPositionStream Positions; // Offset: 0x00 // Size: 0x10
	struct FRuntimeMeshVertexTangentStream Tangents; // Offset: 0x10 // Size: 0x18
	struct FRuntimeMeshVertexTexCoordStream TexCoords; // Offset: 0x28 // Size: 0x18
	struct FRuntimeMeshVertexColorStream Colors; // Offset: 0x40 // Size: 0x10
	struct FRuntimeMeshTriangleStream Triangles; // Offset: 0x50 // Size: 0x18
	struct FRuntimeMeshTriangleStream AdjacencyTriangles; // Offset: 0x68 // Size: 0x18
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshTriangleStream
// Size: 0x18 // Inherited bytes: 0x00
struct FRuntimeMeshTriangleStream {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshVertexColorStream
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshVertexColorStream {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshVertexTexCoordStream
// Size: 0x18 // Inherited bytes: 0x00
struct FRuntimeMeshVertexTexCoordStream {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshVertexTangentStream
// Size: 0x18 // Inherited bytes: 0x00
struct FRuntimeMeshVertexTangentStream {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshVertexPositionStream
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshVertexPositionStream {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshMaterialSlot
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshMaterialSlot {
	// Fields
	struct FName SlotName; // Offset: 0x00 // Size: 0x08
	struct TWeakObjectPtr<struct UMaterialInterface> Material; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshLODProperties
// Size: 0x08 // Inherited bytes: 0x00
struct FRuntimeMeshLODProperties {
	// Fields
	float ScreenSize; // Offset: 0x00 // Size: 0x04
	bool bCanGetSectionsIndependently; // Offset: 0x04 // Size: 0x01
	bool bCanGetAllSectionsAtOnce; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshSectionProperties
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshSectionProperties {
	// Fields
	enum class ERuntimeMeshUpdateFrequency UpdateFrequency; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t MaterialSlot; // Offset: 0x04 // Size: 0x04
	bool bIsVisible; // Offset: 0x08 // Size: 0x01
	bool bCastsShadow; // Offset: 0x09 // Size: 0x01
	bool bUseHighPrecisionTangents; // Offset: 0x0a // Size: 0x01
	bool bUseHighPrecisionTexCoords; // Offset: 0x0b // Size: 0x01
	char NumTexCoords; // Offset: 0x0c // Size: 0x01
	bool bWants32BitIndices; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
};

