#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class FastPicture.TestMatchRawSourceInfo
// Size: 0x120 // Inherited bytes: 0x28
struct UTestMatchRawSourceInfo : UObject {
	// Fields
	bool IsAndroid; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FString DeviceMake; // Offset: 0x30 // Size: 0x10
	struct FString DeviceModel; // Offset: 0x40 // Size: 0x10
	struct FString MemorySizeInGB; // Offset: 0x50 // Size: 0x10
	struct FString GPUFamily; // Offset: 0x60 // Size: 0x10
	struct FString iOSVersion; // Offset: 0x70 // Size: 0x10
	struct FString AndroidVersion; // Offset: 0x80 // Size: 0x10
	struct FString GLVersion; // Offset: 0x90 // Size: 0x10
	struct FString VulkanVersion; // Offset: 0xa0 // Size: 0x10
	struct FString CPUCoreNum; // Offset: 0xb0 // Size: 0x10
	struct FString CPUMaxFreq; // Offset: 0xc0 // Size: 0x10
	struct FString Platform; // Offset: 0xd0 // Size: 0x10
	struct FString Grade; // Offset: 0xe0 // Size: 0x10
	struct FString GradeScore; // Offset: 0xf0 // Size: 0x10
	struct FString CVarsSWitchDummy; // Offset: 0x100 // Size: 0x10
	struct FString Chipset; // Offset: 0x110 // Size: 0x10
};

// Object Name: Class FastPicture.IOSDeviceMakeList
// Size: 0x38 // Inherited bytes: 0x28
struct UIOSDeviceMakeList : UObject {
	// Fields
	struct TArray<struct FString> IOSDeviceMakeList; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class FastPicture.EmulatorProfile
// Size: 0x48 // Inherited bytes: 0x28
struct UEmulatorProfile : UObject {
	// Fields
	struct FString IOSEmulatorProfile; // Offset: 0x28 // Size: 0x10
	struct FString AndroidEmulatorProfile; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class FastPicture.AssignProfile
// Size: 0x38 // Inherited bytes: 0x28
struct UAssignProfile : UObject {
	// Fields
	struct FString AssignProfile; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class FastPicture.FastPictureMatchRulesWhiteList
// Size: 0x48 // Inherited bytes: 0x28
struct UFastPictureMatchRulesWhiteList : UObject {
	// Fields
	struct TArray<struct FFPProfileMatch> iOSMatchProfileWhiteList; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FFPProfileMatch> MatchProfileWhiteList; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class FastPicture.AndroidMatchRulesScoreList
// Size: 0x38 // Inherited bytes: 0x28
struct UAndroidMatchRulesScoreList : UObject {
	// Fields
	struct TArray<struct FFPGradeProfileMatch> GradeMatchProfile; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class FastPicture.AndroidMemoryLimitGrade
// Size: 0x50 // Inherited bytes: 0x28
struct UAndroidMemoryLimitGrade : UObject {
	// Fields
	int32_t MemoryPriority; // Offset: 0x28 // Size: 0x04
	int32_t MemoryLimitNum; // Offset: 0x2c // Size: 0x04
	struct TArray<int32_t> MemoryLimitValue; // Offset: 0x30 // Size: 0x10
	struct TArray<int32_t> MemoryLimitGrade; // Offset: 0x40 // Size: 0x10
};

// Object Name: Class FastPicture.AndroidRuleGrade
// Size: 0x70 // Inherited bytes: 0x28
struct UAndroidRuleGrade : UObject {
	// Fields
	int32_t RuleGradeNum; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<int32_t> RuleGradeEnable; // Offset: 0x30 // Size: 0x10
	struct TArray<int32_t> RuleMemoryCondition; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> RuleGradeCondition; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FString> RuleGradeFinal; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class FastPicture.AndroidRuleGrade_GPUAndVersion
// Size: 0x90 // Inherited bytes: 0x28
struct UAndroidRuleGrade_GPUAndVersion : UObject {
	// Fields
	int32_t RuleGradeNum; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<int32_t> RuleGradeEnable; // Offset: 0x30 // Size: 0x10
	struct TArray<int32_t> RuleAndroidVersion; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> RuleAndroidGPU1; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FString> RuleAndroidGPU2; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FString> RuleCurGrade; // Offset: 0x70 // Size: 0x10
	struct TArray<struct FString> RuleGradeFinal; // Offset: 0x80 // Size: 0x10
};

// Object Name: Class FastPicture.AndroidScoreToProfileName
// Size: 0x50 // Inherited bytes: 0x28
struct UAndroidScoreToProfileName : UObject {
	// Fields
	int32_t MaxScore; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FScoreToProfileName> GradeScoreProfileName; // Offset: 0x30 // Size: 0x10
	struct TArray<float> GradeScoreTypePercentage; // Offset: 0x40 // Size: 0x10
};

// Object Name: Class FastPicture.RenderPass2MatchRules
// Size: 0x38 // Inherited bytes: 0x28
struct URenderPass2MatchRules : UObject {
	// Fields
	struct TArray<struct FFPProfileMatch> RenderPass2; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class FastPicture.SwitchPass2MatchRules
// Size: 0x48 // Inherited bytes: 0x28
struct USwitchPass2MatchRules : UObject {
	// Fields
	struct TArray<struct FFPProfileMatch> iOSSwitcherPass2; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FFPProfileMatch> SwitcherPass2; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class FastPicture.SwitchMapMatchRules
// Size: 0x38 // Inherited bytes: 0x28
struct USwitchMapMatchRules : UObject {
	// Fields
	struct TArray<struct FFPMapProfileMatch> SwitcherMap; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class FastPicture.FastPictureDeviceCheckRules
// Size: 0x48 // Inherited bytes: 0x28
struct UFastPictureDeviceCheckRules : UObject {
	// Fields
	struct TArray<struct FFPDeviceCheckMatch> iOSDeviceSupportInfo; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FFPDeviceCheckMatch> DeviceSupportInfo; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class FastPicture.GPUPassRules
// Size: 0x38 // Inherited bytes: 0x28
struct UGPUPassRules : UObject {
	// Fields
	struct TArray<struct FFPGUPProfileMatch> GPURules; // Offset: 0x28 // Size: 0x10
};

