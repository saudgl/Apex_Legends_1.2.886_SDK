#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class CircleGridManager.CircleGridDataTable
// Size: 0x40 // Inherited bytes: 0x30
struct UCircleGridDataTable : UDataAsset {
	// Fields
	struct TArray<struct FIntPoint> DataMap; // Offset: 0x30 // Size: 0x10
};

// Object Name: Class CircleGridManager.CircleGridDataManager
// Size: 0xb0 // Inherited bytes: 0x30
struct UCircleGridDataManager : UDataAsset {
	// Fields
	struct FVector2D Origin; // Offset: 0x30 // Size: 0x08
	float GridSize; // Offset: 0x38 // Size: 0x04
	int32_t MaxRateCount; // Offset: 0x3c // Size: 0x04
	int32_t MaxBitCount; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TArray<int32_t> DataTable; // Offset: 0x48 // Size: 0x10
	int32_t RowNum; // Offset: 0x58 // Size: 0x04
	int32_t ColNum; // Offset: 0x5c // Size: 0x04
	struct TMap<int32_t, struct UCircleGridDataTable*> CircleGridDataTablePtr; // Offset: 0x60 // Size: 0x50
};

// Object Name: Class CircleGridManager.CircleGridManager
// Size: 0x80 // Inherited bytes: 0x30
struct UCircleGridManager : UDataAsset {
	// Fields
	struct TMap<int32_t, struct UCircleGridDataManager*> GridDatas; // Offset: 0x30 // Size: 0x50
};

// Object Name: Class CircleGridManager.PoisonCircleColorAsset
// Size: 0x80 // Inherited bytes: 0x30
struct UPoisonCircleColorAsset : UDataAsset {
	// Fields
	struct TMap<int32_t, struct FColor> CircleColorSetting; // Offset: 0x30 // Size: 0x50

	// Functions

	// Object Name: Function CircleGridManager.PoisonCircleColorAsset.GetColorByIndex
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FColor GetColorByIndex(int32_t InRateIndex); // Offset: 0x1021a30b4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function CircleGridManager.PoisonCircleColorAsset.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FColor GetColor(int32_t InRate); // Offset: 0x1021a3028 // Return & Params: Num(2) Size(0x8)
};

