#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class RichTextBlockWidget.DynamicRichTextBlockDecorator
// Size: 0x50 // Inherited bytes: 0x28
struct UDynamicRichTextBlockDecorator : UObject {
	// Fields
	bool bReveal; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int32_t RevealedIndex; // Offset: 0x2c // Size: 0x04
	struct FLinearColor UnderLineColor; // Offset: 0x30 // Size: 0x10
	struct FVector2D ImageOffset; // Offset: 0x40 // Size: 0x08
	struct URichTextBox* ParentRichTextBox; // Offset: 0x48 // Size: 0x08
};

// Object Name: Class RichTextBlockWidget.RichTextBox
// Size: 0x4b0 // Inherited bytes: 0x138
struct URichTextBox : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x138 // Size: 0x18
	struct FDelegate TextDelegate; // Offset: 0x150 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x160 // Size: 0x50
	struct FLinearColor Color; // Offset: 0x1b0 // Size: 0x10
	struct TArray<struct UDynamicRichTextBlockDecorator*> Decorators; // Offset: 0x1c0 // Size: 0x10
	char pad_0x1D0[0x10]; // Offset: 0x1d0 // Size: 0x10
	struct FMulticastInlineDelegate OnHyperlinkClicked; // Offset: 0x1e0 // Size: 0x10
	struct FMulticastInlineDelegate OnDynamicTextAppended; // Offset: 0x1f0 // Size: 0x10
	struct FText HighLightText; // Offset: 0x200 // Size: 0x18
	char pad_0x218[0x298]; // Offset: 0x218 // Size: 0x298

	// Functions

	// Object Name: Function RichTextBlockWidget.RichTextBox.SetText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetText(struct FText& InText); // Offset: 0x101cd0cb0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function RichTextBlockWidget.RichTextBox.SetHighlightText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetHighlightText(struct FText& InHighlightText); // Offset: 0x101cd0ae0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function RichTextBlockWidget.RichTextBox.SetFont
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetFont(struct FSlateFontInfo& InFont); // Offset: 0x101cd0bc8 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function RichTextBlockWidget.RichTextBox.RemoveFrontTextLines
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveFrontTextLines(int32_t RemovedLineCount); // Offset: 0x101cd09b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction RichTextBlockWidget.RichTextBox.OnRichTextHyperlinkClicked__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnRichTextHyperlinkClicked__DelegateSignature(struct TArray<struct FString>& MetaData); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction RichTextBlockWidget.RichTextBox.OnDynamicTextAppendedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnDynamicTextAppendedEvent__DelegateSignature(struct FString AppendString); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function RichTextBlockWidget.RichTextBox.ClearAllDisplayText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllDisplayText(); // Offset: 0x101cd0a34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RichTextBlockWidget.RichTextBox.AppendDynamicTextString
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t AppendDynamicTextString(struct FString AppendString); // Offset: 0x101cd0a48 // Return & Params: Num(2) Size(0x14)
};

