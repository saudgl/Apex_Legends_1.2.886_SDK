#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class IGCacheSim.IGCacheSimBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UIGCacheSimBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function IGCacheSim.IGCacheSimBlueprintLibrary.StopCacheSimulation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopCacheSimulation(); // Offset: 0x1023a7530 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function IGCacheSim.IGCacheSimBlueprintLibrary.StartCacheSimulation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartCacheSimulation(); // Offset: 0x1023a7544 // Return & Params: Num(0) Size(0x0)
};

