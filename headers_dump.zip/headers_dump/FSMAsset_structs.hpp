#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct FSMAsset.FSMData
// Size: 0x50 // Inherited bytes: 0x00
struct FFSMData {
	// Fields
	struct TMap<struct FName, struct FTransRule> CurrState_Mapping_TransRule; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct FSMAsset.TransRule
// Size: 0x58 // Inherited bytes: 0x00
struct FTransRule {
	// Fields
	struct TMap<struct FName, enum class ETransRule> Keyword_mapping_TargetState; // Offset: 0x00 // Size: 0x50
	struct FName FromState; // Offset: 0x50 // Size: 0x08
};

