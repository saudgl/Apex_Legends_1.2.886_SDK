#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum UnrealArchExt.EFrontendMapStatus
enum class EFrontendMapStatus : uint8 {
	None = 0,
	PreLoad = 1,
	LoadMap = 2,
	InitMap = 3,
	InitLogic = 4,
	Waiting = 5,
	Running = 6,
	Timeout = 7,
	Failed = 8,
	Over = 9,
	EFrontendMapStatus_MAX = 10
};

// Object Name: Enum UnrealArchExt.EUserWidgetFadingStatus
enum class EUserWidgetFadingStatus : uint8 {
	UserWidgetFadingStatus_None = 0,
	UserWidgetFadingStatus_FadingIn = 1,
	UserWidgetFadingStatus_FadingOut = 2,
	UserWidgetFadingStatus_MAX = 3
};

