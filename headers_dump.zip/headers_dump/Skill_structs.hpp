#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Skill.UTSkillHitInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FUTSkillHitInfo {
	// Fields
	struct TArray<struct AActor*> ToPawn; // Offset: 0x00 // Size: 0x10
	struct AActor* FromPawn; // Offset: 0x10 // Size: 0x08
	int32_t SkillID; // Offset: 0x18 // Size: 0x04
	int32_t SkillPhaseID; // Offset: 0x1c // Size: 0x04
	bool Flag; // Offset: 0x20 // Size: 0x01
	bool IsHeadShot; // Offset: 0x21 // Size: 0x01
	enum class EPhysicalSurface HitSurfaceType; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x1]; // Offset: 0x23 // Size: 0x01
	struct FVector HitEnvLocation; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct Skill.PredictionKey
// Size: 0x10 // Inherited bytes: 0x00
struct FPredictionKey {
	// Fields
	struct UPackageMap* PredictiveConnection; // Offset: 0x00 // Size: 0x08
	int16_t BaseKey; // Offset: 0x08 // Size: 0x02
	int16_t RelyKey; // Offset: 0x0a // Size: 0x02
	bool bIsServerInitiated; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct Skill.SkillModifierCalculator
// Size: 0x40 // Inherited bytes: 0x00
struct FSkillModifierCalculator {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FString CalculatedValue; // Offset: 0x08 // Size: 0x10
	enum class ESkillAttrOperator CalculatorType; // Offset: 0x18 // Size: 0x01
	enum class ESkillAttrOperator CombineType; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x26]; // Offset: 0x1a // Size: 0x26
};

// Object Name: ScriptStruct Skill.SkillModifierList
// Size: 0x10 // Inherited bytes: 0x00
struct FSkillModifierList {
	// Fields
	struct TArray<struct FSkillModifierInfo> List; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Skill.SkillModifierInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FSkillModifierInfo {
	// Fields
	struct FSkillModifierDesc Desc; // Offset: 0x00 // Size: 0x10
	struct FSkillModifierOperator Operator; // Offset: 0x10 // Size: 0x18
};

// Object Name: ScriptStruct Skill.SkillModifierOperator
// Size: 0x18 // Inherited bytes: 0x00
struct FSkillModifierOperator {
	// Fields
	struct FString Value; // Offset: 0x00 // Size: 0x10
	bool bIsNumericAttribute; // Offset: 0x10 // Size: 0x01
	enum class ESkillAttrOperator OperationType; // Offset: 0x11 // Size: 0x01
	enum class ESkillAttrOperator CombineType; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x5]; // Offset: 0x13 // Size: 0x05
};

// Object Name: ScriptStruct Skill.SkillModifierDesc
// Size: 0x10 // Inherited bytes: 0x00
struct FSkillModifierDesc {
	// Fields
	struct FName AttributeName; // Offset: 0x00 // Size: 0x08
	struct FName Tag; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Skill.SkillPredictionInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FSkillPredictionInfo {
	// Fields
	struct FPredictionKey PredictionKey; // Offset: 0x00 // Size: 0x10
	int32_t BindPhaseId; // Offset: 0x10 // Size: 0x04
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> OwnerSkillManager; // Offset: 0x14 // Size: 0x08
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Skill.SkillSaveData
// Size: 0x50 // Inherited bytes: 0x00
struct FSkillSaveData {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Skill.PhaseSaveData
// Size: 0x58 // Inherited bytes: 0x00
struct FPhaseSaveData {
	// Fields
	char pad_0x0[0x58]; // Offset: 0x00 // Size: 0x58
};

// Object Name: ScriptStruct Skill.ActionSaveData
// Size: 0x20 // Inherited bytes: 0x00
struct FActionSaveData {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct Skill.UTSkillDamageConfigData
// Size: 0x38 // Inherited bytes: 0x00
struct FUTSkillDamageConfigData {
	// Fields
	struct FString DamageConfigKey; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> PickerConfigKeyArray; // Offset: 0x10 // Size: 0x10
	enum class EDamageSourceType DamageSourceType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	float FixedDamageAmount; // Offset: 0x24 // Size: 0x04
	float OtherDamageScale; // Offset: 0x28 // Size: 0x04
	float GroupDamageScale; // Offset: 0x2c // Size: 0x04
	float TeamDamageScale; // Offset: 0x30 // Size: 0x04
	float SelfDamageScale; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct Skill.UTSkillActionCreateData
// Size: 0x0c // Inherited bytes: 0x00
struct FUTSkillActionCreateData {
	// Fields
	float DelayTime; // Offset: 0x00 // Size: 0x04
	float Duration; // Offset: 0x04 // Size: 0x04
	bool IsBlueprintImplement; // Offset: 0x08 // Size: 0x01
	bool bForceExecute; // Offset: 0x09 // Size: 0x01
	bool bImportant; // Offset: 0x0a // Size: 0x01
	char pad_0xB[0x1]; // Offset: 0x0b // Size: 0x01
};

// Object Name: ScriptStruct Skill.SkillConditionWarpper
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillConditionWarpper {
	// Fields
	struct UUTSkillCondition* SkillCondition; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct Skill.UTSkillCreateData
// Size: 0xd0 // Inherited bytes: 0x00
struct FUTSkillCreateData {
	// Fields
	int32_t SkillGroupIndex; // Offset: 0x00 // Size: 0x04
	float Range; // Offset: 0x04 // Size: 0x04
	struct UUTSkillCDBase* SkillCD; // Offset: 0x08 // Size: 0x08
	struct TMap<int32_t, struct UUTSkillWidget*> SkillUIs; // Offset: 0x10 // Size: 0x50
	struct TMap<struct FString, int32_t> SkillUIPathToHandle; // Offset: 0x60 // Size: 0x50
	struct TArray<struct UUTSkillPhase*> Phases; // Offset: 0xb0 // Size: 0x10
	bool WidgetInitialVisibility; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x3]; // Offset: 0xc1 // Size: 0x03
	int32_t SkillMainWidgetHandle; // Offset: 0xc4 // Size: 0x04
	bool bIgnoreDamage; // Offset: 0xc8 // Size: 0x01
	bool bStopOnDisconnected; // Offset: 0xc9 // Size: 0x01
	bool bStopOnWillEnterBackground; // Offset: 0xca // Size: 0x01
	char pad_0xCB[0x5]; // Offset: 0xcb // Size: 0x05
};

// Object Name: ScriptStruct Skill.UTSkillUIData
// Size: 0x30 // Inherited bytes: 0x00
struct FUTSkillUIData {
	// Fields
	struct FString UIDefineName; // Offset: 0x00 // Size: 0x10
	struct FString UISlotName; // Offset: 0x10 // Size: 0x10
	struct UUserWidget* SkillBtnBPTemplate; // Offset: 0x20 // Size: 0x08
	struct UUserWidget* CancelBtnBPTemplate; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct Skill.UTSkillPhaseJumpResult
// Size: 0x08 // Inherited bytes: 0x00
struct FUTSkillPhaseJumpResult {
	// Fields
	int32_t SkillIndex; // Offset: 0x00 // Size: 0x04
	char DirtyTrigger; // Offset: 0x04 // Size: 0x01
	enum class EUTSkillPhaseJumpResult ResultCode; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
};

// Object Name: ScriptStruct Skill.UTSkillSynData
// Size: 0x20 // Inherited bytes: 0x00
struct FUTSkillSynData {
	// Fields
	uint64_t DoneSkillPhaseMask; // Offset: 0x00 // Size: 0x08
	int32_t CurSkillIndex; // Offset: 0x08 // Size: 0x04
	int32_t CurSkillPhase; // Offset: 0x0c // Size: 0x04
	enum class EUTSkillStopReason StopReason; // Offset: 0x10 // Size: 0x01
	bool bCasting; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	int32_t PhaseFlag; // Offset: 0x14 // Size: 0x04
	int32_t ClientBaseKey; // Offset: 0x18 // Size: 0x04
	int32_t CastCount; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Skill.UTSkillHitEnvInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FUTSkillHitEnvInfo {
	// Fields
	struct TArray<struct AActor*> ToPawn; // Offset: 0x00 // Size: 0x10
	struct AActor* FromPawn; // Offset: 0x10 // Size: 0x08
	int32_t SkillID; // Offset: 0x18 // Size: 0x04
	int32_t SkillPhaseID; // Offset: 0x1c // Size: 0x04
	enum class EPhysicalSurface HitSurfaceType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	struct FVector HitEnvLocation; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct Skill.SkillCDSyncData
// Size: 0x1c // Inherited bytes: 0x00
struct FSkillCDSyncData {
	// Fields
	int32_t SkillIndex; // Offset: 0x00 // Size: 0x04
	bool bEnableCD; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int32_t AvailableTimes; // Offset: 0x08 // Size: 0x04
	int32_t AvailableTimesRound; // Offset: 0x0c // Size: 0x04
	float Energy; // Offset: 0x10 // Size: 0x04
	float LastActiveTime; // Offset: 0x14 // Size: 0x04
	bool bMarkModify; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
};

// Object Name: ScriptStruct Skill.Skilladdchild
// Size: 0x08 // Inherited bytes: 0x00
struct FSkilladdchild {
	// Fields
	struct UUAEUserWidget* child; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct Skill.PredcitionData
// Size: 0x20 // Inherited bytes: 0x00
struct FPredcitionData {
	// Fields
	struct FPredictionKey BasePredictionKey; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FSkillPredictionInfo> PredictionList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Skill.UTAddedSkillSturct
// Size: 0x18 // Inherited bytes: 0x00
struct FUTAddedSkillSturct {
	// Fields
	struct FString SkillTemplatePath; // Offset: 0x00 // Size: 0x10
	int32_t SkillIndex; // Offset: 0x10 // Size: 0x04
	int32_t SkillHandle; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Skill.UTSkillAutoTriggerCondition
// Size: 0x28 // Inherited bytes: 0x00
struct FUTSkillAutoTriggerCondition {
	// Fields
	enum class ESkillConditionType Condition; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t Param_W; // Offset: 0x04 // Size: 0x04
	int32_t Param_X; // Offset: 0x08 // Size: 0x04
	int32_t Param_Y; // Offset: 0x0c // Size: 0x04
	int32_t Param_Z; // Offset: 0x10 // Size: 0x04
	enum class ESkillEndConditionType EndCondition; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	int32_t Param_A; // Offset: 0x18 // Size: 0x04
	int32_t Param_B; // Offset: 0x1c // Size: 0x04
	int32_t Param_C; // Offset: 0x20 // Size: 0x04
	int32_t Param_D; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Skill.UTSkillPhaseCreateData
// Size: 0xc8 // Inherited bytes: 0x00
struct FUTSkillPhaseCreateData {
	// Fields
	float PhaseDuration; // Offset: 0x00 // Size: 0x04
	float PhaseSpeed; // Offset: 0x04 // Size: 0x04
	float AutonomousPhaseDelay; // Offset: 0x08 // Size: 0x04
	bool bMustHasTarget; // Offset: 0x0c // Size: 0x01
	bool bCoolDownStart; // Offset: 0x0d // Size: 0x01
	bool bReleasedStart; // Offset: 0x0e // Size: 0x01
	char pad_0xF[0x1]; // Offset: 0x0f // Size: 0x01
	int32_t NextPhaseID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TSet<int32_t> NextPhaseIDs; // Offset: 0x18 // Size: 0x50
	struct TArray<struct UUTSkillCondition*> PhaseConditions; // Offset: 0x68 // Size: 0x10
	enum class UTSkillPhaseType PhaseType; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x7]; // Offset: 0x79 // Size: 0x07
	struct FString EnterPhaseTipString; // Offset: 0x80 // Size: 0x10
	struct UUTSkillPicker* Picker; // Offset: 0x90 // Size: 0x08
	struct TArray<struct UUTSkillEffect*> Actions; // Offset: 0x98 // Size: 0x10
	struct TArray<struct UUTSkillEffect*> HurtAppearances; // Offset: 0xa8 // Size: 0x10
	struct TArray<struct UUTSkillEventEffectMapForEditor*> EditorEventEffectMap; // Offset: 0xb8 // Size: 0x10
};

// Object Name: ScriptStruct Skill.UTSkillEventActionMap
// Size: 0x30 // Inherited bytes: 0x00
struct FUTSkillEventActionMap {
	// Fields
	enum class EUTSkillEventType SkillEventType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UUTSkillEffect* Action; // Offset: 0x08 // Size: 0x08
	struct TArray<struct UUTSkillCondition*> Conditions; // Offset: 0x10 // Size: 0x10
	struct TArray<struct UUTSkillCondition*> TargetConditions; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Skill.UTSkillPickedTarget
// Size: 0x48 // Inherited bytes: 0x00
struct FUTSkillPickedTarget {
	// Fields
	struct TWeakObjectPtr<struct AActor> Target; // Offset: 0x00 // Size: 0x08
	struct FVector ImpactPoint; // Offset: 0x08 // Size: 0x0c
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct UPrimitiveComponent*> TargetComponents; // Offset: 0x18 // Size: 0x10
	bool IsHeadShot; // Offset: 0x28 // Size: 0x01
	char HitPos; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
	struct FName BoneName; // Offset: 0x2c // Size: 0x08
	struct FVector HitEnvLocation; // Offset: 0x34 // Size: 0x0c
	enum class EPhysicalSurface hitPhysMatType; // Offset: 0x40 // Size: 0x01
	bool IgnoreTakeDamage; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x6]; // Offset: 0x42 // Size: 0x06
};

// Object Name: ScriptStruct Skill.UTSkillPickerCreateData
// Size: 0x0c // Inherited bytes: 0x00
struct FUTSkillPickerCreateData {
	// Fields
	enum class UTSkillPickerType PickerType; // Offset: 0x00 // Size: 0x01
	enum class UTPickerTargetType PickerTargetType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int32_t PickerMaxCount; // Offset: 0x04 // Size: 0x04
	bool bIncludeOwner; // Offset: 0x08 // Size: 0x01
	bool bOnlyHero; // Offset: 0x09 // Size: 0x01
	bool bEnableTrace; // Offset: 0x0a // Size: 0x01
	bool WallCollision; // Offset: 0x0b // Size: 0x01
};

