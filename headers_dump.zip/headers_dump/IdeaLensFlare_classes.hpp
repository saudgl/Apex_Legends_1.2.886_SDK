#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class IdeaLensFlare.IdeaLensFlareActor
// Size: 0x3e0 // Inherited bytes: 0x268
struct AIdeaLensFlareActor : ACameraObserverActor {
	// Fields
	bool EnableCustomSunDirection; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x3]; // Offset: 0x269 // Size: 0x03
	struct FVector CustomSunDirection; // Offset: 0x26c // Size: 0x0c
	bool EnableSun; // Offset: 0x278 // Size: 0x01
	char pad_0x279[0x3]; // Offset: 0x279 // Size: 0x03
	float SunSize; // Offset: 0x27c // Size: 0x04
	struct FLinearColor SunTint; // Offset: 0x280 // Size: 0x10
	struct FLinearColor SunColor; // Offset: 0x290 // Size: 0x10
	float WorldRadius; // Offset: 0x2a0 // Size: 0x04
	struct FVector WorldOrigin; // Offset: 0x2a4 // Size: 0x0c
	struct FVector2D SunUV0; // Offset: 0x2b0 // Size: 0x08
	struct FVector2D SunUVSize; // Offset: 0x2b8 // Size: 0x08
	int32_t SunFaceNumLod0; // Offset: 0x2c0 // Size: 0x04
	int32_t SunFaceNumLod1; // Offset: 0x2c4 // Size: 0x04
	int32_t SunFaceNumLod2; // Offset: 0x2c8 // Size: 0x04
	char pad_0x2CC[0x4]; // Offset: 0x2cc // Size: 0x04
	struct UMaterialInterface* SunMaterial; // Offset: 0x2d0 // Size: 0x08
	uint32_t SunTranslucentSortPriority; // Offset: 0x2d8 // Size: 0x04
	enum class EDetailMode SunDetailMode; // Offset: 0x2dc // Size: 0x01
	char pad_0x2DD[0x3]; // Offset: 0x2dd // Size: 0x03
	float SunTransparency; // Offset: 0x2e0 // Size: 0x04
	bool EnableHalo; // Offset: 0x2e4 // Size: 0x01
	char pad_0x2E5[0x3]; // Offset: 0x2e5 // Size: 0x03
	struct FVector2D HaloSize; // Offset: 0x2e8 // Size: 0x08
	struct FLinearColor HaloColor; // Offset: 0x2f0 // Size: 0x10
	struct FLinearColor HaloTint; // Offset: 0x300 // Size: 0x10
	float HaloTransparency; // Offset: 0x310 // Size: 0x04
	struct FVector2D HaloUV0; // Offset: 0x314 // Size: 0x08
	struct FVector2D HaloUVSize; // Offset: 0x31c // Size: 0x08
	int32_t HaloFaceNumLod0; // Offset: 0x324 // Size: 0x04
	int32_t HaloFaceNumLod1; // Offset: 0x328 // Size: 0x04
	int32_t HaloFaceNumLod2; // Offset: 0x32c // Size: 0x04
	struct UMaterialInterface* HaloMaterial; // Offset: 0x330 // Size: 0x08
	uint32_t HaloTranslucentSortPriority; // Offset: 0x338 // Size: 0x04
	float HaloFadeSpeed; // Offset: 0x33c // Size: 0x04
	enum class EDetailMode HaloDetailMode; // Offset: 0x340 // Size: 0x01
	enum class ECollisionChannel TraceChannel; // Offset: 0x341 // Size: 0x01
	bool EnableLensFlare; // Offset: 0x342 // Size: 0x01
	char pad_0x343[0x5]; // Offset: 0x343 // Size: 0x05
	struct TArray<struct FLensFlareElement> LensFlareElements; // Offset: 0x348 // Size: 0x10
	struct UMaterialInterface* LensFlareMaterial; // Offset: 0x358 // Size: 0x08
	uint32_t LensFlareTranslucentSortPriority; // Offset: 0x360 // Size: 0x04
	float LensFlareFadeThreshold; // Offset: 0x364 // Size: 0x04
	float LensFlareFadeSpeed; // Offset: 0x368 // Size: 0x04
	enum class EDetailMode LensFlareDetailMode; // Offset: 0x36c // Size: 0x01
	char pad_0x36D[0x3]; // Offset: 0x36d // Size: 0x03
	struct FLinearColor LensFlareTint; // Offset: 0x370 // Size: 0x10
	float LensFlareTransparency; // Offset: 0x380 // Size: 0x04
	char pad_0x384[0x4]; // Offset: 0x384 // Size: 0x04
	struct URuntimeMeshComponent* Sun; // Offset: 0x388 // Size: 0x08
	struct URuntimeMeshComponent* Halo; // Offset: 0x390 // Size: 0x08
	struct URuntimeMeshComponent* LensFlare; // Offset: 0x398 // Size: 0x08
	char pad_0x3A0[0x40]; // Offset: 0x3a0 // Size: 0x40
};

