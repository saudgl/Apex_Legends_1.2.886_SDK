#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ZZAnimationLib.CharacterAnimConfigAssetUserData
// Size: 0x170 // Inherited bytes: 0x28
struct UCharacterAnimConfigAssetUserData : UAssetUserData {
	// Fields
	struct UAimOffsetBlendSpace1D* WeaponLeanAO; // Offset: 0x28 // Size: 0x08
	struct UAimOffsetBlendSpace* ActiveAO; // Offset: 0x30 // Size: 0x08
	struct UAimOffsetBlendSpace* PostWeaponAnimAO; // Offset: 0x38 // Size: 0x08
	struct UAimOffsetBlendSpace* WeaponRetractAO; // Offset: 0x40 // Size: 0x08
	struct UAnimSequenceBase* WeaponAccessoryGripAnim; // Offset: 0x48 // Size: 0x08
	struct UAnimSequence* MovingIdleAnim; // Offset: 0x50 // Size: 0x08
	struct UAnimSequence* LeisureIdleAnim; // Offset: 0x58 // Size: 0x08
	struct UAnimSequence* AdditionalAnim; // Offset: 0x60 // Size: 0x08
	struct UAnimSequence* AdditionalIdleAnim; // Offset: 0x68 // Size: 0x08
	struct UAnimSequence* LeftHandAdditionalIdleAnim; // Offset: 0x70 // Size: 0x08
	struct UAnimSequence* StandIdleAnim; // Offset: 0x78 // Size: 0x08
	struct UAnimSequence* StandTurnLeftAnim; // Offset: 0x80 // Size: 0x08
	struct UAnimSequence* StandTurnRightAnim; // Offset: 0x88 // Size: 0x08
	struct UAnimSequence* CrouchIdleAnim; // Offset: 0x90 // Size: 0x08
	struct UAnimSequence* CrouchTurnLeftAnim; // Offset: 0x98 // Size: 0x08
	struct UAnimSequence* CrouchTurnRightAnim; // Offset: 0xa0 // Size: 0x08
	struct UAnimSequence* ProneIdleAnim; // Offset: 0xa8 // Size: 0x08
	struct UAnimSequence* ProneTurnLeftAnim; // Offset: 0xb0 // Size: 0x08
	struct UAnimSequence* ProneTurnRightAnim; // Offset: 0xb8 // Size: 0x08
	struct UAnimSequence* JumpStartAnim; // Offset: 0xc0 // Size: 0x08
	struct UAnimSequence* JumpDownAnim; // Offset: 0xc8 // Size: 0x08
	struct UAnimSequence* JumpLandAnim_Normal; // Offset: 0xd0 // Size: 0x08
	struct UAnimSequence* JumpLandAnim_Heavy; // Offset: 0xd8 // Size: 0x08
	struct UBlendSpaceBase* FallingDownBS; // Offset: 0xe0 // Size: 0x08
	struct UAnimSequence* ProneToStanding; // Offset: 0xe8 // Size: 0x08
	struct UAnimSequence* ProneToCrouching; // Offset: 0xf0 // Size: 0x08
	struct UAnimSequence* CrouchingToStanding; // Offset: 0xf8 // Size: 0x08
	struct UAnimSequence* CrouchingToProne; // Offset: 0x100 // Size: 0x08
	struct UAnimSequence* StandingToProne; // Offset: 0x108 // Size: 0x08
	float StandingToPronePlayRate; // Offset: 0x110 // Size: 0x04
	char pad_0x114[0x4]; // Offset: 0x114 // Size: 0x04
	struct UAnimSequence* StandingToCrouching; // Offset: 0x118 // Size: 0x08
	struct UBlendSpaceBase* StandMoveBS; // Offset: 0x120 // Size: 0x08
	struct UBlendSpaceBase* CrouchMoveBS; // Offset: 0x128 // Size: 0x08
	struct UBlendSpaceBase* ProneMoveBS; // Offset: 0x130 // Size: 0x08
	struct UBlendSpaceBase* FlyMoveBS; // Offset: 0x138 // Size: 0x08
	struct UBlendSpaceBase* SprintMoveBS; // Offset: 0x140 // Size: 0x08
	struct UBlendSpaceBase* SlipMoveBS; // Offset: 0x148 // Size: 0x08
	struct UAimOffsetBlendSpace* SpringBasedAimAO; // Offset: 0x150 // Size: 0x08
	struct UAnimSequence* TargetVaultAnim; // Offset: 0x158 // Size: 0x08
	struct UAnimSequence* BreathStabilityAnim; // Offset: 0x160 // Size: 0x08
	struct UAnimSequence* BreathAimGaspingAnim; // Offset: 0x168 // Size: 0x08
};

// Object Name: Class ZZAnimationLib.CharacterAnimConfigDataAsset
// Size: 0x178 // Inherited bytes: 0x30
struct UCharacterAnimConfigDataAsset : UDataAsset {
	// Fields
	struct UAimOffsetBlendSpace1D* WeaponLeanAO; // Offset: 0x30 // Size: 0x08
	struct UAimOffsetBlendSpace* ActiveAO; // Offset: 0x38 // Size: 0x08
	struct UAimOffsetBlendSpace* PostWeaponAnimAO; // Offset: 0x40 // Size: 0x08
	struct UAimOffsetBlendSpace* WeaponRetractAO; // Offset: 0x48 // Size: 0x08
	struct UAnimSequenceBase* WeaponAccessoryGripAnim; // Offset: 0x50 // Size: 0x08
	struct UAnimSequence* MovingIdleAnim; // Offset: 0x58 // Size: 0x08
	struct UAnimSequence* LeisureIdleAnim; // Offset: 0x60 // Size: 0x08
	struct UAnimSequence* AdditionalAnim; // Offset: 0x68 // Size: 0x08
	struct UAnimSequence* AdditionalIdleAnim; // Offset: 0x70 // Size: 0x08
	struct UAnimSequence* LeftHandAdditionalIdleAnim; // Offset: 0x78 // Size: 0x08
	struct UAnimSequence* StandIdleAnim; // Offset: 0x80 // Size: 0x08
	struct UAnimSequence* StandTurnLeftAnim; // Offset: 0x88 // Size: 0x08
	struct UAnimSequence* StandTurnRightAnim; // Offset: 0x90 // Size: 0x08
	struct UAnimSequence* CrouchIdleAnim; // Offset: 0x98 // Size: 0x08
	struct UAnimSequence* CrouchTurnLeftAnim; // Offset: 0xa0 // Size: 0x08
	struct UAnimSequence* CrouchTurnRightAnim; // Offset: 0xa8 // Size: 0x08
	struct UAnimSequence* ProneIdleAnim; // Offset: 0xb0 // Size: 0x08
	struct UAnimSequence* ProneTurnLeftAnim; // Offset: 0xb8 // Size: 0x08
	struct UAnimSequence* ProneTurnRightAnim; // Offset: 0xc0 // Size: 0x08
	struct UAnimSequence* JumpStartAnim; // Offset: 0xc8 // Size: 0x08
	struct UAnimSequence* JumpDownAnim; // Offset: 0xd0 // Size: 0x08
	struct UAnimSequence* JumpLandAnim_Normal; // Offset: 0xd8 // Size: 0x08
	struct UAnimSequence* JumpLandAnim_Heavy; // Offset: 0xe0 // Size: 0x08
	struct UBlendSpaceBase* FallingDownBS; // Offset: 0xe8 // Size: 0x08
	struct UAnimSequence* ProneToStanding; // Offset: 0xf0 // Size: 0x08
	struct UAnimSequence* ProneToCrouching; // Offset: 0xf8 // Size: 0x08
	struct UAnimSequence* CrouchingToStanding; // Offset: 0x100 // Size: 0x08
	struct UAnimSequence* CrouchingToProne; // Offset: 0x108 // Size: 0x08
	struct UAnimSequence* StandingToProne; // Offset: 0x110 // Size: 0x08
	float StandingToPronePlayRate; // Offset: 0x118 // Size: 0x04
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
	struct UAnimSequence* StandingToCrouching; // Offset: 0x120 // Size: 0x08
	struct UBlendSpaceBase* StandMoveBS; // Offset: 0x128 // Size: 0x08
	struct UBlendSpaceBase* CrouchMoveBS; // Offset: 0x130 // Size: 0x08
	struct UBlendSpaceBase* ProneMoveBS; // Offset: 0x138 // Size: 0x08
	struct UBlendSpaceBase* FlyMoveBS; // Offset: 0x140 // Size: 0x08
	struct UBlendSpaceBase* SprintMoveBS; // Offset: 0x148 // Size: 0x08
	struct UBlendSpaceBase* SlipMoveBS; // Offset: 0x150 // Size: 0x08
	struct UAimOffsetBlendSpace* SpringBasedAimAO; // Offset: 0x158 // Size: 0x08
	struct UAnimSequence* TargetVaultAnim; // Offset: 0x160 // Size: 0x08
	struct UAnimSequence* BreathStabilityAnim; // Offset: 0x168 // Size: 0x08
	struct UAnimSequence* BreathAimGaspingAnim; // Offset: 0x170 // Size: 0x08
};

// Object Name: Class ZZAnimationLib.CharacterSpeedLayerConfig
// Size: 0x50 // Inherited bytes: 0x28
struct UCharacterSpeedLayerConfig : UObject {
	// Fields
	struct TArray<struct FSingleCharacterSpeedLayer> Layers; // Offset: 0x28 // Size: 0x10
	struct FSingleCharacterSpeedLayer LowSpeedLayer; // Offset: 0x38 // Size: 0x10
	int32_t LowSpeedGearIndex; // Offset: 0x48 // Size: 0x04
	float SpeedRangeBuffer; // Offset: 0x4c // Size: 0x04

	// Functions

	// Object Name: Function ZZAnimationLib.CharacterSpeedLayerConfig.CalculateCurrentLayerIndex
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int32_t CalculateCurrentLayerIndex(int32_t inPreviousIndex, float inCurrentVelocity, float& outPlayRate); // Offset: 0x1023790d8 // Return & Params: Num(4) Size(0x10)
};

// Object Name: Class ZZAnimationLib.DynamicAttributtAnimInstance
// Size: 0xc00 // Inherited bytes: 0x270
struct UDynamicAttributtAnimInstance : UAnimInstance {
	// Fields
	struct FDynamicAttrAnimInstanceProxy Proxy; // Offset: 0x270 // Size: 0x990
};

// Object Name: Class ZZAnimationLib.JogStartingComponent
// Size: 0x220 // Inherited bytes: 0xf0
struct UJogStartingComponent : UActorComponent {
	// Fields
	char pad_0xF0[0x8]; // Offset: 0xf0 // Size: 0x08
	struct FMulticastInlineDelegate OnJogStartDelegate; // Offset: 0xf8 // Size: 0x10
	struct ACharacter* OwnerCharacter; // Offset: 0x108 // Size: 0x08
	struct UCharacterMovementComponent* ObserveredCharacterMovementComponent; // Offset: 0x110 // Size: 0x08
	struct USkeletalMeshComponent* ObserveredSkeletalMeshComponent; // Offset: 0x118 // Size: 0x08
	struct FVector JogStartingLocation; // Offset: 0x120 // Size: 0x0c
	float DistanceNeededToNomalJog; // Offset: 0x12c // Size: 0x04
	float VelocityCanBeSeemsAsIdleThreshold; // Offset: 0x130 // Size: 0x04
	struct FName JogStartingLocationKey; // Offset: 0x134 // Size: 0x08
	struct FName JogStartDistanceKey; // Offset: 0x13c // Size: 0x08
	struct FName JogStartToJoggingConditionKey; // Offset: 0x144 // Size: 0x08
	struct FName IdleToJogStartConditionKey; // Offset: 0x14c // Size: 0x08
	struct FName MainJogStartAnimSeqKey; // Offset: 0x154 // Size: 0x08
	struct FName SecondaryJogStartAnimSeqKey; // Offset: 0x15c // Size: 0x08
	struct FName JogStartFirstStepAngleAlphaKey; // Offset: 0x164 // Size: 0x08
	struct FName JogStartFirstStepTransitionKey; // Offset: 0x16c // Size: 0x08
	struct FName MainJogStartAnimPositionKey; // Offset: 0x174 // Size: 0x08
	struct FName SecondaryJogStartAnimPositionKey; // Offset: 0x17c // Size: 0x08
	char pad_0x184[0x4]; // Offset: 0x184 // Size: 0x04
	struct UAnimSequence* JogStartForwardSequence; // Offset: 0x188 // Size: 0x08
	struct UAnimSequence* JogStartBackwardSequence; // Offset: 0x190 // Size: 0x08
	struct UAnimSequence* JogStartLeftSequence; // Offset: 0x198 // Size: 0x08
	struct UAnimSequence* JogStartRightSequence; // Offset: 0x1a0 // Size: 0x08
	char pad_0x1A8[0x78]; // Offset: 0x1a8 // Size: 0x78
};

// Object Name: Class ZZAnimationLib.JogStopComponent
// Size: 0x168 // Inherited bytes: 0xf0
struct UJogStopComponent : UActorComponent {
	// Fields
	char pad_0xF0[0x8]; // Offset: 0xf0 // Size: 0x08
	struct FMulticastInlineDelegate OnJogStopDelegate; // Offset: 0xf8 // Size: 0x10
	struct ACharacter* OwnerCharacter; // Offset: 0x108 // Size: 0x08
	struct UCharacterMovementComponent* ObserveredCharacterMovementComponent; // Offset: 0x110 // Size: 0x08
	struct USkeletalMeshComponent* ObserveredSkeletalMeshComponent; // Offset: 0x118 // Size: 0x08
	char pad_0x120[0x48]; // Offset: 0x120 // Size: 0x48
};

// Object Name: Class ZZAnimationLib.ZZAnimationLibBPLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UZZAnimationLibBPLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZPredictStopOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void ZZPredictStopOffset(struct UCharacterMovementComponent* inCharacterMovementComp, bool isPivot, struct FVector& outPredictOffset, bool& Success); // Offset: 0x10237c2b0 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZMergeAttrDicts
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FAnimInstanceAttributeDict ZZMergeAttrDicts(struct TArray<struct FAnimInstanceAttributeDict>& inDicts); // Offset: 0x10237b4c0 // Return & Params: Num(2) Size(0x1f0)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetVectorAttrFromMap
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector ZZGetVectorAttrFromMap(struct FAnimInstanceAttributeDict& inDict, struct FName KeyName, bool& Success); // Offset: 0x10237add0 // Return & Params: Num(4) Size(0x1f8)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetStrafeMovingDirectionWithCustomRange
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	float ZZGetStrafeMovingDirectionWithCustomRange(struct FCustomizedOrientationWarpingAngleSetting AngleSetting, struct FVector MovingDirectionInLocalSpace, struct FVector ForwardAxis, struct FVector UpAxis); // Offset: 0x10237cd2c // Return & Params: Num(5) Size(0x58)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetStrafeMovingDirectionWithBufferWithCustomRange
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void ZZGetStrafeMovingDirectionWithBufferWithCustomRange(struct FCustomizedOrientationWarpingAngleSetting AngleSetting, float inStrafeMovingDirection, int32_t& DirectionA, int32_t PreviousDirection, float bufferValue); // Offset: 0x10237c7c4 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetStrafeMovingDirectionWithBuffer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void ZZGetStrafeMovingDirectionWithBuffer(float inStrafeMovingDirection, enum class ECharacterLocalDirection& DirectionA, enum class ECharacterLocalDirection PreviousDirection, float bufferValue); // Offset: 0x10237d148 // Return & Params: Num(4) Size(0xc)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetStrafeMovingDirectionsWithCustomRange
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void ZZGetStrafeMovingDirectionsWithCustomRange(struct FCustomizedOrientationWarpingAngleSetting AngleSetting, float inStrafeMovingDirection, enum class ECharacterLocalDirection& DirectionA, enum class ECharacterLocalDirection& DirectionB, float& BlendAlpha); // Offset: 0x10237ca64 // Return & Params: Num(5) Size(0x3c)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetStrafeMovingDirections
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void ZZGetStrafeMovingDirections(float inStrafeMovingDirection, enum class ECharacterLocalDirection& DirectionA, enum class ECharacterLocalDirection& DirectionB, float& BlendAlpha); // Offset: 0x10237d2a0 // Return & Params: Num(4) Size(0xc)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetStrafeMovingDirection
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	float ZZGetStrafeMovingDirection(struct FVector MovingDirectionInLocalSpace, struct FVector ForwardAxis, struct FVector UpAxis); // Offset: 0x10237d42c // Return & Params: Num(4) Size(0x28)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetStrafeMainDirectionWithCustomRange
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t ZZGetStrafeMainDirectionWithCustomRange(struct FCustomizedOrientationWarpingAngleSetting AngleSetting, float inMovingCardinalDirection); // Offset: 0x10237cf7c // Return & Params: Num(3) Size(0x38)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetStrafeMainDirection
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	enum class ECharacterLocalDirection ZZGetStrafeMainDirection(float inMovingCardinalDirection); // Offset: 0x10237d530 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetSpecificStateWeightByNames
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float ZZGetSpecificStateWeightByNames(struct UAnimInstance* inAnimInstance, struct FName inMachineName, struct FName inStateName); // Offset: 0x10237c1b0 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetRotatorAttrFromMap
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FRotator ZZGetRotatorAttrFromMap(struct FAnimInstanceAttributeDict& inDict, struct FName KeyName, bool& Success); // Offset: 0x10237aa50 // Return & Params: Num(4) Size(0x1f8)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetMovementRelatedInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void ZZGetMovementRelatedInfo(struct UCharacterMovementComponent* inCharacterMovement, struct FAnimMovementData& outAnimMovementData); // Offset: 0x10237b9d0 // Return & Params: Num(2) Size(0x68)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetIntegerAttrFromMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t ZZGetIntegerAttrFromMap(struct FAnimInstanceAttributeDict& inDict, struct FName KeyName, bool& Success); // Offset: 0x10237af94 // Return & Params: Num(4) Size(0x1f0)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetFloatAttrFromMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float ZZGetFloatAttrFromMap(struct FAnimInstanceAttributeDict& inDict, struct FName KeyName, bool& Success); // Offset: 0x10237b150 // Return & Params: Num(4) Size(0x1f0)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetCurrentStateWeightByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float ZZGetCurrentStateWeightByName(struct UAnimInstance* inAnimInstance, struct FName inMachineName); // Offset: 0x10237c0f4 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetCurrentStateNameByMachineName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FName ZZGetCurrentStateNameByMachineName(struct UAnimInstance* inAnimInstance, struct FName inMachineName); // Offset: 0x10237c038 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetBoolAttrFromMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool ZZGetBoolAttrFromMap(struct FAnimInstanceAttributeDict& inDict, struct FName KeyName, bool& Success); // Offset: 0x10237ac14 // Return & Params: Num(4) Size(0x1ea)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZGetAnimSeqAttrFromMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UAnimSequence* ZZGetAnimSeqAttrFromMap(struct FAnimInstanceAttributeDict& inDict, struct FName KeyName, bool& Success); // Offset: 0x10237a894 // Return & Params: Num(4) Size(0x1f8)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZEvaluateCurveName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float ZZEvaluateCurveName(struct UAnimSequence* inAnimSeq, float InTime, bool& Success, struct FName CurveName); // Offset: 0x10237d5ac // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZCollectAnimBPAttributeFromComponents
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FAnimInstanceAttributeDict ZZCollectAnimBPAttributeFromComponents(struct AActor* TargetActor, bool useCustomComponentTagName, struct FName customComponentTagName); // Offset: 0x10237bac0 // Return & Params: Num(4) Size(0x1f8)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZCalculatTargetFrame
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float ZZCalculatTargetFrame(float inTargetValue, struct UAnimSequence* inAnimSequence, enum class EFindTargetFrameResult& OutResult, struct FName CurveName, bool curveIsInOrder); // Offset: 0x10237c610 // Return & Params: Num(6) Size(0x24)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZCalculatOrientationWarpingAngle
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void ZZCalculatOrientationWarpingAngle(float directionAngle, float& outLocomotionNorthAngle, float& outLocomotionWestAngle, float& outLocomotionSouthAngle, float& outLocomotionEastAngle); // Offset: 0x10237c428 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZAttrDictDebugStrs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct TArray<struct FString> ZZAttrDictDebugStrs(struct FAnimInstanceAttributeDict& inDict); // Offset: 0x10237b30c // Return & Params: Num(2) Size(0x1f0)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.ZZAnimationLibSampleFunction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float ZZAnimationLibSampleFunction(float Param); // Offset: 0x10237d714 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.SwitchToCPUSkinning
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SwitchToCPUSkinning(struct USkinnedMeshComponent* InMesh, bool inEnableCPUSkinning); // Offset: 0x102379e78 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.SquaredDistanceFromPointToSegment
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	float SquaredDistanceFromPointToSegment(struct FVector CapsulePointA, struct FVector CapsulePointB, struct FVector TestPoint); // Offset: 0x102379d74 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.SquaredDistanceAndReferencePointFromPointToSegment
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	float SquaredDistanceAndReferencePointFromPointToSegment(struct FVector CapsulePointA, struct FVector CapsulePointB, struct FVector TestPoint, struct FVector& ReferencePoint); // Offset: 0x102379c20 // Return & Params: Num(5) Size(0x34)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.GetValidSectionFromCustomizedOrientationWarpingAngleSetting
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t GetValidSectionFromCustomizedOrientationWarpingAngleSetting(struct FCustomizedOrientationWarpingAngleSetting OrientationWarpingAngleSetting, float directionAngle); // Offset: 0x10237a6c8 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.GetLocomotionOfAllDirections
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct TArray<float> GetLocomotionOfAllDirections(struct FCustomizedOrientationWarpingAngleSetting OrientationWarpingAngleSetting, float directionAngle); // Offset: 0x10237a2b0 // Return & Params: Num(3) Size(0x48)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.GetLocomotionOfACertainDirection
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetLocomotionOfACertainDirection(struct FCustomizedOrientationWarpingAngleSetting OrientationWarpingAngleSetting, float directionAngle, int32_t DirectionIndex); // Offset: 0x10237a4b8 // Return & Params: Num(4) Size(0x3c)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.GetLocalSpaceBoneTransformOfRefPose
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform GetLocalSpaceBoneTransformOfRefPose(struct UAnimSequence* inAnimSequence, struct FName InBoneName); // Offset: 0x102379f38 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.GetLocalSpaceBoneTransformOfAnimSequence
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform GetLocalSpaceBoneTransformOfAnimSequence(struct UAnimSequence* inAnimSequence, float InTime, struct FName InBoneName); // Offset: 0x10237a030 // Return & Params: Num(4) Size(0x50)

	// Object Name: Function ZZAnimationLib.ZZAnimationLibBPLibrary.GetComponentSpaceBoneTransformOfAnimSequence
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform GetComponentSpaceBoneTransformOfAnimSequence(struct UAnimSequence* inAnimSequence, float InTime, struct FName InBoneName); // Offset: 0x10237a170 // Return & Params: Num(4) Size(0x50)
};

// Object Name: Class ZZAnimationLib.ZZAnimAttrFetchInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UZZAnimAttrFetchInterface : UInterface {
	// Functions

	// Object Name: Function ZZAnimationLib.ZZAnimAttrFetchInterface.FetchAnimAttr
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	struct FAnimInstanceAttributeDict FetchAnimAttr(); // Offset: 0x102386580 // Return & Params: Num(1) Size(0x1e0)
};

// Object Name: Class ZZAnimationLib.ZZAnimSettings
// Size: 0x58 // Inherited bytes: 0x38
struct UZZAnimSettings : UDeveloperSettings {
	// Fields
	struct FName CollectAttributeFromComponentWithTagName; // Offset: 0x38 // Size: 0x08
	struct FName DistanceCurveName; // Offset: 0x40 // Size: 0x08
	struct FName DisableSpeedWarpingCurveName; // Offset: 0x48 // Size: 0x08
	struct FName TurningDistanceCurveName; // Offset: 0x50 // Size: 0x08
};

