#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VideoLocalLangCfgForLaunch_Type.BP_STRUCT_VideoLocalLangCfgForLaunch_Type
// Size: 0x170 // Inherited bytes: 0x00
struct FBP_STRUCT_VideoLocalLangCfgForLaunch_Type {
	// Fields
	struct FString Source_2_1D985AA2442A79EAB7706B9550322F5C; // Offset: 0x00 // Size: 0x10
	struct FString en_3_5D5F0FC0650DFFBF5D5F464A09D4230E; // Offset: 0x10 // Size: 0x10
	struct FString ru_4_40A574C05C6752D95D5F39EB09D42225; // Offset: 0x20 // Size: 0x10
	struct FString de_5_2E512D40347D48175D5F462209D42315; // Offset: 0x30 // Size: 0x10
	struct FString ja_6_486A6DC057E195CD5D5F46E909D424B1; // Offset: 0x40 // Size: 0x10
	struct FString ko_7_777D518008724D7A5D5F391A09D424AF; // Offset: 0x50 // Size: 0x10
	struct FString zh_8_38BF738060ED0FC45D5F38F409D423B8; // Offset: 0x60 // Size: 0x10
	struct FString zh-Hant-HK_9_57B151803965E9B04C8F7F5C0A66E50B; // Offset: 0x70 // Size: 0x10
	struct FString zh-Hant-TW_10_0BF7D780365416304C8F62CF0A66E657; // Offset: 0x80 // Size: 0x10
	struct FString th_11_1EA232003D88C20A5D5F383909D42218; // Offset: 0x90 // Size: 0x10
	struct FString vi_12_7CACF2C01EAA31495D5F387809D42279; // Offset: 0xa0 // Size: 0x10
	struct FString id_13_19688E402750DE315D5F46CF09D42344; // Offset: 0xb0 // Size: 0x10
	struct FString pt_14_629AB4007B45E39A5D5F39A809D422C4; // Offset: 0xc0 // Size: 0x10
	struct FString fr_15_0C67F100159EB7625D5F467509D42362; // Offset: 0xd0 // Size: 0x10
	struct FString es_16_5D641100650DFFC45D5F465109D42373; // Offset: 0xe0 // Size: 0x10
	struct FString es-MX_17_5C63E58046EEF38403696D730237DD68; // Offset: 0xf0 // Size: 0x10
	struct FString fil_18_4EBFA9C043DAE62D3E1FD9EB0D42376C; // Offset: 0x100 // Size: 0x10
	struct FString tr_19_1EAC34803D88C2145D5F382309D42202; // Offset: 0x110 // Size: 0x10
	struct FString ar_20_214F8FC022CB21475D5F47D309D42332; // Offset: 0x120 // Size: 0x10
	struct FString hi_21_6A68AF4076C026975D5F46A309D42359; // Offset: 0x130 // Size: 0x10
	struct FString it_22_197892402750DE415D5F46DF09D424B4; // Offset: 0x140 // Size: 0x10
	struct FString ms_23_558B13006993BCBC5D5F395B09D424F3; // Offset: 0x150 // Size: 0x10
	struct FString pl_24_6292B2007B45E3925D5F39A009D422DC; // Offset: 0x160 // Size: 0x10
};

