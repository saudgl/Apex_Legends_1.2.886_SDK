#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MaskBox.MaskBox
// Size: 0x170 // Inherited bytes: 0x128
struct UMaskBox : UContentWidget {
	// Fields
	int32_t InvalidateFrameCount; // Offset: 0x124 // Size: 0x04
	int32_t Phase; // Offset: 0x128 // Size: 0x04
	int32_t PhaseCount; // Offset: 0x12c // Size: 0x04
	bool IgnoreStretch; // Offset: 0x130 // Size: 0x01
	int32_t MaskType; // Offset: 0x134 // Size: 0x04
	struct FVector2D MaskTransformPivot; // Offset: 0x138 // Size: 0x08
	struct FVector2D MaskTransformScale; // Offset: 0x140 // Size: 0x08
	float MaskTransformAngle; // Offset: 0x148 // Size: 0x04
	char pad_0x14D[0x3]; // Offset: 0x14d // Size: 0x03
	struct UMaterialInterface* MaskMaterial; // Offset: 0x150 // Size: 0x08
	struct UTexture2D* MaskTexture; // Offset: 0x158 // Size: 0x08
	char pad_0x160[0x10]; // Offset: 0x160 // Size: 0x10

	// Functions

	// Object Name: Function MaskBox.MaskBox.SetMaskTransformScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformScale(struct FVector2D Scale); // Offset: 0x101d7d44c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MaskBox.MaskBox.SetMaskTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformPivot(struct FVector2D Pivot); // Offset: 0x101d7d358 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MaskBox.MaskBox.SetMaskTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskTransformAngle(float Angle); // Offset: 0x101d7d3d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MaskBox.MaskBox.SetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskMaterial(struct UMaterialInterface* EffectMaterial); // Offset: 0x101d7d540 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MaskBox.MaskBox.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture); // Offset: 0x101d7d4c4 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction MaskBox.MaskBox.GetVector2D__DelegateSignature
	// Flags: [Public|Delegate|HasDefaults]
	struct FVector2D GetVector2D__DelegateSignature(); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MaskBox.MaskBox.GetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaskMaterial(); // Offset: 0x101d7d5bc // Return & Params: Num(1) Size(0x8)
};

