#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct IdeaLensFlare.LensFlareElement
// Size: 0x38 // Inherited bytes: 0x00
struct FLensFlareElement {
	// Fields
	float Position; // Offset: 0x00 // Size: 0x04
	float ScaleFactor; // Offset: 0x04 // Size: 0x04
	float RotationFactor; // Offset: 0x08 // Size: 0x04
	float FadeTowardsSun; // Offset: 0x0c // Size: 0x04
	struct FVector2D Size; // Offset: 0x10 // Size: 0x08
	struct FVector2D UV0; // Offset: 0x18 // Size: 0x08
	struct FVector2D UVSize; // Offset: 0x20 // Size: 0x08
	struct FLinearColor Color; // Offset: 0x28 // Size: 0x10
};

