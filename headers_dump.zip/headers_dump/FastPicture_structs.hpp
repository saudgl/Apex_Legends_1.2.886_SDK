#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct FastPicture.FPGUPProfileMatch
// Size: 0x20 // Inherited bytes: 0x00
struct FFPGUPProfileMatch {
	// Fields
	struct FString Profile; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FFPProfileMatchItem> Match; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.FPProfileMatchItem
// Size: 0x18 // Inherited bytes: 0x00
struct FFPProfileMatchItem {
	// Fields
	enum class EFastPictureSourceType SourceType; // Offset: 0x00 // Size: 0x01
	enum class EFastPictureCompareType CompareType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FString MatchString; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.FPProfileMatch
// Size: 0x20 // Inherited bytes: 0x00
struct FFPProfileMatch {
	// Fields
	struct FString Profile; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FFPProfileMatchItem> Match; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.FPSoundQualityInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FFPSoundQualityInfo {
	// Fields
	int32_t BaseQuality; // Offset: 0x00 // Size: 0x04
	int32_t MaxQuality; // Offset: 0x04 // Size: 0x04
	int32_t CurQuality; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct FastPicture.FPSVSyncInfo
// Size: 0x24 // Inherited bytes: 0x00
struct FFPSVSyncInfo {
	// Fields
	int32_t RenderLv; // Offset: 0x00 // Size: 0x04
	int32_t FPS25VSync; // Offset: 0x04 // Size: 0x04
	int32_t FPS30VSync; // Offset: 0x08 // Size: 0x04
	int32_t FPS40VSync; // Offset: 0x0c // Size: 0x04
	int32_t FPS50VSync; // Offset: 0x10 // Size: 0x04
	int32_t FPS60VSync; // Offset: 0x14 // Size: 0x04
	int32_t FPS80VSync; // Offset: 0x18 // Size: 0x04
	int32_t FPS90VSync; // Offset: 0x1c // Size: 0x04
	int32_t FPS120VSync; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct FastPicture.FOVLimitInfo
// Size: 0x1c // Inherited bytes: 0x00
struct FFOVLimitInfo {
	// Fields
	int32_t RenderLv; // Offset: 0x00 // Size: 0x04
	int32_t FPPFOVMin; // Offset: 0x04 // Size: 0x04
	int32_t FPPFOVMax; // Offset: 0x08 // Size: 0x04
	int32_t FPPFOVDefault; // Offset: 0x0c // Size: 0x04
	int32_t TPPFOVMin; // Offset: 0x10 // Size: 0x04
	int32_t TPPFOVMax; // Offset: 0x14 // Size: 0x04
	int32_t TPPFOVDefault; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct FastPicture.TwoHighTipInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FTwoHighTipInfo {
	// Fields
	int32_t RenderLevel; // Offset: 0x00 // Size: 0x04
	int32_t MaxSupportFPS; // Offset: 0x04 // Size: 0x04
	int32_t TipType; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct FastPicture.DeviceProfileSectionInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FDeviceProfileSectionInfo {
	// Fields
	struct FString SectionName; // Offset: 0x00 // Size: 0x10
	struct FString DeviceType; // Offset: 0x10 // Size: 0x10
	struct FString BaseProfileName; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FCVarCmdInfo> CVarList; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FTextureLODGroupInitInfo> TextureLODGroups; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.TextureLODGroupInitInfo
// Size: 0x5c // Inherited bytes: 0x00
struct FTextureLODGroupInitInfo {
	// Fields
	bool bInit; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FTextureLODGroup TextureLODGroup; // Offset: 0x04 // Size: 0x58
};

// Object Name: ScriptStruct FastPicture.CVarCmdInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FCVarCmdInfo {
	// Fields
	struct FString CmdName; // Offset: 0x00 // Size: 0x10
	struct FString CmdValue; // Offset: 0x10 // Size: 0x10
	struct FString Annotation; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.ProfileNameAndType
// Size: 0x20 // Inherited bytes: 0x00
struct FProfileNameAndType {
	// Fields
	struct FString PlatformType; // Offset: 0x00 // Size: 0x10
	struct FString ProfileName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.FPRenderInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FFPRenderInfo {
	// Fields
	int32_t RenderLevel; // Offset: 0x00 // Size: 0x04
	int32_t MinFPS; // Offset: 0x04 // Size: 0x04
	int32_t MaxFPS; // Offset: 0x08 // Size: 0x04
	int32_t DefaultFPS; // Offset: 0x0c // Size: 0x04
	bool IsDefaultRenderLevel; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t ShowType; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct FastPicture.FPDeviceCheckMatch
// Size: 0x28 // Inherited bytes: 0x00
struct FFPDeviceCheckMatch {
	// Fields
	int32_t CheckPass; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString ReasonTips; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FFPProfileMatchItem> Match; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.FPRenderStyleAndPPMaping
// Size: 0x60 // Inherited bytes: 0x00
struct FFPRenderStyleAndPPMaping {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x00 // Size: 0x60
};

// Object Name: ScriptStruct FastPicture.FPRenderItem
// Size: 0x20 // Inherited bytes: 0x00
struct FFPRenderItem {
	// Fields
	struct FString RenderKey; // Offset: 0x00 // Size: 0x10
	struct FString RenderValue; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.FPMapProfileMatch
// Size: 0x30 // Inherited bytes: 0x00
struct FFPMapProfileMatch {
	// Fields
	struct FString Profile; // Offset: 0x00 // Size: 0x10
	struct FString MapName; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FFPProfileMatchItem> Match; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.ScoreToProfileName
// Size: 0x18 // Inherited bytes: 0x00
struct FScoreToProfileName {
	// Fields
	struct FString ProfileName; // Offset: 0x00 // Size: 0x10
	int32_t Score; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct FastPicture.FPGradeProfileMatch
// Size: 0x18 // Inherited bytes: 0x00
struct FFPGradeProfileMatch {
	// Fields
	enum class EFastPictureGradeScoreType ScoreType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t Score; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FFPProfileMatchItem> Match; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct FastPicture.MatchRawSourceInfo
// Size: 0xf0 // Inherited bytes: 0x00
struct FMatchRawSourceInfo {
	// Fields
	struct FString DeviceMake; // Offset: 0x00 // Size: 0x10
	struct FString DeviceModel; // Offset: 0x10 // Size: 0x10
	struct FString MemorySizeInGB; // Offset: 0x20 // Size: 0x10
	struct FString GPUFamily; // Offset: 0x30 // Size: 0x10
	struct FString iOSVersion; // Offset: 0x40 // Size: 0x10
	struct FString AndroidVersion; // Offset: 0x50 // Size: 0x10
	struct FString GLVersion; // Offset: 0x60 // Size: 0x10
	struct FString VulkanVersion; // Offset: 0x70 // Size: 0x10
	struct FString CPUCoreNum; // Offset: 0x80 // Size: 0x10
	struct FString CPUMaxFreq; // Offset: 0x90 // Size: 0x10
	struct FString Platform; // Offset: 0xa0 // Size: 0x10
	struct FString Grade; // Offset: 0xb0 // Size: 0x10
	struct FString GradeScore; // Offset: 0xc0 // Size: 0x10
	struct FString CVarsSWitchDummy; // Offset: 0xd0 // Size: 0x10
	struct FString Chipset; // Offset: 0xe0 // Size: 0x10
};

