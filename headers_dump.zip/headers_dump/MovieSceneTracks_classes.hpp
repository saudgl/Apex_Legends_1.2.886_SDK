#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MovieSceneTracks.MovieSceneTransformOrigin
// Size: 0x28 // Inherited bytes: 0x28
struct UMovieSceneTransformOrigin : UInterface {
	// Functions

	// Object Name: Function MovieSceneTracks.MovieSceneTransformOrigin.BP_GetTransformOrigin
	// Flags: [Event|Protected|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	struct FTransform BP_GetTransformOrigin(); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x30)
};

// Object Name: Class MovieSceneTracks.MovieScene3DConstraintSection
// Size: 0x100 // Inherited bytes: 0xd8
struct UMovieScene3DConstraintSection : UMovieSceneSection {
	// Fields
	struct FGuid ConstraintId; // Offset: 0xd8 // Size: 0x10
	struct FMovieSceneObjectBindingID ConstraintBindingID; // Offset: 0xe8 // Size: 0x18

	// Functions

	// Object Name: Function MovieSceneTracks.MovieScene3DConstraintSection.SetConstraintBindingID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void SetConstraintBindingID(struct FMovieSceneObjectBindingID& InConstraintBindingID); // Offset: 0x1050cb630 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function MovieSceneTracks.MovieScene3DConstraintSection.GetConstraintBindingID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FMovieSceneObjectBindingID GetConstraintBindingID(); // Offset: 0x1050cb6e0 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class MovieSceneTracks.MovieScene3DAttachSection
// Size: 0x118 // Inherited bytes: 0x100
struct UMovieScene3DAttachSection : UMovieScene3DConstraintSection {
	// Fields
	struct FName AttachSocketName; // Offset: 0x100 // Size: 0x08
	struct FName AttachComponentName; // Offset: 0x108 // Size: 0x08
	enum class EAttachmentRule AttachmentLocationRule; // Offset: 0x110 // Size: 0x01
	enum class EAttachmentRule AttachmentRotationRule; // Offset: 0x111 // Size: 0x01
	enum class EAttachmentRule AttachmentScaleRule; // Offset: 0x112 // Size: 0x01
	enum class EDetachmentRule DetachmentLocationRule; // Offset: 0x113 // Size: 0x01
	enum class EDetachmentRule DetachmentRotationRule; // Offset: 0x114 // Size: 0x01
	enum class EDetachmentRule DetachmentScaleRule; // Offset: 0x115 // Size: 0x01
	char pad_0x116[0x2]; // Offset: 0x116 // Size: 0x02
};

// Object Name: Class MovieSceneTracks.MovieScene3DConstraintTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieScene3DConstraintTrack : UMovieSceneTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> ConstraintSections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieScene3DAttachTrack
// Size: 0x68 // Inherited bytes: 0x68
struct UMovieScene3DAttachTrack : UMovieScene3DConstraintTrack {
};

// Object Name: Class MovieSceneTracks.MovieScene3DPathSection
// Size: 0x1a8 // Inherited bytes: 0x100
struct UMovieScene3DPathSection : UMovieScene3DConstraintSection {
	// Fields
	struct FMovieSceneFloatChannel TimingCurve; // Offset: 0x100 // Size: 0xa0
	enum class MovieScene3DPathSection_Axis FrontAxisEnum; // Offset: 0x1a0 // Size: 0x01
	enum class MovieScene3DPathSection_Axis UpAxisEnum; // Offset: 0x1a1 // Size: 0x01
	char bFollow : 1; // Offset: 0x1a2 // Size: 0x01
	char bReverse : 1; // Offset: 0x1a2 // Size: 0x01
	char bForceUpright : 1; // Offset: 0x1a2 // Size: 0x01
	char pad_0x1A2_3 : 5; // Offset: 0x1a2 // Size: 0x01
	char pad_0x1A3[0x5]; // Offset: 0x1a3 // Size: 0x05
};

// Object Name: Class MovieSceneTracks.MovieScene3DPathTrack
// Size: 0x68 // Inherited bytes: 0x68
struct UMovieScene3DPathTrack : UMovieScene3DConstraintTrack {
};

// Object Name: Class MovieSceneTracks.MovieScene3DTransformSection
// Size: 0x728 // Inherited bytes: 0xd8
struct UMovieScene3DTransformSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneTransformMask TransformMask; // Offset: 0xd8 // Size: 0x04
	char pad_0xDC[0x4]; // Offset: 0xdc // Size: 0x04
	struct FMovieSceneFloatChannel Translation[0x3]; // Offset: 0xe0 // Size: 0x1e0
	struct FMovieSceneFloatChannel Rotation[0x3]; // Offset: 0x2c0 // Size: 0x1e0
	struct FMovieSceneFloatChannel Scale[0x3]; // Offset: 0x4a0 // Size: 0x1e0
	struct FMovieSceneFloatChannel ManualWeight; // Offset: 0x680 // Size: 0xa0
	char pad_0x720[0x4]; // Offset: 0x720 // Size: 0x04
	bool bUseQuaternionInterpolation; // Offset: 0x724 // Size: 0x01
	char pad_0x725[0x3]; // Offset: 0x725 // Size: 0x03
};

// Object Name: Class MovieSceneTracks.MovieScenePropertyTrack
// Size: 0x88 // Inherited bytes: 0x58
struct UMovieScenePropertyTrack : UMovieSceneNameableTrack {
	// Fields
	struct UMovieSceneSection* SectionToKey; // Offset: 0x58 // Size: 0x08
	struct FName PropertyName; // Offset: 0x60 // Size: 0x08
	struct FString PropertyPath; // Offset: 0x68 // Size: 0x10
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x78 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieScene3DTransformTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieScene3DTransformTrack : UMovieScenePropertyTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneActorReferenceSection
// Size: 0x208 // Inherited bytes: 0xd8
struct UMovieSceneActorReferenceSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneActorReferenceData ActorReferenceData; // Offset: 0xd8 // Size: 0xa0
	struct FIntegralCurve ActorGuidIndexCurve; // Offset: 0x178 // Size: 0x80
	struct TArray<struct FString> ActorGuidStrings; // Offset: 0x1f8 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneActorReferenceTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneActorReferenceTrack : UMovieScenePropertyTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneAudioSection
// Size: 0x278 // Inherited bytes: 0xd8
struct UMovieSceneAudioSection : UMovieSceneSection {
	// Fields
	struct USoundBase* Sound; // Offset: 0xd8 // Size: 0x08
	struct FFrameNumber StartFrameOffset; // Offset: 0xe0 // Size: 0x04
	float StartOffset; // Offset: 0xe4 // Size: 0x04
	float AudioStartTime; // Offset: 0xe8 // Size: 0x04
	float AudioDilationFactor; // Offset: 0xec // Size: 0x04
	float AudioVolume; // Offset: 0xf0 // Size: 0x04
	char pad_0xF4[0x4]; // Offset: 0xf4 // Size: 0x04
	struct FMovieSceneFloatChannel SoundVolume; // Offset: 0xf8 // Size: 0xa0
	struct FMovieSceneFloatChannel PitchMultiplier; // Offset: 0x198 // Size: 0xa0
	bool bSuppressSubtitles; // Offset: 0x238 // Size: 0x01
	bool bOverrideAttenuation; // Offset: 0x239 // Size: 0x01
	char pad_0x23A[0x6]; // Offset: 0x23a // Size: 0x06
	struct USoundAttenuation* AttenuationSettings; // Offset: 0x240 // Size: 0x08
	struct FDelegate OnQueueSubtitles; // Offset: 0x248 // Size: 0x10
	struct FMulticastInlineDelegate OnAudioFinished; // Offset: 0x258 // Size: 0x10
	struct FMulticastInlineDelegate OnAudioPlaybackPercent; // Offset: 0x268 // Size: 0x10

	// Functions

	// Object Name: Function MovieSceneTracks.MovieSceneAudioSection.SetStartOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetStartOffset(struct FFrameNumber InStartOffset); // Offset: 0x1050ccc90 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieSceneTracks.MovieSceneAudioSection.SetSound
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSound(struct USoundBase* InSound); // Offset: 0x1050ccd24 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieSceneTracks.MovieSceneAudioSection.GetStartOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FFrameNumber GetStartOffset(); // Offset: 0x1050ccc74 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieSceneTracks.MovieSceneAudioSection.GetSound
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct USoundBase* GetSound(); // Offset: 0x1050ccd08 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class MovieSceneTracks.MovieSceneAudioTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneAudioTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> AudioSections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneBoolSection
// Size: 0x170 // Inherited bytes: 0xd8
struct UMovieSceneBoolSection : UMovieSceneSection {
	// Fields
	bool DefaultValue; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x7]; // Offset: 0xd9 // Size: 0x07
	struct FMovieSceneBoolChannel BoolCurve; // Offset: 0xe0 // Size: 0x90
};

// Object Name: Class MovieSceneTracks.MovieSceneBoolTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneBoolTrack : UMovieScenePropertyTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneByteSection
// Size: 0x170 // Inherited bytes: 0xd8
struct UMovieSceneByteSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneByteChannel ByteCurve; // Offset: 0xd8 // Size: 0x98
};

// Object Name: Class MovieSceneTracks.MovieSceneByteTrack
// Size: 0x90 // Inherited bytes: 0x88
struct UMovieSceneByteTrack : UMovieScenePropertyTrack {
	// Fields
	struct UEnum* Enum; // Offset: 0x88 // Size: 0x08
};

// Object Name: Class MovieSceneTracks.MovieSceneCameraAnimSection
// Size: 0x118 // Inherited bytes: 0xd8
struct UMovieSceneCameraAnimSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneCameraAnimSectionData AnimData; // Offset: 0xd8 // Size: 0x20
	struct UCameraAnim* CameraAnim; // Offset: 0xf8 // Size: 0x08
	float PlayRate; // Offset: 0x100 // Size: 0x04
	float PlayScale; // Offset: 0x104 // Size: 0x04
	float BlendInTime; // Offset: 0x108 // Size: 0x04
	float BlendOutTime; // Offset: 0x10c // Size: 0x04
	bool bLooping; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x7]; // Offset: 0x111 // Size: 0x07
};

// Object Name: Class MovieSceneTracks.MovieSceneCameraAnimTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneCameraAnimTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> CameraAnimSections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneCameraCutSection
// Size: 0x100 // Inherited bytes: 0xd8
struct UMovieSceneCameraCutSection : UMovieSceneSection {
	// Fields
	struct FGuid CameraGuid; // Offset: 0xd8 // Size: 0x10
	struct FMovieSceneObjectBindingID CameraBindingID; // Offset: 0xe8 // Size: 0x18

	// Functions

	// Object Name: Function MovieSceneTracks.MovieSceneCameraCutSection.SetCameraBindingID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void SetCameraBindingID(struct FMovieSceneObjectBindingID& InCameraBindingID); // Offset: 0x1050ce0f8 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function MovieSceneTracks.MovieSceneCameraCutSection.GetCameraBindingID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FMovieSceneObjectBindingID GetCameraBindingID(); // Offset: 0x1050ce1a8 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class MovieSceneTracks.MovieSceneCameraCutTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneCameraCutTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneCameraShakeSection
// Size: 0x118 // Inherited bytes: 0xd8
struct UMovieSceneCameraShakeSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneCameraShakeSectionData ShakeData; // Offset: 0xd8 // Size: 0x20
	struct UCameraShake* ShakeClass; // Offset: 0xf8 // Size: 0x08
	float PlayScale; // Offset: 0x100 // Size: 0x04
	enum class ECameraAnimPlaySpace PlaySpace; // Offset: 0x104 // Size: 0x01
	char pad_0x105[0x3]; // Offset: 0x105 // Size: 0x03
	struct FRotator UserDefinedPlaySpace; // Offset: 0x108 // Size: 0x0c
	char pad_0x114[0x4]; // Offset: 0x114 // Size: 0x04
};

// Object Name: Class MovieSceneTracks.MovieSceneCameraShakeTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneCameraShakeTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> CameraShakeSections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneCinematicShotSection
// Size: 0x170 // Inherited bytes: 0x148
struct UMovieSceneCinematicShotSection : UMovieSceneSubSection {
	// Fields
	struct FString ShotDisplayName; // Offset: 0x148 // Size: 0x10
	struct FText DisplayName; // Offset: 0x158 // Size: 0x18

	// Functions

	// Object Name: Function MovieSceneTracks.MovieSceneCinematicShotSection.SetShotDisplayName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetShotDisplayName(struct FString InShotDisplayName); // Offset: 0x1050d3ed0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieSceneTracks.MovieSceneCinematicShotSection.GetShotDisplayName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetShotDisplayName(); // Offset: 0x1050d3fb8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class MovieSceneTracks.MovieSceneCinematicShotTrack
// Size: 0x68 // Inherited bytes: 0x68
struct UMovieSceneCinematicShotTrack : UMovieSceneSubTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneColorSection
// Size: 0x358 // Inherited bytes: 0xd8
struct UMovieSceneColorSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneFloatChannel RedCurve; // Offset: 0xd8 // Size: 0xa0
	struct FMovieSceneFloatChannel GreenCurve; // Offset: 0x178 // Size: 0xa0
	struct FMovieSceneFloatChannel BlueCurve; // Offset: 0x218 // Size: 0xa0
	struct FMovieSceneFloatChannel AlphaCurve; // Offset: 0x2b8 // Size: 0xa0
};

// Object Name: Class MovieSceneTracks.MovieSceneColorTrack
// Size: 0x90 // Inherited bytes: 0x88
struct UMovieSceneColorTrack : UMovieScenePropertyTrack {
	// Fields
	bool bIsSlateColor; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x7]; // Offset: 0x89 // Size: 0x07
};

// Object Name: Class MovieSceneTracks.MovieSceneEnumSection
// Size: 0x170 // Inherited bytes: 0xd8
struct UMovieSceneEnumSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneByteChannel EnumCurve; // Offset: 0xd8 // Size: 0x98
};

// Object Name: Class MovieSceneTracks.MovieSceneEnumTrack
// Size: 0x90 // Inherited bytes: 0x88
struct UMovieSceneEnumTrack : UMovieScenePropertyTrack {
	// Fields
	struct UEnum* Enum; // Offset: 0x88 // Size: 0x08
};

// Object Name: Class MovieSceneTracks.MovieSceneEulerTransformTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneEulerTransformTrack : UMovieScenePropertyTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneEventSectionBase
// Size: 0xd8 // Inherited bytes: 0xd8
struct UMovieSceneEventSectionBase : UMovieSceneSection {
};

// Object Name: Class MovieSceneTracks.MovieSceneEventRepeaterSection
// Size: 0xe0 // Inherited bytes: 0xd8
struct UMovieSceneEventRepeaterSection : UMovieSceneEventSectionBase {
	// Fields
	struct FMovieSceneEvent Event; // Offset: 0xd8 // Size: 0x08
};

// Object Name: Class MovieSceneTracks.MovieSceneEventSection
// Size: 0x1d8 // Inherited bytes: 0xd8
struct UMovieSceneEventSection : UMovieSceneSection {
	// Fields
	struct FNameCurve Events; // Offset: 0xd8 // Size: 0x78
	struct FMovieSceneEventSectionData EventData; // Offset: 0x150 // Size: 0x88
};

// Object Name: Class MovieSceneTracks.MovieSceneEventTrack
// Size: 0x78 // Inherited bytes: 0x58
struct UMovieSceneEventTrack : UMovieSceneNameableTrack {
	// Fields
	char bFireEventsWhenForwards : 1; // Offset: 0x55 // Size: 0x01
	char bFireEventsWhenBackwards : 1; // Offset: 0x55 // Size: 0x01
	enum class EFireEventsAtPosition EventPosition; // Offset: 0x56 // Size: 0x01
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // Offset: 0x58 // Size: 0x10
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x68 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneEventTriggerSection
// Size: 0x160 // Inherited bytes: 0xd8
struct UMovieSceneEventTriggerSection : UMovieSceneEventSectionBase {
	// Fields
	struct FMovieSceneEventChannel EventChannel; // Offset: 0xd8 // Size: 0x88
};

// Object Name: Class MovieSceneTracks.MovieSceneFloatSection
// Size: 0x178 // Inherited bytes: 0xd8
struct UMovieSceneFloatSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneFloatChannel FloatCurve; // Offset: 0xd8 // Size: 0xa0
};

// Object Name: Class MovieSceneTracks.MovieSceneFadeSection
// Size: 0x190 // Inherited bytes: 0x178
struct UMovieSceneFadeSection : UMovieSceneFloatSection {
	// Fields
	struct FLinearColor FadeColor; // Offset: 0x178 // Size: 0x10
	char bFadeAudio : 1; // Offset: 0x188 // Size: 0x01
	char pad_0x188_1 : 7; // Offset: 0x188 // Size: 0x01
	char pad_0x189[0x7]; // Offset: 0x189 // Size: 0x07
};

// Object Name: Class MovieSceneTracks.MovieSceneFloatTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneFloatTrack : UMovieScenePropertyTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneFadeTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneFadeTrack : UMovieSceneFloatTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneIntegerSection
// Size: 0x168 // Inherited bytes: 0xd8
struct UMovieSceneIntegerSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneIntegerChannel IntegerCurve; // Offset: 0xd8 // Size: 0x90
};

// Object Name: Class MovieSceneTracks.MovieSceneIntegerTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneIntegerTrack : UMovieScenePropertyTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneLevelVisibilitySection
// Size: 0xf0 // Inherited bytes: 0xd8
struct UMovieSceneLevelVisibilitySection : UMovieSceneSection {
	// Fields
	enum class ELevelVisibility Visibility; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x7]; // Offset: 0xd9 // Size: 0x07
	struct TArray<struct FName> LevelNames; // Offset: 0xe0 // Size: 0x10

	// Functions

	// Object Name: Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVisibility(enum class ELevelVisibility InVisibility); // Offset: 0x1050d6aa0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetLevelNames
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetLevelNames(struct TArray<struct FName>& InLevelNames); // Offset: 0x1050d6934 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetVisibility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ELevelVisibility GetVisibility(); // Offset: 0x1050d6b1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetLevelNames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FName> GetLevelNames(); // Offset: 0x1050d6a1c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class MovieSceneTracks.MovieSceneLevelVisibilityTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneLevelVisibilityTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneMaterialTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneMaterialTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneMaterialParameterCollectionTrack
// Size: 0x70 // Inherited bytes: 0x68
struct UMovieSceneMaterialParameterCollectionTrack : UMovieSceneMaterialTrack {
	// Fields
	struct UMaterialParameterCollection* MPC; // Offset: 0x68 // Size: 0x08
};

// Object Name: Class MovieSceneTracks.MovieSceneComponentMaterialTrack
// Size: 0x70 // Inherited bytes: 0x68
struct UMovieSceneComponentMaterialTrack : UMovieSceneMaterialTrack {
	// Fields
	int32_t MaterialIndex; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
};

// Object Name: Class MovieSceneTracks.MovieSceneObjectPropertySection
// Size: 0x198 // Inherited bytes: 0xd8
struct UMovieSceneObjectPropertySection : UMovieSceneSection {
	// Fields
	struct FMovieSceneObjectPathChannel ObjectChannel; // Offset: 0xd8 // Size: 0xc0
};

// Object Name: Class MovieSceneTracks.MovieSceneObjectPropertyTrack
// Size: 0x90 // Inherited bytes: 0x88
struct UMovieSceneObjectPropertyTrack : UMovieScenePropertyTrack {
	// Fields
	struct UObject* PropertyClass; // Offset: 0x88 // Size: 0x08
};

// Object Name: Class MovieSceneTracks.MovieSceneParameterSection
// Size: 0x108 // Inherited bytes: 0xd8
struct UMovieSceneParameterSection : UMovieSceneSection {
	// Fields
	struct TArray<struct FScalarParameterNameAndCurve> ScalarParameterNamesAndCurves; // Offset: 0xd8 // Size: 0x10
	struct TArray<struct FVectorParameterNameAndCurves> VectorParameterNamesAndCurves; // Offset: 0xe8 // Size: 0x10
	struct TArray<struct FColorParameterNameAndCurves> ColorParameterNamesAndCurves; // Offset: 0xf8 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneParticleParameterTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneParticleParameterTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneParticleSection
// Size: 0x170 // Inherited bytes: 0xd8
struct UMovieSceneParticleSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneParticleChannel ParticleKeys; // Offset: 0xd8 // Size: 0x98
};

// Object Name: Class MovieSceneTracks.MovieSceneParticleTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneParticleTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> ParticleSections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieScenePrimitiveMaterialSection
// Size: 0x198 // Inherited bytes: 0xd8
struct UMovieScenePrimitiveMaterialSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneObjectPathChannel MaterialChannel; // Offset: 0xd8 // Size: 0xc0
};

// Object Name: Class MovieSceneTracks.MovieScenePrimitiveMaterialTrack
// Size: 0x90 // Inherited bytes: 0x88
struct UMovieScenePrimitiveMaterialTrack : UMovieScenePropertyTrack {
	// Fields
	int32_t MaterialIndex; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
};

// Object Name: Class MovieSceneTracks.MovieSceneSkeletalAnimationSection
// Size: 0x1d0 // Inherited bytes: 0xd8
struct UMovieSceneSkeletalAnimationSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneSkeletalAnimationParams Params; // Offset: 0xd8 // Size: 0xd0
	struct UAnimSequence* AnimSequence; // Offset: 0x1a8 // Size: 0x08
	struct UAnimSequenceBase* Animation; // Offset: 0x1b0 // Size: 0x08
	float StartOffset; // Offset: 0x1b8 // Size: 0x04
	float EndOffset; // Offset: 0x1bc // Size: 0x04
	float PlayRate; // Offset: 0x1c0 // Size: 0x04
	char bReverse : 1; // Offset: 0x1c4 // Size: 0x01
	char pad_0x1C4_1 : 7; // Offset: 0x1c4 // Size: 0x01
	char pad_0x1C5[0x3]; // Offset: 0x1c5 // Size: 0x03
	struct FName SlotName; // Offset: 0x1c8 // Size: 0x08
};

// Object Name: Class MovieSceneTracks.MovieSceneSkeletalAnimationTrack
// Size: 0x70 // Inherited bytes: 0x58
struct UMovieSceneSkeletalAnimationTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> AnimationSections; // Offset: 0x58 // Size: 0x10
	bool bUseLegacySectionIndexBlend; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: Class MovieSceneTracks.MovieSceneSlomoSection
// Size: 0x178 // Inherited bytes: 0x178
struct UMovieSceneSlomoSection : UMovieSceneFloatSection {
};

// Object Name: Class MovieSceneTracks.MovieSceneSlomoTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneSlomoTrack : UMovieSceneFloatTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneSpawnSection
// Size: 0x170 // Inherited bytes: 0x170
struct UMovieSceneSpawnSection : UMovieSceneBoolSection {
};

// Object Name: Class MovieSceneTracks.MovieSceneSpawnTrack
// Size: 0x78 // Inherited bytes: 0x58
struct UMovieSceneSpawnTrack : UMovieSceneTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 // Size: 0x10
	struct FGuid ObjectGuid; // Offset: 0x68 // Size: 0x10
};

// Object Name: Class MovieSceneTracks.MovieSceneStringSection
// Size: 0x178 // Inherited bytes: 0xd8
struct UMovieSceneStringSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneStringChannel StringCurve; // Offset: 0xd8 // Size: 0xa0
};

// Object Name: Class MovieSceneTracks.MovieSceneStringTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneStringTrack : UMovieScenePropertyTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneTransformTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneTransformTrack : UMovieScenePropertyTrack {
};

// Object Name: Class MovieSceneTracks.MovieSceneVectorSection
// Size: 0x360 // Inherited bytes: 0xd8
struct UMovieSceneVectorSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneFloatChannel Curves[0x4]; // Offset: 0xd8 // Size: 0x280
	int32_t ChannelsUsed; // Offset: 0x358 // Size: 0x04
	char pad_0x35C[0x4]; // Offset: 0x35c // Size: 0x04
};

// Object Name: Class MovieSceneTracks.MovieSceneVectorTrack
// Size: 0x90 // Inherited bytes: 0x88
struct UMovieSceneVectorTrack : UMovieScenePropertyTrack {
	// Fields
	int32_t NumChannelsUsed; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
};

// Object Name: Class MovieSceneTracks.MovieSceneVisibilityTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneVisibilityTrack : UMovieSceneBoolTrack {
};

