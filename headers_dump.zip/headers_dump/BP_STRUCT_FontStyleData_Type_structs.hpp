#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_FontStyleData_Type.BP_STRUCT_FontStyleData_Type
// Size: 0x4c // Inherited bytes: 0x00
struct FBP_STRUCT_FontStyleData_Type {
	// Fields
	struct TArray<struct FName> Name_57_0611D88054FAD01C6102E8A80BC343B4; // Offset: 0x00 // Size: 0x10
	int32_t FontSize_58_636F728027FC424630FEE7640083BAF5; // Offset: 0x10 // Size: 0x04
	struct FName Color_59_78AD05C03A06296B418170E8039A10C2; // Offset: 0x14 // Size: 0x08
	struct FName Shadow_60_41F5FF8011CF7B764CC5C8500884A157; // Offset: 0x1c // Size: 0x08
	bool Italic_61_28C4FB803B9690B62D03AFC90A10B8C3; // Offset: 0x24 // Size: 0x01
	bool Underline_62_56EF8F80504B59B862EA8514076CA5A5; // Offset: 0x25 // Size: 0x01
	bool Bold_63_2EA3E6405688EC4D21B218F40A39B0F4; // Offset: 0x26 // Size: 0x01
	char pad_0x27[0x1]; // Offset: 0x27 // Size: 0x01
	struct FName Image_64_49927EC00DC0E02D41E10D5C039F9A75; // Offset: 0x28 // Size: 0x08
	struct FName ImageSize_65_4FEBC5803B7CCE824D263FEC0A792095; // Offset: 0x30 // Size: 0x08
	bool IsLink_66_0F3178801F35D04A2D05B4FD0A1EF67B; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	struct FName ImageOffset_67_0611D88054FAD01C6102E8A80BC343B4; // Offset: 0x3c // Size: 0x08
	struct FName TextMaterial_68_330CBB002D079E56776834B7001AAC7C; // Offset: 0x44 // Size: 0x08
};

