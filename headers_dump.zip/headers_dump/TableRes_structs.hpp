#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct TableRes.ArmoryScopeSkin_TabRes
// Size: 0x40 // Inherited bytes: 0x00
struct FArmoryScopeSkin_TabRes {
	// Fields
	int32_t ScopeSkinID; // Offset: 0x00 // Size: 0x04
	int32_t ScopeID; // Offset: 0x04 // Size: 0x04
	struct FName LobbyMesh; // Offset: 0x08 // Size: 0x08
	struct TArray<struct FName> LobbyMaterials; // Offset: 0x10 // Size: 0x10
	struct FName TppMesh; // Offset: 0x20 // Size: 0x08
	struct FName FppMesh; // Offset: 0x28 // Size: 0x08
	struct TArray<struct FName> Materials; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct TableRes.ArmorySkinScopeRelation_TabRes
// Size: 0x18 // Inherited bytes: 0x00
struct FArmorySkinScopeRelation_TabRes {
	// Fields
	int32_t WeaponSkinID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int32_t> ScopeSkinIDs; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct TableRes.ArmorySkinTable_TabRes
// Size: 0x130 // Inherited bytes: 0x08
struct FArmorySkinTable_TabRes : FTableRowBase {
	// Fields
	int32_t ID; // Offset: 0x08 // Size: 0x04
	int32_t ArmoryID; // Offset: 0x0c // Size: 0x04
	int32_t StoreID; // Offset: 0x10 // Size: 0x04
	struct FName PicPath; // Offset: 0x14 // Size: 0x08
	struct FName ResPath; // Offset: 0x1c // Size: 0x08
	struct FName LobbyStockPath; // Offset: 0x24 // Size: 0x08
	struct FName LobbyBarrelPath; // Offset: 0x2c // Size: 0x08
	struct FName LobbyMagazinePath; // Offset: 0x34 // Size: 0x08
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct TArray<struct FName> SkinMaterialPath; // Offset: 0x40 // Size: 0x10
	struct FName ResStatic; // Offset: 0x50 // Size: 0x08
	struct FName ResStaticMaterialPath; // Offset: 0x58 // Size: 0x08
	struct FName ResFpp; // Offset: 0x60 // Size: 0x08
	struct FName ResTpp; // Offset: 0x68 // Size: 0x08
	struct TArray<struct FName> SkinMaterial; // Offset: 0x70 // Size: 0x10
	struct FName BaseMagazine; // Offset: 0x80 // Size: 0x08
	struct FName WeaponOffset; // Offset: 0x88 // Size: 0x08
	struct FText WeaponSkinName; // Offset: 0x90 // Size: 0x18
	float WeaponZoom; // Offset: 0xa8 // Size: 0x04
	struct FName WeaponEffectKeyName; // Offset: 0xac // Size: 0x08
	struct FName WeaponFrameEffect; // Offset: 0xb4 // Size: 0x08
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct TArray<int32_t> Effect; // Offset: 0xc0 // Size: 0x10
	struct TArray<int32_t> CumulativeKill; // Offset: 0xd0 // Size: 0x10
	struct FName KillEffect1p; // Offset: 0xe0 // Size: 0x08
	struct FName KillEffect3p; // Offset: 0xe8 // Size: 0x08
	struct FName BulletScreenPath; // Offset: 0xf0 // Size: 0x08
	struct FName OpticalBulletScreenPath; // Offset: 0xf8 // Size: 0x08
	int32_t CouldShow; // Offset: 0x100 // Size: 0x04
	struct FName SpecialScreenPath; // Offset: 0x104 // Size: 0x08
	int32_t LimitID; // Offset: 0x10c // Size: 0x04
	struct FName KillDeathMatPath; // Offset: 0x110 // Size: 0x08
	int32_t SecondaryWeaponSkinID; // Offset: 0x118 // Size: 0x04
	struct FName SkinAnimConfig; // Offset: 0x11c // Size: 0x08
	int32_t ParentMeshID; // Offset: 0x124 // Size: 0x04
	int32_t KillMsgSkinID; // Offset: 0x128 // Size: 0x04
	char pad_0x12C[0x4]; // Offset: 0x12c // Size: 0x04
};

// Object Name: ScriptStruct TableRes.CharAnimDataSetQuote_TabRes
// Size: 0x10 // Inherited bytes: 0x00
struct FCharAnimDataSetQuote_TabRes {
	// Fields
	int32_t DataSetID; // Offset: 0x00 // Size: 0x04
	int32_t HeroID; // Offset: 0x04 // Size: 0x04
	int32_t ID; // Offset: 0x08 // Size: 0x04
	int32_t WeaponID; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct TableRes.CharAnimDataSet_TabRes
// Size: 0x18 // Inherited bytes: 0x00
struct FCharAnimDataSet_TabRes {
	// Fields
	int32_t DataSetID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString DataSetPath; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct TableRes.GameItemData_TabRes
// Size: 0x280 // Inherited bytes: 0x08
struct FGameItemData_TabRes : FTableRowBase {
	// Fields
	int32_t ItemID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FText ItemName; // Offset: 0x10 // Size: 0x18
	struct FText ShortName; // Offset: 0x28 // Size: 0x18
	struct FText DItemName; // Offset: 0x40 // Size: 0x18
	int32_t ItemType; // Offset: 0x58 // Size: 0x04
	int32_t ItemSubType; // Offset: 0x5c // Size: 0x04
	int32_t BPID; // Offset: 0x60 // Size: 0x04
	int32_t RelateID; // Offset: 0x64 // Size: 0x04
	struct FText ItemDesc; // Offset: 0x68 // Size: 0x18
	int32_t MaxCount; // Offset: 0x80 // Size: 0x04
	int32_t ItemQuality; // Offset: 0x84 // Size: 0x04
	bool Consumable; // Offset: 0x88 // Size: 0x01
	bool Equippable; // Offset: 0x89 // Size: 0x01
	char pad_0x8A[0x2]; // Offset: 0x8a // Size: 0x02
	int32_t UseType; // Offset: 0x8c // Size: 0x04
	bool AutoEquipandDrop; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x3]; // Offset: 0x91 // Size: 0x03
	int32_t ProgressBarCount; // Offset: 0x94 // Size: 0x04
	int32_t SortWeight; // Offset: 0x98 // Size: 0x04
	int32_t ToolbarWeight; // Offset: 0x9c // Size: 0x04
	int32_t Bagable; // Offset: 0xa0 // Size: 0x04
	int32_t WareHouseable; // Offset: 0xa4 // Size: 0x04
	float SellPrice; // Offset: 0xa8 // Size: 0x04
	int32_t SellCurrency; // Offset: 0xac // Size: 0x04
	int32_t Weight; // Offset: 0xb0 // Size: 0x04
	bool IsNotice; // Offset: 0xb4 // Size: 0x01
	char pad_0xB5[0x3]; // Offset: 0xb5 // Size: 0x03
	int32_t EndTime; // Offset: 0xb8 // Size: 0x04
	int32_t EqualGold; // Offset: 0xbc // Size: 0x04
	struct FName ItemSmallIcon; // Offset: 0xc0 // Size: 0x08
	struct FName ItemBigIcon; // Offset: 0xc8 // Size: 0x08
	struct FName WeaponKillIcon; // Offset: 0xd0 // Size: 0x08
	struct FText SimpleName; // Offset: 0xd8 // Size: 0x18
	struct FName Sequenecer; // Offset: 0xf0 // Size: 0x08
	bool IsOldSeq; // Offset: 0xf8 // Size: 0x01
	char pad_0xF9[0x3]; // Offset: 0xf9 // Size: 0x03
	struct FName ModelPath; // Offset: 0xfc // Size: 0x08
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
	struct FString UIPath; // Offset: 0x108 // Size: 0x10
	struct FName SceneName; // Offset: 0x118 // Size: 0x08
	int32_t UnLockShareID; // Offset: 0x120 // Size: 0x04
	char pad_0x124[0x4]; // Offset: 0x124 // Size: 0x04
	struct FText LobbyActor; // Offset: 0x128 // Size: 0x18
	struct FText LobbyActor_Param1; // Offset: 0x140 // Size: 0x18
	bool IsAutoMark; // Offset: 0x158 // Size: 0x01
	char pad_0x159[0x7]; // Offset: 0x159 // Size: 0x07
	struct FText ShotItemDesc; // Offset: 0x160 // Size: 0x18
	int32_t JumpID; // Offset: 0x178 // Size: 0x04
	char pad_0x17C[0x4]; // Offset: 0x17c // Size: 0x04
	struct FText TypeDesc; // Offset: 0x180 // Size: 0x18
	int32_t LabelType; // Offset: 0x198 // Size: 0x04
	char pad_0x19C[0x4]; // Offset: 0x19c // Size: 0x04
	struct TArray<int32_t> LabeID; // Offset: 0x1a0 // Size: 0x10
	struct FText StoreDesc1; // Offset: 0x1b0 // Size: 0x18
	struct FText StoreDesc2; // Offset: 0x1c8 // Size: 0x18
	struct FName MovieID; // Offset: 0x1e0 // Size: 0x08
	struct FName PicPath; // Offset: 0x1e8 // Size: 0x08
	struct FText RichTextBlock; // Offset: 0x1f0 // Size: 0x18
	struct FName ConfigData; // Offset: 0x208 // Size: 0x08
	bool IsManualDecompose; // Offset: 0x210 // Size: 0x01
	char pad_0x211[0x7]; // Offset: 0x211 // Size: 0x07
	struct FString CornerBigPic; // Offset: 0x218 // Size: 0x10
	struct FString CornerSmallPic; // Offset: 0x228 // Size: 0x10
	struct FString LobbyHeadShowPic; // Offset: 0x238 // Size: 0x10
	struct FName ActivityRefinePic; // Offset: 0x248 // Size: 0x08
	int32_t DeleteType; // Offset: 0x250 // Size: 0x04
	int32_t IntroAudioID; // Offset: 0x254 // Size: 0x04
	struct FName JumpStartTime; // Offset: 0x258 // Size: 0x08
	struct FName JumpEndTime; // Offset: 0x260 // Size: 0x08
	bool Discard; // Offset: 0x268 // Size: 0x01
	bool PackIn; // Offset: 0x269 // Size: 0x01
	char pad_0x26A[0x2]; // Offset: 0x26a // Size: 0x02
	struct FName SaleBeginTime; // Offset: 0x26c // Size: 0x08
	struct FName SaleEndTime; // Offset: 0x274 // Size: 0x08
	char pad_0x27C[0x4]; // Offset: 0x27c // Size: 0x04
};

// Object Name: ScriptStruct TableRes.PlayerLoadoutDataSet_TabRes
// Size: 0xa8 // Inherited bytes: 0x00
struct FPlayerLoadoutDataSet_TabRes {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t MainWeapon; // Offset: 0x04 // Size: 0x04
	int32_t SubWeapon; // Offset: 0x08 // Size: 0x04
	int32_t MainBulletNum; // Offset: 0x0c // Size: 0x04
	int32_t SubBulletNum; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<int32_t> MainWeaponFittings; // Offset: 0x18 // Size: 0x10
	struct TArray<int32_t> SubWeaponFittings; // Offset: 0x28 // Size: 0x10
	struct TArray<int32_t> Shield; // Offset: 0x38 // Size: 0x10
	struct TArray<int32_t> ShieldNum; // Offset: 0x48 // Size: 0x10
	struct TArray<int32_t> Drug; // Offset: 0x58 // Size: 0x10
	struct TArray<int32_t> DrugNum; // Offset: 0x68 // Size: 0x10
	int32_t Helmet; // Offset: 0x78 // Size: 0x04
	int32_t Armor; // Offset: 0x7c // Size: 0x04
	int32_t Backpack; // Offset: 0x80 // Size: 0x04
	int32_t FallingShield; // Offset: 0x84 // Size: 0x04
	struct TArray<int32_t> Grenade; // Offset: 0x88 // Size: 0x10
	struct TArray<int32_t> GrenadeNum; // Offset: 0x98 // Size: 0x10
};

// Object Name: ScriptStruct TableRes.PlayerLoadoutWeaponDataSet_TabRes
// Size: 0x28 // Inherited bytes: 0x00
struct FPlayerLoadoutWeaponDataSet_TabRes {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t Set; // Offset: 0x04 // Size: 0x04
	int32_t Level; // Offset: 0x08 // Size: 0x04
	bool SpecialWeapon; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	int32_t WeaponID; // Offset: 0x10 // Size: 0x04
	int32_t BulletNum; // Offset: 0x14 // Size: 0x04
	struct TArray<int32_t> WeaponFittings; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct TableRes.TestStruct_TabRes
// Size: 0x60 // Inherited bytes: 0x08
struct FTestStruct_TabRes : FTableRowBase {
	// Fields
	int32_t intVar; // Offset: 0x08 // Size: 0x04
	bool boolVar; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float floatVar; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FText textVar; // Offset: 0x18 // Size: 0x18
	struct FName nameVar; // Offset: 0x30 // Size: 0x08
	struct FString stringVar; // Offset: 0x38 // Size: 0x10
	struct FColor colorVar; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct TArray<int32_t> intarrVar; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct TableRes.WeaponCharmScale_TabRes
// Size: 0x10 // Inherited bytes: 0x00
struct FWeaponCharmScale_TabRes {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
	int32_t AmuletID; // Offset: 0x04 // Size: 0x04
	int32_t GunID; // Offset: 0x08 // Size: 0x04
	float Scale; // Offset: 0x0c // Size: 0x04
};

