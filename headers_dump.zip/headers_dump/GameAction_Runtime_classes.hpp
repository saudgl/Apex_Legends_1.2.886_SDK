#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GameAction_Runtime.GameActionAnimationSection
// Size: 0x228 // Inherited bytes: 0xd8
struct UGameActionAnimationSection : UMovieSceneSection {
	// Fields
	struct FGameActionAnimationParams Params; // Offset: 0xd8 // Size: 0x150
};

// Object Name: Class GameAction_Runtime.GameActionAnimationTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UGameActionAnimationTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UGameActionAnimationSection*> Sections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class GameAction_Runtime.GameActionAnimNotify
// Size: 0x48 // Inherited bytes: 0x38
struct UGameActionAnimNotify : UAnimNotify {
	// Fields
	struct UGameActionInstanceBase* ActionToPlay; // Offset: 0x38 // Size: 0x08
	struct FName EntryName; // Offset: 0x40 // Size: 0x08
};

// Object Name: Class GameAction_Runtime.GameActionScene
// Size: 0x28 // Inherited bytes: 0x28
struct UGameActionScene : UObject {
};

// Object Name: Class GameAction_Runtime.GameActionBlueprint
// Size: 0xd0 // Inherited bytes: 0xd0
struct UGameActionBlueprint : UBlueprint {
};

// Object Name: Class GameAction_Runtime.GameActionComponent
// Size: 0x1a8 // Inherited bytes: 0xf0
struct UGameActionComponent : UActorComponent {
	// Fields
	struct TSet<struct UGameActionInstanceBase*> DefaultActions; // Offset: 0xf0 // Size: 0x50
	struct TSet<struct UGameActionInstanceBase*> PreActionInstances; // Offset: 0x140 // Size: 0x50
	struct TArray<struct UGameActionInstanceBase*> ActionInstances; // Offset: 0x190 // Size: 0x10
	struct UGameActionSequencePlayer* SharedPlayer; // Offset: 0x1a0 // Size: 0x08

	// Functions

	// Object Name: Function GameAction_Runtime.GameActionComponent.TryPlayCreatedGameAction
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable]
	bool TryPlayCreatedGameAction(struct UGameActionInstanceBase* Instance, struct FGameActionEntry& Entry); // Offset: 0x101f18184 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function GameAction_Runtime.GameActionComponent.RemoveGameAction
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void RemoveGameAction(struct UGameActionInstanceBase* Action); // Offset: 0x101f184dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameAction_Runtime.GameActionComponent.PlayGameActionToServer
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void PlayGameActionToServer(struct UGameActionInstanceBase* Action, struct FName EntryName); // Offset: 0x101f1808c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameAction_Runtime.GameActionComponent.PlayGameAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayGameAction(struct UGameActionInstanceBase* Action, struct FName EntryName); // Offset: 0x101f18300 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameAction_Runtime.GameActionComponent.OnRep_ActionInstances
	// Flags: [Final|Native|Public]
	void OnRep_ActionInstances(); // Offset: 0x101f185e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionComponent.IsSharedPlayerPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSharedPlayerPlaying(); // Offset: 0x101f18058 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameAction_Runtime.GameActionComponent.IsAnyActionActived
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsAnyActionActived(); // Offset: 0x101f18150 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameAction_Runtime.GameActionComponent.GetSharedPlayerActiveAction
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameActionInstanceBase* GetSharedPlayerActiveAction(); // Offset: 0x101f18024 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameAction_Runtime.GameActionComponent.FindGameAction
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameActionInstanceBase* FindGameAction(struct UGameActionInstanceBase* Action); // Offset: 0x101f18450 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameAction_Runtime.GameActionComponent.CreateGameActionToPlay
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	struct UGameActionInstanceBase* CreateGameActionToPlay(struct UGameActionInstanceBase* Action); // Offset: 0x101f18274 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameAction_Runtime.GameActionComponent.ContainGameAction
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ContainGameAction(struct UGameActionInstanceBase* Action); // Offset: 0x101f183bc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GameAction_Runtime.GameActionComponent.AddGameAction
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	struct UGameActionInstanceBase* AddGameAction(struct UGameActionInstanceBase* Action); // Offset: 0x101f18558 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameAction_Runtime.GameActionComponent.AbortSharedPlayerActiveAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AbortSharedPlayerActiveAction(); // Offset: 0x101f18010 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameAction_Runtime.GameActionDynamicSpawnSectionBase
// Size: 0x168 // Inherited bytes: 0xd8
struct UGameActionDynamicSpawnSectionBase : UMovieSceneSection {
	// Fields
	struct FMovieSceneBoolChannel SpawnableCurve; // Offset: 0xd8 // Size: 0x90
};

// Object Name: Class GameAction_Runtime.GameActionSpawnByTemplateSection
// Size: 0x170 // Inherited bytes: 0x168
struct UGameActionSpawnByTemplateSection : UGameActionDynamicSpawnSectionBase {
	// Fields
	struct UGameActionSequenceSpawnerSettings* SpawnerSettings; // Offset: 0x168 // Size: 0x08
};

// Object Name: Class GameAction_Runtime.GameActionSpawnBySpawnerSection
// Size: 0x170 // Inherited bytes: 0x168
struct UGameActionSpawnBySpawnerSection : UGameActionDynamicSpawnSectionBase {
	// Fields
	struct UGameActionSequenceCustomSpawnerBase* CustomSpawner; // Offset: 0x168 // Size: 0x08
};

// Object Name: Class GameAction_Runtime.GameActionDynamicSpawnTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UGameActionDynamicSpawnTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UGameActionDynamicSpawnSectionBase*> SpawnSection; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class GameAction_Runtime.GameActionEventBase
// Size: 0x30 // Inherited bytes: 0x28
struct UGameActionEventBase : UObject {
	// Fields
	struct UObject* WorldContentObject; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function GameAction_Runtime.GameActionEventBase.ReceiveGetEventName
	// Flags: [Native|Event|Protected|BlueprintEvent|Const]
	struct FString ReceiveGetEventName(); // Offset: 0x101f19aec // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class GameAction_Runtime.GameActionKeyEvent
// Size: 0x30 // Inherited bytes: 0x30
struct UGameActionKeyEvent : UGameActionEventBase {
	// Functions

	// Object Name: Function GameAction_Runtime.GameActionKeyEvent.ReceiveWhenEventExecute
	// Flags: [Event|Protected|BlueprintEvent|Const]
	void ReceiveWhenEventExecute(struct UObject* EventOwner, struct UGameActionInstanceBase* GameActionInstance); // Offset: 0x1043c773c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class GameAction_Runtime.GameActionStateEvent
// Size: 0x38 // Inherited bytes: 0x30
struct UGameActionStateEvent : UGameActionEventBase {
	// Fields
	char bInstanced : 1; // Offset: 0x30 // Size: 0x01
	char pad_0x30_1 : 7; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07

	// Functions

	// Object Name: Function GameAction_Runtime.GameActionStateEvent.ReceiveWhenEventTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenEventTick(struct UObject* EventOwner, struct UGameActionInstanceBase* GameActionInstance, float DeltaSeconds); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function GameAction_Runtime.GameActionStateEvent.ReceiveWhenEventStart
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenEventStart(struct UObject* EventOwner, struct UGameActionInstanceBase* GameActionInstance); // Offset: 0x1043c773c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameAction_Runtime.GameActionStateEvent.ReceiveWhenEventEnd
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenEventEnd(struct UObject* EventOwner, struct UGameActionInstanceBase* GameActionInstance, bool bIsCompleted); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x11)
};

// Object Name: Class GameAction_Runtime.GameActionStateInnerKeyEvent
// Size: 0x30 // Inherited bytes: 0x28
struct UGameActionStateInnerKeyEvent : UObject {
	// Fields
	struct UObject* WorldContentObject; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function GameAction_Runtime.GameActionStateInnerKeyEvent.ReceiveWhenEventExecute
	// Flags: [Event|Protected|BlueprintEvent|Const]
	void ReceiveWhenEventExecute(struct UObject* EventOwner, struct UGameActionStateEvent* OwningState, struct UGameActionInstanceBase* GameActionInstance); // Offset: 0x1043c773c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GameAction_Runtime.GameActionStateInnerKeyEvent.ReceiveGetEventName
	// Flags: [Native|Event|Protected|BlueprintEvent|Const]
	struct FString ReceiveGetEventName(); // Offset: 0x101f1a4a8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class GameAction_Runtime.GameActionKeyEventTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UGameActionKeyEventTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UGameActionKeyEventSection*> EventSections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class GameAction_Runtime.GameActionKeyEventSection
// Size: 0x160 // Inherited bytes: 0xd8
struct UGameActionKeyEventSection : UMovieSceneSection {
	// Fields
	struct FGameActionKeyEventChannel KeyEventChannel; // Offset: 0xd8 // Size: 0x88
};

// Object Name: Class GameAction_Runtime.GameActionStateEventSection
// Size: 0x168 // Inherited bytes: 0xd8
struct UGameActionStateEventSection : UMovieSceneSection {
	// Fields
	struct UGameActionStateEvent* StateEvent; // Offset: 0xd8 // Size: 0x08
	struct FGameActionStateEventInnerKeyChannel InnerKeyChannel; // Offset: 0xe0 // Size: 0x88
};

// Object Name: Class GameAction_Runtime.GameActionStateEventTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UGameActionStateEventTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UGameActionStateEventSection*> EventSections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class GameAction_Runtime.GameActionGeneratedClass
// Size: 0x400 // Inherited bytes: 0x400
struct UGameActionGeneratedClass : UBlueprintGeneratedClass {
};

// Object Name: Class GameAction_Runtime.GameActionInstanceBase
// Size: 0x90 // Inherited bytes: 0x28
struct UGameActionInstanceBase : UObject {
	// Fields
	struct UGameActionComponent* OwningComponent; // Offset: 0x28 // Size: 0x08
	struct FGameActionEntry DefaultEntry; // Offset: 0x30 // Size: 0x10
	char bSharePlayer : 1; // Offset: 0x40 // Size: 0x01
	char pad_0x40_1 : 7; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
	struct UGameActionSequencePlayer* SequencePlayer; // Offset: 0x48 // Size: 0x08
	float SubStepDuration; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct UGameActionSegmentBase* ActivedSegment; // Offset: 0x58 // Size: 0x08
	char pad_0x60[0x18]; // Offset: 0x60 // Size: 0x18
	struct TArray<struct AActor*> InstanceManagedSpawnables; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.TryStartEntry
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool TryStartEntry(struct FGameActionEntry& Entry); // Offset: 0x101f1bc48 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.TryStartDefaultEntry
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TryStartDefaultEntry(); // Offset: 0x101f1bc14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.TryEventTransition
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TryEventTransition(struct FName EventName); // Offset: 0x101f1bb50 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.TransformActorData
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	void TransformActorData(struct FGameActionPossessableActorData& ActorData, struct FVector& WorldLocation, struct FRotator& WorldRotation); // Offset: 0x101f1b984 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.ReceiveWhenDestruct
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenDestruct(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.ReceiveWhenDeactived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenDeactived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.ReceiveWhenConstruct
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenConstruct(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.ReceiveWhenActived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenActived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.ReceiveWhenAborted
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ReceiveWhenAborted(); // Offset: 0x101f1bb34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.PushEnableSubStepMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PushEnableSubStepMode(); // Offset: 0x101f1bd80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.PopEnableSubStepMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PopEnableSubStepMode(); // Offset: 0x101f1bd6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.OnRep_OwningComponent
	// Flags: [Final|Native|Public]
	void OnRep_OwningComponent(); // Offset: 0x101f1bd94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.OnRep_ActivedSegment
	// Flags: [Final|Native|Public]
	void OnRep_ActivedSegment(struct UGameActionSegmentBase* PreActivedSegment); // Offset: 0x101f1bcf0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.IsLocalControlled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLocalControlled(); // Offset: 0x101f1bddc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.IsActived
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsActived(); // Offset: 0x101f1bbdc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.InvokeTransitionToServer
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void InvokeTransitionToServer(struct UGameActionSegmentBase* FromSegment, struct UGameActionSegmentBase* ToSegment, struct FName ServerCheckFunctionName); // Offset: 0x101f1b87c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.HasAuthority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAuthority(); // Offset: 0x101f1bda8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.GetOwner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ACharacter* GetOwner(); // Offset: 0x101f1be10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.GetOriginTransform
	// Flags: [Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTransform GetOriginTransform(); // Offset: 0x101f1babc // Return & Params: Num(1) Size(0x30)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.FinishInstanceToServer
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void FinishInstanceToServer(); // Offset: 0x101f1b7dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.CancelActionToClient
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void CancelActionToClient(struct UGameActionSegmentBase* Segment); // Offset: 0x101f1b7f8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.AbortInstanceToServer
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void AbortInstanceToServer(); // Offset: 0x101f1b7c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.AbortInstanceNetMulticast
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void AbortInstanceNetMulticast(); // Offset: 0x101f1b7a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionInstanceBase.AbortGameAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AbortGameAction(); // Offset: 0x101f1bc00 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameAction_Runtime.GameActionSegmentBase
// Size: 0xa8 // Inherited bytes: 0x28
struct UGameActionSegmentBase : UObject {
	// Fields
	struct FDelegate OnActionActivedEvent; // Offset: 0x28 // Size: 0x10
	struct FDelegate OnActionAbortedEvent; // Offset: 0x38 // Size: 0x10
	struct FDelegate OnActionDeactivedEvent; // Offset: 0x48 // Size: 0x10
	struct FDelegate OnActionTickEvent; // Offset: 0x58 // Size: 0x10
	struct FDelegate OnActionTransitionFailed; // Offset: 0x68 // Size: 0x10
	struct FDelegate EvaluateExposedInputsEvent; // Offset: 0x78 // Size: 0x10
	struct TArray<struct FGameActionTickTransition> TickTransitions; // Offset: 0x88 // Size: 0x10
	struct TArray<struct FGameActionEventTransition> EventTransitions; // Offset: 0x98 // Size: 0x10

	// Functions

	// Object Name: Function GameAction_Runtime.GameActionSegmentBase.ReceiveWhenTransitionFailed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ReceiveWhenTransitionFailed(struct UGameActionSegmentBase* TransitionFailedSegment); // Offset: 0x101f1d01c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameAction_Runtime.GameActionSegmentBase.ReceiveWhenActionTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenActionTick(float DeltaSeconds); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameAction_Runtime.GameActionSegmentBase.ReceiveWhenActionDeactived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenActionDeactived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionSegmentBase.ReceiveWhenActionActived
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveWhenActionActived(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionSegmentBase.ReceiveWhenActionAborted
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ReceiveWhenActionAborted(); // Offset: 0x101f1d0a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction GameAction_Runtime.GameActionSegmentBase.EvaluateExposedInputsEvent__DelegateSignature
	// Flags: [Public|Delegate]
	void EvaluateExposedInputsEvent__DelegateSignature(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionSegmentBase.DefaultTransitionFailedToClient
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void DefaultTransitionFailedToClient(); // Offset: 0x101f1d000 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameAction_Runtime.GameActionSegmentGeneric
// Size: 0xa8 // Inherited bytes: 0xa8
struct UGameActionSegmentGeneric : UGameActionSegmentBase {
};

// Object Name: Class GameAction_Runtime.GameActionSegment
// Size: 0xb8 // Inherited bytes: 0xa8
struct UGameActionSegment : UGameActionSegmentBase {
	// Fields
	struct UGameActionSequence* GameActionSequence; // Offset: 0xa8 // Size: 0x08
	enum class EGameActionPlayerEndAction PlayEndAction; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x3]; // Offset: 0xb1 // Size: 0x03
	float PlayRate; // Offset: 0xb4 // Size: 0x04

	// Functions

	// Object Name: Function GameAction_Runtime.GameActionSegment.TransitionFailedToClientSyncTime
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void TransitionFailedToClientSyncTime(float RollbackSeconds); // Offset: 0x101f1d8dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameAction_Runtime.GameActionSegment.TransitionFailedToClientStopAction
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void TransitionFailedToClientStopAction(); // Offset: 0x101f1d8c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionSegment.OnSequenceFinished
	// Flags: [Final|Native|Protected]
	void OnSequenceFinished(); // Offset: 0x101f1d8ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameAction_Runtime.GameActionSegment.IsInSequenceTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool IsInSequenceTime(struct FFrameNumber Lower, struct FFrameNumber Upper); // Offset: 0x101f1d774 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function GameAction_Runtime.GameActionSegment.GetSequenceTotalTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSequenceTotalTime(); // Offset: 0x101f1d844 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameAction_Runtime.GameActionSegment.GetCurrentPlayTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCurrentPlayTime(); // Offset: 0x101f1d878 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class GameAction_Runtime.GameActionSequence
// Size: 0x400 // Inherited bytes: 0x348
struct UGameActionSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 // Size: 0x08
	struct FGuid OwnerGuid; // Offset: 0x350 // Size: 0x10
	struct TMap<struct FGuid, struct FName> PossessableActors; // Offset: 0x360 // Size: 0x50
	struct TMap<struct FGuid, struct FGameActionSequenceSubobjectBinding> BindingSubobjects; // Offset: 0x3b0 // Size: 0x50
};

// Object Name: Class GameAction_Runtime.GameActionSequenceSpawnerSettingsBase
// Size: 0x30 // Inherited bytes: 0x28
struct UGameActionSequenceSpawnerSettingsBase : UObject {
	// Fields
	char bAsReference : 1; // Offset: 0x28 // Size: 0x01
	char pad_0x28_1 : 7; // Offset: 0x28 // Size: 0x01
	enum class EGameActionSpawnOwnership Ownership; // Offset: 0x29 // Size: 0x01
	char bDestroyWhenAborted : 1; // Offset: 0x2a // Size: 0x01
	char pad_0x2A_1 : 7; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x1]; // Offset: 0x2b // Size: 0x01
	float DestroyDelayTime; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class GameAction_Runtime.GameActionSequenceSpawnerSettings
// Size: 0x30 // Inherited bytes: 0x30
struct UGameActionSequenceSpawnerSettings : UGameActionSequenceSpawnerSettingsBase {
};

// Object Name: Class GameAction_Runtime.GameActionSequenceCustomSpawnerBase
// Size: 0x30 // Inherited bytes: 0x30
struct UGameActionSequenceCustomSpawnerBase : UGameActionSequenceSpawnerSettingsBase {
};

// Object Name: Class GameAction_Runtime.GameActionSequenceCustomSpawner
// Size: 0x30 // Inherited bytes: 0x30
struct UGameActionSequenceCustomSpawner : UGameActionSequenceCustomSpawnerBase {
	// Functions

	// Object Name: Function GameAction_Runtime.GameActionSequenceCustomSpawner.ReceivePreSpawning
	// Flags: [Event|Protected|BlueprintEvent|Const]
	void ReceivePreSpawning(struct AActor* SpawningActor); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameAction_Runtime.GameActionSequenceCustomSpawner.ReceivePostSpawned
	// Flags: [Event|Protected|BlueprintEvent|Const]
	void ReceivePostSpawned(struct AActor* SpawnedActor); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameAction_Runtime.GameActionSequenceCustomSpawner.ReceiveGetSpawnType
	// Flags: [Event|Protected|BlueprintEvent|Const]
	struct AActor* ReceiveGetSpawnType(struct UGameActionInstanceBase* GameActionInstance); // Offset: 0x1043c773c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class GameAction_Runtime.GameActionSequencePlayer
// Size: 0x880 // Inherited bytes: 0x28
struct UGameActionSequencePlayer : UObject {
	// Fields
	char pad_0x28[0x470]; // Offset: 0x28 // Size: 0x470
	struct FFrameNumber StartTime; // Offset: 0x498 // Size: 0x04
	int32_t DurationFrames; // Offset: 0x49c // Size: 0x04
	struct UGameActionSequence* ServerPlayedSequence; // Offset: 0x4a0 // Size: 0x08
	struct UGameActionSequence* Sequence; // Offset: 0x4a8 // Size: 0x08
	struct FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance; // Offset: 0x4b0 // Size: 0x300
	char pad_0x7B0[0x6c]; // Offset: 0x7b0 // Size: 0x6c
	enum class EMovieScenePlayerStatus Status; // Offset: 0x81c // Size: 0x01
	char pad_0x81D[0x3]; // Offset: 0x81d // Size: 0x03
	int32_t CurrentNumLoops; // Offset: 0x820 // Size: 0x04
	struct FMovieSceneSequenceReplProperties NetSyncProps; // Offset: 0x824 // Size: 0x10
	char pad_0x834[0x24]; // Offset: 0x834 // Size: 0x24
	struct UGameActionInstanceBase* GameAction; // Offset: 0x858 // Size: 0x08
	char pad_0x860[0x8]; // Offset: 0x860 // Size: 0x08
	struct TWeakObjectPtr<struct ACharacter> CameraUpdateActor; // Offset: 0x868 // Size: 0x08
	struct TWeakObjectPtr<struct APlayerController> CameraUpdateController; // Offset: 0x870 // Size: 0x08
	char pad_0x878[0x8]; // Offset: 0x878 // Size: 0x08
};

// Object Name: Class GameAction_Runtime.GameActionTimeTestingSection
// Size: 0xe0 // Inherited bytes: 0xd8
struct UGameActionTimeTestingSection : UMovieSceneSection {
	// Fields
	char bIsEnable : 1; // Offset: 0xd8 // Size: 0x01
	char pad_0xD8_1 : 7; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x7]; // Offset: 0xd9 // Size: 0x07
};

// Object Name: Class GameAction_Runtime.GameActionTimeTestingTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UGameActionTimeTestingTrack : UMovieSceneTrack {
	// Fields
	struct TArray<struct UGameActionTimeTestingSection*> EventSections; // Offset: 0x58 // Size: 0x10
};

