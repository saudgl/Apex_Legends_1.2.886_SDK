#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class HeadMountedDisplay.HeadMountedDisplayFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UHeadMountedDisplayFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.UpdateExternalTrackingHMDPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void UpdateExternalTrackingHMDPosition(struct FTransform& ExternalTrackingTransform); // Offset: 0x1048b3440 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetWorldToMetersScale
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetWorldToMetersScale(struct UObject* WorldContext, float NewScale); // Offset: 0x1048b37cc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetTrackingOrigin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetTrackingOrigin(enum class EHMDTrackingOrigin Origin); // Offset: 0x1048b36dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetSpectatorScreenTexture(struct UTexture* InTexture); // Offset: 0x1048b3244 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenModeTexturePlusEyeLayout
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void SetSpectatorScreenModeTexturePlusEyeLayout(struct FVector2D EyeRectMin, struct FVector2D EyeRectMax, struct FVector2D TextureRectMin, struct FVector2D TextureRectMax, bool bDrawEyeFirst, bool bClearBlack, bool bUseAlpha); // Offset: 0x1048b302c // Return & Params: Num(7) Size(0x23)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetSpectatorScreenMode(enum class ESpectatorScreenMode mode); // Offset: 0x1048b32b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetClippingPlanes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetClippingPlanes(float Near, float Far); // Offset: 0x1048b38ec // Return & Params: Num(2) Size(0x8)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.ResetOrientationAndPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ResetOrientationAndPosition(float Yaw, enum class EOrientPositionSelector Options); // Offset: 0x1048b39a0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsSpectatorScreenModeControllable
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsSpectatorScreenModeControllable(); // Offset: 0x1048b332c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsInLowPersistenceMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsInLowPersistenceMode(); // Offset: 0x1048b3ac4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsHeadMountedDisplayEnabled(); // Offset: 0x1048b4420 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayConnected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsHeadMountedDisplayConnected(); // Offset: 0x1048b43ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsDeviceTracking
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsDeviceTracking(struct FXRDeviceId& XRDeviceId); // Offset: 0x1048b2a5c // Return & Params: Num(2) Size(0xd)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.HasValidTrackingPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool HasValidTrackingPosition(); // Offset: 0x1048b41f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetWorldToMetersScale
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetWorldToMetersScale(struct UObject* WorldContext); // Offset: 0x1048b3750 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetVRFocusState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetVRFocusState(bool& bUseFocus, bool& bHasFocus); // Offset: 0x1048b3360 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingToWorldTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FTransform GetTrackingToWorldTransform(struct UObject* WorldContext); // Offset: 0x1048b35f0 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingSensorParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void GetTrackingSensorParameters(struct FVector& Origin, struct FRotator& Rotation, float& LeftFOV, float& RightFOV, float& TopFOV, float& BottomFOV, float& Distance, float& NearPlane, float& FarPlane, bool& IsActive, int32_t Index); // Offset: 0x1048b3d94 // Return & Params: Num(11) Size(0x3c)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingOrigin
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	enum class EHMDTrackingOrigin GetTrackingOrigin(); // Offset: 0x1048b36a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetScreenPercentage
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetScreenPercentage(); // Offset: 0x1048b38b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPositionalTrackingCameraParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void GetPositionalTrackingCameraParameters(struct FVector& CameraOrigin, struct FRotator& CameraRotation, float& HFOV, float& VFOV, float& CameraDistance, float& NearPlane, float& FarPlane); // Offset: 0x1048b3adc // Return & Params: Num(7) Size(0x2c)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPixelDensity
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetPixelDensity(); // Offset: 0x1048b3884 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetOrientationAndPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void GetOrientationAndPosition(struct FRotator& DeviceRotation, struct FVector& DevicePosition); // Offset: 0x1048b422c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetNumOfTrackingSensors
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t GetNumOfTrackingSensors(); // Offset: 0x1048b41c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDWornState
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	enum class EHMDWornState GetHMDWornState(); // Offset: 0x1048b4300 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FName GetHMDDeviceName(); // Offset: 0x1048b4334 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetDeviceWorldPose
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetDeviceWorldPose(struct UObject* WorldContext, struct FXRDeviceId& XRDeviceId, bool& bIsTracked, struct FRotator& Orientation, bool& bHasPositionalTracking, struct FVector& Position); // Offset: 0x1048b2aec // Return & Params: Num(6) Size(0x34)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetDevicePose
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetDevicePose(struct FXRDeviceId& XRDeviceId, bool& bIsTracked, struct FRotator& Orientation, bool& bHasPositionalTracking, struct FVector& Position); // Offset: 0x1048b2d30 // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnumerateTrackedDevices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FXRDeviceId> EnumerateTrackedDevices(struct FName SystemId, enum class EXRTrackedDeviceType DeviceType); // Offset: 0x1048b2f28 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableLowPersistenceMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EnableLowPersistenceMode(bool bEnable); // Offset: 0x1048b3a58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableHMD
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableHMD(bool bEnable); // Offset: 0x1048b4368 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.CalibrateExternalTrackingToHMD
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void CalibrateExternalTrackingToHMD(struct FTransform& ExternalTrackingTransform); // Offset: 0x1048b3518 // Return & Params: Num(1) Size(0x30)
};

// Object Name: Class HeadMountedDisplay.MotionControllerComponent
// Size: 0x610 // Inherited bytes: 0x560
struct UMotionControllerComponent : UPrimitiveComponent {
	// Fields
	int32_t PlayerIndex; // Offset: 0x55c // Size: 0x04
	enum class EControllerHand Hand; // Offset: 0x560 // Size: 0x01
	struct FName MotionSource; // Offset: 0x564 // Size: 0x08
	char bDisableLowLatencyUpdate : 1; // Offset: 0x56c // Size: 0x01
	enum class ETrackingStatus CurrentTrackingStatus; // Offset: 0x56d // Size: 0x01
	bool bDisplayDeviceModel; // Offset: 0x56e // Size: 0x01
	char pad_0x56F_1 : 7; // Offset: 0x56f // Size: 0x01
	struct FName DisplayModelSource; // Offset: 0x570 // Size: 0x08
	struct UStaticMesh* CustomDisplayMesh; // Offset: 0x578 // Size: 0x08
	struct TArray<struct UMaterialInterface*> DisplayMeshMaterialOverrides; // Offset: 0x580 // Size: 0x10
	char pad_0x590[0x60]; // Offset: 0x590 // Size: 0x60
	struct UPrimitiveComponent* DisplayComponent; // Offset: 0x5f0 // Size: 0x08
	char pad_0x5F8[0x18]; // Offset: 0x5f8 // Size: 0x18

	// Functions

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.SetTrackingSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTrackingSource(enum class EControllerHand NewSource); // Offset: 0x1048b59c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.SetTrackingMotionSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTrackingMotionSource(struct FName NewSource); // Offset: 0x1048b5910 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.SetShowDeviceModel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetShowDeviceModel(bool bShowControllerModel); // Offset: 0x1048b5b34 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.SetDisplayModelSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDisplayModelSource(struct FName NewDisplayModelSource); // Offset: 0x1048b5ab8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.SetCustomDisplayMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCustomDisplayMesh(struct UStaticMesh* NewDisplayMesh); // Offset: 0x1048b5a3c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.SetAssociatedPlayerIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAssociatedPlayerIndex(int32_t NewPlayer); // Offset: 0x1048b5894 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.OnMotionControllerUpdated
	// Flags: [Event|Protected|BlueprintEvent]
	void OnMotionControllerUpdated(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.IsTracked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTracked(); // Offset: 0x1048b5bb8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.GetTrackingSource
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EControllerHand GetTrackingSource(); // Offset: 0x1048b598c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.GetParameterValue
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	float GetParameterValue(struct FName InName, bool& bValueFound); // Offset: 0x1048b57b0 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.GetHandJointPosition
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	struct FVector GetHandJointPosition(int32_t jointIndex, bool& bValueFound); // Offset: 0x1048b56c4 // Return & Params: Num(3) Size(0x14)
};

// Object Name: Class HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UMotionTrackedDeviceFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.SetIsControllerMotionTrackingEnabledByDefault
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetIsControllerMotionTrackingEnabledByDefault(bool Enable); // Offset: 0x1048b6a7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsMotionTrackingEnabledForSource(int32_t PlayerIndex, struct FName SourceName); // Offset: 0x1048b6894 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsMotionTrackingEnabledForDevice(int32_t PlayerIndex, enum class EControllerHand Hand); // Offset: 0x1048b6954 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsMotionTrackingEnabledForComponent(struct UMotionControllerComponent* MotionControllerComponent); // Offset: 0x1048b6818 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackedDeviceCountManagementNecessary
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsMotionTrackedDeviceCountManagementNecessary(); // Offset: 0x1048b6af8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionSourceTracking
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsMotionSourceTracking(int32_t PlayerIndex, struct FName SourceName); // Offset: 0x1048b623c // Return & Params: Num(3) Size(0xd)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMotionTrackingEnabledControllerCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t GetMotionTrackingEnabledControllerCount(); // Offset: 0x1048b6a14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMaximumMotionTrackedControllerCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t GetMaximumMotionTrackedControllerCount(); // Offset: 0x1048b6a48 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetActiveTrackingSystemName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FName GetActiveTrackingSystemName(); // Offset: 0x1048b62fc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnumerateMotionSources
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FName> EnumerateMotionSources(); // Offset: 0x1048b6330 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableMotionTrackingOfSource(int32_t PlayerIndex, struct FName SourceName); // Offset: 0x1048b6698 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableMotionTrackingOfDevice(int32_t PlayerIndex, enum class EControllerHand Hand); // Offset: 0x1048b6758 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent); // Offset: 0x1048b661c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DisableMotionTrackingOfSource(int32_t PlayerIndex, struct FName SourceName); // Offset: 0x1048b64ac // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DisableMotionTrackingOfDevice(int32_t PlayerIndex, enum class EControllerHand Hand); // Offset: 0x1048b6564 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfControllersForPlayer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DisableMotionTrackingOfControllersForPlayer(int32_t PlayerIndex); // Offset: 0x1048b63b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfAllControllers
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DisableMotionTrackingOfAllControllers(); // Offset: 0x1048b6424 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DisableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent); // Offset: 0x1048b6438 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class HeadMountedDisplay.VRNotificationsComponent
// Size: 0x180 // Inherited bytes: 0xf0
struct UVRNotificationsComponent : UActorComponent {
	// Fields
	struct FMulticastInlineDelegate HMDTrackingInitializingAndNeedsHMDToBeTrackedDelegate; // Offset: 0xf0 // Size: 0x10
	struct FMulticastInlineDelegate HMDTrackingInitializedDelegate; // Offset: 0x100 // Size: 0x10
	struct FMulticastInlineDelegate HMDRecenteredDelegate; // Offset: 0x110 // Size: 0x10
	struct FMulticastInlineDelegate HMDLostDelegate; // Offset: 0x120 // Size: 0x10
	struct FMulticastInlineDelegate HMDReconnectedDelegate; // Offset: 0x130 // Size: 0x10
	struct FMulticastInlineDelegate HMDConnectCanceledDelegate; // Offset: 0x140 // Size: 0x10
	struct FMulticastInlineDelegate HMDPutOnHeadDelegate; // Offset: 0x150 // Size: 0x10
	struct FMulticastInlineDelegate HMDRemovedFromHeadDelegate; // Offset: 0x160 // Size: 0x10
	struct FMulticastInlineDelegate VRControllerRecenteredDelegate; // Offset: 0x170 // Size: 0x10
};

// Object Name: Class HeadMountedDisplay.XRAssetFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UXRAssetFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HeadMountedDisplay.XRAssetFunctionLibrary.AddNamedDeviceVisualizationComponentBlocking
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UPrimitiveComponent* AddNamedDeviceVisualizationComponentBlocking(struct AActor* Target, struct FName SystemName, struct FName DeviceName, bool bManualAttachment, struct FTransform& RelativeTransform, struct FXRDeviceId& XRDeviceId); // Offset: 0x1048b73dc // Return & Params: Num(7) Size(0x68)

	// Object Name: Function HeadMountedDisplay.XRAssetFunctionLibrary.AddDeviceVisualizationComponentBlocking
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UPrimitiveComponent* AddDeviceVisualizationComponentBlocking(struct AActor* Target, struct FXRDeviceId& XRDeviceId, bool bManualAttachment, struct FTransform& RelativeTransform); // Offset: 0x1048b7634 // Return & Params: Num(5) Size(0x58)
};

// Object Name: Class HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent
// Size: 0x60 // Inherited bytes: 0x30
struct UAsyncTask_LoadXRDeviceVisComponent : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnModelLoaded; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnLoadFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
	struct UPrimitiveComponent* SpawnedComponent; // Offset: 0x58 // Size: 0x08

	// Functions

	// Object Name: Function HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent.AddNamedDeviceVisualizationComponentAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UAsyncTask_LoadXRDeviceVisComponent* AddNamedDeviceVisualizationComponentAsync(struct AActor* Target, struct FName SystemName, struct FName DeviceName, bool bManualAttachment, struct FTransform& RelativeTransform, struct FXRDeviceId& XRDeviceId, struct UPrimitiveComponent*& NewComponent); // Offset: 0x1048b7cbc // Return & Params: Num(8) Size(0x70)

	// Object Name: Function HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent.AddDeviceVisualizationComponentAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UAsyncTask_LoadXRDeviceVisComponent* AddDeviceVisualizationComponentAsync(struct AActor* Target, struct FXRDeviceId& XRDeviceId, bool bManualAttachment, struct FTransform& RelativeTransform, struct UPrimitiveComponent*& NewComponent); // Offset: 0x1048b7a84 // Return & Params: Num(6) Size(0x60)
};

