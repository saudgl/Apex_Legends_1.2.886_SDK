#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum FSMAsset.ETransRule
enum class ETransRule : uint8 {
	None = 0,
	Inclusive = 1,
	Exclusive = 2,
	__MAX = 3,
	ETransRule_MAX = 4
};

