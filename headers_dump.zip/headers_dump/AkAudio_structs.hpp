#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AkAudio.AKWaapiJsonObject
// Size: 0x10 // Inherited bytes: 0x00
struct FAKWaapiJsonObject {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkWaapiSubscriptionId
// Size: 0x08 // Inherited bytes: 0x00
struct FAkWaapiSubscriptionId {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AkAudio.AkAdvancedInitializationSettings
// Size: 0x3c // Inherited bytes: 0x00
struct FAkAdvancedInitializationSettings {
	// Fields
	uint32_t IO_MemorySize; // Offset: 0x00 // Size: 0x04
	uint32_t IO_MemorySize_Low; // Offset: 0x04 // Size: 0x04
	float TargetAutoStreamBufferLength; // Offset: 0x08 // Size: 0x04
	bool UseStreamCache; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	uint32_t MaximumPinnedBytesInCache; // Offset: 0x10 // Size: 0x04
	int32_t PrepareEventMemoryPoolID; // Offset: 0x14 // Size: 0x04
	bool EnableGameSyncPreparation; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	uint32_t ContinuousPlaybackLookAhead; // Offset: 0x1c // Size: 0x04
	uint32_t MonitorPoolSize; // Offset: 0x20 // Size: 0x04
	uint32_t MonitorQueuePoolSize; // Offset: 0x24 // Size: 0x04
	uint32_t MaximumHardwareTimeoutMs; // Offset: 0x28 // Size: 0x04
	bool DebugOutOfRangeCheckEnabled; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
	float DebugOutOfRangeLimit; // Offset: 0x30 // Size: 0x04
	struct FAkAdvancedSpatialAudioSettings SpatialAudioSettings; // Offset: 0x34 // Size: 0x08
};

// Object Name: ScriptStruct AkAudio.AkAdvancedSpatialAudioSettings
// Size: 0x08 // Inherited bytes: 0x00
struct FAkAdvancedSpatialAudioSettings {
	// Fields
	float DiffractionShadowAttenuationFactor; // Offset: 0x00 // Size: 0x04
	float DiffractionShadowDegrees; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkAdvancedInitializationSettingsWithMultiCoreRendering
// Size: 0x40 // Inherited bytes: 0x3c
struct FAkAdvancedInitializationSettingsWithMultiCoreRendering : FAkAdvancedInitializationSettings {
	// Fields
	bool EnableMultiCoreRendering; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.AkAndroidAdvancedInitializationSettings
// Size: 0x48 // Inherited bytes: 0x40
struct FAkAndroidAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint32_t AudioAPI; // Offset: 0x40 // Size: 0x04
	bool RoundFrameSizeToHardwareSize; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.AkExternalSourceInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FAkExternalSourceInfo {
	// Fields
	struct FString ExternalSrcName; // Offset: 0x00 // Size: 0x10
	enum class AkCodecId CodecID; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString Filename; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkSegmentInfo
// Size: 0x24 // Inherited bytes: 0x00
struct FAkSegmentInfo {
	// Fields
	int32_t CurrentPosition; // Offset: 0x00 // Size: 0x04
	int32_t PreEntryDuration; // Offset: 0x04 // Size: 0x04
	int32_t ActiveDuration; // Offset: 0x08 // Size: 0x04
	int32_t PostExitDuration; // Offset: 0x0c // Size: 0x04
	int32_t RemainingLookAheadTime; // Offset: 0x10 // Size: 0x04
	float BeatDuration; // Offset: 0x14 // Size: 0x04
	float BarDuration; // Offset: 0x18 // Size: 0x04
	float GridDuration; // Offset: 0x1c // Size: 0x04
	float GridOffset; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkMidiEventBase
// Size: 0x02 // Inherited bytes: 0x00
struct FAkMidiEventBase {
	// Fields
	enum class EAkMidiEventType Type; // Offset: 0x00 // Size: 0x01
	char Chan; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiProgramChange
// Size: 0x03 // Inherited bytes: 0x02
struct FAkMidiProgramChange : FAkMidiEventBase {
	// Fields
	char ProgramNum; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiChannelAftertouch
// Size: 0x03 // Inherited bytes: 0x02
struct FAkMidiChannelAftertouch : FAkMidiEventBase {
	// Fields
	char Value; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiNoteAftertouch
// Size: 0x04 // Inherited bytes: 0x02
struct FAkMidiNoteAftertouch : FAkMidiEventBase {
	// Fields
	char Note; // Offset: 0x02 // Size: 0x01
	char Value; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiPitchBend
// Size: 0x08 // Inherited bytes: 0x02
struct FAkMidiPitchBend : FAkMidiEventBase {
	// Fields
	char ValueLsb; // Offset: 0x02 // Size: 0x01
	char ValueMsb; // Offset: 0x03 // Size: 0x01
	int32_t FullValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkMidiCc
// Size: 0x04 // Inherited bytes: 0x02
struct FAkMidiCc : FAkMidiEventBase {
	// Fields
	enum class EAkMidiCcValues Cc; // Offset: 0x02 // Size: 0x01
	char Value; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiNoteOnOff
// Size: 0x04 // Inherited bytes: 0x02
struct FAkMidiNoteOnOff : FAkMidiEventBase {
	// Fields
	char Note; // Offset: 0x02 // Size: 0x01
	char Velocity; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiGeneric
// Size: 0x04 // Inherited bytes: 0x02
struct FAkMidiGeneric : FAkMidiEventBase {
	// Fields
	char Param1; // Offset: 0x02 // Size: 0x01
	char Param2; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkChannelMask
// Size: 0x04 // Inherited bytes: 0x00
struct FAkChannelMask {
	// Fields
	int32_t ChannelMask; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkCommonInitializationSettings
// Size: 0x68 // Inherited bytes: 0x00
struct FAkCommonInitializationSettings {
	// Fields
	uint32_t MaximumNumberOfMemoryPools; // Offset: 0x00 // Size: 0x04
	uint32_t MaximumNumberOfPositioningPaths; // Offset: 0x04 // Size: 0x04
	uint32_t DefaultPoolSize; // Offset: 0x08 // Size: 0x04
	float MemoryCutoffThreshold; // Offset: 0x0c // Size: 0x04
	uint32_t CommandQueueSize; // Offset: 0x10 // Size: 0x04
	uint32_t SamplesPerFrame; // Offset: 0x14 // Size: 0x04
	struct FAkMainOutputSettings MainOutputSettings; // Offset: 0x18 // Size: 0x28
	float StreamingLookAheadRatio; // Offset: 0x40 // Size: 0x04
	uint32_t StreamManagerPoolSize; // Offset: 0x44 // Size: 0x04
	uint32_t LowerEnginePoolSize; // Offset: 0x48 // Size: 0x04
	float LowerEngineMemoryCutoffThreshold; // Offset: 0x4c // Size: 0x04
	uint16_t NumberOfRefillsInVoice; // Offset: 0x50 // Size: 0x02
	char pad_0x52[0x2]; // Offset: 0x52 // Size: 0x02
	struct FAkSpatialAudioSettings SpatialAudioSettings; // Offset: 0x54 // Size: 0x14
};

// Object Name: ScriptStruct AkAudio.AkSpatialAudioSettings
// Size: 0x14 // Inherited bytes: 0x00
struct FAkSpatialAudioSettings {
	// Fields
	uint32_t SpatialAudioPoolSize; // Offset: 0x00 // Size: 0x04
	uint32_t SpatialAudioPoolSize_Low; // Offset: 0x04 // Size: 0x04
	uint32_t MaxSoundPropagationDepth; // Offset: 0x08 // Size: 0x04
	uint32_t DiffractionFlags; // Offset: 0x0c // Size: 0x04
	float MovementThreshold; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkMainOutputSettings
// Size: 0x28 // Inherited bytes: 0x00
struct FAkMainOutputSettings {
	// Fields
	struct FString AudioDeviceShareset; // Offset: 0x00 // Size: 0x10
	uint32_t DeviceID; // Offset: 0x10 // Size: 0x04
	enum class EAkPanningRule PanningRule; // Offset: 0x14 // Size: 0x04
	enum class EAkChannelConfigType ChannelConfigType; // Offset: 0x18 // Size: 0x04
	uint32_t ChannelMask; // Offset: 0x1c // Size: 0x04
	uint32_t NumberOfChannels; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkCommonInitializationSettingsWithSampleRate
// Size: 0x70 // Inherited bytes: 0x68
struct FAkCommonInitializationSettingsWithSampleRate : FAkCommonInitializationSettings {
	// Fields
	uint32_t SampleRate; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkCommonInitializationSettingsWithSampleRateAndAudioLevel
// Size: 0x88 // Inherited bytes: 0x70
struct FAkCommonInitializationSettingsWithSampleRateAndAudioLevel : FAkCommonInitializationSettingsWithSampleRate {
	// Fields
	uint32_t DefaultPoolSize_High; // Offset: 0x6c // Size: 0x04
	uint32_t DefaultPoolSize_Mid; // Offset: 0x70 // Size: 0x04
	uint32_t DefaultPoolSize_Low; // Offset: 0x74 // Size: 0x04
	uint32_t LowerEnginePoolSize_High; // Offset: 0x78 // Size: 0x04
	uint32_t LowerEnginePoolSize_Mid; // Offset: 0x7c // Size: 0x04
	uint32_t LowerEnginePoolSize_Low; // Offset: 0x80 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkCommunicationSettings
// Size: 0x20 // Inherited bytes: 0x00
struct FAkCommunicationSettings {
	// Fields
	uint32_t PoolSize; // Offset: 0x00 // Size: 0x04
	uint16_t DiscoveryBroadcastPort; // Offset: 0x04 // Size: 0x02
	uint16_t CommandPort; // Offset: 0x06 // Size: 0x02
	uint16_t NotificationPort; // Offset: 0x08 // Size: 0x02
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	struct FString NetworkName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkCommunicationSettingsWithSystemInitialization
// Size: 0x28 // Inherited bytes: 0x20
struct FAkCommunicationSettingsWithSystemInitialization : FAkCommunicationSettings {
	// Fields
	bool InitializeSystemComms; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct AkAudio.AkAudioLevelFolderPaths
// Size: 0x70 // Inherited bytes: 0x00
struct FAkAudioLevelFolderPaths {
	// Fields
	struct FString HighLevelFolder; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> HighLevelHotPatchFolder; // Offset: 0x10 // Size: 0x10
	struct FString MidLevelFolder; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FString> MidLevelHotPatchFolder; // Offset: 0x30 // Size: 0x10
	struct FString LowLevelFolder; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> LowLevelHotPatchFolder; // Offset: 0x50 // Size: 0x10
	struct FString MiscFolder; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkAudioSession
// Size: 0x0c // Inherited bytes: 0x00
struct FAkAudioSession {
	// Fields
	enum class EAkAudioSessionCategory AudioSessionCategory; // Offset: 0x00 // Size: 0x04
	uint32_t AudioSessionCategoryOptions; // Offset: 0x04 // Size: 0x04
	enum class EAkAudioSessionMode AudioSessionMode; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkBoolPropertyToControl
// Size: 0x10 // Inherited bytes: 0x00
struct FAkBoolPropertyToControl {
	// Fields
	struct FString ItemProperty; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkPropertyToControl
// Size: 0x10 // Inherited bytes: 0x00
struct FAkPropertyToControl {
	// Fields
	struct FString ItemProperty; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkPS4AdvancedInitializationSettings
// Size: 0x48 // Inherited bytes: 0x40
struct FAkPS4AdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint32_t ACPBatchBufferSize; // Offset: 0x40 // Size: 0x04
	bool UseHardwareCodecLowLatencyMode; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.VoTemplateData
// Size: 0x18 // Inherited bytes: 0x00
struct FVoTemplateData {
	// Fields
	struct FString TemplateEventSuffix; // Offset: 0x00 // Size: 0x10
	int32_t ExternalSourcesNum; // Offset: 0x10 // Size: 0x04
	bool bContainRadio; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.VoFolderData
// Size: 0x18 // Inherited bytes: 0x00
struct FVoFolderData {
	// Fields
	struct FString FolderName; // Offset: 0x00 // Size: 0x10
	bool bEnableCharacterFolder; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct AkAudio.AkWwiseItemToControl
// Size: 0x40 // Inherited bytes: 0x00
struct FAkWwiseItemToControl {
	// Fields
	struct FAkWwiseObjectDetails ItemPicked; // Offset: 0x00 // Size: 0x30
	struct FString ItemPath; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkWwiseObjectDetails
// Size: 0x30 // Inherited bytes: 0x00
struct FAkWwiseObjectDetails {
	// Fields
	struct FString ItemName; // Offset: 0x00 // Size: 0x10
	struct FString ItemPath; // Offset: 0x10 // Size: 0x10
	struct FString ItemID; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkPoly
// Size: 0x10 // Inherited bytes: 0x00
struct FAkPoly {
	// Fields
	struct UAkAcousticTexture* Texture; // Offset: 0x00 // Size: 0x08
	bool EnableSurface; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
};

// Object Name: ScriptStruct AkAudio.AkWaapiFieldNames
// Size: 0x10 // Inherited bytes: 0x00
struct FAkWaapiFieldNames {
	// Fields
	struct FString FieldName; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkWaapiUri
// Size: 0x10 // Inherited bytes: 0x00
struct FAkWaapiUri {
	// Fields
	struct FString Uri; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkWindowsAdvancedInitializationSettings
// Size: 0x48 // Inherited bytes: 0x40
struct FAkWindowsAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint32_t AudioAPI; // Offset: 0x40 // Size: 0x04
	bool GlobalFocus; // Offset: 0x44 // Size: 0x01
	bool UseHeadMountedDisplayAudioDevice; // Offset: 0x45 // Size: 0x01
	char pad_0x46[0x2]; // Offset: 0x46 // Size: 0x02
};

// Object Name: ScriptStruct AkAudio.AkXboxOneApuHeapInitializationSettings
// Size: 0x08 // Inherited bytes: 0x00
struct FAkXboxOneApuHeapInitializationSettings {
	// Fields
	uint32_t CachedSize; // Offset: 0x00 // Size: 0x04
	uint32_t NonCachedSize; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkXboxOneAdvancedInitializationSettings
// Size: 0x48 // Inherited bytes: 0x40
struct FAkXboxOneAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint32_t ShapeDefaultPoolSize; // Offset: 0x40 // Size: 0x04
	uint16_t MaximumNumberOfXMAVoices; // Offset: 0x44 // Size: 0x02
	bool UseHardwareCodecLowLatencyMode; // Offset: 0x46 // Size: 0x01
	char pad_0x47[0x1]; // Offset: 0x47 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkAudioEventTrackKey
// Size: 0x20 // Inherited bytes: 0x00
struct FAkAudioEventTrackKey {
	// Fields
	float Time; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x08 // Size: 0x08
	struct FString EventName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.MovieSceneAkAudioEventTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FMovieSceneAkAudioEventTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneAkAudioEventSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AkAudio.MovieSceneAkAudioRTPCTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FMovieSceneAkAudioRTPCTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneAkAudioRTPCSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AkAudio.MovieSceneFloatChannelSerializationHelper
// Size: 0x30 // Inherited bytes: 0x00
struct FMovieSceneFloatChannelSerializationHelper {
	// Fields
	enum class ERichCurveExtrapolation PreInfinityExtrap; // Offset: 0x00 // Size: 0x01
	enum class ERichCurveExtrapolation PostInfinityExtrap; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct TArray<int32_t> Times; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FMovieSceneFloatValueSerializationHelper> Values; // Offset: 0x18 // Size: 0x10
	float DefaultValue; // Offset: 0x28 // Size: 0x04
	bool bHasDefaultValue; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.MovieSceneFloatValueSerializationHelper
// Size: 0x1c // Inherited bytes: 0x00
struct FMovieSceneFloatValueSerializationHelper {
	// Fields
	float Value; // Offset: 0x00 // Size: 0x04
	enum class ERichCurveInterpMode InterpMode; // Offset: 0x04 // Size: 0x01
	enum class ERichCurveTangentMode TangentMode; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FMovieSceneTangentDataSerializationHelper Tangent; // Offset: 0x08 // Size: 0x14
};

// Object Name: ScriptStruct AkAudio.MovieSceneTangentDataSerializationHelper
// Size: 0x14 // Inherited bytes: 0x00
struct FMovieSceneTangentDataSerializationHelper {
	// Fields
	float ArriveTangent; // Offset: 0x00 // Size: 0x04
	float LeaveTangent; // Offset: 0x04 // Size: 0x04
	enum class ERichCurveTangentWeightMode TangentWeightMode; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float ArriveTangentWeight; // Offset: 0x0c // Size: 0x04
	float LeaveTangentWeight; // Offset: 0x10 // Size: 0x04
};

