#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_LaunchLocalizationTable_Type.BP_STRUCT_LaunchLocalizationTable_Type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_LaunchLocalizationTable_Type {
	// Fields
	struct FName Key_2_B9B645FF4CF9CCD5449B73859FDE5793; // Offset: 0x00 // Size: 0x08
	struct FText Value_3_62B3C7C032CE309920D927FE09A9C235; // Offset: 0x08 // Size: 0x18
};

