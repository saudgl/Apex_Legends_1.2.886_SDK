#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SignificanceManager.SignificanceManager
// Size: 0x140 // Inherited bytes: 0x28
struct USignificanceManager : UObject {
	// Fields
	char pad_0x28[0x100]; // Offset: 0x28 // Size: 0x100
	struct FSoftClassPath SignificanceManagerClassName; // Offset: 0x128 // Size: 0x18
};

