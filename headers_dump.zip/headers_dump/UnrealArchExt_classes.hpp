#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UnrealArchExt.UAEUserWidget
// Size: 0x388 // Inherited bytes: 0x240
struct UUAEUserWidget : UUserWidget {
	// Fields
	struct UFrontendHUD* OwningFrontendHUD; // Offset: 0x240 // Size: 0x08
	struct ULogicManagerBase* OwningLogicManager; // Offset: 0x248 // Size: 0x08
	struct UUAEWidgetContainer* OwningWidgetContainer; // Offset: 0x250 // Size: 0x08
	struct UUAEUserWidget* ParentWidget; // Offset: 0x258 // Size: 0x08
	char pad_0x260[0x50]; // Offset: 0x260 // Size: 0x50
	struct TArray<struct TFieldPath<FProperty>> Params; // Offset: 0x2b0 // Size: 0x10
	char pad_0x2C0[0x10]; // Offset: 0x2c0 // Size: 0x10
	struct FMulticastInlineDelegate widgetSizeNofity; // Offset: 0x2d0 // Size: 0x10
	struct FUserWidgetState DefaultUserWidgetState; // Offset: 0x2e0 // Size: 0x28
	struct FUserWidgetState CurrentUserWidgetState; // Offset: 0x308 // Size: 0x28
	float TickRate; // Offset: 0x330 // Size: 0x04
	bool bReceiveOnClickedEvent; // Offset: 0x334 // Size: 0x01
	bool bReceiveOnRightClickedEvent; // Offset: 0x335 // Size: 0x01
	bool bReceiveOnDoubleClickedEvent; // Offset: 0x336 // Size: 0x01
	bool bAutoSetScreenPosOnMouseEnter; // Offset: 0x337 // Size: 0x01
	struct FVector2D ScreenPos; // Offset: 0x338 // Size: 0x08
	struct FVector2D LastMouseEventScreenPos; // Offset: 0x340 // Size: 0x08
	struct FDelegate OnMouseButtonDownHandler; // Offset: 0x348 // Size: 0x10
	struct FDelegate OnMouseButtonUpHandler; // Offset: 0x358 // Size: 0x10
	char pad_0x368[0x9]; // Offset: 0x368 // Size: 0x09
	enum class EUserWidgetFadingStatus FadingStatus; // Offset: 0x371 // Size: 0x01
	char pad_0x372[0x2]; // Offset: 0x372 // Size: 0x02
	float CurrentOpacity; // Offset: 0x374 // Size: 0x04
	float FadingInTime; // Offset: 0x378 // Size: 0x04
	float FadingOutTime; // Offset: 0x37c // Size: 0x04
	bool bNoFadeIn; // Offset: 0x380 // Size: 0x01
	bool bNoFadeOut; // Offset: 0x381 // Size: 0x01
	bool bShouldCollapse; // Offset: 0x382 // Size: 0x01
	char pad_0x383[0x5]; // Offset: 0x383 // Size: 0x05

	// Functions

	// Object Name: Function UnrealArchExt.UAEUserWidget.Visible
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Visible(); // Offset: 0x103eb1530 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.UAEUserWidget.UnRegistFromGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistFromGameFrontendHUD(); // Offset: 0x103eb1300 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SynchronizeBlueprintProperties
	// Flags: [Event|Public|BlueprintEvent]
	void SynchronizeBlueprintProperties(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.Show
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Show(); // Offset: 0x103eb1578 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SetParentWidgetRecursive
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetParentWidgetRecursive(struct UUAEUserWidget* InParentWidget); // Offset: 0x103eb1738 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SetParentWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetParentWidget(struct UUAEUserWidget* InParentWidget); // Offset: 0x103eb17b4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SetAdapation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAdapation(float Left, float Top, float Right, float Bottom); // Offset: 0x103eb13b4 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.RegistToGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistToGameFrontendHUD(); // Offset: 0x103eb1314 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.Register
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Register(struct ULogicManagerBase* LogicManager, bool bAddToViewport); // Offset: 0x103eb1830 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ReceiveShow
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveShow(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ReceiveHide
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveHide(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ReceivedInitWidget
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivedInitWidget(); // Offset: 0x1043c773c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnRightClicked
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	void OnRightClicked(struct FVector2D TempScreenPos); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnFadeOutFinished
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void OnFadeOutFinished(); // Offset: 0x103eb14f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnFadeInFinished
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void OnFadeInFinished(); // Offset: 0x103eb1514 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnDoubleClicked
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	void OnDoubleClicked(struct FVector2D TempScreenPos); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnClicked
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	void OnClicked(struct FVector2D TempScreenPos); // Offset: 0x1043c773c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.Hide
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Hide(); // Offset: 0x103eb1564 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.HandleUIMessageBattle
	// Flags: [Final|Native|Public]
	void HandleUIMessageBattle(struct FString UIMessage); // Offset: 0x103eb158c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.HandleUIMessage
	// Flags: [Final|Native|Public]
	void HandleUIMessage(struct FString UIMessage); // Offset: 0x103eb1614 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetParentWidget
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEUserWidget* GetParentWidget(); // Offset: 0x103eb169c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetOwningLogicManager
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULogicManagerBase* GetOwningLogicManager(); // Offset: 0x103eb16d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetOwningFrontendHUD
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure]
	struct UFrontendHUD* GetOwningFrontendHUD(); // Offset: 0x103eb1704 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetImgDynamicMaterial
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetImgDynamicMaterial(struct UImage* ImageMat); // Offset: 0x103eb1328 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UnrealArchExt.TableTraver
// Size: 0x28 // Inherited bytes: 0x28
struct UTableTraver : UObject {
};

// Object Name: Class UnrealArchExt.AssetsPreloaderBase
// Size: 0x30 // Inherited bytes: 0x28
struct UAssetsPreloaderBase : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class UnrealArchExt.BackendUtils
// Size: 0x30 // Inherited bytes: 0x28
struct UBackendUtils : UObject {
	// Fields
	struct UBackendHUD* OwningBackendHUD; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class UnrealArchExt.BackendHUD
// Size: 0x60 // Inherited bytes: 0x28
struct UBackendHUD : UObject {
	// Fields
	struct UEngine* Engine; // Offset: 0x28 // Size: 0x08
	struct FString BackendUtilsClassName; // Offset: 0x30 // Size: 0x10
	struct UBackendUtils* Utils; // Offset: 0x40 // Size: 0x08
	struct TArray<struct UFrontendHUD*> FrontendHUDList; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x8]; // Offset: 0x58 // Size: 0x08

	// Functions

	// Object Name: Function UnrealArchExt.BackendHUD.GetFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetFrontendHUD(int32_t FrontendHUDIndex); // Offset: 0x103eaab58 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.BackendHUD.GetFirstClientFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetFirstClientFrontendHUD(); // Offset: 0x103eaab24 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UnrealArchExt.FrontendHUD
// Size: 0xf0 // Inherited bytes: 0x28
struct UFrontendHUD : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 // Size: 0x18
	struct UGameInstance* GameInstance; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
	struct FString FrontendUtilsClassName; // Offset: 0x50 // Size: 0x10
	struct UFrontendUtils* Utils; // Offset: 0x60 // Size: 0x08
	struct FString LatestGameStatusURL; // Offset: 0x68 // Size: 0x10
	struct TMap<struct FName, struct UFrontendState*> StateClassMap; // Offset: 0x78 // Size: 0x50
	struct UFrontendState* CurrentState; // Offset: 0xc8 // Size: 0x08
	struct FName LastGameStatus; // Offset: 0xd0 // Size: 0x08
	struct FString LastStatusOptions; // Offset: 0xd8 // Size: 0x10
	struct UAssetsPreloaderBase* AssetsPreloader; // Offset: 0xe8 // Size: 0x08

	// Functions

	// Object Name: Function UnrealArchExt.FrontendHUD.SwitchGameStatus
	// Flags: [Native|Public|BlueprintCallable]
	void SwitchGameStatus(struct FName GameStatus, struct FString Options); // Offset: 0x103eab6a0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UnrealArchExt.FrontendHUD.ShutdownUnrealNetwork
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShutdownUnrealNetwork(); // Offset: 0x103eab654 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendHUD.ReturnToLastStatus
	// Flags: [Native|Public|BlueprintCallable]
	void ReturnToLastStatus(); // Offset: 0x103eab668 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendHUD.ResetGameStauts
	// Flags: [Native|Public|BlueprintCallable]
	void ResetGameStauts(); // Offset: 0x103eab684 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorld* GetWorld(); // Offset: 0x103eab864 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetUtils
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendUtils* GetUtils(); // Offset: 0x103eab7c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetPlayerController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APlayerController* GetPlayerController(); // Offset: 0x103eab7fc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetLastGameStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FName GetLastGameStatus(); // Offset: 0x103eab5e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetGameViewportClient
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameViewportClient* GetGameViewportClient(); // Offset: 0x103eab830 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetGameStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FName GetGameStatus(); // Offset: 0x103eab61c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UFrontendState* GetCurrentState(); // Offset: 0x103eab5c8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UnrealArchExt.FrontendUtils
// Size: 0x1a8 // Inherited bytes: 0x28
struct UFrontendUtils : UObject {
	// Fields
	struct UFrontendHUD* OwningFrontendHUD; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x18]; // Offset: 0x30 // Size: 0x18
	struct FName CurrentSceneCameraName; // Offset: 0x48 // Size: 0x08
	struct TArray<struct ACameraActor*> SceneCameraList; // Offset: 0x50 // Size: 0x10
	struct TMap<struct FName, struct TWeakObjectPtr<struct ACameraActor>> SceneCameraMap; // Offset: 0x60 // Size: 0x50
	char pad_0xB0[0x58]; // Offset: 0xb0 // Size: 0x58
	struct TMap<struct FString, struct ULevelStreamingDynamic*> DynamicLevelMap; // Offset: 0x108 // Size: 0x50
	char pad_0x158[0x50]; // Offset: 0x158 // Size: 0x50

	// Functions

	// Object Name: Function UnrealArchExt.FrontendUtils.UnRegisterSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegisterSceneCamera(struct FName SceneCameraName, struct ACameraActor* SceneCamera); // Offset: 0x103eabff8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.SwitchSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchSceneCamera(struct FName SceneCameraName, float BlendTime, bool bForce); // Offset: 0x103eac170 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function UnrealArchExt.FrontendUtils.RegisterSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterSceneCamera(struct FName SceneCameraName, struct ACameraActor* SceneCamera); // Offset: 0x103eac0b4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.OnUnLoadedDynamicLevel
	// Flags: [Final|Native|Protected]
	void OnUnLoadedDynamicLevel(); // Offset: 0x103eabf0c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendUtils.OnLoadedDynamicLevel
	// Flags: [Final|Native|Protected]
	void OnLoadedDynamicLevel(); // Offset: 0x103eabf34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendUtils.OnHandleSteamingLevelComplete
	// Flags: [Final|Native|Protected]
	void OnHandleSteamingLevelComplete(int32_t LinkID); // Offset: 0x103eabf48 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnrealArchExt.FrontendUtils.OnDynamicLevelVisible
	// Flags: [Final|Native|Protected]
	void OnDynamicLevelVisible(); // Offset: 0x103eabf20 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendUtils.GetOwningFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetOwningFrontendHUD(); // Offset: 0x103eac27c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendUtils.GetCurrentSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ACameraActor* GetCurrentSceneCamera(); // Offset: 0x103eabfc4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UnrealArchExt.FrontendState
// Size: 0xf0 // Inherited bytes: 0x28
struct UFrontendState : UObject {
	// Fields
	struct FName StateName; // Offset: 0x28 // Size: 0x08
	struct FString Options; // Offset: 0x30 // Size: 0x10
	struct FString MapPath; // Offset: 0x40 // Size: 0x10
	struct FString StateURL; // Offset: 0x50 // Size: 0x10
	struct UWorld* MapWorld; // Offset: 0x60 // Size: 0x08
	struct UFrontendHUD* OwningFrontendHUD; // Offset: 0x68 // Size: 0x08
	enum class EFrontendMapStatus RunningStatus; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x7]; // Offset: 0x71 // Size: 0x07
	struct TMap<enum class EFrontendMapStatus, int32_t> StateTimeoutConfig; // Offset: 0x78 // Size: 0x50
	char pad_0xC8[0x28]; // Offset: 0xc8 // Size: 0x28

	// Functions

	// Object Name: Function UnrealArchExt.FrontendState.OnStatusChanged
	// Flags: [Native|Protected]
	void OnStatusChanged(); // Offset: 0x103eacdc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendState.GetStateWorld
	// Flags: [Final|Native|Public]
	struct UWorld* GetStateWorld(); // Offset: 0x103eacf88 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendState.GetStateURL
	// Flags: [Final|Native|Public]
	struct FString GetStateURL(); // Offset: 0x103eace80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendState.GetStateStatus
	// Flags: [Final|Native|Public]
	enum class EFrontendMapStatus GetStateStatus(); // Offset: 0x103eacfa4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.FrontendState.GetStateOptions
	// Flags: [Final|Native|Public]
	struct FString GetStateOptions(); // Offset: 0x103eacde0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendState.GetStateName
	// Flags: [Final|Native|Public]
	struct FName GetStateName(); // Offset: 0x103eace64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendState.GetMapPath
	// Flags: [Final|Native|Public]
	struct FString GetMapPath(); // Offset: 0x103eacf04 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UnrealArchExt.LogicManagerBase
// Size: 0x128 // Inherited bytes: 0x28
struct ULogicManagerBase : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	struct UFrontendHUD* OwningFrontendHUD; // Offset: 0x38 // Size: 0x08
	bool bPersistentUI; // Offset: 0x40 // Size: 0x01
	bool bDynamicWidget; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x1]; // Offset: 0x42 // Size: 0x01
	bool bKeepDynamicWidget; // Offset: 0x43 // Size: 0x01
	int32_t iUIControlState; // Offset: 0x44 // Size: 0x04
	int32_t DefaultSceneCameraIndex; // Offset: 0x48 // Size: 0x04
	float DefaultCameraBlendTime; // Offset: 0x4c // Size: 0x04
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FName> GameStatusList; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FString> PushedWidgets; // Offset: 0x70 // Size: 0x10
	struct TArray<struct FString> DefaultChildList; // Offset: 0x80 // Size: 0x10
	struct TArray<struct UObject*> WidgetUClassList; // Offset: 0x90 // Size: 0x10
	struct TArray<struct UUAEUserWidget*> WidgetList; // Offset: 0xa0 // Size: 0x10
	struct TMap<struct FString, struct UUAEUserWidget*> WidgetMap; // Offset: 0xb0 // Size: 0x50
	char pad_0x100[0x8]; // Offset: 0x100 // Size: 0x08
	struct TArray<struct FString> DelayMessage; // Offset: 0x108 // Size: 0x10
	struct TArray<struct UObject*> DelayMessage_Obj; // Offset: 0x118 // Size: 0x10

	// Functions

	// Object Name: Function UnrealArchExt.LogicManagerBase.SetEnableRemoveDynamicWidgets
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableRemoveDynamicWidgets(bool bEnable); // Offset: 0x103ead858 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.LogicManagerBase.IsEnableRemoveDynamicWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsEnableRemoveDynamicWidgets(); // Offset: 0x103ead8dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.LogicManagerBase.GetOwningFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetOwningFrontendHUD(); // Offset: 0x103eadab8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.LogicManagerBase.GetDefaultSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetDefaultSceneCamera(); // Offset: 0x103eada84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnrealArchExt.LogicManagerBase.DispatchUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DispatchUIMessage(struct FString UIMessage, struct UObject* Source, struct UUAEUserWidget* Target); // Offset: 0x103ead910 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class UnrealArchExt.UAEDataTable
// Size: 0x118 // Inherited bytes: 0xb0
struct UUAEDataTable : UDataTable {
	// Fields
	char pad_0xB0[0x10]; // Offset: 0xb0 // Size: 0x10
	struct TMap<struct FName, struct TFieldPath<FProperty>> nameToProperty; // Offset: 0xc0 // Size: 0x50
	char pad_0x110[0x8]; // Offset: 0x110 // Size: 0x08

	// Functions

	// Object Name: Function UnrealArchExt.UAEDataTable.BP_ToDerivedRowDataQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool BP_ToDerivedRowDataQuery(struct FAETableDerivedRowDataQueryBP& IoDerivedQuery, struct FAETableRowDataQueryBP& InQuery, struct FName InParentRowColumnName); // Offset: 0x103eaf1f4 // Return & Params: Num(4) Size(0xc9)

	// Object Name: Function UnrealArchExt.UAEDataTable.BP_MakeRowDataQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool BP_MakeRowDataQuery(struct FAETableRowDataQueryBP& OutQuery, struct UUAEDataTable* InTable, struct FName InRowName); // Offset: 0x103eaf418 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function UnrealArchExt.UAEDataTable.BP_MakeDerivedRowDataQueryWithColumnName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool BP_MakeDerivedRowDataQueryWithColumnName(struct FAETableDerivedRowDataQueryBP& IoDerivedQuery, struct UUAEDataTable* InTable, struct FName InRowName, struct FName InParentRowColumnName); // Offset: 0x103eaefac // Return & Params: Num(5) Size(0xc9)

	// Object Name: Function UnrealArchExt.UAEDataTable.BP_GetCellValueFromQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool BP_GetCellValueFromQuery(struct FTableRowBase& OutValue, struct FAETableRowDataQueryBP& InQuery, struct FName InColumnName); // Offset: 0x103eafcb0 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function UnrealArchExt.UAEDataTable.BP_GetCellValueFromDerivedQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool BP_GetCellValueFromDerivedQuery(struct FTableRowBase& OutValue, struct FAETableDerivedRowDataQueryBP& InQuery, struct FName InColumnName); // Offset: 0x103eaf9f0 // Return & Params: Num(4) Size(0xc9)

	// Object Name: Function UnrealArchExt.UAEDataTable.BP_GetCellArrayValueFromQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool BP_GetCellArrayValueFromQuery(struct TArray<int32_t>& OutArray, struct FAETableRowDataQueryBP& InQuery, struct FName InColumnName); // Offset: 0x103eaf860 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function UnrealArchExt.UAEDataTable.BP_GetCellArrayValueFromDerivedQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool BP_GetCellArrayValueFromDerivedQuery(struct TArray<int32_t>& OutArray, struct FAETableDerivedRowDataQueryBP& InQuery, struct FName InColumnName); // Offset: 0x103eaf5f0 // Return & Params: Num(4) Size(0xc9)
};

// Object Name: Class UnrealArchExt.UAECompositeDataTable
// Size: 0x148 // Inherited bytes: 0x118
struct UUAECompositeDataTable : UUAEDataTable {
	// Fields
	struct TArray<struct UDataTable*> ParentTables; // Offset: 0x118 // Size: 0x10
	struct UDataTable* UpdateTable; // Offset: 0x128 // Size: 0x08
	char bContainsData : 1; // Offset: 0x130 // Size: 0x01
	char pad_0x130_1 : 7; // Offset: 0x130 // Size: 0x01
	char pad_0x131[0x7]; // Offset: 0x131 // Size: 0x07
	struct TArray<struct UDataTable*> OldParentTables; // Offset: 0x138 // Size: 0x10

	// Functions

	// Object Name: Function UnrealArchExt.UAECompositeDataTable.InitData
	// Flags: [Final|Native|Public]
	void InitData(bool bInit, bool bForceUpdate); // Offset: 0x103eae3e8 // Return & Params: Num(2) Size(0x2)
};

// Object Name: Class UnrealArchExt.UAEWidgetContainer
// Size: 0x3a8 // Inherited bytes: 0x388
struct UUAEWidgetContainer : UUAEUserWidget {
	// Fields
	struct TArray<struct UUAEUserWidget*> WidgetList; // Offset: 0x388 // Size: 0x10
	struct TArray<struct UUAEUserWidget*> WidgetBufferList; // Offset: 0x398 // Size: 0x10

	// Functions

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.RemoveWidgetInternal
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void RemoveWidgetInternal(struct UUAEUserWidget* Widget); // Offset: 0x103eb2bd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.RemoveWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveWidget(struct UUAEUserWidget* Widget); // Offset: 0x103eb2cdc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.AddWidgetInternal
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void AddWidgetInternal(struct UUAEUserWidget* Widget); // Offset: 0x103eb2c58 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.AddWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddWidget(struct UUAEUserWidget* Widget); // Offset: 0x103eb2d58 // Return & Params: Num(1) Size(0x8)
};

