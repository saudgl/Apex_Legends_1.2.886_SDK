#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum HTN.EHTNPlanExecutionFinishedResult
enum class EHTNPlanExecutionFinishedResult : uint8 {
	Succeeded = 0,
	FailedOrAborted = 1,
	EHTNPlanExecutionFinishedResult_MAX = 2
};

// Object Name: Enum HTN.EHTNFindExtensionResult
enum class EHTNFindExtensionResult : uint8 {
	Found = 0,
	NotFound = 1,
	EHTNFindExtensionResult_MAX = 2
};

// Object Name: Enum HTN.EHTNDecoratorTestResult
enum class EHTNDecoratorTestResult : uint8 {
	Failed = 0,
	Passed = 1,
	NotTested = 2,
	EHTNDecoratorTestResult_MAX = 3
};

// Object Name: Enum HTN.EHTNDecoratorConditionCheckType
enum class EHTNDecoratorConditionCheckType : uint8 {
	PlanEnter = 0,
	PlanExit = 1,
	PlanRecheck = 2,
	Execution = 3,
	EHTNDecoratorConditionCheckType_MAX = 4
};

// Object Name: Enum HTN.EHTNTaskFunction
enum class EHTNTaskFunction : uint8 {
	None = 0,
	CreatePlanSteps = 1,
	RecheckPlan = 2,
	Execute = 3,
	Abort = 4,
	EHTNTaskFunction_MAX = 5
};

// Object Name: Enum HTN.EHTNResetCooldownAffectedCooldowns
enum class EHTNResetCooldownAffectedCooldowns : uint8 {
	CooldownsWithGameplayTag = 0,
	CooldownsWithoutGameplayTag = 1,
	AllCooldowns = 2,
	EHTNResetCooldownAffectedCooldowns_MAX = 3
};

// Object Name: Enum HTN.EHTNResetDoOnceAffectedDecorators
enum class EHTNResetDoOnceAffectedDecorators : uint8 {
	DoOnceDecoratorsWithGameplayTag = 0,
	DoOnceDecoratorsWithoutGameplayTag = 1,
	AllDoOnceDecorators = 2,
	EHTNResetDoOnceAffectedDecorators_MAX = 3
};

// Object Name: Enum HTN.EHTNTaskStatus
enum class EHTNTaskStatus : uint8 {
	Active = 0,
	Aborting = 1,
	Inactive = 2,
	EHTNTaskStatus_MAX = 3
};

// Object Name: Enum HTN.EHTNNodeResult
enum class EHTNNodeResult : uint8 {
	Succeeded = 0,
	Failed = 1,
	Aborted = 2,
	InProgress = 3,
	EHTNNodeResult_MAX = 4
};

