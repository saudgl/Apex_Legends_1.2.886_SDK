#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GameRobot.MyAutoTest
// Size: 0x1c0 // Inherited bytes: 0x28
struct UMyAutoTest : UObject {
	// Fields
	char pad_0x28[0x198]; // Offset: 0x28 // Size: 0x198
};

